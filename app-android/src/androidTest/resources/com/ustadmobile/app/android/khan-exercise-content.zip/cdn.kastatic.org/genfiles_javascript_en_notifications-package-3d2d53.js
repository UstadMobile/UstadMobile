KAdefine("javascript/notifications-package/notifications.js", function(require, module, exports) {
var $=require("jquery")
var Backbone=require("backbone")
var _=require("underscore")
var KA=require("../shared-package/ka.js")
var _require=require("./util.js"),dispatchEvent=_require.dispatchEvent
var Notifications=_.extend({_urgentViews:[],renderUrgent:function e(r,i){var a=r.map(function(e){return new Backbone.Model(e)})
for(var t=this._urgentViews,n=Array.isArray(t),s=0,t=n?t:t[Symbol.iterator]();;){var o
if(n){if(s>=t.length)break
o=t[s++]}else{s=t.next()
if(s.done)break
o=s.value}var l=o
l.remove()}$(".urgent-wrapper.above-header").remove()
var u=$("#outer-wrapper")
var c="urgent-wrapper above-header "+"profile-header-scroll"+(KA.isBibliotronPage?" bibliotron-notification":"")
a.forEach(function(){return u.before("<div class='"+c+"'></div>")})
var f=$(".urgent-wrapper.above-header")
var v=require("./urgent-notification-view.js")
this._urgentViews=a.map(function(e,r){var a=Notifications.getViewClass(e.get("class_"),v)
var t=new a({model:e,el:$(f.get(r)),continueUrl:i})
t.render()
return t})
this.trigger("show-urgent")
dispatchEvent("initNav",window)},signalUrgentHidden:function e(r){this._urgentViews=this._urgentViews.filter(function(e){return e!==r})
if(!this._urgentViews.length){this.trigger("hide-urgent")
dispatchEvent("initNav",window)}},_classNameToViewClass:{},registerViewClasses:function e(r){_.extend(Notifications._classNameToViewClass,r)},getViewClass:function e(r,i){require("./config.js")()
var a=this
var t=_.find(r.slice().reverse(),function(e){return!!a._classNameToViewClass[e]})
if(t){return a._classNameToViewClass[t]}else{return i}},_classNameToTemplateInfo:{},registerTemplateInfo:function e(r){_.each(r,function(e,r){this._classNameToTemplateInfo[r]={template:e.template,componentClass:e.componentClass,cssClass:e.cssClass,dialogHeader:e.dialogHeader,dialogTemplate:e.dialogTemplate}},this)},getTemplateInfo:function e(r){require("./config.js")()
var i=this
var a=_.find(r.slice().reverse(),function(e){return!!i._classNameToTemplateInfo[e]})
if(a){return i._classNameToTemplateInfo[a]}else{return null}}},Backbone.Events)
module.exports=Notifications

});
KAdefine("javascript/notifications-package/config.js", function(require, module, exports) {
var _practiceIsComingNotification=require("./practice-is-coming-notification.jsx")
var _practiceIsComingNotification2=babelHelpers.interopRequireDefault(_practiceIsComingNotification)
var _privacyPolicy2018Notification=require("./privacy-policy-2018-notification.jsx")
var _privacyPolicy2018Notification2=babelHelpers.interopRequireDefault(_privacyPolicy2018Notification)
var _u13ReminderNotification=require("./u13-reminder-notification.jsx")
var _u13ReminderNotification2=babelHelpers.interopRequireDefault(_u13ReminderNotification)
var _=require("underscore")
var AcceptTermsOfServiceNotificationView=require("./accept-terms-of-service-notification-view.js")
var BannerNotificationView=require("./banner-notification-view.js")
var BaseNotificationView=require("./base-notification-view.js")
var EmailBounceNotificationView=require("./email-bounce-notification-view.js")
var LearningDashboardNotificationView=require("./learning-dashboard-notification-view.js")
var LinkEmailNotificationView=require("./link-email-notification-view.js")
var Notifications=require("./notifications.js")
var PhantomNotificationView=require("./phantom-notification-view.js")
var ReadableNotificationView=require("./readable-notification-view.js")
var RequestNotificationView=require("./request-notification-view.js")
var RestrictedDomainAgeCheckNotificationView=require("./restricted-domain-age-check-notification-view.js")
var UrgentNotificationView=require("./urgent-notification-view.js")
var VerifyEmailNotificationView=require("./verify-email-notification-view.js")
var viewClasses={AcceptTermsOfServiceNotification:AcceptTermsOfServiceNotificationView,APUpsellNotification:UrgentNotificationView,BannerNotification:BannerNotificationView,BaseNotification:BaseNotificationView,DonateNotification:UrgentNotificationView,EmailBounceNotification:EmailBounceNotificationView,HourOfCodeNotification:BannerNotificationView,LearningDashboardNotification:LearningDashboardNotificationView,LinkEmailNotification:LinkEmailNotificationView,PhantomNotification:PhantomNotificationView,PracticeIsComingNotification:UrgentNotificationView,PrivacyPolicy2018Notification:UrgentNotificationView,ReadableNotification:ReadableNotificationView,RequestNotification:RequestNotificationView,RestrictedDomainAgeCheckNotification:RestrictedDomainAgeCheckNotificationView,SATUpsellNotification:UrgentNotificationView,U13ReminderNotification:UrgentNotificationView,UrgentNotification:UrgentNotificationView,VerifyEmailNotification:VerifyEmailNotificationView,ZeroRatedNotification:UrgentNotificationView,ZeroRatingAvailableNotification:UrgentNotificationView}
var templateInfo={AcceptTermsOfServiceNotification:{template:require("./accept-terms-of-service-notification.handlebars.js"),cssClass:"accept-terms-of-service-notification"},ApiVersionMismatchNotification:{template:require("./api-version-mismatch-notification.handlebars.js"),cssClass:"api-version-mismatch-notification"},BannerNotification:{template:require("./banner-notification.handlebars.js"),cssClass:"banner-notification"},DonateNotification:{componentClass:require("./donate-notification.jsx")},EmailBounceNotification:{template:require("./email-bounce-notification.handlebars.js"),cssClass:"email-bounce-notification"},HourOfCodeNotification:{cssClass:"hourofcode-notification",componentClass:require("./hourofcode-notification-view.jsx")},I18nSuggestNotification:{template:require("./i18n-suggest-notification.handlebars.js"),cssClass:"i18n-suggest-notification"},LinkEmailNotification:{template:require("./link-email-notification.handlebars.js"),cssClass:"link-email-notification"},PhantomNotification:{template:require("./phantom-notification.handlebars.js"),cssClass:"phantom-notification"},PracticeIsComingNotification:{componentClass:_practiceIsComingNotification2.default},PrivacyPolicy2018Notification:{componentClass:_privacyPolicy2018Notification2.default,cssClass:"urgent-notification"},RestrictedDomainAgeCheckNotification:{cssClass:"restricted-domain-age-check-notification"},SATUpsellNotification:{componentClass:require("./sat-upsell-notification.jsx"),cssClass:"urgent-notification"},U13ReminderNotification:{componentClass:_u13ReminderNotification2.default},SiteOutageNotification:{componentClass:require("./site-outage-notification.jsx")},DonateTestModeNotification:{componentClass:require("./donate-test-mode-notification.jsx")},UrgentNotification:{template:require("./urgent-notification.handlebars.js"),cssClass:"urgent-notification"},VerifyEmailNotification:{template:require("./verify-email-notification.handlebars.js"),cssClass:"verify-email-notification"},ZeroRatedNotification:{template:require("./zero-rated-notification.handlebars.js")},ZeroRatingAvailableNotification:{template:require("./zero-rating-available-notification.handlebars.js")}}
var config=_.once(function(){Notifications.registerViewClasses(viewClasses)
Notifications.registerTemplateInfo(templateInfo)})
module.exports=config

});
KAdefine("javascript/notifications-package/base-notification-view.js", function(require, module, exports) {
var $=require("jquery")
var Backbone=require("backbone")
var Notifications=require("./notifications.js")
var BaseNotificationView=Backbone.View.extend({getTemplateInfo:function e(){var t=this.model.get("class_")
return Notifications.getTemplateInfo(t)},getComponentClass:function e(){var t=this.getTemplateInfo()
return t&&t.componentClass},getTemplate:function e(){var t=this.getTemplateInfo()
return t&&t.template},getTemplateContext:function e(){return this.model.attributes},deleteNotification:function e(){var t=this.model.get("urlsafeKey")
if(t){return $.ajax({type:"DELETE",url:"/api/internal/user/notifications/"+t})}}})
module.exports=BaseNotificationView

});
KAdefine("javascript/notifications-package/readable-notification-view.js", function(require, module, exports) {
var _moment=require("moment")
var _moment2=babelHelpers.interopRequireDefault(_moment)
var $=require("jquery")
var _=require("underscore")
var BaseNotificationView=require("./base-notification-view.js")
var KAConsole=require("../shared-package/console.js")
var NotificationDialogView=require("./notification-dialog-view.jsx")
var ReadableNotificationView=BaseNotificationView.extend({tagName:"li",className:"notification",initialize:function e(){this.model.set("timeago",(0,_moment2.default)(this.model.get("date")).fromNow())
if(this.model.get("read")!=null){if(this.model.get("url")){this.model.set("url","/notifications/read?keys="+this.model.get("urlsafeKey")+"&redirect_url="+encodeURIComponent(this.model.get("url")))}else{this.model.set("dialog",true)}}},readAndRenderDialog:function e(){var i=this.getTemplateInfo()
if(i.dialogTemplate){NotificationDialogView.show(this.model,i.dialogHeader,i.dialogTemplate)}this.$el.removeClass("unread")
$(".user-notifications-toggle").dropdown("close")
var t=this.model.get("urlsafeKey")
if(t){$.ajax({type:"POST",url:"/api/internal/user/notifications/"+t+"/read"})}},render:function e(i){var t=this.getTemplate()
if(!t){KAConsole.log("No template for NotificationView classes: "+this.model.get("class_"))
return}var a=$(t(this.getTemplateContext()))
if(this.model.get("url")){a=$("<a>").attr("href",this.model.get("url")).append(a)}else{if(this.model.get("read")!=null){if($.inArray("CoachRecommendationNotification",this.model.get("class_"))>-1){a=$("<a>").attr("href","/?learn=1").append(a)}else{a=$("<a>").attr("href","#").append(a).click(_.bind(function(e){e.preventDefault()
this.readAndRenderDialog()},this))}}}if(this.model.get("read")===false){this.$el.addClass("unread")}this.$el.addClass(this.getTemplateInfo().cssClass).append(a)
if(i){this.$el.prependTo(this.options.$container)}else{this.$el.insertBefore(this.options.$container.find(".loading"))}}})
module.exports=ReadableNotificationView

});
KAdefine("javascript/notifications-package/notification-dialog-view.jsx", function(require, module, exports) {
var React=require("react")
var ReactDOM=require("react-dom")
var DeprecatedModal=require("../shared-components-package/deprecated-modal.jsx")
function show(e,t,o){var r=arguments.length>3&&arguments[3]!==undefined?arguments[3]:[]
var a=document.body.appendChild(document.createElement("div"))
var n=React.createElement("div",{dangerouslySetInnerHTML:{__html:o(e.attributes)}})
var d=function e(){ReactDOM.unmountComponentAtNode(a)
a.parentNode.removeChild(a)}
r.push("notification-dialog")
var c=r.join(" ")
var l=React.createElement(DeprecatedModal,{backdrop:true,preventBodyScroll:true,showCloseButton:true,shouldHandleClose:true,title:t,footer:e.attributes.timeago,onClose:d,className:c},n)
ReactDOM.render(l,a)
return{component:l,close:d}}module.exports={show:show}

});
KAdefine("javascript/notifications-package/urgent-notification-view.js", function(require, module, exports) {
var $=require("jquery")
var React=require("react")
var ReactDOM=require("react-dom")
var _=require("underscore")
var BaseNotificationView=require("./base-notification-view.js")
var Cookies=require("../shared-package/cookies.js")
var KA=require("../shared-package/ka.js")
var KAConsole=require("../shared-package/console.js")
var Notifications=require("./notifications.js")
var _require=require("./util.js"),dispatchEvent=_require.dispatchEvent
var UrgentNotificationView=BaseNotificationView.extend({events:{"click .notification-bar-close a":"hideAndDelete","click .notification-bar-snooze a":"snooze","click .notification-bar-snooze i":"snooze","click .notification-bar-long-snooze a":"longSnooze","click .notification-bar-long-snooze i":"longSnooze","click .notification-bar-month-snooze a":"monthSnooze","click .notification-bar-month-snooze i":"monthSnooze","click .notification-bar-two-month-snooze a":"twoMonthSnooze","click .notification-bar-two-month-snooze i":"twoMonthSnooze","click .notification-bar-session-snooze a":"sessionSnooze","click .notification-bar-session-snooze i":"sessionSnooze"},initialize:function i(){this.model.set("continueUrlEncoded",encodeURIComponent(this.options.continueUrl))},getNotificationElement:function i(){return this.$el.find(".notification-bar")},displayNotification:function i(){var e=this.getNotificationElement()
e.data("view",this)
if(!e.is(":visible")){_.delay(_.bind(function(){e.css("visibility","hidden").css("display","").css("top",-e.height()-2).css("visibility","visible")
var i=$(".notification-bar-content").height()
i+=parseInt($(".notification-bar-content").css("paddingTop"),10)
i+=parseInt($(".notification-bar-content").css("paddingBottom"),10)
var t=Math.max(i,40)
var o={duration:350,queue:false}
$(".notification-bar-spacer").animate({height:t},o)
e.show().animate({top:0},o,null,function(){dispatchEvent("initNav",window)})},this),100)}else{dispatchEvent("initNav",window)}},render:function i(){var e=this
var t=parseInt(this.$el.data("priority"))
if(t&&t>this.model.get("priority")){KAConsole.log("Skipping render of lower priority notification.")
return}this.$el.data("priority",this.model.get("priority"))
var o=this.getComponentClass()
var n=this.getTemplate()
if(!n&&!o){KAConsole.log("No template for UrgentNotificationView classes: "+this.model.get("class_"))
return}if(this.model.get("class_").includes("DonateNotification")&&KA.isIE10){return}if(this.isSnoozed()){return}var a=this.getNotificationElement()
if(o){ReactDOM.render(React.createFactory(o)({context:this.getTemplateContext(),closeCallback:function i(t){return e.hideAndDelete(t)},snoozeFor:function i(t){return e.snoozeFor(t)}}),this.$el[0])
if(a.is(":visible")){return}}else{var s=n(this.getTemplateContext())
if(a.is(":visible")){a.html($(s).filter(".notification-bar").html())
return}this.$el.html(s)}this.displayNotification()},isSnoozed:function i(){if(_.last(this.model.get("class_"))==="DonateNotification"&&Cookies.readCookie("donatedRecently")){return true}return Cookies.readCookie(this.getSnoozeCookieName())},getSnoozeCookieName:function i(){var e=this.model.get("text")
var t=0
if(e){for(var o=0;o<e.length;o++){t+=e.charCodeAt(o)}}if(t===0){t=_.last(this.model.get("class_"))}if(t==="DonateNotification"){return"snoozeNote_DonateNotification2"}return"snoozeNote_"+t},hideAndDelete:function i(e){e.preventDefault()
this.$el.data("priority",null)
this.hide()
this.deleteNotification()},snoozeFor:function i(e){Cookies.createCookie(this.getSnoozeCookieName(),e?e.toString():"session",e)
this.hide()},snooze:function i(e){e.preventDefault()
this.snoozeFor(1)},longSnooze:function i(e){e.preventDefault()
this.snoozeFor(7)},monthSnooze:function i(e){e.preventDefault()
this.snoozeFor(31)},twoMonthSnooze:function i(e){e.preventDefault()
this.snoozeFor(61)},sessionSnooze:function i(e){e.preventDefault()
this.snoozeFor()},hide:function i(e){var t=this
var o=e?0:350
var n=this.getNotificationElement()
var a=n.css("display").indexOf("flex")!==-1?{height:0}:{top:-n.height()-2}
var s={duration:o,queue:false}
n.css("height",n.height())
n.css("min-height",0)
$(".notification-bar-spacer").animate({height:0},s)
n.animate(a,$.extend(s,{complete:function i(){t.remove()
Notifications.signalUrgentHidden(t)}}))}})
module.exports=UrgentNotificationView

});
KAdefine("javascript/notifications-package/banner-notification-view.js", function(require, module, exports) {
var $=require("jquery")
var Notifications=require("./notifications.js")
var _require=require("./util.js"),dispatchEvent=_require.dispatchEvent
var UrgentNotificationView=require("./urgent-notification-view.js")
var BannerNotificationView=UrgentNotificationView.extend({render:function i(){UrgentNotificationView.prototype.render.call(this)
$(".urgent-wrapper").addClass("banner-notification")
dispatchEvent("initNav",window)},displayNotification:function i(){var t=this.getNotificationElement()
t.show()},hide:function i(){var t=this.getNotificationElement()
t.slideUp(300,function(){Notifications.signalUrgentHidden(t)})}})
module.exports=BannerNotificationView

});
KAdefine("javascript/notifications-package/phantom-notification-view.js", function(require, module, exports) {
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _=require("underscore")
var BigBingo=require("../shared-package/bigbingo.js")
var Cookies=require("../shared-package/cookies.js")
var launchSignupLoginInModal=require("../signup-link-package/launch-signup-login-in-modal.js")
var UrgentNotificationView=require("./urgent-notification-view.js")
var PhantomNotificationView=UrgentNotificationView.extend({events:{"click .phantom-notif-sign-in":"signInClicked","click .phantom-notif-closed":"closeClicked"},isKind:function i(n){return this.model.get("notificationKind")===this.model.get(n)},signInClicked:function i(n){if(!_ka2.default.isPhantom()||Cookies.readCookie("u13")||window.top.location.pathname==="/signup"||_ka2.default.isPhone){return}n.preventDefault()
BigBingo.markConversion("phantom_notification_clicked")
var e=document.getElementsByClassName("urgent-wrapper")[0]
if(!e){return}var o=window.top.location.toString()
launchSignupLoginInModal("learner",o,"signup",e)},closeClicked:function i(n){this.hideAndDelete(n)
BigBingo.markConversion("phantom_notification_closed")},getTemplateContext:function i(){return _.extend({},this.model.attributes,{firstProblem:this.isKind("FIRST_PROBLEM"),manyProblems:this.isKind("MANY_PROBLEMS"),proficiency:this.isKind("PROFICIENCY"),firstBadge:this.isKind("FIRST_BADGE"),laterBadge:this.isKind("LATER_BADGE"),manyPoints:this.isKind("MANY_POINTS"),manyScratchpads:this.isKind("MANY_SCRATCHPADS"),someVideo:this.isKind("SOME_VIDEO"),finishedVideo:this.isKind("FINISHED_VIDEO")})},render:function i(){BigBingo.markConversion("phantom_notification_seen")
if(this.isKind("SOME_VIDEO")){BigBingo.markConversion("phantom_notification_video_some")}else if(this.isKind("FINISHED_VIDEO")){BigBingo.markConversion("phantom_notification_video_finished")}UrgentNotificationView.prototype.render.call(this)}})
module.exports=PhantomNotificationView

});
KAdefine("javascript/notifications-package/learning-dashboard-notification-view.js", function(require, module, exports) {
var UrgentNotificationView=require("./urgent-notification-view.js")
var bindSignupLinks=require("../signup-link-package/bind-signup-links.js")
var LearningDashboardNotificationView=UrgentNotificationView.extend({render:function i(){var n=this
UrgentNotificationView.prototype.render.call(this)
bindSignupLinks(this.$(".action-button"),function(){n.hide(true)})}})
module.exports=LearningDashboardNotificationView

});
KAdefine("javascript/notifications-package/request-notification-view.js", function(require, module, exports) {
var ReadableNotificationView=require("./readable-notification-view.js")
var RequestNotificationView=ReadableNotificationView.extend({events:{"click a":"cancel","click .accept":"accept","click .deny":"deny"},cancel:function e(i){i.preventDefault()
i.stopPropagation()},accept:function e(i){},deny:function e(i){},showSpinner:function e(){this.$el.find(".spinner").show().end().find(".simple-button").addClass("disabled")}})
module.exports=RequestNotificationView

});
KAdefine("javascript/notifications-package/i18n-suggest-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="demo-notification-bar notification-bar" style="display:none;">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">'+i18n._("Khan Academy is now available in {{languageNameInRequestLanguage}} (<span lang={{languageCode}}>{{localLanguageName}}</span>)! Interested?")+' <a class="simple-button orange" href="{{action}}" lang={{languageCode}}>{{translatedButtonText}}</a></span>\n        <span class="notification-bar-close">\n            <button aria-label=\''+i18n._("close banner")+'\'>\n                <img\n                    src=\'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNyAxNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMS4zMzc4OTA2Mi41TDE2LjM3MTE4NzIgMTUuNTMzMjk2Nk0xNi4zMzc4OTA2LjVMMS4zMDQ1OTQwNCAxNS41MzMyOTY2IiBzdHJva2U9IiMyMTI0MkMiIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==\'\n                    width="17"\n                    height="17"\n                />\n            </button>\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer"></div>')

});
KAdefine("javascript/notifications-package/phantom-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="notification-bar" style="display:none;">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n            {{#if firstProblem }}\n            '+i18n._("You&rsquo;ve done your first {{translatedExerciseDisplayName}} problem!")+"\n            {{/if}}\n            {{#if manyProblems }}\n            "+i18n._("You&rsquo;ve done {{problem_number}} problems in {{translatedExerciseDisplayName}}!")+"\n            {{/if}}\n            {{#if proficiency }}\n            "+i18n._("You&rsquo;re now proficient in {{translatedExerciseDisplayName}}.")+"\n            {{/if}}\n            {{#if firstBadge }}\n            "+i18n._("Congrats on your first <a href='{{achievementsUrl}}'>badge</a>!")+"\n            {{/if}}\n            {{#if laterBadge }}\n            "+i18n._("You&rsquo;ve earned <a href='/profile'>{{badgesCount}} badges</a> so far.")+"\n            {{/if}}\n            {{#if manyPoints }}\n            "+i18n._("You&rsquo;ve earned over <a href='/profile'>{{points}} points</a>!")+"\n            {{/if}}\n            {{#if manyScratchpads }}\n            "+i18n._("You&rsquo;ve created {{scratchpad_count}} programs.")+"\n            {{/if}}\n\n            {{#if someVideo}}\n            "+i18n._("You&rsquo;ve nearly finished watching a video!")+"\n            {{/if}}\n\n            {{#if finishedVideo}}\n            "+i18n._("You&rsquo;ve finished a video!")+"\n            {{/if}}\n            <a href='/signup?continue={{continueUrlEncoded}}' class='simple-button green signup-modal-link phantom-notif-sign-in'>"+i18n._("Sign up to save your progress")+'</a>\n        </span>\n        <span class="notification-bar-close">\n            <button class="phantom-notif-closed" aria-label=\''+i18n._("close banner")+'\'>\n                <img\n                    src=\'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNyAxNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMS4zMzc4OTA2Mi41TDE2LjM3MTE4NzIgMTUuNTMzMjk2Nk0xNi4zMzc4OTA2LjVMMS4zMDQ1OTQwNCAxNS41MzMyOTY2IiBzdHJva2U9IiMyMTI0MkMiIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==\'\n                    width="17"\n                    height="17"\n                />\n            </button>\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer"></div>')

});
KAdefine("javascript/notifications-package/email-bounce-notification-view.js", function(require, module, exports) {
var UrgentNotificationView=require("./urgent-notification-view.js")
var EmailBounceNotificationView=UrgentNotificationView.extend({render:function i(){var e=this
EmailBounceNotificationView.__super__.render.call(this)
require.dynimport("../phantom-package/notifications.js").then(function(i){return i.default}).then(function(i){i.initBouncedEmailNotice({email:e.model.get("email")})})}})
module.exports=EmailBounceNotificationView

});
KAdefine("javascript/notifications-package/email-bounce-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('{{! The notification at the top of each page shown when a user is mid-signup,\n   but we detected that the e-mail we tried to send them bounced. }}\n<div class="notification-bar auto-visible phantom-notification-bar error">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n            '+i18n._('We couldn\'t deliver your sign-up email to <span class="email-address">{{ email }}')+'</span>.\n        </span>\n        <a class="change-button simple-button warning" href="javascript:void(0);">'+i18n._("Change address")+'</a>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/verify-email-notification-view.js", function(require, module, exports) {
var UrgentNotificationView=require("./urgent-notification-view.js")
var VerifyEmailNotificationView=UrgentNotificationView.extend({render:function i(){var e=this
VerifyEmailNotificationView.__super__.render.call(this)
require.dynimport("../phantom-package/notifications.js").then(function(i){return i.default}).then(function(i){i.initEmailReminder({email:e.model.get("email"),unverifiedAuthEmailToken:e.model.get("unverifiedAuthEmailToken")})})}})
module.exports=VerifyEmailNotificationView

});
KAdefine("javascript/notifications-package/verify-email-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('{{! The notification at the top of each page shown when a user is mid-signup,\n   but we know they haven\'t checked their email to verify their email address }}\n<div class="notification-bar auto-visible phantom-notification-bar">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n            {{#if mailServerUrl}}\n                {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n                '+i18n._('<a class="simple-button primary" href="{{ mailServerUrl }}">\n'+'                    <i class="icon-envelope-alt"></i>\n'+'                    <span class="button-text">Open your {{ mailServerName }}</span>\n'+"                </a>\n"+'                <span class="finish-sign-up">\n'+"                    to finish signing up with\n"+"                </span>\n"+'                <span class="email-address">{{ email }}</span>.')+"\n            {{else}}\n            {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n            "+i18n._('<span class="finish-sign-up">\n'+"                Open your email to finish signing up with\n"+"            </span>\n"+'            <span class="email-address">{{ email }}</span>.')+'\n            {{/if}}\n        </span>\n        <a class="resend-link" href="javascript:void(0);">'+i18n._("Resend email")+'</a>\n        <a class="change-link" href="javascript:void(0);">'+i18n._("Change email")+'</a>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/api-version-mismatch-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="notification-bar" style="display:none;">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n            '+i18n._('The version of this page that you are viewing is out of date, and some features may stop working. Please <a href="javascript: location.reload(true)">refresh the page</a>.')+'\n        </span>\n        <span class="notification-bar-close">\n            <button aria-label=\''+i18n._("close banner")+'\'>\n                <img\n                    src=\'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNyAxNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMS4zMzc4OTA2Mi41TDE2LjM3MTE4NzIgMTUuNTMzMjk2Nk0xNi4zMzc4OTA2LjVMMS4zMDQ1OTQwNCAxNS41MzMyOTY2IiBzdHJva2U9IiMyMTI0MkMiIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==\'\n                    width="17"\n                    height="17"\n                />\n            </button>\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer"></div>')

});
KAdefine("javascript/notifications-package/urgent-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
module.exports=_handlebars2.default.compile('{{! The default template for UrgentNotifications }}\n{{! TODO(leah): Improve styling and use this for more notifications }}\n<div class="notification-bar auto-visible {{notificationClass}}">\n    <div class="notification-bar-inner">\n        {{#if removable}}\n        <span class="notification-bar-snooze right-x">\n            <i class="icon-remove"/>\n        </span>\n        {{/if}}\n\n        <span class="notification-bar-content">\n            {{translatedText}}\n\n            {{#if translatedButtonText}}\n            <a href="{{link}}" class="action-button simple-button"\n                    {{#if openInNewTab}}target="_blank"{{/if}}>\n                {{translatedButtonText}}\n                {{#if chevron}}\n                    <i class="icon-chevron-right"/>\n                {{/if}}\n            </a>\n            {{/if}}\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/banner-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
module.exports=_handlebars2.default.compile('<div class="notification-bar banner-notification {{notificationClass}}">\n    <div class="notification-bar-inner">\n        {{#if removable}}\n        <span class="notification-bar-long-snooze right-x">\n            <i class="icon-remove"/>\n        </span>\n        {{/if}}\n\n        <span class="notification-bar-content">\n            {{translatedText}}\n\n            {{#if translatedButtonText}}\n            <a href="{{link}}" class="action-button simple-button"\n                    {{#if openInNewTab}}target="_blank"{{/if}}>\n                {{translatedButtonText}}\n                {{#if chevron}}\n                    <i class="icon-chevron-right"/>\n                {{/if}}\n            </a>\n            {{/if}}\n        </span>\n    </div>\n</div>')

});
KAdefine("javascript/notifications-package/link-email-notification-view.js", function(require, module, exports) {
var UrgentNotificationView=require("./urgent-notification-view.js")
var LinkEmailNotificationView=UrgentNotificationView.extend({render:function i(){LinkEmailNotificationView.__super__.render.call(this)
require.dynimport("../phantom-package/notifications.js").then(function(i){return i.default}).then(function(i){i.initLinkFirstEmail()})}})
module.exports=LinkEmailNotificationView

});
KAdefine("javascript/notifications-package/link-email-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="notification-bar auto-visible">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n        {{translatedText}}\n        <div style="display: inline;" id="add-email-button-notification-mountpoint"></div>\n        </span>\n        <span class="notification-bar-snooze">(<a href="javascript:">'+i18n._("close")+'</a>)</span>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/accept-terms-of-service-notification-view.js", function(require, module, exports) {
var $=require("jquery")
var UrgentNotificationView=require("./urgent-notification-view.js")
var AcceptTermsOfServiceNotificationView=UrgentNotificationView.extend({render:function e(){AcceptTermsOfServiceNotificationView.__super__.render.call(this)
if(/[?&]view=mobile(&|$)/.test(window.location.search)){return}Promise.all([require.dynimport("../phantom-package/notifications.js").then(function(e){return e.default}),require.dynimport("../../stylesheets/shared-package/shared.less")]).then(function(e){var i=e[0]
i.initAcceptTermsOfService()})
$("#accept-tos-modal").modal("show")
var i=Math.min(550,window.innerWidth-32)
var t=$("#accept-tos-modal").data("modal")
t.$backdrop.css("z-index",1e5)
t.$element.css({"z-index":100001,display:"block",width:i,marginLeft:-(i/2+16)})}})
module.exports=AcceptTermsOfServiceNotificationView

});
KAdefine("javascript/notifications-package/accept-terms-of-service-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('{{! This notification pops an undismissable modal to force acceptance of the Terms of Service }}\n<div class="modal hide fade notification-dialog" id="accept-tos-modal" data-keyboard="false" data-backdrop="static">\n    <div class="modal-header">\n        <h2>'+i18n._("Welcome to Khan Academy!")+'</h2>\n    </div>\n    <div class="modal-body">\n        <p>\n            '+i18n._("We're excited to have you studying with us. To help you learn as much as possible, we'll be following your progress and guiding you through what to learn next.")+'\n        </p>\n        <p class="tos-line">\n            <span class="tos-input">\n                <input id="tos" name="tos" value="0" type="checkbox">\n            </span>\n            <label class="tos-label" for="tos">\n            {{#if isChildAccount}}\n                '+i18n._("I (and my parent) agree to the <a href='/about/tos' target='_blank' tabindex='1'>Terms of Service</a> and <a href='/about/privacy-policy' target='_blank' tabindex='1'>Privacy Policy</a>.")+"\n            {{else}}\n                "+i18n._("I agree to the <a href='/about/tos' target='_blank' tabindex='1'>Terms of Service</a> and <a href='/about/privacy-policy' target='_blank' tabindex='1'>Privacy Policy</a>.")+'\n            {{/if}}\n            </label>\n        </p>\n    </div>\n    <div class="modal-footer">\n        <a id="tos-cancel-button" href="/logout">'+i18n._("Logout")+"</a> "+i18n._("or")+'\n        <input class="simple-button green" id="tos-ok-button" name="tos-ok-button" value="'+i18n._("Start learning")+'" type="button" disabled>\n    </div>\n</div>')

});
KAdefine("javascript/notifications-package/restricted-domain-age-check-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile("<p>\n    {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n    "+i18n._("\n"+"        Please let us know how old you are so we can give you the best experience.\n"+'        <a target="_blank" href="#" id="age-question-learn-more">Learn more about why we ask.</a>\n'+"    ")+'\n</p>\n<p id="age-question-explanation" style="display:none;">\n    {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n    '+i18n._("\n"+"        We’re deeply committed to creating a safe and secure online environment for all of our learners, and we want learners of all ages to enjoy using our site.\n"+"        We’re asking about your age because we take <a href='/resources/parents-mentors-1/privacy-and-security/a/a/how-does-khan-academy-protect-students-under-age-13'>extra care for our younger learners under the age of 13</a>, so please be honest!\n"+"        We want to give you the best, safest experience for your age.\n"+"        Happy learning!\n"+"    ")+'\n</p>\n\n<div id="age-question">\n    <label for="student-age">\n        '+i18n._("How old are you?")+'\n    </label>\n    <span id="age-selector-container"></span>\n</div>\n\n<div id="done-button-container"></div>')

});
KAdefine("javascript/notifications-package/restricted-domain-age-check-notification-view.js", function(require, module, exports) {
var _wonderBlocksButtonV=require("@khanacademy/wonder-blocks-button-v2")
var _wonderBlocksButtonV2=babelHelpers.interopRequireDefault(_wonderBlocksButtonV)
var $=require("jquery")
var React=require("react")
var ReactDOM=require("react-dom")
var i18n=require("../shared-package/i18n.js")
var AgeSelector=React.createFactory(require("./age-selector.jsx"))
var KAConsole=require("../shared-package/console.js")
var UrgentNotificationView=require("./urgent-notification-view.js")
var NotificationDialogView=require("./notification-dialog-view.jsx")
var template=require("./restricted-domain-age-check-notification.handlebars.js")
var RestrictedDomainAgeCheckNotificationView=UrgentNotificationView.extend({_age:null,showModal:function e(){this._modal=NotificationDialogView.show(this.model,i18n._("We see you're signing in with a school account!"),template,["restricted-domain-modal"])
$("#age-question-learn-more").click(function(e){e.preventDefault()
$(this).hide()
$("#age-question-explanation").slideDown(300)})
this.renderAgeSelector()
this.renderButton()},renderAgeSelector:function e(){var t=this
var i=AgeSelector({onChange:function e(i){t.onChange(i)}})
ReactDOM.render(i,$("#age-selector-container")[0])},renderButton:function e(){var t=this
ReactDOM.render(React.createElement(_wonderBlocksButtonV2.default,{onClick:function e(){return t.submit()},disabled:this._age==null,style:{minWidth:220,margin:"5px 0"},kind:"secondary"},i18n._("Done! Keep learning.")),document.querySelector("#done-button-container"))},onChange:function e(t){if(parseInt(t)){this._age=t}else{this._age=null}this.renderButton()},submit:function e(){if(!parseInt(this._age)){KAConsole.log("Must specify age.")
return}var t=this._age<13
$.ajax({type:"POST",url:"/api/internal/user/settings/restricted_domain_response",data:{under13:t?"1":"0"},success:function e(t){},error:function e(){KAConsole.log("Failed to send restricted domain response.")}})
this._modal.close()},render:function e(){RestrictedDomainAgeCheckNotificationView.__super__.render.call(this)
this.showModal()}})
module.exports=RestrictedDomainAgeCheckNotificationView

});
KAdefine("javascript/notifications-package/donate-notification.jsx", function(require, module, exports) {
var _bigbingo=require("../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _icon=require("../shared-styles-package/icon.jsx")
var _icon2=babelHelpers.interopRequireDefault(_icon)
var React=require("react")
var PropTypes=require("prop-types")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var xThinIcon="M9.9,9.9C9.9,10,9.8,10,9.7,10c-0.1,0-0.2,0-0.2-0.1L5,5.4L0.5,9.9C\n    0.5,10,0.4,10,0.3,10c-0.1,0-0.2,0-0.2-0.1C0,9.8,0,9.6,0.1,9.5L4.6,5L\n    0.1,0.5C0,0.4,0,0.2,0.1,0.1C0.2,0,0.4,0,0.5,0.1L5,4.6l4.4-4.5C9.6,0,\n    9.8,0,9.9,0.1c0.1,0.1,0.1,0.3,0,0.4L5.4,5l4.5,4.5C10,9.6,10,9.8,9.9,\n    9.9z"
var DonateNotificationWithNewForm=function(e){babelHelpers.inherits(t,e)
function t(){var r,n,i
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,a=Array(o),s=0;s<o;s++){a[s]=arguments[s]}return i=(r=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(a))),n),n.state={formClass:EmptyForm},n.onDismiss=function(e){n.props.snoozeFor(61)},n.buildMethodChoices=function(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++){t[r]=arguments[r]}var i=[]
for(var o=t,a=Array.isArray(o),s=0,o=a?o:o[Symbol.iterator]();;){var c
if(a){if(s>=o.length)break
c=o[s++]}else{s=o.next()
if(s.done)break
c=s.value}var l=c
if(l.onSubmitKey in n.state){i.push({id:l.id,label:l.label,onSubmit:n.state[l.onSubmitKey]})}}return i},r),babelHelpers.possibleConstructorReturn(n,i)}t.prototype.componentDidMount=function e(){var t=this
_bigbingo2.default.markConversionsWithExtras([{id:"donation_banner_viewed",extra:{page:window.location.href,kaid:_ka2.default.getKaid()}}])
require.dynimport("../donate-package/donate-form-controller.jsx").then(function(e){return e.default}).then(function(e){t.setState({formClass:e})})
require.dynimport("../donate-package/methods/paypal.js").then(function(e){return e.default}).then(function(e){t.setState({startPaypal:e})})
require.dynimport("../donate-package/methods/stripe.js").then(function(e){return e.default}).then(function(e){t.setState({startStripe:e})})}
t.prototype.render=function e(){var t=this.state.formClass
return React.createElement(Banner,{onDismiss:this.onDismiss},React.createElement(t,{donateParameters:this.props.context,formContext:"banner"}))}
return t}(React.Component)
DonateNotificationWithNewForm.propTypes={context:PropTypes.shape({amount:PropTypes.string.isRequired,interval:PropTypes.string.isRequired,askStringMonthly:PropTypes.array.isRequired,askStringOnetime:PropTypes.array.isRequired,askHtml:PropTypes.array.isRequired,imageRelativeUrl:PropTypes.string,thermometer:PropTypes.any}).isRequired,snoozeFor:PropTypes.func.isRequired}
var Banner=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement("div",{className:"notification-bar donate-notification","data-test-id":"donate-notification",id:"donate-notification"},React.createElement("div",{className:css(styles.notificationBarInner)},React.createElement("a",{"aria-label":"close",className:css(styles.removeLink),href:"javascript:void(0)",onClick:this.props.onDismiss,role:"button","data-test-id":"close-donate-notification"},React.createElement(_icon2.default,{alt:"close",className:css(styles.removeIcon),icon:xThinIcon})),this.props.children))}
return t}(React.Component)
Banner.propTypes={children:PropTypes.node,onDismiss:PropTypes.func}
var EmptyForm=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement("div",null)}
return t}(React.Component)
var removeIconSizePx=16
var removeIconSpacingPx=20
var styles=StyleSheet.create({notificationBarInner:{margin:0,maxWidth:"100%",width:"100%"},removeLink:{":hover":{cursor:"pointer"},height:removeIconSizePx,left:removeIconSpacingPx,position:"absolute",top:removeIconSpacingPx,width:removeIconSizePx,zIndex:1},removeIcon:{fontSize:22,fontWeight:"normal",lineHeight:1,height:removeIconSizePx,textAlign:"right",width:removeIconSizePx}})
module.exports=DonateNotificationWithNewForm

});
KAdefine("javascript/notifications-package/hourofcode-notification-view.jsx", function(require, module, exports) {
var _bannerInner
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var React=require("react")
var PropTypes=require("prop-types")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var styleConstants=require("../shared-styles-package/constants.js")
var _require2=require("../shared-package/i18n.js"),$_=_require2.$_
var styles=StyleSheet.create({bannerFull:{backgroundColor:"#669f25"},bannerInner:(_bannerInner={height:"auto",margin:"0 auto",paddingTop:20,paddingBottom:20,textAlign:"center"},_bannerInner["@media screen and (max-width: "+styleConstants.pureSmMax+")"]={height:"250px",maxWidth:"400px",width:"100%"},_bannerInner["@media screen and (max-width: "+styleConstants.pureMdMin+")"]={height:"90px",width:"720px"},_bannerInner["@media screen and (max-width: "+styleConstants.pureXlMin+")"]={height:"150px",width:"1200px"},_bannerInner),snoozeButton:{color:"white",cursor:"pointer",fontSize:"16px",padding:"10px",position:"absolute",right:"5px",top:"5px"},image:{marginRight:"30px",verticalAlign:"top",width:"200px"},button:{background:"white",border:"1px solid #ffffff",borderRadius:"50px",color:"#719807",cursor:"pointer",display:"inline-block",fontSize:"18px",lineHeight:"40px",marginLeft:"15px",marginTop:"15px",padding:"0 25px",textDecoration:"none",verticalAlign:"top"},headingBlock:{display:"inline-block"},mainHeading:{color:"white",fontSize:"40px",fontWeight:"bold",marginBottom:"0px"},subHeading:{color:"white",fontSize:"15px",marginBottom:"0px"},clearBlock:{clear:"both"}})
var HourOfCodeNotification=function(e){babelHelpers.inherits(t,e)
function t(){var r,n,a
babelHelpers.classCallCheck(this,t)
for(var s=arguments.length,o=Array(s),i=0;i<s;i++){o[i]=arguments[i]}return a=(r=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),n),n.state={hidden:false},n.snooze=function(){n.props.snoozeFor(7)
n.setState({hidden:true})},r),babelHelpers.possibleConstructorReturn(n,a)}t.prototype.render=function e(){var t=this
if(this.state.hidden){return null}return React.createElement("div",{className:css(styles.bannerFull)},React.createElement("span",{onClick:function e(){return t.snooze()},className:css(styles.snoozeButton)},React.createElement("i",{className:"icon-remove"})),React.createElement("div",{className:css(styles.bannerInner)},React.createElement("a",{href:"/hourofcode"},React.createElement("img",{src:(0,_staticUrl2.default)("/images/homepage/hourofcodetrio.png"),alt:"",className:css(styles.image)}),React.createElement("div",{className:css(styles.headingBlock)},React.createElement("h1",{className:css(styles.mainHeading)},$_(null,"Hour of Code")),React.createElement("h2",{className:css(styles.subHeading)},$_(null,"Computer Science Ed Week, Dec. 7-13, 2015"))),React.createElement("button",{type:"button",className:css(styles.button)},$_(null,"Start coding now")),React.createElement("div",{className:css(styles.clearBlock)}))))}
return t}(React.Component)
HourOfCodeNotification.propTypes={snoozeFor:PropTypes.func.isRequired}
module.exports=HourOfCodeNotification

});
KAdefine("javascript/notifications-package/zero-rated-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="notification-bar auto-visible zero-rated-notification" style="display:none">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-session-snooze right-x">\n            <i class="icon-remove"/>\n        </span>\n\n        <span class="notification-bar-content">\n            '+i18n._("Welcome! You can now use Khan Academy without using any of your mobile data.")+"\n            <a href='/r/zero-rating-learn-more'>"+i18n._("Learn more here.")+'</a>\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/zero-rating-available-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="notification-bar auto-visible zero-rated-notification" style="display:none;">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-session-snooze right-x">\n            <i class="icon-remove"/>\n        </span>\n\n        <span class="notification-bar-content">\n            {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n            '+i18n._("Thanks to your mobile carrier, Khan Academy is now available free\n"+"            of data charges. Start learning at\n"+'            <a href="/zero/prefer-zero">{{zeroRatedBaseUrl}}</a>.')+'\n        </span>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/notifications-package/sat-upsell-notification.jsx", function(require, module, exports) {
var _notificationContent,_textContainer,_bigButton,_smallButton
var _wonderBlocksButtonV=require("@khanacademy/wonder-blocks-button-v2")
var _wonderBlocksButtonV2=babelHelpers.interopRequireDefault(_wonderBlocksButtonV)
var React=require("react")
var _require=require("aphrodite"),css=_require.css,StyleSheet=_require.StyleSheet
var bindSignupLinks=require("../signup-link-package/bind-signup-links.js")
var $i18nDoNotTranslate=require("../shared-package/i18n.js").$i18nDoNotTranslate
var globalStyles=require("../shared-styles-package/global-styles.js")
var mediaQueries=require("../shared-styles-package/media-queries.js")
var SATUpsellNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.componentDidMount=function e(){var t=document.getElementById("sat-upsell-link")
bindSignupLinks([t],null,null,"/mission/sat")}
t.prototype.render=function e(){return React.createElement("div",{className:"notification-bar banner-notification"},React.createElement("div",{className:css(styles.notificationContent)},React.createElement("div",{className:css(styles.textContainer)},React.createElement("div",{className:"notification-primary-text"},$i18nDoNotTranslate(null,"Get personalized practice recommendations for the skills you'll need for the SAT, plus eight official practice exams from College Board."))),React.createElement(_wonderBlocksButtonV2.default,{style:styles.bigButton,id:"sat-upsell-link",href:"/mission/sat",skipClientNav:true},$i18nDoNotTranslate(null,"Practice for the SAT")),React.createElement(_wonderBlocksButtonV2.default,{style:styles.smallButton,size:"small",id:"sat-upsell-link",href:"/mission/sat",skipClientNav:true},$i18nDoNotTranslate(null,"Practice for the SAT"))))}
return t}(React.Component)
var styles=StyleSheet.create({notificationContent:(_notificationContent={backgroundColor:globalStyles.colors.white,display:"flex",justifyContent:"center",margin:"auto",maxWidth:1e3},_notificationContent[mediaQueries.xsOrSmaller]={flexDirection:"column"},_notificationContent),textContainer:(_textContainer={display:"inline-block",margin:5},_textContainer[mediaQueries.xsOrSmaller]={fontSize:14},_textContainer),bigButton:(_bigButton={margin:"auto 0",minWidth:180},_bigButton[mediaQueries.xsOrSmaller]={display:"none"},_bigButton),smallButton:(_smallButton={margin:"auto 0",width:"100%"},_smallButton[mediaQueries.smOrLarger]={display:"none"},_smallButton)})
module.exports=SATUpsellNotification

});
KAdefine("javascript/notifications-package/practice-is-coming-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _topBannerAnimateIn,_topBannerAnimateOut,_closeIcon
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _closeIcon2=require("../reusable-components-package/close-icon.jsx")
var _closeIcon3=babelHelpers.interopRequireDefault(_closeIcon2)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _mediaQueries=require("../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var _hoverBehavior=require("../components/button-package/hover-behavior.jsx")
var _hoverBehavior2=babelHelpers.interopRequireDefault(_hoverBehavior)
var _link=require("../components/link-package/link.jsx")
var _link2=babelHelpers.interopRequireDefault(_link)
var $i18nDoNotTranslate=require("../shared-package/i18n.js").$i18nDoNotTranslate
var SNOOZE_DAYS=7
var PracticeIsComingNotification=function(e){babelHelpers.inherits(a,e)
function a(){var n,r,t
babelHelpers.classCallCheck(this,a)
for(var i=arguments.length,o=Array(i),s=0;s<i;s++){o[s]=arguments[s]}return t=(n=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),r),r.state={isOpen:true},r.handleDismiss=function(e){r.setState({isOpen:false},r.props.snoozeFor(SNOOZE_DAYS))},n),babelHelpers.possibleConstructorReturn(r,t)}a.prototype.renderCopy=function e(){return $i18nDoNotTranslate(null,"We’re actively working on this course. More improvements coming soon!")}
a.prototype.render=function e(){var a=(0,_aphrodite.css)(styles.notificationStylesOverride,this.state.isOpen?styles.topBannerAnimateIn:styles.topBannerAnimateOut)
return React.createElement("div",{className:"notification-bar "+a},React.createElement("div",{className:(0,_aphrodite.css)(styles.topBanner)},React.createElement(_hoverBehavior2.default,{onClick:this.handleDismiss},function(e,a){var n=e.hovered
return React.createElement(_link2.default,babelHelpers.extends({"aria-label":"close",className:(0,_aphrodite.css)(styles.closeIcon,n&&styles.hovered),href:"javascript:void(0)"},a),React.createElement(_closeIcon3.default,{size:31,iconSize:11}))}),React.createElement("div",{className:(0,_aphrodite.css)(styles.copy)},this.renderCopy())))}
return a}(_react.Component)
exports.default=PracticeIsComingNotification
var animateMarginTop=function e(a,n){return{"0%":{marginTop:a},"100%":{marginTop:n}}}
var BANNER_HEIGHT=60
var MOBILE_BANNER_HEIGHT=112
var TRANSITION_DURATION=300
var bannerAnimationIn=animateMarginTop(-BANNER_HEIGHT,0)
var bannerAnimationOut=animateMarginTop(0,-BANNER_HEIGHT)
var mobileBannerAnimationIn=animateMarginTop(-MOBILE_BANNER_HEIGHT,0)
var mobileBannerAnimationOut=animateMarginTop(0,-MOBILE_BANNER_HEIGHT)
var styles=_aphrodite.StyleSheet.create({copy:babelHelpers.extends({},_globalStyles.typography.bodyXsmallBold,{margin:"auto",padding:"19px 45px"}),notificationStylesOverride:{position:"inherit",display:"block"},topBanner:{display:"flex",alignItems:"center",paddingLeft:14,paddingRight:14,backgroundColor:_globalStyles.colors.gray97,color:_globalStyles.colors.gray17},topBannerAnimateIn:(_topBannerAnimateIn={animationName:bannerAnimationIn,animationDuration:TRANSITION_DURATION+"ms"},_topBannerAnimateIn[_mediaQueries2.default.smOrSmaller]={animationName:mobileBannerAnimationIn},_topBannerAnimateIn),topBannerAnimateOut:(_topBannerAnimateOut={animationName:bannerAnimationOut,animationDuration:TRANSITION_DURATION+"ms",animationFillMode:"forwards"},_topBannerAnimateOut[_mediaQueries2.default.smOrSmaller]={animationName:mobileBannerAnimationOut},_topBannerAnimateOut),closeIcon:(_closeIcon={position:"absolute",opacity:.6,height:31},_closeIcon[_mediaQueries2.default.smOrSmaller]={alignSelf:"flex-start",paddingTop:14},_closeIcon),hovered:{opacity:1}})

});
KAdefine("javascript/notifications-package/privacy-policy-2018-notification.jsx", function(require, module, exports) {
var _text,_buttonContainer,_privacyPolicyButton
var _wonderBlocksButtonV=require("@khanacademy/wonder-blocks-button-v2")
var _wonderBlocksButtonV2=babelHelpers.interopRequireDefault(_wonderBlocksButtonV)
var _mediaQueries=require("../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var classNames=require("classnames")
var React=require("react")
var _require=require("aphrodite"),css=_require.css,StyleSheet=_require.StyleSheet
var _require2=require("../shared-package/i18n.js"),_=_require2._,$_=_require2.$_
var globalStyles=require("../shared-styles-package/global-styles.js")
var _require3=require("../shared-package/absolute-links.js"),safeLinkTo=_require3.safeLinkTo
var PrivacyPolicy2018Notification=function(e){babelHelpers.inherits(t,e)
function t(){var a,r,i
babelHelpers.classCallCheck(this,t)
for(var n=arguments.length,s=Array(n),l=0;l<n;l++){s[l]=arguments[l]}return i=(a=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),r),r.state={hidden:false},a),babelHelpers.possibleConstructorReturn(r,i)}t.prototype.render=function e(){var t=this
if(this.state.hidden){return null}var a=$_(null,"here")
var r=_("Visit our privacy policy")
var i=safeLinkTo("https://www.khanacademy.org/about/privacy-policy")
return React.createElement("div",{className:classNames("notification-bar",css(styles.banner))},React.createElement("div",{className:classNames("notification-bar-inner",css(styles.content))},React.createElement("div",{className:css(styles.text)},$_({here:React.createElement("a",{href:i,"aria-label":r},a)},"At Khan Academy, we take the protection of your personal information seriously. We have updated our Privacy Policy to provide increased transparency and to address the EU General Data Protection Regulation (“GDPR”). Learn more %(here)s.")),React.createElement("div",{className:css(styles.buttonContainer)},React.createElement(_wonderBlocksButtonV2.default,{light:true,kind:"secondary",id:"privacy-policy-dismiss",onClick:function e(){return t.setState({hidden:true})},style:styles.privacyPolicyButton},$_(null,"Dismiss")))))}
return t}(React.Component)
var styles=StyleSheet.create({content:{maxWidth:1200,textAlign:"center",marginLeft:"auto",marginRight:"auto"},banner:{position:"static",backgroundColor:"#0a2a66",color:globalStyles.colors.white},text:(_text={display:"table-cell",textAlign:"left",paddingLeft:27,paddingTop:8,paddingBottom:8},_text[_mediaQueries2.default.smOrSmaller]={display:"block",paddingLeft:17,paddingRight:17},_text),buttonContainer:(_buttonContainer={display:"table-cell",verticalAlign:"middle",marginLeft:32,marginRight:5,paddingLeft:24,paddingRight:8},_buttonContainer[_mediaQueries2.default.smOrSmaller]={display:"block",marginLeft:17,marginRight:17,paddingLeft:0,paddingRight:0,marginBottom:16},_buttonContainer),privacyPolicyButton:(_privacyPolicyButton={marginRight:10},_privacyPolicyButton[_mediaQueries2.default.smOrSmaller]={width:"100%"},_privacyPolicyButton)})
module.exports=PrivacyPolicy2018Notification

});
KAdefine("javascript/notifications-package/u13-reminder-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _babelHelpers$extends
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _classnames=require("classnames")
var _classnames2=babelHelpers.interopRequireDefault(_classnames)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _mediaQueries=require("../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var _require=require("../shared-package/i18n.js"),$_=_require.$_
var ORANGE_BACKGROUND="/images/u13/orangebkgd.png"
var U13ReminderNotification=function(e){babelHelpers.inherits(a,e)
function a(){var t,r,l
babelHelpers.classCallCheck(this,a)
for(var n=arguments.length,s=Array(n),i=0;i<n;i++){s[i]=arguments[i]}return l=(t=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),r),r.state={U13ReminderModal:null,loadingModalLate:false,parentEmail:r.props.context.parentEmail,showReminderModal:false},r._isMounted=false,r.handleClick=function(){var e=r.state.U13ReminderModal
r.setState({showReminderModal:true})
if(!e){r.setState({loadingModalLate:true})}},r.handleClose=function(e){r.setState({showReminderModal:false})},r.updateParentEmail=function(e){r._isMounted&&r.setState({parentEmail:e})},r.loadModalComponent=function(){require.dynimport("../login-package/u13-reminder-modal.jsx").then(function(e){return e.default}).then(function(e){r.setState({U13ReminderModal:e,loadingModalLate:false})})},t),babelHelpers.possibleConstructorReturn(r,l)}a.prototype.componentDidMount=function e(){this._isMounted=true
this.loadModalComponent()}
a.prototype.componentWillUnmount=function e(){this._isMounted=false}
a.prototype.renderCTAText=function e(){var a=this.state.loadingModalLate
if(a){return $_(null,"Loading...")}else{return $_(null,"Learn why")}}
a.prototype.render=function e(){var a=this.props.context,t=a.daysLeft,r=a.daysLeftString
var l=this.state,n=l.parentEmail,s=l.showReminderModal,i=l.U13ReminderModal
return React.createElement("div",{className:(0,_classnames2.default)("notification-bar",(0,_aphrodite.css)(styles.bannerWrapper))},React.createElement("div",{className:(0,_aphrodite.css)(styles.banner)},React.createElement("div",{className:(0,_aphrodite.css)(styles.bannerInner),onClick:this.handleClick},$_({days:r},"Your parent or guardian must approve your account or it will be deleted in %(days)s.")," ",React.createElement("a",{className:(0,_aphrodite.css)(styles.learnWhy),href:"javascript:void(0)",onClick:this.handleClick,tabIndex:"1"},this.renderCTAText())),s&&i&&React.createElement(i,{daysLeft:t,daysLeftString:r,parentEmail:n,onUpdateParentEmail:this.updateParentEmail,onClose:this.handleClose})))}
return a}(_react.Component)
var BANNER_HEIGHT=60
var styles=_aphrodite.StyleSheet.create({bannerWrapper:{position:"inherit",display:"block",backgroundImage:"url("+(0,_staticUrl2.default)(ORANGE_BACKGROUND)+")"},banner:{display:"flex",alignItems:"center",justifyContent:"center",minHeight:BANNER_HEIGHT},bannerInner:babelHelpers.extends({},_globalStyles2.default.typography.bodySmallBold,(_babelHelpers$extends={color:_globalStyles2.default.colors.white,cursor:"pointer",textAlign:"center"},_babelHelpers$extends[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({padding:10},_globalStyles2.default.typography.bodyXsmallBold),_babelHelpers$extends)),learnWhy:{color:"white",textDecoration:"underline"}})
exports.default=U13ReminderNotification

});
KAdefine("javascript/notifications-package/site-outage-notification.jsx", function(require, module, exports) {
var classNames=require("classnames")
var React=require("react")
var _require=require("aphrodite"),css=_require.css,StyleSheet=_require.StyleSheet
var _require2=require("../shared-package/i18n.js"),_=_require2._,$_=_require2.$_,$i18nDoNotTranslate=_require2.$i18nDoNotTranslate
var _require3=require("../shared-package/absolute-links.js"),safeLinkTo=_require3.safeLinkTo
var severityMessage=function e(r){if(r==="ui"){return _("We've identified user interface issues and are working to fix them.")}else if(r==="minor"){return _("We've identified minor technical issues and are working to fix them.")}else if(r==="serious"){return _("We've identified technical issues and are working to fix them.")}console.error("Unexpected severity "+r+" in SiteOutageNotification.")
return""}
var categoryMessage=function e(r){if(r==="mobile"){return _("Native mobile applications may be affected.")}else if(r==="progress"){return _("Progress may be affected.")}else if(r==="mastery"){return _("Mastery may be affected.")}else if(r==="login"){return _("Login may be affected.")}else if(r==="exercises"){return _("Exercises may be affected.")}else if(r==="videos"){return _("Videos may be affected.")}else if(r==="scratchpads"){return _("Scratchpads may be affected.")}else if(r==="rostering"){return _("Classroom rostering may be affected.")}else if(r==="assignments"){return _("Classroom assignments may be affected.")}else if(r==="availability"){return _("Site availability may be affected.")}else if(r==="slowness"){return _("You may experience slowness.")}else if(r==="errors"){return _("You may experience errors.")}else if(r==="sat"){return _("SAT prep may be affected.")}else if(r==="testprep"){return _("Test prep may be affected.")}else if(r==="discussions"){return _("Discussions may be affected.")}else if(r==="general"){return""}console.error("Unexpected category "+r+" in SiteOutageNotification.")
return""}
var SiteOutageNotification=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props.context.severity
var t=this.props.context.category
var a=safeLinkTo("https://status.khanacademy.org")
var s=React.createElement("a",{href:a},$i18nDoNotTranslate(null,"status.khanacademy.org"))
var i=classNames("notification-bar",css(styles.banner))
return React.createElement("div",{className:i},React.createElement("div",{className:"notification-bar-inner"},React.createElement("span",{"data-test-id":"incident-banner",className:"notification-bar-content"},severityMessage(r)+" ",categoryMessage(t)+" ",$_({link:s},"Please see %(link)s for more information."))))}
return r}(React.Component)
var styles=StyleSheet.create({banner:{position:"static"}})
module.exports=SiteOutageNotification

});
KAdefine("javascript/notifications-package/donate-test-mode-notification.jsx", function(require, module, exports) {
var classNames=require("classnames")
var React=require("react")
var _require=require("aphrodite"),css=_require.css,StyleSheet=_require.StyleSheet
var _require2=require("../shared-package/i18n.js"),_=_require2._,$i18nDoNotTranslate=_require2.$i18nDoNotTranslate
var DonateTestModeNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=classNames("notification-bar",css(styles.banner))
return React.createElement("div",{className:t},React.createElement("div",{className:"notification-bar-inner"},React.createElement("span",{"data-test-id":"incident-banner",className:"notification-bar-content"},$i18nDoNotTranslate(null,"STRIPE TEST MODE IS ENABLED!"))))}
return t}(React.Component)
var styles=StyleSheet.create({banner:{position:"static",color:"yellow",fontWeight:"bold",fontFamily:["Comic Sans MS","cursive","sans-serif"]}})
module.exports=DonateTestModeNotification

});
KAdefine("javascript/notifications-package/readable-notification.jsx", function(require, module, exports) {
var _assignmentCreatedNotification=require("./readable-notifications/assignment-created-notification.jsx")
var _assignmentCreatedNotification2=babelHelpers.interopRequireDefault(_assignmentCreatedNotification)
var _assignmentDueDateNotification=require("./readable-notifications/assignment-due-date-notification.jsx")
var _assignmentDueDateNotification2=babelHelpers.interopRequireDefault(_assignmentDueDateNotification)
var _coachRequestAcceptedNotification=require("./readable-notifications/coach-request-accepted-notification.jsx")
var _coachRequestAcceptedNotification2=babelHelpers.interopRequireDefault(_coachRequestAcceptedNotification)
var _subjectMasteryAssignmentCreatedNotification=require("./readable-notifications/subject-mastery-assignment-created-notification.jsx")
var _subjectMasteryAssignmentCreatedNotification2=babelHelpers.interopRequireDefault(_subjectMasteryAssignmentCreatedNotification)
var React=require("react")
var AvatarNotification=require("./readable-notifications/avatar-notification.jsx")
var BadgeNotification=require("./readable-notifications/badge-notification.jsx")
var ClassMissionNotification=require("./readable-notifications/class-mission-notification.jsx")
var CoachRecommendationNotification=require("./readable-notifications/coach-recommendation-notification.jsx")
var CoachRequestNotification=require("./readable-notifications/coach-request-notification.jsx")
var GroupedBadgeNotification=require("./readable-notifications/grouped-badge-notification.jsx")
var InfoNotification=require("./readable-notifications/info-notification.jsx")
var ModNotification=require("./readable-notifications/mod-notification.jsx")
var NewAvatarNotification=require("./readable-notifications/new-avatar-notification.jsx")
var ResponseFeedbackNotification=require("./readable-notifications/response-feedback-notification.jsx")
var RewardNotification=require("./readable-notifications/reward-notification.jsx")
var SatCoachDataSharingRequestNotification=require("./readable-notifications/sat-coach-data-sharing-request-notification.jsx")
var ScratchpadFeedbackNotification=require("./readable-notifications/scratchpad-feedback-notification.jsx")
var classToComponentMap={AssignmentCreatedNotification:_assignmentCreatedNotification2.default,AssignmentDueDateNotification:_assignmentDueDateNotification2.default,AvatarNotification:AvatarNotification,BadgeNotification:BadgeNotification,ClassMissionNotification:ClassMissionNotification,CoachRecommendationNotification:CoachRecommendationNotification,CoachRequestNotification:CoachRequestNotification,CoachRequestAcceptedNotification:_coachRequestAcceptedNotification2.default,GroupedBadgeNotification:GroupedBadgeNotification,InfoNotification:InfoNotification,ModNotification:ModNotification,NewAvatarNotification:NewAvatarNotification,ResponseFeedbackNotification:ResponseFeedbackNotification,RewardNotification:RewardNotification,SatCoachDataSharingRequestNotification:SatCoachDataSharingRequestNotification,ScratchpadFeedbackNotification:ScratchpadFeedbackNotification,SubjectMasteryAssignmentCreatedNotification:_subjectMasteryAssignmentCreatedNotification2.default}
var ReadableNotification=function(i){babelHelpers.inherits(t,i)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,i.apply(this,arguments))}t.prototype.render=function i(){var t=this.props.class_.slice().reverse()
var a=t.filter(function(i){return classToComponentMap.hasOwnProperty(i)})
if(!a.length){return null}var e=classToComponentMap[a[0]]
return React.createElement(e,this.props)}
return t}(React.Component)
module.exports=ReadableNotification

});
KAdefine("javascript/notifications-package/components/base-readable-notification.jsx", function(require, module, exports) {
var _staticUrl=require("../../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var React=require("react")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var globalStyles=require("../../shared-styles-package/global-styles.js")
var _require2=require("../util.js"),markNotificationAsRead=_require2.markNotificationAsRead
var TimeAgo=require("../../react-components-package/timeago.jsx")
var iconSize=30
var iconMargin=9
var BaseReadableNotication=function(e){babelHelpers.inherits(t,e)
function t(){var a,r,i
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,n=Array(o),l=0;l<o;l++){n[l]=arguments[l]}return i=(a=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),r),r.getHref=function(){var e=r.props,t=e.url,a=e.markAsReadOnClick,i=e.urlsafeKey
var o=void 0
if(a&&t){o="/notifications/read?keys="+i+("&redirect_url="+encodeURIComponent(t))}else if(t){o=t}return o},r.handleClick=function(){var e=r.props,t=e.markAsReadOnClick,a=e.url,i=e.urlsafeKey,o=e.onClick
if(t&&!a){markNotificationAsRead(i)}if(o){o()}},r.handleKeyDown=function(e){var t=r.props.onKeyDown
var a=r.getHref()
if(e.key==="Enter"||e.key===" "){e.preventDefault()
if(a){window.location.href=a}else{r.handleClick()}}else if(t){t(e)}},a),babelHelpers.possibleConstructorReturn(r,i)}t.prototype.render=function e(){var t=this.props,a=t.onClick,r=t.innerRef,i=t.indexInNotificationsList,o=t.tabbable
var n=this.getHref()
var l=React.createElement("div",{className:css(styles.layout,a&&styles.button),onClick:this.handleClick,onKeyDown:this.handleKeyDown},this.props.brandNew&&React.createElement("div",{className:css(styles.new)}),React.createElement("div",{className:css(styles.icon)},React.createElement("img",{alt:"","aria-hidden":true,src:(0,_staticUrl2.default)(this.props.iconSrc),width:iconSize,height:iconSize})),React.createElement("div",{className:css(styles.content)},this.props.children),React.createElement("div",{className:css(styles.date)},React.createElement(TimeAgo,{time:this.props.date})))
return React.createElement("div",{ref:r,className:css(styles.notification,this.props.read===false&&styles.unread),"data-navigable-index":i},n?React.createElement("a",{href:n,className:css(styles.link),onKeyDown:this.handleKeyDown,tabIndex:o?0:-1},l):React.createElement("button",{className:css(styles.notAButton),onKeyDown:this.handleKeyDown,tabIndex:o?0:-1},l))}
return t}(React.Component)
BaseReadableNotication.defaultProps={markAsReadOnClick:true}
var styles=StyleSheet.create({notification:{backgroundColor:globalStyles.colors.gray95,color:globalStyles.colors.gray17,marginTop:4,":hover":{backgroundColor:globalStyles.colors.gray98,color:globalStyles.domainColors("default").domain3},fontSize:12},unread:{backgroundColor:globalStyles.colors.white},new:{backgroundColor:globalStyles.colors.kaGreen,width:6,height:6,borderRadius:"50%",position:"absolute",top:7,right:7},link:{textDecoration:"none",display:"block",color:"inherit"},button:{cursor:"pointer"},notAButton:{border:0,padding:0,margin:0,textAlign:"left",backgroundColor:"inherit",fontFamily:"inherit",fontSize:"inherit",lineHeight:"inherit"},layout:{display:"flex",flexFlow:"row wrap",position:"relative",borderBottom:"1px solid rgba(0, 0, 0, 0.1)",padding:16},icon:{width:iconSize,height:iconSize,flex:"0 "+iconSize+"px",marginRight:iconMargin,marginTop:5},content:{flex:"1 0",marginLeft:0,marginBottom:10},date:{color:globalStyles.colors.gray41,flex:"1 100%",marginLeft:iconSize+iconMargin}})
module.exports=BaseReadableNotication

});
KAdefine("javascript/notifications-package/components/dialog.jsx", function(require, module, exports) {
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _button=require("../../components/button-package/button.jsx")
var _button2=babelHelpers.interopRequireDefault(_button)
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var Spinner=require("../../shared-components-package/spinner.jsx")
var statuses={PROMPT:"PROMPT",PROGRESS:"PROGRESS",ACCEPTED:"ACCEPTED",DENIED:"DENIED",ERROR:"ERROR"}
var Dialog=function(e){babelHelpers.inherits(t,e)
function t(){var s,a,r
babelHelpers.classCallCheck(this,t)
for(var n=arguments.length,l=Array(n),c=0;c<n;c++){l[c]=arguments[c]}return r=(s=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),a),a.state={status:statuses.PROMPT},a.setStatus=function(e,t){a.setState({status:e},t)},a._handleAccept=function(e){if(a.props.preventDefault){e.preventDefault()}a.props.onAccept(a.setStatus)},a._handleDeny=function(e){if(a.props.preventDefault){e.preventDefault()}a.props.onDeny(a.setStatus)},s),babelHelpers.possibleConstructorReturn(a,r)}t.prototype.render=function e(){var t=this.props.viewMap
var s=this.state.status
if(t.hasOwnProperty(s)){return React.createElement("div",{className:css(styles.view)},t[s])}else if(s===statuses.PROMPT){return React.createElement("div",null,React.createElement("span",{className:css(styles.small)},React.createElement(_button2.default,{size:"small",onClick:this._handleAccept},this.props.acceptText)),React.createElement("span",{className:css(styles.small)},React.createElement(_button2.default,{type:"secondary",size:"small",onClick:this._handleDeny},this.props.denyText)))}else if(s===statuses.PROGRESS){return React.createElement("div",{className:css(styles.view)},React.createElement(Spinner,null))}else{return React.createElement("div",{className:css(styles.view)})}}
return t}(React.Component)
var styles=StyleSheet.create({small:{display:"inline-block",marginRight:10,marginTop:5},view:{height:21,padding:"5px 0",marginTop:5}})
module.exports=Dialog

});
KAdefine("javascript/notifications-package/components/discussion-content-modal.jsx", function(require, module, exports) {
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _modal=require("../../components/modal-package/modal.jsx")
var _modal2=babelHelpers.interopRequireDefault(_modal)
var _spinner=require("../../shared-components-package/spinner.jsx")
var _spinner2=babelHelpers.interopRequireDefault(_spinner)
var _timeago=require("../../react-components-package/timeago.jsx")
var _timeago2=babelHelpers.interopRequireDefault(_timeago)
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var DiscussionContentModal=function(e){babelHelpers.inherits(t,e)
function t(){var a,r,n
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,l=Array(o),s=0;s<o;s++){l[s]=arguments[s]}return n=(a=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),r),r.state={formatContent:null},a),babelHelpers.possibleConstructorReturn(r,n)}t.prototype.componentDidMount=function e(){var t=this
require.dynimport("../../corelibs-legacy-package/handlebars-extras.js").then(function(e){return e.default}).then(function(e){var a=e.formatContent
t.setState({formatContent:a})})}
t.prototype.render=function e(){var t=this.state.formatContent&&this.state.formatContent(this.props.content)
return React.createElement(_modal2.default,{hostInBody:true,onClose:this.props.onClose,style:styles.modal},React.createElement(_modal.ModalHeader,null,$_(null,"A Guardian left you a message")),React.createElement("div",{className:(0,_aphrodite.css)(styles.content)},t?React.createElement("span",{dangerouslySetInnerHTML:{__html:t}}):React.createElement(_spinner2.default,null)),React.createElement(_modal.ModalFooter,{style:{paddingLeft:24,paddingRight:24}},React.createElement(_timeago2.default,{time:this.props.date})))}
return t}(React.Component)
var styles=_aphrodite.StyleSheet.create({modal:{maxWidth:688},content:{padding:24}})
module.exports=DiscussionContentModal

});
KAdefine("javascript/notifications-package/readable-notifications/assignment-created-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseReadableNotification=require("../components/base-readable-notification.jsx")
var _baseReadableNotification2=babelHelpers.interopRequireDefault(_baseReadableNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var AssignmentCreatedNotification=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){var a=this.props,t=a.brandNew,n=a.read,s=a.date,r=a.url,i=a.urlsafeKey,l=a.coachAvatarUrl,o=a.coachName,c=a.contentTitle,u=a.topicIconUrl,m=a.numAssignments,b=a.className
var d=Number(m)>1
var p=!u||!c&&!d
var f=b?$_({className:React.createElement("strong",null,b)},"%(className)s"):""
var v=function e(a){return React.createElement("strong",null,i18n.ngettext("%(num)s new assignment","%(num)s new assignments",a))}
var N=void 0
var g=v(Number(m))
if(p){N=$_({coachName:React.createElement("strong",null,o)},"Your coach %(coachName)s has created an assignment for you.")}else if(d&&b){N=$_({newAssignments:g,classNameClause:f},"You have %(newAssignments)s for %(classNameClause)s!")}else if(d&&!b){N=$_({newAssignments:g},"You have %(newAssignments)s!")}else{N=$_({contentTitle:React.createElement("strong",null,c)},"New assignment! %(contentTitle)s")}return React.createElement(_baseReadableNotification2.default,babelHelpers.extends({brandNew:t,read:n,date:s,iconSrc:p?l:u,url:r,urlsafeKey:i},this.props),N)}
return a}(React.Component)
exports.default=AssignmentCreatedNotification

});
KAdefine("javascript/notifications-package/readable-notifications/subject-mastery-assignment-created-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseReadableNotification=require("../components/base-readable-notification.jsx")
var _baseReadableNotification2=babelHelpers.interopRequireDefault(_baseReadableNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var SubjectMasteryAssignmentCreatedNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props,a=t.masteryPercentage,r=t.topicTranslatedTitle,i=t.topicIconUrl,s=babelHelpers.objectWithoutProperties(t,["masteryPercentage","topicTranslatedTitle","topicIconUrl"])
return React.createElement(_baseReadableNotification2.default,babelHelpers.extends({brandNew:true,read:false,iconSrc:i},s),$_({masteryPercentage:a,topicTranslatedTitle:r},"New goal! Master %(masteryPercentage)s% of %(topicTranslatedTitle)s"))}
return t}(React.Component)
exports.default=SubjectMasteryAssignmentCreatedNotification

});
KAdefine("javascript/notifications-package/readable-notifications/assignment-due-date-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _moment=require("moment")
var _moment2=babelHelpers.interopRequireDefault(_moment)
var _baseReadableNotification=require("../components/base-readable-notification.jsx")
var _baseReadableNotification2=babelHelpers.interopRequireDefault(_baseReadableNotification)
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var AssignmentDueDateNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props,a=t.brandNew,r=t.read,n=t.date,o=t.url,i=t.urlsafeKey,l=t.coachAvatarUrl,s=t.coachName,c=t.contentTitle,u=t.dueDate,m=t.topicIconUrl
var d=!m||!c
var b=d?$_({coachName:React.createElement("strong",null,s)},"Your coach %(coachName)s has created an assignment for you."):$_({contentTitle:React.createElement("strong",null,c),dateMMDDYYYY:React.createElement("strong",null,(0,_moment2.default)(u).format("L")),timeHHMM:React.createElement("strong",null,(0,_moment2.default)(u).format("LT"))},"The due date for your assignment %(contentTitle)s has changed to %(dateMMDDYYYY)s at %(timeHHMM)s.")
return React.createElement(_baseReadableNotification2.default,babelHelpers.extends({brandNew:a,read:r,date:n,iconSrc:d?l:m,url:o,urlsafeKey:i},this.props),b)}
return t}(React.Component)
exports.default=AssignmentDueDateNotification

});
KAdefine("javascript/notifications-package/readable-notifications/avatar-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var KA=require("../../shared-package/ka.js")
var AvatarNotification=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props.translatedCategoryTitle
var t=KA.getUserProfile()
var a=t?t.get("points"):0
var s=a>=this.props.pointsRequired
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.iconSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),s?$_({categoryTitle:React.createElement("strong",null,r)},"You've just unlocked your next set of avatars! %(categoryTitle)s"):$_({categoryTitle:React.createElement("strong",null,r)},"You're close to unlocking your next set of avatars! %(categoryTitle)s"))}
return r}(React.Component)
module.exports=AvatarNotification

});
KAdefine("javascript/notifications-package/readable-notifications/badge-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var BadgeNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.translatedDescription
var r=this.props.translatedTargetContextName
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.iconSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),r?$_({description:React.createElement("strong",null,t),targetContext:React.createElement("strong",null,r)},"You earned %(description)s in %(targetContext)s:"):$_({description:React.createElement("strong",null,t)},"You earned %(description)s:")," ",React.createElement("em",null,this.props.translatedExtendedDescription))}
return t}(React.Component)
module.exports=BadgeNotification

});
KAdefine("javascript/notifications-package/readable-notifications/class-mission-notification.jsx", function(require, module, exports) {
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var $_=i18n.$_
var ClassMissionNotification=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.imageSource,markAsReadOnClick:false,urlsafeKey:this.props.urlsafeKey,url:this.props.startUrl},this.props),$_({coachNickname:React.createElement("strong",null,this.props.coachNickname),missionName:React.createElement("strong",null,this.props.missionName)},"Your coach %(coachNickname)s has enrolled you in %(missionName)s"))}
return a}(React.Component)
module.exports=ClassMissionNotification

});
KAdefine("javascript/notifications-package/readable-notifications/coach-recommendation-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var CoachRecommendationNotification=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props.coachName
var a=this.props.recommendationTitle
var t=this.props.url||"/?learn=1"
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.coachAvatarUrl,url:t,urlsafeKey:this.props.urlsafeKey},this.props),$_({coachName:React.createElement("strong",null,r),recommendationTitle:React.createElement("strong",null,a)},"Your coach %(coachName)s recommended %(recommendationTitle)s for you."))}
return r}(React.Component)
module.exports=CoachRecommendationNotification

});
KAdefine("javascript/notifications-package/readable-notifications/coach-request-notification.jsx", function(require, module, exports) {
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var Dialog=require("../components/dialog.jsx")
var KA=require("../../shared-package/ka.js")
var ProfileModel=require("../../shared-package/profile-model.js")
var $_=i18n.$_
var withCoachModel=function e(a,n){require.dynimport("../../profile-package/coaches.js").then(function(e){return e.default}).then(function(e){var r=e.CoachCollection
var t=new ProfileModel(KA.getUserProfile().attributes)
var i=new r([],{userProfile:t})
i.query({kaid:t.get("kaid"),success:function e(r){var t=r.find(function(e){return e.get("kaid")===a})
n(t,r)}})})}
var CoachRequestNotification=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){var a=this.props,n=a.coachKaid,r=a.coachNickname
var t=void 0
var i=void 0
if(this.props.coachIsParent){t=$_({coachNickname:React.createElement("strong",null,r)},"%(coachNickname)s wants to register as your parent. They will have permission to view your activity and make practice recommendations.")
i=i18n._("Accept as parent")}else{t=$_({coachNickname:React.createElement("strong",null,r)},"%(coachNickname)s would like to be your coach. A coach has permission to view your activity and give you assignments.")
i=i18n._("Accept as coach")}return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:"/images/hand-tree.new.png",markAsReadOnClick:false,urlsafeKey:this.props.urlsafeKey},this.props),t,React.createElement(Dialog,{preventDefault:true,acceptText:i,denyText:i18n._("Deny request"),viewMap:{ACCEPTED:this.props.coachIsParent?$_({coachNickname:React.createElement("strong",null,r)},"Done! %(coachNickname)s is now your parent."):$_({coachNickname:React.createElement("strong",null,r)},"Done! %(coachNickname)s is now your coach."),DENIED:$_(null,"Thanks. Coach request denied."),ERROR:$_(null,"Error updating coaches.")},onAccept:function e(a){a("PROGRESS")
withCoachModel(n,function(e,n){if(!e||!n){return a("ERROR")}n.bind("saveSuccess",function(){return a("ACCEPTED")})
n.bind("saveError",function(){return a("ERROR")})
if(e.get("isCoachingLoggedInUser")){e.trigger("change",e)}else{e.set({isCoachingLoggedInUser:true})}})},onDeny:function e(a){a("PROGRESS")
withCoachModel(n,function(e,n){if(!e||!n){return a("ERROR")}n.bind("saveSuccess",function(){return a("DENIED")})
n.bind("saveError",function(){return a("ERROR")})
n.remove(typeof e.cid!=="undefined"?e.cid:e.id)})}}))}
return a}(React.Component)
module.exports=CoachRequestNotification

});
KAdefine("javascript/notifications-package/readable-notifications/coach-request-accepted-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseReadableNotification=require("../components/base-readable-notification.jsx")
var _baseReadableNotification2=babelHelpers.interopRequireDefault(_baseReadableNotification)
var _staticUrl=require("../../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var DEFAULT_ICON="/images/coach/default_class.svg"
var CoachRequestAcceptedNotification=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){var a=this.props,t=a.brandNew,r=a.read,s=a.date,i=a.url,c=a.urlsafeKey,l=a.imageSource,n=a.studentIdentifier,o=a.classInfo
var u=React.createElement("strong",null,n)
var d=o?$_({student:u,class:React.createElement("strong",null,o)},"%(student)s has joined %(class)s"):$_({student:u},"%(student)s has accepted your coach request!")
return React.createElement(_baseReadableNotification2.default,babelHelpers.extends({brandNew:t,read:r,date:s,iconSrc:(0,_staticUrl2.default)(l||DEFAULT_ICON),url:i,urlsafeKey:c},this.props),d)}
return a}(_react.Component)
exports.default=CoachRequestAcceptedNotification

});
KAdefine("javascript/notifications-package/readable-notifications/grouped-badge-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var _require2=require("../util.js"),serialCommafy=_require2.serialCommafy
var GroupedBadgeNotification=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props,t=r.translatedDescriptions,a=r.translatedTargetContextNames
var s=t.map(function(e,r){var t=a[r]
return t?$_({desc:e,context:t},"%(desc)s in %(context)s"):e})
var i=s.map(function(e,r){return React.createElement("strong",{key:r},e)})
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.iconSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),$_({groupedBadgeDescription:serialCommafy(i)},"You earned %(groupedBadgeDescription)s."))}
return r}(React.Component)
module.exports=GroupedBadgeNotification

});
KAdefine("javascript/notifications-package/readable-notifications/info-notification.jsx", function(require, module, exports) {
var React=require("react")
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var InfoNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:"/images/hand-tree.new.png",url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),this.props.translatedText)}
return t}(React.Component)
module.exports=InfoNotification

});
KAdefine("javascript/notifications-package/readable-notifications/mod-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var DiscussionContentModal=require("../components/discussion-content-modal.jsx")
var _require2=require("../util.js"),ellipsis=_require2.ellipsis
var ModNotification=function(e){babelHelpers.inherits(t,e)
function t(){var a,s,r
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,i=Array(o),n=0;n<o;n++){i[n]=arguments[n]}return r=(a=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(i))),s),s.state={showModal:false},a),babelHelpers.possibleConstructorReturn(s,r)}t.prototype.render=function e(){var t=this
return React.createElement("div",null,React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:"/images/mod-exclam.png",onClick:function e(){return t.setState({showModal:true})},urlsafeKey:this.props.urlsafeKey},this.props),$_({aGuardian:React.createElement("strong",null,$_(null,"A guardian")),message:ellipsis(this.props.text,75)},'%(aGuardian)s left you a message: "%(message)s"')),this.state.showModal&&React.createElement(DiscussionContentModal,{title:$_(null,"A guardian left you a message"),content:this.props.text,date:this.props.date,onClose:function e(){return t.setState({showModal:false})}}))}
return t}(React.Component)
module.exports=ModNotification

});
KAdefine("javascript/notifications-package/readable-notifications/new-avatar-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var _require2=require("../util.js"),serialCommafy=_require2.serialCommafy
var NewAvatarNotification=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props.translatedDisplayName
var a=this.props.translatedRequirements.map(function(e,r){return React.createElement("em",{key:r},e)})
var t=!!a.length
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.thumbnailSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),React.createElement("div",null,$_(null,"A new avatar has been released!")),React.createElement("div",null,React.createElement("strong",null,r),t&&": ",t&&serialCommafy(a)))}
return r}(React.Component)
module.exports=NewAvatarNotification

});
KAdefine("javascript/notifications-package/readable-notifications/response-feedback-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var _require2=require("../util.js"),ellipsis=_require2.ellipsis
var ResponseFeedbackNotification=function(e){babelHelpers.inherits(s,e)
function s(){babelHelpers.classCallCheck(this,s)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}s.prototype.render=function e(){var s=this.props.authorNickname
var t=ellipsis(this.props.translatedFocusTitle,40)
var a=void 0
var r=void 0
if(this.props.feedbackIsProjectEvalRequest){a=$_({authorNickname:React.createElement("strong",null,s),focusTitle:React.createElement("strong",null,t)},"%(authorNickname)s requested a project evaluation on %(focusTitle)s")}else if(this.props.feedbackIsProjectEvalAnswer){a=$_({authorNickname:React.createElement("strong",null,s),focusTitle:React.createElement("strong",null,t)},"%(authorNickname)s evaluated your project %(focusTitle)s.")
r=this.props.feedbackIsPassingEvalAnswer?$_(null,"The project passed evaluation!"):$_(null,"The project needs more work.")}else if(this.props.feedbackIsQuestion){a=$_({authorNickname:React.createElement("strong",null,s),focusTitle:React.createElement("strong",null,t)},"%(authorNickname)s asked a question on %(focusTitle)s:")
r=ellipsis(this.props.content,75)}else if(this.props.feedbackIsReply){a=$_({authorNickname:React.createElement("strong",null,s),focusTitle:React.createElement("strong",null,t)},"%(authorNickname)s added a comment on %(focusTitle)s:")
r=ellipsis(this.props.content,75)}else{a=$_({authorNickname:React.createElement("strong",null,s),focusTitle:React.createElement("strong",null,t)},"%(authorNickname)s answered your question on %(focusTitle)s:")
r=ellipsis(this.props.content,75)}return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.authorAvatarSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),a," ",r)}
return s}(React.Component)
ResponseFeedbackNotification.defaultProps={feedbackIsProjectEvalRequest:false,feedbackIsProjectEvalAnswer:false,feedbackIsPassingEvalAnswer:false,feedbackIsQuestion:false,feedbackIsReply:false}
module.exports=ResponseFeedbackNotification

});
KAdefine("javascript/notifications-package/readable-notifications/reward-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var RewardNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.translatedDisplayName
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.thumbnailSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),React.createElement("div",null,$_({displayName:React.createElement("strong",null,t)},"You've just unlocked %(displayName)s!")),React.createElement("div",null,this.props.translatedRequirements.map(function(e,t){return React.createElement("div",{key:t},React.createElement("div",null,React.createElement("em",null,e)))})))}
return t}(React.Component)
module.exports=RewardNotification

});
KAdefine("javascript/notifications-package/readable-notifications/sat-coach-data-sharing-request-notification.jsx", function(require, module, exports) {
var React=require("react")
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var _require=require("../../shared-package/i18n.js"),$i18nDoNotTranslate=_require.$i18nDoNotTranslate
var SatCoachDataSharingRequestNotification=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){var a=React.createElement("div",null,$i18nDoNotTranslate(null,"Your coach "),React.createElement("strong",null,this.props.coachNickname)," ",$i18nDoNotTranslate(null,"would like you to share your SAT practice activity with them"))
return React.createElement(BaseReadableNotication,{brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:"/images/coach/default_class.svg",url:this.props.url,urlsafeKey:this.props.urlsafeKey},a)}
return a}(React.Component)
module.exports=SatCoachDataSharingRequestNotification

});
KAdefine("javascript/notifications-package/readable-notifications/scratchpad-feedback-notification.jsx", function(require, module, exports) {
var React=require("react")
var _require=require("../../shared-package/i18n.js"),$_=_require.$_
var BaseReadableNotication=require("../components/base-readable-notification.jsx")
var _require2=require("../util.js"),ellipsis=_require2.ellipsis
var ScratchpadFeedbackNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.authorNickname
var r=ellipsis(this.props.translatedScratchpadTitle,40)
var a=ellipsis(this.props.content,75)
return React.createElement(BaseReadableNotication,babelHelpers.extends({brandNew:this.props.brandNew,read:this.props.read,date:this.props.date,iconSrc:this.props.authorAvatarSrc,url:this.props.url,urlsafeKey:this.props.urlsafeKey},this.props),this.props.feedbackIsComment?$_({authorNickname:React.createElement("strong",null,t),scratchpadTitle:React.createElement("strong",null,r)},"%(authorNickname)s posted feedback on %(scratchpadTitle)s:"):$_({authorNickname:React.createElement("strong",null,t),scratchpadTitle:React.createElement("strong",null,r)},"%(authorNickname)s asked a new question about %(scratchpadTitle)s:")," ",a)}
return t}(React.Component)
module.exports=ScratchpadFeedbackNotification

});
KAdefine("javascript/notifications-package/toast-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _toast
exports.renderToast=renderToast
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactDom=require("react-dom")
var _reactDom2=babelHelpers.interopRequireDefault(_reactDom)
var _aphrodite=require("aphrodite")
var _archiveAssignmentNotification=require("./toast-notifications/archive-assignment-notification.jsx")
var _archiveAssignmentNotification2=babelHelpers.interopRequireDefault(_archiveAssignmentNotification)
var _assignmentCompletedNotification=require("./toast-notifications/assignment-completed-notification.jsx")
var _assignmentCompletedNotification2=babelHelpers.interopRequireDefault(_assignmentCompletedNotification)
var _classCreatedNotification=require("./toast-notifications/class-created-notification.jsx")
var _classCreatedNotification2=babelHelpers.interopRequireDefault(_classCreatedNotification)
var _autoAssignNotification=require("./toast-notifications/auto-assign-notification.jsx")
var _autoAssignNotification2=babelHelpers.interopRequireDefault(_autoAssignNotification)
var _createAssignmentNotification=require("./toast-notifications/create-assignment-notification.jsx")
var _createAssignmentNotification2=babelHelpers.interopRequireDefault(_createAssignmentNotification)
var _createSubjectMasteryAssignmentNotification=require("./toast-notifications/create-subject-mastery-assignment-notification.jsx")
var _createSubjectMasteryAssignmentNotification2=babelHelpers.interopRequireDefault(_createSubjectMasteryAssignmentNotification)
var _updateAssignmentNotification=require("./toast-notifications/update-assignment-notification.jsx")
var _updateAssignmentNotification2=babelHelpers.interopRequireDefault(_updateAssignmentNotification)
var _passwordResetNotification=require("./toast-notifications/password-reset-notification.jsx")
var _passwordResetNotification2=babelHelpers.interopRequireDefault(_passwordResetNotification)
var _recoveryEmailSentNotification=require("./toast-notifications/recovery-email-sent-notification.jsx")
var _recoveryEmailSentNotification2=babelHelpers.interopRequireDefault(_recoveryEmailSentNotification)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _constants=require("../shared-styles-package/constants.js")
var classToComponentMap={ArchiveAssignmentNotification:_archiveAssignmentNotification2.default,AssignmentCompletedNotification:_assignmentCompletedNotification2.default,ClassCreatedNotification:_classCreatedNotification2.default,AutoAssignNotification:_autoAssignNotification2.default,CreateAssignmentNotification:_createAssignmentNotification2.default,CreateSubjectMasteryAssignmentNotification:_createSubjectMasteryAssignmentNotification2.default,UpdateAssignmentNotification:_updateAssignmentNotification2.default,PasswordResetNotification:_passwordResetNotification2.default,RecoveryEmailSentNotification:_recoveryEmailSentNotification2.default}
var ToastNotification=function(t){babelHelpers.inherits(e,t)
function e(){babelHelpers.classCallCheck(this,e)
return babelHelpers.possibleConstructorReturn(this,t.apply(this,arguments))}e.prototype.render=function t(){var e=this.props.class_.slice().reverse()
var i=e.filter(function(t){return classToComponentMap.hasOwnProperty(t)})
if(!i.length){return null}var a=classToComponentMap[i[0]]
return React.createElement("div",{className:(0,_aphrodite.css)(styles.toast)},React.createElement(a,this.props))}
return e}(_react.Component)
exports.default=ToastNotification
var styles=_aphrodite.StyleSheet.create({toast:(_toast={position:"fixed",zIndex:_constants.zindexAboveModal,top:57,right:0},_toast["@media screen and (min-width: "+_globalStyles2.default.pageWidth+"px)"]={right:"calc((100% - "+_globalStyles2.default.pageWidth+"px) / 2)"},_toast)})
var container=void 0
function renderToast(t){if(!container){container=document.createElement("div")
document.body.appendChild(container)}_reactDom2.default.unmountComponentAtNode(container)
try{_reactDom2.default.render(React.createElement(ToastNotification,t),container)}catch(t){console.error(t)}}
});
KAdefine("javascript/notifications-package/components/base-toast-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _toast=require("../../components/toast-package/toast.jsx")
var _toast2=babelHelpers.interopRequireDefault(_toast)
var _errorToast=require("../../components/toast-package/error-toast.jsx")
var _errorToast2=babelHelpers.interopRequireDefault(_errorToast)
var BaseToastNotification=function(e){babelHelpers.inherits(t,e)
function t(){var r,a,o
babelHelpers.classCallCheck(this,t)
for(var s=arguments.length,i=Array(s),n=0;n<s;n++){i[n]=arguments[n]}return o=(r=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(i))),a),a.state={show:true},r),babelHelpers.possibleConstructorReturn(a,o)}t.prototype.render=function e(){var t=this
if(!this.state.show){return null}var r=this.props,a=r.children,o=r.linkText,s=r.href,i=r.autoTimeout,n=r.isError,l=r.testId
var u=n?_errorToast2.default:_toast2.default
return React.createElement(u,{linkText:o,href:s,onClose:function e(){return t.setState({show:false})},autoTimeout:n?undefined:i,testId:l},a)}
return t}(_react.Component)
BaseToastNotification.defaultProps={autoTimeout:4e3,isError:false}
exports.default=BaseToastNotification

});
KAdefine("javascript/notifications-package/toast-notifications/archive-assignment-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
exports.default=function(e){var t=e.successCount,s=e.failedCount,a=e.studentListName
return t===0?React.createElement(_baseToastNotification2.default,{isError:true},i18n.ngettext("Oops! Looks like deleting %(num)s assignment failed. Please try again!","Oops! Looks like deleting %(num)s assignments failed. Please try again!",s)):React.createElement(_baseToastNotification2.default,null,s?i18n._("You deleted %(sNum)s assignment(s) from your class %(studentListName)s but looks like deleting %(fNum)s assignment(s) failed. Please try again.",{sNum:t,studentListName:a,fNum:s}):i18n.ngettext("You deleted %(num)s assignment from your class %(studentListName)s.","You deleted %(num)s assignments from your class %(studentListName)s.",t,{num:t,studentListName:a}))}

});
KAdefine("javascript/notifications-package/toast-notifications/assignment-completed-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var AssignmentCompletedNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props,i=t.firstCompletion,r=t.studentListName
if(!i){return null}var a=$_(null,"You completed your assignment!")
if(r){a=$_({studentListName:React.createElement("strong",null,r)},"You completed your assignment for %(studentListName)s.")}return React.createElement(_baseToastNotification2.default,{linkText:i18n._("View assignments"),href:"/profile/me/assignments"},a)}
return t}(_react.Component)
exports.default=AssignmentCompletedNotification

});
KAdefine("javascript/notifications-package/toast-notifications/class-created-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var ClassCreatedNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props,a=t.studentListName,s=t.countStudents
var n=i18n.ngettext("%(num)s student","%(num)s students",s)
return React.createElement(_baseToastNotification2.default,null,s?$_({studentListName:React.createElement("strong",null,a),numStudents:React.createElement("strong",null,n)},"You imported a class %(studentListName)s that includes %(numStudents)s."):$_({studentListName:React.createElement("strong",null,a)},"You created a class %(studentListName)s."))}
return t}(_react.Component)
exports.default=ClassCreatedNotification

});
KAdefine("javascript/notifications-package/toast-notifications/auto-assign-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
exports.default=function(e){var r=e.isError
return React.createElement(_baseToastNotification2.default,{isError:r},r?$_(null,"Sorry, an error occurred while trying to process this request. Please try again."):$_(null,"We've updated your active and draft assignments to include your newly added students."))}

});
KAdefine("javascript/notifications-package/toast-notifications/create-assignment-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var ToastCopyMap={ASSIGN:{ERROR:function t(s,e,n){if(s===1){return i18n._("Oops! Looks like assigning %(title)s failed. Please try again!",{title:n})}return i18n._("Oops! Looks like assigning %(num)s assignments failed. Please try again!",{num:e})},SINGLE_CONTENT_SINGLE_CLASS:function t(s,e,n){return i18n.ngettext("You assigned %(title)s to %(num)s student in your class %(studentListName)s.","You assigned %(title)s to %(num)s students in your class %(studentListName)s.",e,{title:s,studentListName:n})},SINGLE_CONTENT_MULTI_CLASS:function t(s,e,n){if(n){var a=i18n.ngettext("You assigned %(title)s to %(num)s class.","You assigned %(title)s to %(num)s classes.",e,{title:s})
var i=i18n.ngettext(" %(emptyClassCount)s class was not assigned to because it had no students."," %(emptyClassCount)s classes were not assigned to because they had no students.",n,{emptyClassCount:n})
return a+i}return i18n._("You assigned %(title)s to %(classCount)s classes.",{title:s,classCount:e})},MULTI_CONTENT_SINGLE_CLASS:function t(s,e,n){return i18n.ngettext("You assigned %(contentCount)s items to %(num)s student in your class %(studentListName)s.","You assigned %(contentCount)s items to %(num)s students in your class %(studentListName)s.",e,{contentCount:s,studentListName:n})},MULTI_CONTENT_MULTI_CLASS:function t(s,e,n){if(n){return i18n.ngettext("You assigned %(contentCount)s items to %(classCount)s classes. %(num)s class was not assigned to because it had no students.","You assigned %(contentCount)s items to %(classCount)s classes. %(num)s classes were not assigned to because they had no students.",n,{contentCount:s,classCount:e})}return i18n._("You assigned %(contentCount)s items to %(classCount)s classes.",{contentCount:s,classCount:e})}},SAVE:{ERROR:function t(s,e,n){if(s===1){return i18n._("Oops! Looks like saving %(title)s failed. Please try again!",{title:n})}return i18n._("Oops! Looks like saving %(num)s assignments failed. Please try again!",{num:e})},SINGLE_CONTENT_SINGLE_CLASS:function t(s,e,n){return i18n.ngettext("You saved %(title)s to %(num)s student in your class %(studentListName)s.","You saved %(title)s to %(num)s students in your class %(studentListName)s.",e,{title:s,studentListName:n})},SINGLE_CONTENT_MULTI_CLASS:function t(s,e,_){return i18n._("You saved %(title)s to %(classCount)s classes.",{title:s,classCount:e})},MULTI_CONTENT_SINGLE_CLASS:function t(s,e,n){return i18n.ngettext("You saved %(contentCount)s items to %(num)s student in your class %(studentListName)s.","You saved %(contentCount)s items to %(num)s students in your class %(studentListName)s.",e,{contentCount:s,studentListName:n})},MULTI_CONTENT_MULTI_CLASS:function t(s,e,_){return i18n._("You saved %(contentCount)s items to %(classCount)s classes.",{contentCount:s,classCount:e})}}}
var isInAssignmentsTab=function t(){var s=/\/coach\/class\/\d+\/assignments/
return window.location.pathname.match(s)}
exports.default=function(t){var s=t.isDuplicateError,e=s===undefined?false:s,n=t.createAction,a=n===undefined?"ASSIGN":n,i=t.successContentCount,o=i===undefined?0:i,u=t.successClassCount,r=u===undefined?0:u,c=t.requestedClassCount,l=c===undefined?0:c,d=t.requestedContentCount,C=d===undefined?0:d,f=t.studentList,m=t.contentTitle,N=m===undefined?"":m,T=t.studentCount,L=T===undefined?0:T
if(e){return React.createElement(_baseToastNotification2.default,{isError:true},$_(null,"Oops! You have already created this assignment for these student(s) with this due date."))}var g=l-r
var S=l*C
var E=f&&f.name||""
var p=f&&f.id||""
var v={}
if(!isInAssignmentsTab()){var I=a==="SAVE"?"draft":"active"
if(l===1){v.href="/coach/class/"+p+"/assignments?assignmentFilter="+I
v.linkText=a==="SAVE"?i18n._("View saved assignments"):i18n._("View assignments")}else{v.href="/coach/dashboard"
v.linkText=i18n._("Go to dashboard")}}var b=babelHelpers.extends({},v,{testId:"assignment-toast-notification"})
if(o===0||r===0){return React.createElement(_baseToastNotification2.default,{isError:true},ToastCopyMap[a]["ERROR"](C,S,N))}else if(C===1&&l===1){return React.createElement(_baseToastNotification2.default,b,ToastCopyMap[a]["SINGLE_CONTENT_SINGLE_CLASS"](N,L,E))}else if(C===1&&l>1){return React.createElement(_baseToastNotification2.default,b,ToastCopyMap[a]["SINGLE_CONTENT_MULTI_CLASS"](N,r,g))}else if(C>1&&l===1){return React.createElement(_baseToastNotification2.default,b,ToastCopyMap[a]["MULTI_CONTENT_SINGLE_CLASS"](o,L,E))}else{return React.createElement(_baseToastNotification2.default,b,ToastCopyMap[a]["MULTI_CONTENT_MULTI_CLASS"](o,r,g))}}

});
KAdefine("javascript/notifications-package/toast-notifications/create-subject-mastery-assignment-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
exports.default=function(e){var t=e.studentList,a=e.numOfAssignedStudents
var s=t.name
var r="/coach/class/"+t.id+"/assignments"
var n=a===t.countStudents
var i=n?i18n._('Course mastery goal created for all students in "%(studentListName)s"',{studentListName:s}):i18n.ngettext('Course mastery goal created for %(num)s student in "%(studentListName)s."','Course mastery goal created for %(num)s students in "%(studentListName)s."',a,{studentListName:s})
return React.createElement(_baseToastNotification2.default,{linkText:i18n._("View in assignments tab"),href:r},i)}

});
KAdefine("javascript/notifications-package/toast-notifications/update-assignment-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
exports.default=function(e){var t=e.contentTitle,a=e.studentListName,i=a===undefined?"":a,r=e.isError,s=r===undefined?false:r
return React.createElement(_baseToastNotification2.default,{isError:s},s?$_({title:t},"Oops! Looks like editing %(title)s failed. Please try again!"):$_({title:t,studentListName:i},"You edited %(title)s in your class %(studentListName)s."))}

});
KAdefine("javascript/notifications-package/toast-notifications/password-reset-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var PasswordResetNotification=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.studentName
return React.createElement(_baseToastNotification2.default,{testId:"password-reset-toast"},i18n._("You reset the password for %(studentName)s.",{studentName:t}))}
return t}(React.Component)
exports.default=PasswordResetNotification

});
KAdefine("javascript/notifications-package/toast-notifications/recovery-email-sent-notification.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _baseToastNotification=require("../components/base-toast-notification.jsx")
var _baseToastNotification2=babelHelpers.interopRequireDefault(_baseToastNotification)
var i18n=require("../../shared-package/i18n.js")
var RecoveryEmailSentNotification=function(e){babelHelpers.inherits(r,e)
function r(){var t,a,o
babelHelpers.classCallCheck(this,r)
for(var s=arguments.length,n=Array(s),i=0;i<s;i++){n[i]=arguments[i]}return o=(t=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),a),a.renderToastSuccess=function(){var e=a.props.studentName
return React.createElement(_baseToastNotification2.default,{testId:"recovery-email-sent-toast"},i18n._("An account recovery email has been sent to %(studentName)s.",{studentName:e}))},a.renderToastError=function(){var e=a.props.errorMessage
return React.createElement(_baseToastNotification2.default,{isError:true},e)},t),babelHelpers.possibleConstructorReturn(a,o)}r.prototype.render=function e(){var r=this.props.errorMessage
return r?this.renderToastError():this.renderToastSuccess()}
return r}(React.Component)
exports.default=RecoveryEmailSentNotification

});
KAdefine("javascript/notifications-package/util.js", function(require, module, exports) {
var React=require("react")
var _require=require("../shared-package/i18n.js"),$_=_require.$_
var BigBingo=require("../shared-package/bigbingo.js")
var _require2=require("../shared-package/khan-fetch.js"),khanFetch=_require2.khanFetch
var KA=require("../shared-package/ka.js")
var deleteNotification=function e(t){BigBingo.markConversion("global_nav_open_notification")
var n=khanFetch("/api/internal/user/notifications/"+t,{method:"DELETE"})
return KA.IS_DEV_SERVER?n:n.catch(function(e){return Promise.resolve()})}
var markNotificationAsRead=function e(t){BigBingo.markConversion("global_nav_open_notification")
var n=khanFetch("/api/internal/user/notifications/"+t+"/read",{method:"POST"})
return KA.IS_DEV_SERVER?n:n.catch(function(e){return Promise.resolve()})}
var ellipsis=function e(t,n){if(!t||n<=3){return""}else if(t.length<=n){return t}else{return t.slice(0,n-3)+"..."}}
var intersperse=function e(t,n){if(t.length===0){return[]}return t.slice(1).reduce(function(e,t){return e.concat([n,t])},[t[0]])}
var serialCommafy=function e(t){var n=t.length
if(n===0){return null}else if(n===1){return t[0]}else if(n===2){return React.createElement("span",null,$_({item1:t[0],item2:t[1]},"%(item1)s and %(item2)s"))}else{var r=React.createElement("span",null,intersperse(t.slice(0,n-1),", "))
return React.createElement("span",null,$_({items_with_commas:r,last_item:t[n-1]},"%(items_with_commas)s, and %(last_item)s"))}}
var dispatchEvent=function(){var e={}
var t=function t(n){var r=e[n]
if(r){return r}if(typeof Event==="function"){r=new Event(n)}else{r=document.createEvent("Event")
r.initEvent(n,true,true)}e[n]=r
return r}
return function(e,n){return n.dispatchEvent(t(e))}}()
module.exports={deleteNotification:deleteNotification,markNotificationAsRead:markNotificationAsRead,ellipsis:ellipsis,serialCommafy:serialCommafy,dispatchEvent:dispatchEvent}

});
KAdefine("javascript/notifications-package/age-selector.jsx", function(require, module, exports) {
var React=require("react")
var _=require("underscore")
var i18n=require("../shared-package/i18n.js")
var Select=require("../shared-components-package/select.jsx")
var AgeSelector=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=1
var t=140
var n=_.times(t-r+1,function(e){return[e+r,e+r]})
return React.createElement(Select,babelHelpers.extends({},this.props,{options:n,blankText:i18n._("Age")}))}
return r}(React.Component)
module.exports=AgeSelector

});
; KAdefine.updatePathToPackageMap({"javascript/corelibs-legacy-package/handlebars-extras.js": "corelibs-legacy.js", "javascript/donate-package/donate-form-controller.jsx": "donate.js", "javascript/donate-package/methods/paypal.js": "donate.js", "javascript/donate-package/methods/stripe.js": "donate.js", "javascript/login-package/u13-reminder-modal.jsx": "login.js", "javascript/phantom-package/notifications.js": "phantom.js", "javascript/profile-package/coaches.js": "profile.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/notifications-package.js.map 