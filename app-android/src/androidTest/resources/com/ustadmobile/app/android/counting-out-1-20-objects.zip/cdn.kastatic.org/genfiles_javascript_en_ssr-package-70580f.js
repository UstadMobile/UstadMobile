KAdefine("javascript/components/ssr-package/cookies-provider.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _cookies=require("../../shared-package/cookies.js")
var _cookies2=babelHelpers.interopRequireDefault(_cookies)
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v2")
var CookiesProvider=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props,o=r.mockOnFirstRender,t=r.children,n=r.placeholder
if(o&&n){throw new Error("placeholder may only be set in deferred mode.")}var i=o?function(){return t(mockCookies)}:n
return _react2.default.createElement(_wonderBlocksCoreV.WithSSRPlaceholder,{placeholder:i},function(){return t(_cookies2.default)})}
return r}(_react2.default.Component)
exports.default=CookiesProvider
var mockCookies={createCookie:function e(){throw new Error("Cannot use createCookie in <CookiesProvider mockOnFirstRender />")},readCookie:function e(){return null},eraseCookie:function e(){throw new Error("Cannot use eraseCookie in <CookiesProvider mockOnFirstRender />")},areCookiesEnabled:function e(){return false}}

});
KAdefine("javascript/components/ssr-package/ka-provider.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _ka=require("../../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v2")
var KAProvider=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props,a=r.mockOnFirstRender,t=r.children,n=r.placeholder
if(a&&n){throw new Error("placeholder may only be set in deferred mode.")}var o=a?function(){return t(mockKA)}:n
return _react2.default.createElement(_wonderBlocksCoreV.WithSSRPlaceholder,{placeholder:o},function(){return t(_ka2.default)})}
return r}(_react2.default.Component)
exports.default=KAProvider
var mockKA={getUserID:function e(){return undefined},getKaid:function e(){return undefined},currentServerTime:function e(){throw new Error("Cannot use currentServerTime in <KAProvider mockOnFirstRender />")},prefersReducedMotion:function e(){return true},noColorInVideos:function e(){return false},getUserProfile:function e(){return undefined},setUserProfile:function e(){throw new Error("Cannot use setUserProfile in <KAProvider mockOnFirstRender />")},getGlobalPermissions:function e(){return[]},isPrephantom:function e(){return true},isPhantom:function e(){return false},isDeveloper:function e(){return false},isLoggedIn:function e(){return false},addProfileChangeListener:function e(){throw new Error("Cannot use addProfileChangeListener in <KAProvider mockOnFirstRender />")},removeProfileChangeListener:function e(){throw new Error("Cannot use removeProfileChangeListener in <KAProvider mockOnFirstRender />")},featureFlag:function e(r){if(r==="LEARN_STORM_CURRENT_WEEK"){return-1}return false},setFeatureFlag:function e(){throw new Error("Cannot use setFeatureFlag in <KAProvider mockOnFirstRender />")},bingoId:undefined,commitSHA:"ffffffffffffffffffffffffffffffffffffffff",gaeStatsKeyPrefix:"kaprovider.mock",perseusNeedsExtraWidgets:false,showTutorialNav:false,jipt_dom_insert_checks:[],requestLogId:"kaprovider.mock",sentryRelease:"kaprovider.mock",stripePublicKey:"",userId:undefined,staticVersion:"kaprovider.mock",version:"kaprovider.mock",vipIssueReporter:false,reportData_:{},REACT_SSR:_ka2.default.REACT_SSR,FB_APP_ID:_ka2.default.FB_APP_ID,MAX_BIO_LENGTH:_ka2.default.MAX_BIO_LENGTH,mathjaxUrl:_ka2.default.mathjaxUrl,staticUrlBase:_ka2.default.staticUrlBase,IS_DEV_SERVER:_ka2.default.IS_DEV_SERVER,isBibliotronPage:_ka2.default.isBibliotronPage,isIE10:_ka2.default.isIE10,isIE11:_ka2.default.isIE11,isIOS:_ka2.default.isIOS,isIPad:_ka2.default.isIPad,isMobile:_ka2.default.isMobile,isPhone:_ka2.default.isPhone,isTablet:_ka2.default.isTablet,isZeroRated:_ka2.default.isZeroRated,kaLocale:_ka2.default.kaLocale,language:_ka2.default.language,languageIsRtl:_ka2.default.languageIsRtl,languageLocalName:_ka2.default.languageLocalName,languageYoutube:_ka2.default.languageYoutube,momentLocale:_ka2.default.momentLocale,icuLocale:_ka2.default.icuLocale,loginUrl:_ka2.default.loginUrl,usePreviewFMS:_ka2.default.usePreviewFMS}

});
KAdefine("javascript/ssr-package/eager-promise.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var EagerPromise=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.call(this,function(){throw new Error("Constructing an EagerPromise via 'new' is not allowed. "+"Please use EagerPromise.resolve.")}()))}r.resolveEagerly=function e(r){var t=Promise.resolve(r)
t._eagerResult__DO_NOT_USE=r
return t}
r.unwrap=function e(r){if("_eagerResult__DO_NOT_USE"in r){return r._eagerResult__DO_NOT_USE}else{throw new NotAnEagerPromiseError}}
r.unwrapAll=function e(t){return t.map(function(e){return r.unwrap(e)})}
r.maybeUnwrapAll=function e(t){try{return r.unwrapAll(t)}catch(e){if(e instanceof NotAnEagerPromiseError){return Promise.all(t)}throw e}}
return r}(Promise)
exports.default=EagerPromise
var NotAnEagerPromiseError=exports.NotAnEagerPromiseError=function(){function e(){babelHelpers.classCallCheck(this,e)}e.prototype.toString=function e(){return"Attempted to resolve something other than a EagerPromise"}
return e}()

});
KAdefine("javascript/ssr-package/is-ssr.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var KA=require("../shared-package/ka.js")
var isSSR=Boolean(KA.REACT_SSR)
exports.default=isSSR

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/ssr-package.js.map 