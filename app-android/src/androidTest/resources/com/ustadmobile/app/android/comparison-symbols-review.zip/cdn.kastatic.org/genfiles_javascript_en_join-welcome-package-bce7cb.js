KAdefine("javascript/join-welcome-package/join-modal.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _modal,_container,_previewContainer,_body,_bodyItem
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _wonderBlocksLinkV=require("@khanacademy/wonder-blocks-link-v3")
var _wonderBlocksLinkV2=babelHelpers.interopRequireDefault(_wonderBlocksLinkV)
var _wonderBlocksSpacingV=require("@khanacademy/wonder-blocks-spacing-v2")
var _wonderBlocksSpacingV2=babelHelpers.interopRequireDefault(_wonderBlocksSpacingV)
var _wonderBlocksTypographyV=require("@khanacademy/wonder-blocks-typography-v1")
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v2")
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _mediaQueries=require("../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _button=require("../components/button-package/button.jsx")
var _button2=babelHelpers.interopRequireDefault(_button)
var _modal2=require("../components/modal-package/modal.jsx")
var _modal3=babelHelpers.interopRequireDefault(_modal2)
var i18n=require("../shared-package/i18n.js")
var JoinModal=function(e){babelHelpers.inherits(r,e)
function r(){var o,t,a
babelHelpers.classCallCheck(this,r)
for(var l=arguments.length,n=Array(l),s=0;s<l;s++){n[s]=arguments[s]}return a=(o=(t=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),t),t.state={showModal:true},t.handleClose=function(){var e=t.props.onClose
e()
t.setState({showModal:false})},o),babelHelpers.possibleConstructorReturn(t,a)}r.prototype.renderImage=function e(){return React.createElement("img",{className:(0,_aphrodite.css)(styles.image),src:(0,_staticUrl2.default)("/images/coach/pencilHand-800x.png"),alt:""})}
r.prototype.getHeadingText=function e(){var r=this.props.purpose
switch(r){case"welcome":return i18n.$_("Welcome to your class, %(className)s.",{className:React.createElement(_wonderBlocksCoreV.Text,{"data-test-id":"class-name-in-join-modal"},this.props.className)})
case"confirm":return i18n.$_("Join %(className)s class.",{className:this.props.className})}}
r.prototype.getBodyText=function e(){var r=this.props.purpose
switch(r){case"welcome":return i18n._("Assignments or goals your teacher creates for you will appear at the top of your Khan Academy home page.")
case"confirm":return React.createElement(_wonderBlocksCoreV.Text,null,i18n._("Not your class?")," ",React.createElement(_wonderBlocksLinkV2.default,{skipClientNav:true,href:"/coaches"},i18n._("Join a different class.")))}}
r.prototype.renderCTAText=function e(){var r=this.props.purpose
switch(r){case"welcome":return i18n._("Onward!")
case"confirm":return i18n._("Join class")}}
r.prototype.renderMessage=function e(){return React.createElement(_wonderBlocksCoreV.View,{style:styles.body},React.createElement(_wonderBlocksCoreV.View,{style:styles.bodyItem},React.createElement(_wonderBlocksTypographyV.HeadingLarge,null,this.getHeadingText())),React.createElement(_wonderBlocksCoreV.View,{style:styles.bodyItem},React.createElement(_wonderBlocksTypographyV.Body,null,this.getBodyText())))}
r.prototype.renderButton=function e(r){var o=this.props.onCTAClick
return React.createElement(_button2.default,{onClick:function e(){o()
r()},color:_wonderBlocksColorV2.default.blue,"data-test-id":"join-modal-cta"},this.renderCTAText())}
r.prototype.render=function e(){var r=this
var o=this.state.showModal
return o&&React.createElement(_modal3.default,{style:styles.modal,onClose:this.handleClose},function(e){var o=e.closeModal
return React.createElement(_wonderBlocksCoreV.View,{style:styles.container},React.createElement(_wonderBlocksCoreV.View,{style:styles.previewContainer},r.renderImage()),React.createElement(_wonderBlocksCoreV.View,{style:styles.contentContainer},React.createElement(_wonderBlocksCoreV.View,{style:styles.scroll},r.renderMessage()),React.createElement(_wonderBlocksCoreV.View,{style:styles.footer},r.renderButton(o))))})}
return r}(React.Component)
JoinModal.defaultProps={className:""}
exports.default=JoinModal
var MOBILE_GUTTER=52
var VERTICAL_FLOW_QUERY=_mediaQueries2.default.mdOrSmaller
var MOBILE_FULLSCREEN_QUERY=_mediaQueries2.default.xsOrSmaller
var styles=_aphrodite.StyleSheet.create({modal:(_modal={height:464,width:888,display:"flex",flexDirection:"column",overflow:"hidden"},_modal[VERTICAL_FLOW_QUERY]={height:"calc(100% - "+2*MOBILE_GUTTER+"px)",width:"calc(100% - "+2*MOBILE_GUTTER+"px)",borderRadius:_globalStyles.constants.baseBorderRadius},_modal[MOBILE_FULLSCREEN_QUERY]={height:"100%",width:"100%"},_modal),container:(_container={display:"flex",flex:1,flexDirection:"row",minHeight:0},_container[VERTICAL_FLOW_QUERY]={flexDirection:"column"},_container),previewContainer:(_previewContainer={display:"flex",backgroundColor:_wonderBlocksColorV2.default.darkBlue,flex:1,overflow:"hidden"},_previewContainer[VERTICAL_FLOW_QUERY]={alignItems:"center",minHeight:230},_previewContainer),contentContainer:{flex:1,display:"flex",flexDirection:"column"},scroll:{overflow:"auto",flex:1},footer:{borderTop:"solid 1px "+_wonderBlocksColorV2.default.offBlack32,display:"flex",alignItems:"center",flexDirection:"row-reverse",height:72,padding:"0 16px"},body:(_body={display:"flex",flexDirection:"column",paddingTop:_wonderBlocksSpacingV2.default.xxxLarge},_body[VERTICAL_FLOW_QUERY]={paddingTop:_wonderBlocksSpacingV2.default.xLarge},_body),bodyItem:(_bodyItem={display:"flex",flexGrow:1,marginLeft:52,marginRight:64,marginBottom:16},_bodyItem[VERTICAL_FLOW_QUERY]={marginLeft:_wonderBlocksSpacingV2.default.medium,marginRight:_wonderBlocksSpacingV2.default.medium,marginBottom:_wonderBlocksSpacingV2.default.medium},_bodyItem),image:{maxWidth:"100%",maxHeight:"100%",position:"absolute",bottom:0}})

});
KAdefine("javascript/join-welcome-package/join-modal-with-context.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.JoinModalCompleteContext=undefined
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query joinModalClassInfo($classCode: String!) {\n        studentList(classCode: $classCode) {\n            id\n            name\n        }\n    }\n"],["\n    query joinModalClassInfo($classCode: String!) {\n        studentList(classCode: $classCode) {\n            id\n            name\n        }\n    }\n"]),_templateObject2=babelHelpers.taggedTemplateLiteralLoose(["\n    mutation joinStudentMutation($classCode: String!) {\n        joinStudent(classCode: $classCode) {\n            errors\n        }\n    }\n"],["\n    mutation joinStudentMutation($classCode: String!) {\n        joinStudent(classCode: $classCode) {\n            errors\n        }\n    }\n"])
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactApollo=require("react-apollo")
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _apolloWrapper=require("../apollo-package/apollo-wrapper.jsx")
var _apolloWrapper2=babelHelpers.interopRequireDefault(_apolloWrapper)
var _dismissibleApi=require("../components/dismissible-package/dismissible-api.js")
var _parseQueryString=require("../shared-package/parse-query-string.js")
var _parseQueryString2=babelHelpers.interopRequireDefault(_parseQueryString)
var _joinModal=require("./join-modal.jsx")
var _joinModal2=babelHelpers.interopRequireDefault(_joinModal)
var CLASS_INFO_QUERY=(0,_graphqlTag2.default)(_templateObject)
var JOIN_STUDENT_MUTATION=(0,_graphqlTag2.default)(_templateObject2)
var JoinModalCompleteContext=exports.JoinModalCompleteContext=React.createContext(true)
var getDismissKeyForModalAndClassCode=function e(o,a){switch(o){case"welcome":return"join-welcome-modal-"+a
case"confirm":return"join-confirm-modal-"+a
default:return null}}
var JoinModalWithContext=function(e){babelHelpers.inherits(o,e)
function o(){var a,s,t
babelHelpers.classCallCheck(this,o)
for(var r=arguments.length,l=Array(r),n=0;n<r;n++){l[n]=arguments[n]}return t=(a=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),s),s.state={alreadyDismissed:"unknown",classCodeToUse:s.props.joinedClassCode||s.props.confirmJoinClassCode,closed:false,modalToShow:s.props.joinedClassCode?"welcome":s.props.confirmJoinClassCode?"confirm":null},s.handleClose=function(){var e=s.state,o=e.classCodeToUse,a=e.modalToShow
var t=o?getDismissKeyForModalAndClassCode(a,o):null
s.setState({closed:true})
if(a==="welcome"&&t!==null){(0,_dismissibleApi.dismiss)(t,"never")}},s.handleCTAClick=function(){var e=s.state,o=e.classCodeToUse,a=e.modalToShow
var t=o?getDismissKeyForModalAndClassCode(a,o):null
var r=a==="confirm"?(0,_apolloFetch.apolloMutate)(JOIN_STUDENT_MUTATION,{classCode:o}):Promise.resolve(true)
return r.then(function(){if(t!==null){(0,_dismissibleApi.dismiss)(t,"never")}})},a),babelHelpers.possibleConstructorReturn(s,t)}o.prototype.componentDidMount=function e(){var o=this
setTimeout(function(){return o.checkDismissed()})}
o.prototype.componentDidCatch=function e(){}
o.prototype.checkDismissed=function e(){var o=this
var a=this.state,s=a.classCodeToUse,t=a.modalToShow
var r=s?getDismissKeyForModalAndClassCode(t,s):null
if(s&&r){(0,_dismissibleApi.isDismissed)(r).then(function(e){o.setState({alreadyDismissed:e?"yes":"no"})})}}
o.prototype.getCompletion=function e(){var o=this.state,a=o.alreadyDismissed,s=o.classCodeToUse,t=o.closed
return!s||a==="yes"||t}
o.prototype.render=function e(){var o=this
var a=this.props.children
var s=this.state,t=s.alreadyDismissed,r=s.classCodeToUse,l=s.modalToShow
return React.createElement(_apolloWrapper2.default,null,React.createElement(JoinModalCompleteContext.Provider,{value:this.getCompletion()},r&&l&&React.createElement(_reactApollo.Query,{query:CLASS_INFO_QUERY,variables:{classCode:r}},function(e){var a=e.data
var s=a&&a.studentList
return t==="no"&&React.createElement(_joinModal2.default,{className:s&&s.name,onClose:o.handleClose,onCTAClick:o.handleCTAClick,purpose:l})}),a))}
return o}(React.Component)
JoinModalWithContext.defaultProps={confirmJoinClassCode:(0,_parseQueryString2.default)().confirmJoinClassCode,joinedClassCode:(0,_parseQueryString2.default)().joinedClassCode}
exports.default=JoinModalWithContext

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/join-welcome-package.js.map 