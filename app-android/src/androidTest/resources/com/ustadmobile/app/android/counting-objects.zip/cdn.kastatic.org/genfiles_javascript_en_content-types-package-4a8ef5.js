KAdefine("javascript/content-types-package/mastery-types.js", function(require, module, exports) {

});
KAdefine("javascript/content-types-package/practice-types.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var domainSlugMap=exports.domainSlugMap={math:"math","partner-content":"partner-content",computing:"computing","economics-finance-domain":"economics-finance-domain",gtp:"gtp",humanities:"humanities",science:"science","test-prep":"test-prep","college-careers-more":"college-careers-more","college-admissions":"college-careers-more",default:"default"}
var SUBJECT_CHALLENGE_QUIZ_TYPE=exports.SUBJECT_CHALLENGE_QUIZ_TYPE="subject-challenge"

});
KAdefine("javascript/content-types-package/status-types.js", function(require, module, exports) {

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/content-types-package.js.map 