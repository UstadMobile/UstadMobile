KAdefine("javascript/old-throbber-package/spinner.js", function(require, module, exports) {
var _jquery=require("jquery")
var _jquery2=babelHelpers.interopRequireDefault(_jquery)
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var Spinner={jElement:null,show:function e(r,n){if(!Spinner.jElement){Spinner.jElement=(0,_jquery2.default)("<img style='display:none;' "+"src='"+(0,_staticUrl2.default)("/images/spinner.gif")+"' "+"class='spinner'/>");(0,_jquery2.default)(document.body).append(Spinner.jElement)}if(!r.length){return}var t=r.offset()
var i=t.top+r.height()/2-8
var l=n?t.left-16-4:t.left+r.width()+4
Spinner.jElement.css("top",i).css("left",l).css("z-index",2e3).css("display","")},hide:function e(){if(Spinner.jElement){Spinner.jElement.css("display","none")}}}
module.exports=Spinner

});
KAdefine("javascript/sat-mission-package/util.js", function(require, module, exports) {
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var underscore=require("underscore")
var PropTypes=require("prop-types")
var moment=require("moment")
var absoluteLinks=require("../shared-package/absolute-links.js")
var i18n=require("../shared-package/i18n.js")
var _=require("../../third_party/javascript-khansrc/lodash/lodash.js")
var DEFAULT_EXAM_DATE_HOUR_OFFSET=4
var formatTimeSpan=function e(t){if(t<=60){return i18n.ngettext("%(num)s second","%(num)s seconds",t)}var r=t/60
return i18n.ngettext("%(num)s minute","%(num)s minutes",Math.ceil(r))}
var calculateSecondsRemaining=function e(t){var r=new Date
var n=t.getTime()-r.getTime()
return Math.max(0,Math.floor(n/1e3))}
var getWidgetIds=function e(t){var r=t.question.content
var n=r.match(/\[\[☃ [^ ]+ [0-9]+\]\]/g)||[]
var a=n.map(function(e){return e.slice("[[☃ ".length,-"]]".length)})
return a}
var _getWidgetType=function e(t){var r=t.match(/^[^ ]+/)
if(r===null){return null}return r[0]}
var isTwoColumnItem=function e(t){var r=t.question.content.match(/\n\n=====+\n\n/)
return!!r}
var shouldShowHints=function e(t){return!isTwoColumnItem(t)||getNumQuestionsInItem(t)<=1}
var getNumberOfHints=function e(t){return t.hints.length}
var getNumGroupsInItem=function e(t){var r=0
getWidgetIds(t).forEach(function(e){if(_getWidgetType(e)==="group"){++r}})
return r}
var hasPassage=function e(t){return getWidgetIds(t).map(_getWidgetType).some(function(e){return e==="group"})}
var getNumQuestionsInItem=function e(t){return Math.max(1,getNumGroupsInItem(t))}
var getQuestionHistory=function e(t){var r=[]
t.forEach(function(e){e.correct.forEach(function(t){var n={status:"incorrect",itemId:e.itemId}
if(e.hintsUsed){n.status="hint"}else if(t){n.status="correct"}r.push(n)})})
return r}
var waitForStyles=function e(t){return setTimeout(t,0)}
var getItemIndex=function e(t,r){var n=t.items.map(function(e){return getNumQuestionsInItem(JSON.parse(e.itemData))})
var a=n.map(function(e,t,r){return r.slice(0,t+1).reduce(function(e,t){return e+t})})
var s=a.findIndex(function(e){return r<e})
return s}
var getItemIndexForSection=function e(t,r,n){var a=void 0
for(var s=0;s<t.section.numItems;s++){var o=r.getEndingQuestionNumber(t,s+1)
if(n>o){continue}else{a=s
break}}if(a==null){throw new Error("Could not find question "+n)}return a}
var promptToReload=function e(){var t="Oh noes! There was a problem communicating with the "+"server. Click OK to reload and try again."
if(confirm(t)){window.location.href="/mission/sat"}else{window.location.href="/mission/sat"}}
var queuedThrottle=function e(t,r,n,a){var s=[]
var o=function e(){s.reverse()
s=underscore.uniq(s,undefined,function(e){return r.call(e[0],e[1])})
s.forEach(function(e){t.apply(e[0],e[1])})
s=[]}
var i=_.throttle(o,n,a)
var u=function e(){s.push([this,arguments])
i()}
u.flushQueue=o
return u}
var getReadableDomain=function e(t){switch(t){case"math":return"Math"
case"reading-and-writing":return"Reading & Writing"}console.error("Unknown domain",t)
return"Current Domain"}
var TASK_TYPES=["sat.practice","sat.practice-essay","sat.timed-mini-section","sat.diagnostic","sat.onboard"]
var getReadableTaskType=function e(t){switch(t){case"sat.practice":return"Practice"
case"sat.practice-essay":return"Practice Essay"
case"sat.timed-mini-section":return"Timed Mini-Section"
case"sat.diagnostic":return"Diagnostic"
case"sat.onboard":return"Onboard"
case"sat.schedule":return"Schedule"
case"sat.full-exam":return"Practice Test"}console.error("Unknown task type",t)
return"Task"}
var getOtherDomain=function e(t){if(t==="math"){return"reading-and-writing"}return"math"}
var setSessionStorageItem=function e(t,r){if(sessionStorage&&sessionStorage.setItem){sessionStorage.setItem(t,r)}}
var getSessionStorageItem=function e(t){if(sessionStorage&&sessionStorage.getItem){return sessionStorage.getItem(t)}return null}
var startCollegeboardOauth=function e(){window.location.href="/collegeboard/sessions/create"}
var getOnboardProgressSSKey=function e(t){return"sat-onboarding-progress-"+t}
var CB_ACCOMMODATIONS_LINK=absoluteLinks.safeLinkTo("https://www.collegeboard.org/"+"students-with-disabilities/"+"typical-accommodations/time")
var CB_REVIEW_LINK=absoluteLinks.safeLinkTo("https://studentscores.collegeboard.org/"+"viewscore")
var CB_SETTINGS_LINK=absoluteLinks.safeLinkTo("https://account.collegeboard.org/iamweb/"+"secure/smartUpdate")
var CB_REVOKE_ACCESS_LINK=absoluteLinks.safeLinkTo("https://cbsso.collegeboard.org/as/"+"oauth_access_grants.ping")
var EXAM_TIPS_LINK=absoluteLinks.safeLinkTo("https://www.khanacademy.org/"+"test-prep/sat/new-sat-tips-planning/new-sat-how-to-prep/a/"+"tips-for-test-day")
var FAQ_LINK=absoluteLinks.safeLinkTo("https://www.khanacademy.org/"+"test-prep/sat/new-sat-tips-planning/new-sat-how-to-prep/a/"+"frequently-asked-questions-about-the-official-sat-practice")
var IDEA_LINK=absoluteLinks.safeLinkTo("https://khanacademy.zendesk.com/"+"hc/en-us/community/topics/"+"200839048-SAT-Test-Prep")
var PROBLEM_LINK=absoluteLinks.safeLinkTo("https://khanacademy.zendesk.com/hc/en-us/requests/new")
var PARENT_CHILD_SETTINGS_LINK=absoluteLinks.safeLinkTo("https://khanacademy.zendesk.com/hc/en-us/articles/"+"204795250-How-can-I-edit-my-child-s-settings")
var CB_LICENSE_LINK=(0,_staticUrl2.default)("https://s3.amazonaws.com/KA-share/sat/KA_CB_license.pdf")
var NUM_AVAILABLE_PRACTICE_EXAMS=8
var PERSONALIZE_CTA="Personalize"
var SCHEDULE_CTA="Schedule"
var NUM_QUESTIONS_PER_MINUTE=10/15
var numRequiredQuestions=function e(t){return t*NUM_QUESTIONS_PER_MINUTE}
var sessionWasCompleted=function e(t,r){return r>=numRequiredQuestions(t)}
var RequiredMomentType=function e(t,r,n){if(!(t[r]&&t[r]._isAMomentObject)){return new Error("Moment object required")}}
var MomentType=function e(t,r,n){if(!t[r]){return}return RequiredMomentType(t,r,n)}
var SourceType=PropTypes.oneOf(["practice-tab","exams-tab","review-tab","coach-tab"])
MomentType.isRequired=RequiredMomentType
var DAYS_OF_THE_WEEK={S:"Sunday",M:"Monday",T:"Tuesday",W:"Wednesday",Th:"Thursday",F:"Friday",Sa:"Saturday"}
var DATE_FORMAT="YYYY-MM-DD"
var DATETIME_FORMAT="YYYY-MM-DDThh:mm"
var TIME_FORMAT="h:mm a"
var parseDate=function e(t){return moment(t,DATE_FORMAT)}
var parseDateTime=function e(t){return moment(t,DATETIME_FORMAT)}
var parseTime=function e(t){return moment(t,TIME_FORMAT)}
var formatDate=function e(t){return t.format(DATE_FORMAT)}
var formatMinutes=function e(t){var r=Math.floor(t/60)
var n=r===1?"hour":"hours"
var a=t%60
var s=a===1?"minute":"minutes"
return(r>0?r+" "+n:"")+(r>0&&a>0?" ":"")+(a>0?a+" "+s:"")}
var formatTime=function e(t){return t.format("h:mm A")}
var getLocalSatMoment=function e(){return moment().subtract(4,"hours")}
var dateTimeToMoment=function e(t){var r=t.date.format("dddd, MMMM D ")+t.time
return moment(r,"dddd, MMMM D hh:mm A")}
var examDateValueToDateObject=function e(t){var r=arguments.length>1&&arguments[1]!==undefined?arguments[1]:DEFAULT_EXAM_DATE_HOUR_OFFSET
var n=JSON.parse(t)["examDate"]
if(!n){return null}return moment({year:n["year"],month:n["month"],day:n["day"],hour:r})}
var getFirstSkippedInSection=function e(t,r){var n=0
var a=function e(t){var a=r.find(function(e){return parseInt(e.problemNumber,10)===t+1})
if(!a||a.scores.length===0){return{v:{itemNumber:t,questionIndex:0,questionNumber:n}}}else if(a.scores.some(function(e){return e.type==="invalid"})){var s=a.scores.findIndex(function(e){return e.type==="invalid"})
return{v:{itemNumber:t,questionIndex:s,questionNumber:n+s}}}n+=a.scores.length}
for(var s=0;s<t;s++){var o=a(s)
if((typeof o==="undefined"?"undefined":babelHelpers.typeof(o))==="object")return o.v}return null}
var getSkippedItemsInTask=function e(t,r){var n=[]
var a=function e(t){if(!r||!r[t]){n.push([t,0])}else{r[t].correct.forEach(function(e,r){if(e===null){n.push([t,r])}})}}
for(var s=0;s<t;s++){a(s)}return n}
var numberToTitle=function e(t){return"Practice test "+t}
var titleToNumber=function e(t){var r=t.split(" ")
var n=r[r.length-1]
return parseInt(n,10)}
var isEssayPracticeTask=function e(t){if(!t){return false}var r=t.split("-"),n=r[0],a=r[1],_=r[2]
return a==="essay"&&n==="practice"}
var areAllDiagnosticsComplete=function e(t){return t!==null&&t.length===2}
var handleQuestionBookmarkChange=function e(t,r,n){var a=new Set(n)
if(r){a.add(t)}else{a.delete(t)}return Array.from(a).sort(function(e,t){return e-t})}
var SkillLevelChangePropType=PropTypes.shape({skillId:PropTypes.string,skillTitle:PropTypes.string,originalLevel:PropTypes.number,level:PropTypes.number,numCorrect:PropTypes.number,numQuestions:PropTypes.number})
var EssayScoresPropType=PropTypes.shape({reading:PropTypes.any,writing:PropTypes.any,analysis:PropTypes.any})
var EssayScoringPropType=PropTypes.shape({essayAttempt:PropTypes.string,exercise:PropTypes.string.isRequired,deadline:PropTypes.number,formTitle:PropTypes.string,item:PropTypes.objectOf(PropTypes.any).isRequired,lastSaveTime:PropTypes.string,numMinutes:PropTypes.number,startTime:PropTypes.string,submitTime:PropTypes.string,subscores:EssayScoresPropType})
var PracticeEssayType=PropTypes.shape({assignmentId:PropTypes.string.isRequired,author:PropTypes.string.isRequired,completionDt:PropTypes.string,domain:PropTypes.string.isRequired,editDt:PropTypes.string,readableId:PropTypes.string.isRequired,taskType:PropTypes.string.isRequired,title:PropTypes.string.isRequired,translatedTitle:PropTypes.string.isRequired,turnedIn:PropTypes.bool})
module.exports={areAllDiagnosticsComplete:areAllDiagnosticsComplete,calculateSecondsRemaining:calculateSecondsRemaining,CB_ACCOMMODATIONS_LINK:CB_ACCOMMODATIONS_LINK,CB_REVIEW_LINK:CB_REVIEW_LINK,CB_REVOKE_ACCESS_LINK:CB_REVOKE_ACCESS_LINK,CB_SETTINGS_LINK:CB_SETTINGS_LINK,dateTimeToMoment:dateTimeToMoment,DAYS_OF_THE_WEEK:DAYS_OF_THE_WEEK,EssayScoringPropType:EssayScoringPropType,EssayScoresPropType:EssayScoresPropType,examDateValueToDateObject:examDateValueToDateObject,formatDate:formatDate,formatMinutes:formatMinutes,formatTime:formatTime,formatTimeSpan:formatTimeSpan,getFirstSkippedInSection:getFirstSkippedInSection,getItemIndex:getItemIndex,getItemIndexForSection:getItemIndexForSection,getLocalSatMoment:getLocalSatMoment,getNumberOfHints:getNumberOfHints,getNumGroupsInItem:getNumGroupsInItem,getNumQuestionsInItem:getNumQuestionsInItem,getOnboardProgressSSKey:getOnboardProgressSSKey,getOtherDomain:getOtherDomain,getQuestionHistory:getQuestionHistory,getReadableDomain:getReadableDomain,getReadableTaskType:getReadableTaskType,getSessionStorageItem:getSessionStorageItem,getSkippedItemsInTask:getSkippedItemsInTask,getWidgetIds:getWidgetIds,hasPassage:hasPassage,EXAM_TIPS_LINK:EXAM_TIPS_LINK,FAQ_LINK:FAQ_LINK,CB_LICENSE_LINK:CB_LICENSE_LINK,PARENT_CHILD_SETTINGS_LINK:PARENT_CHILD_SETTINGS_LINK,IDEA_LINK:IDEA_LINK,isEssayPracticeTask:isEssayPracticeTask,isTwoColumnItem:isTwoColumnItem,MomentType:MomentType,numberToTitle:numberToTitle,NUM_AVAILABLE_PRACTICE_EXAMS:NUM_AVAILABLE_PRACTICE_EXAMS,NUM_QUESTIONS_PER_MINUTE:NUM_QUESTIONS_PER_MINUTE,numRequiredQuestions:numRequiredQuestions,parseDate:parseDate,parseDateTime:parseDateTime,parseTime:parseTime,PracticeEssayType:PracticeEssayType,PROBLEM_LINK:PROBLEM_LINK,promptToReload:promptToReload,queuedThrottle:queuedThrottle,sessionWasCompleted:sessionWasCompleted,setSessionStorageItem:setSessionStorageItem,shouldShowHints:shouldShowHints,SkillLevelChangePropType:SkillLevelChangePropType,SourceType:SourceType,startCollegeboardOauth:startCollegeboardOauth,TASK_TYPES:TASK_TYPES,titleToNumber:titleToNumber,waitForStyles:waitForStyles,PERSONALIZE_CTA:PERSONALIZE_CTA,SCHEDULE_CTA:SCHEDULE_CTA,handleQuestionBookmarkChange:handleQuestionBookmarkChange}

});
KAdefine("javascript/settings-package/allow-coaches-setting.jsx", function(require, module, exports) {
var i18n=require("../shared-package/i18n.js")
var $=require("jquery")
var React=require("react")
var PropTypes=require("prop-types")
var ReactCSSTransitionGroup=require("react-addons-css-transition-group")
var ToggleSwitch=require("./toggle-switch.jsx")
var AllowCoachesSetting=function(e){babelHelpers.inherits(t,e)
function t(){var r,a,i
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,s=Array(o),n=0;n<o;n++){s[n]=arguments[n]}return i=(r=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),a),a.state={checked:a.props.checked},a.handleToggle=function(e){var t=e.target.checked
a.setState({checked:t})
$.ajax({type:"PUT",url:"/api/internal/user/capabilities?userId="+a.props.userId,data:t?{add:"modifycoaches"}:{remove:"modifycoaches"},error:a._displayError})},a._displayError=function(e,t,r){a.setState({errorMessage:i18n._("Your setting could not be saved"),checked:!a.state.checked})
a._triggerFadeOut()},a._triggerFadeOut=function(){var e=a
setTimeout(function(){e.setState({errorMessage:null})},2e3)},a.renderNotifications=function(){if(a.state.errorMessage){return React.createElement("div",{className:"notification notification-tip error"},a.state.errorMessage)}},r),babelHelpers.possibleConstructorReturn(a,i)}t.prototype.render=function e(){{}return React.createElement("div",{className:"toggle-switch-ajax"},React.createElement(ToggleSwitch,{checked:this.state.checked,switchKey:"canModifyCoaches",handleToggle:this.handleToggle}),React.createElement(ReactCSSTransitionGroup,{transitionName:"fade-in",transitionEnterTimeout:200,transitionLeaveTimeout:200},this.renderNotifications()))}
return t}(React.Component)
AllowCoachesSetting.propTypes={userId:PropTypes.string.isRequired,checked:PropTypes.bool.isRequired}
module.exports=AllowCoachesSetting

});
KAdefine("javascript/settings-package/birthdate-field.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _moment=require("moment")
var _moment2=babelHelpers.interopRequireDefault(_moment)
var _reactDatepicker=require("../../third_party/javascript-khansrc/react-datepicker/react-datepicker.js")
var _reactDatepicker2=babelHelpers.interopRequireDefault(_reactDatepicker)
var i18n=require("../shared-package/i18n.js")
function lessThan13YearsAgo(e){var t=(0,_moment2.default)().subtract(13,"years")
return(0,_moment2.default)(e).diff(t)>0}var BirthdateField=function(e){babelHelpers.inherits(t,e)
function t(){var r,a,i
babelHelpers.classCallCheck(this,t)
for(var n=arguments.length,o=Array(n),s=0;s<n;s++){o[s]=arguments[s]}return i=(r=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),a),a.state={birthdate:a.props.birthdate&&(0,_moment2.default)(a.props.birthdate)},a.handleChange=function(e){var t=a.props.actingAsParent
var r=!t&&lessThan13YearsAgo(e)?window.confirm(i18n._("If you change your birthdate to be "+"younger than 13, you will not be able to change it again "+"until you turn 13. Is this OK?")):true
if(r){a.setState({birthdate:e})}},r),babelHelpers.possibleConstructorReturn(a,i)}t.prototype.render=function e(){var t=this.state.birthdate
var r=this.props.isChildAccount
var a=React.createElement("input",{type:"hidden",id:"birthdate",name:"birthdate",value:t?(0,_moment2.default)(t).toISOString():""})
return React.createElement("div",null,a,React.createElement(_reactDatepicker2.default,{className:(0,_aphrodite.css)(styles.birthdateInput),selected:t,dateFormat:"LL",maxDate:(0,_moment2.default)(),showMonthDropdown:true,showYearDropdown:true,onChange:this.handleChange,disabled:r}))}
return t}(_react.Component)
var styles=_aphrodite.StyleSheet.create({birthdateInput:{width:"100%",marginRight:"16px"}})
exports.default=BirthdateField

});
KAdefine("javascript/settings-package/checkbox.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var KUICheckBox=require("../shared-components-package/checkbox.jsx")
var Checkbox=function(e){babelHelpers.inherits(r,e)
function r(){var t,a,c
babelHelpers.classCallCheck(this,r)
for(var o=arguments.length,s=Array(o),n=0;n<o;n++){s[n]=arguments[n]}return c=(t=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),a),a.state={checked:a.props.checked},a.handleToggle=function(e){var r=e.target.checked
a.setState({checked:r})
if(a.props.onChange){a.props.onChange(e)}},t),babelHelpers.possibleConstructorReturn(a,c)}r.prototype.render=function e(){var r=this.props,t=r.label,a=r.name
return React.createElement("div",null,React.createElement("div",{className:"control-label"},React.createElement("label",{className:"desc"},t)),React.createElement("div",{className:"controls checkbox-container"},React.createElement(KUICheckBox,{name:a,checked:this.state.checked,onChange:this.handleToggle})))}
return r}(React.Component)
Checkbox.propTypes={checked:PropTypes.bool.isRequired,label:PropTypes.string.isRequired,name:PropTypes.string.isRequired,onChange:PropTypes.func}
module.exports=Checkbox

});
KAdefine("javascript/settings-package/connect-email.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _modal
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _button=require("../components/button-package/button.jsx")
var _button2=babelHelpers.interopRequireDefault(_button)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _modal2=require("../components/modal-package/modal.jsx")
var _modal3=babelHelpers.interopRequireDefault(_modal2)
var _modalLauncher=require("../components/modal-package/modal-launcher.jsx")
var _modalLauncher2=babelHelpers.interopRequireDefault(_modalLauncher)
var _cookiesProvider=require("../components/ssr-package/cookies-provider.jsx")
var _cookiesProvider2=babelHelpers.interopRequireDefault(_cookiesProvider)
var i18n=require("../shared-package/i18n.js")
var $_=i18n.$_
var ConnectEmail=function(e){babelHelpers.inherits(a,e)
function a(){var t,r,l
babelHelpers.classCallCheck(this,a)
for(var o=arguments.length,n=Array(o),i=0;i<o;i++){n[i]=arguments[i]}return l=(t=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),r),r._form=null,r.getModal=function(e){var a=e.readCookie("fkey")
var t=React.createElement("a",{href:"/about/tos",target:"_blank"},$_(null,"Terms of Service"))
var l=React.createElement("a",{href:"/about/privacy-policy",target:"_blank"},$_(null,"Privacy Policy"))
var o={justifyContent:"flex-end",paddingLeft:16,paddingRight:16}
return React.createElement(_modal3.default,{style:styles.modal},React.createElement(_modal2.ModalHeader,null,$_(null,"Link an email address")),React.createElement("form",{action:"/settings/linkemail",method:"POST",ref:function e(a){return r._form=a}},React.createElement("input",{type:"hidden",name:"fkey",value:a}),React.createElement("div",{className:(0,_aphrodite.css)(styles.modalBody)},React.createElement("p",null,$_({termsOfService:t,privacyPolicy:l},"Enter your new email address and we'll send a confirmation email for you to open. By adding an email address you agree to our %(termsOfService)s and %(privacyPolicy)s.")),React.createElement("label",null,$_(null,"Email address")),React.createElement("input",{name:"email",type:"email"}))),React.createElement(_modal2.ModalFooter,{style:o},React.createElement(_button2.default,{onClick:function e(){r._form&&r._form.submit()}},$_(null,"Send confirmation email"))))},t),babelHelpers.possibleConstructorReturn(r,l)}a.prototype.render=function e(){var a=this
var t=this.props,r=t.buttonText,l=t.buttonClassNames
var o="connect-email-button"
var n=i18n._("(Opens a modal)")
return React.createElement(_cookiesProvider2.default,{mockOnFirstRender:true},function(e){return React.createElement(_modalLauncher2.default,{ariaLabel:r+" "+n,focusId:o,modal:a.getModal(e)},function(e,a){return React.createElement("input",{"aria-label":a,id:o,className:l,onClick:e,type:"button",value:r})})})}
return a}(_react.Component)
var styles=_aphrodite.StyleSheet.create({modal:(_modal={borderRadius:_globalStyles2.default.borderRadius,maxWidth:"50%",padding:0},_modal[_globalStyles2.default.queries.small]={minWidth:0,width:"100%",height:"100%",borderRadius:0},_modal),modalBody:{padding:16}})
exports.default=ConnectEmail

});
KAdefine("javascript/settings-package/email-reports-section.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var _=require("underscore")
var $_=require("../shared-package/i18n.js").$_
var KeySubscription=require("./key-subscription.jsx")
var i18n=require("../shared-package/i18n.js")
var RP=PropTypes
var ReportsSection=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=null
if(this.props.personalReport){t=React.createElement("div",null,React.createElement("p",null,$_(null,"Receive a summary of your activity for the week:")),React.createElement(KeySubscription,babelHelpers.extends({},this.props.personalReport,{subscriptionKey:this.props.personalReport.key})))}var r=null
if(this.props.hasStudents){var s=i18n.ngettext("Receive a separate email for this class:","Receive separate emails for these classes:",this.props.lists.length)
r=React.createElement("div",null,React.createElement("p",null,$_(null,"Receive a summary of what your students have been working on:")),React.createElement(KeySubscription,babelHelpers.extends({},this.props.allStudentsList,{subscriptionKey:this.props.allStudentsList.key})),_.any(this.props.lists)&&React.createElement("div",null,React.createElement("p",null,s),this.props.lists.map(function(e){return React.createElement(KeySubscription,babelHelpers.extends({},e,{subscriptionKey:e.key}))})))}var a=i18n.ngettext("Receive SAT activity emails for this class:","Receive SAT activity emails for these classes:",this.props.lists.length)
var i=React.createElement("div",null,_.any(this.props.satStudentsList)&&React.createElement("div",null,React.createElement("p",null,a),this.props.satStudentsList.map(function(e){return React.createElement(KeySubscription,babelHelpers.extends({},e,{subscriptionKey:e.key}))})))
var n=null
if(this.props.hasChildren){n=React.createElement("div",null,React.createElement("p",null,$_(null,"Receive a summary of what your children have been working on:")),React.createElement("div",null,this.props.childrenList.map(function(e){return React.createElement(KeySubscription,babelHelpers.extends({},e,{subscriptionKey:e.key}))})))}if(!t&&!r&&!n){return React.createElement("div",null)}return React.createElement("div",{className:"settings-section topics"},React.createElement("h3",null,$_(null,"Weekly activity reports")),React.createElement("form",{className:"form-horizontal"},t,n,r,i))}
return t}(React.Component)
ReportsSection.propTypes={allStudentsList:RP.object.isRequired,hasChildren:RP.bool.isRequired,childrenList:RP.arrayOf(RP.object).isRequired,lists:RP.arrayOf(RP.object).isRequired,satStudentsList:RP.any,personalReport:RP.object}
module.exports=ReportsSection

});
KAdefine("javascript/settings-package/email-settings.jsx", function(require, module, exports) {
var $=require("jquery")
var React=require("react")
var PropTypes=require("prop-types")
var classNames=require("classnames")
var guiders=require("../../third_party/javascript-khansrc/Guiders-JS/guiders.js")
var $_=require("../shared-package/i18n.js").$_
var GeneralSection=require("./general-section.jsx")
var NewslettersSection=require("./newsletters-section.jsx")
var NotificationsSection=require("./notifications-section.jsx")
var PrimaryEmailSection=require("./primary-email-section.jsx")
var ReportsSection=require("./email-reports-section.jsx")
var i18n=require("../shared-package/i18n.js")
var RP=PropTypes
var EmailSettings=function(e){babelHelpers.inherits(t,e)
function t(){var i,s,a
babelHelpers.classCallCheck(this,t)
for(var r=arguments.length,n=Array(r),o=0;o<r;o++){n[o]=arguments[o]}return a=(i=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),s),s.state={email:s.props.email,saving:false,checked:s.props.checked,error:false},s.emailChanged=function(e){var t=s.state.email
var i=e.target.value
s.setState({email:i,saving:true})
s.refs["primaryEmail"].putEmail(i).fail(function(){s.setState({email:t})}).always(function(){s.setState({saving:false})})},s.checkedChanged=function(e){var t=e.target.checked
s.setState({checked:t,error:false})
var i=t?"PUT":"DELETE"
return $.ajax({type:i,url:"/api/internal/user/subscription/"+s.props.subscriptionKey}).fail(function(){s.setState({checked:!t,error:true})})},s.doOneClickUnsub=function(e){var t=e.next("label")
guiders.createGuider({buttons:[{action:guiders.ButtonAction.CLOSE,text:i18n._("Close"),classString:"simple-button green"}],attachTo:t,highlight:t,position:3,offset:{left:5,top:0},title:i18n._("Successfully unsubscribed"),description:i18n._("This subscription has been turned off."),overlay:false,width:280}).show()
if(e.is(":checked")){e.click()}$(".settings-tab.email").one("click",".form-horizontal input, .form-horizontal select",function(){guiders.hideAll()})},i),babelHelpers.possibleConstructorReturn(s,a)}t.prototype.render=function e(){if(this.props.isChildView){return React.createElement("div",null,React.createElement("p",null,$_(null,"Sorry, email notifications are not available for child accounts. Come back after you turn 13!")),React.createElement("p",null,React.createElement("a",{href:"/settings/account"},$_(null,"Back to account settings"))))}if(!this.props.isEmailVerified){return React.createElement("div",null,React.createElement("p",null,$_(null,"Once you open the email we sent and finish signing up, you'll be able to receive other emails from Khan Academy.")))}if(!this.props.sendableEmail){return React.createElement("div",null,React.createElement("p",null,$_(null,"If you connect an email to your account, we'll be able to send you notifications and announcements about new stuff on Khan Academy. Don't worry though, we hate spam too, so we make it really easy to unsubscribe.")),React.createElement("div",{className:"form-horizontal"},React.createElement("div",{className:"control-group"},React.createElement("div",{className:"controls"},React.createElement("a",{className:"simple-button submit-button green",href:"/settings/account#linked-accounts"},$_(null,"Connect an email"))))))}var t=classNames({"email-rest":true,disabled:!this.state.checked})
return React.createElement("div",null,React.createElement(GeneralSection,{checked:this.state.checked,error:this.state.error,checkedChanged:this.checkedChanged}),React.createElement("div",{className:t},React.createElement(PrimaryEmailSection,{email:this.state.email,emails:this.props.emails,emailChanged:this.emailChanged,ref:"primaryEmail",saving:this.state.saving}),React.createElement(NotificationsSection,{masteryTask:this.props.masteryTask,answerNotification:this.props.answerNotification,assignmentNotification:this.props.assignmentNotification,evalNotification:this.props.evalNotification}),React.createElement(ReportsSection,{personalReport:this.props.personalReport,hasStudents:this.props.hasStudents,allStudentsList:this.props.allStudentsList,hasChildren:this.props.hasChildren,childrenList:this.props.childrenList,satStudentsList:this.props.satStudentsList,lists:this.props.studentLists}),React.createElement(NewslettersSection,{ref:"newslettersSection",token:this.props.token})))}
t.prototype.componentDidMount=function e(){var t=this
if(!this.props.token){return}if(!this.state.checked){return}var i="#toggle-switch-"+this.props.token
var s=$(i)
if(s.length){this.doOneClickUnsub(s)}else{this.refs["newslettersSection"].loadedPromise.then(function(){t.doOneClickUnsub($(i))})}}
return t}(React.Component)
EmailSettings.propTypes={isChildView:RP.bool.isRequired,isEmailVerified:RP.bool.isRequired,sendableEmail:RP.bool.isRequired,email:RP.string.isRequired,emails:RP.arrayOf(RP.string).isRequired,token:RP.string,checked:RP.bool.isRequired,subscriptionKey:RP.string.isRequired,personalReport:RP.object,masteryTask:RP.object.isRequired,answerNotification:RP.object,assignmentNotification:RP.object,evalNotification:RP.object,hasStudents:RP.bool.isRequired,allStudentsList:RP.object.isRequired,studentLists:RP.arrayOf(RP.object).isRequired,satStudentsList:RP.arrayOf(RP.object),hasChildren:RP.bool.isRequired,childrenList:RP.arrayOf(RP.object).isRequired}
module.exports=EmailSettings

});
KAdefine("javascript/settings-package/email-subscription.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var $_=require("../shared-package/i18n.js").$_
var ToggleSwitch=require("./toggle-switch.jsx")
var RP=PropTypes
var EmailSubscription=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r
var s
if(this.props.url){r=React.createElement("a",{href:this.props.url,className:"desc no-underline"},this.props.description)}else{var t="toggle-switch-"+this.props.subscriptionKey
s="control-label-"+this.props.subscriptionKey
r=React.createElement("label",{htmlFor:t,className:"desc",id:s},this.props.description)}var i
if(this.props.error){i=React.createElement("span",{className:"error"},React.createElement("i",{className:"icon-warning-sign"})," ",$_(null,"Error! Please try again :("))}var a="control-group "+this.props.subscriptionKey
return React.createElement("div",{className:a},React.createElement("div",{className:"control-label"},r),React.createElement("div",{className:"controls toggle-switch-container"},React.createElement(ToggleSwitch,{checked:this.props.checked,classes:this.props.classes,handleToggle:this.props.handleToggle,labelId:s,switchKey:this.props.subscriptionKey}),i))}
return r}(React.Component)
EmailSubscription.propTypes={checked:RP.bool.isRequired,subscriptionKey:RP.string.isRequired,description:RP.string.isRequired,handleToggle:RP.func.isRequired,classes:RP.string,url:RP.string,error:RP.bool}
module.exports=EmailSubscription

});
KAdefine("javascript/settings-package/forms.js", function(require, module, exports) {
var $=require("jquery")
var Backbone=require("backbone")
var _=require("underscore")
var i18n=require("../shared-package/i18n.js")
var Forms={}
Forms.Form=Backbone.View.extend({initialize:function r(t){var i=t["validatorDefaults"]||{}
var e=t["validators"]||{}
_.each(e,function(r,t){var s=_.extend({},{msg:i18n._("Invalid field"),selector:"#"+t,errorSelector:"#"+t+"-message"},i)
e[t]=_.defaults(r,s)})
this.options["validators"]=e
this.$form=this.$el
this.validatorOptions=this.options["validators"]
this.validatedInputIds=_.keys(this.validatorOptions)
this.validators=this._configureValidators(this.validatorOptions)
this.$form.on("submit",_.bind(this._onSubmitRequested,this))},_configureValidators:function r(t){var i=this
return _.map(t,function(r,t){var e=i._getBuiltinValidator(r)||r["validate"]
if(!_.isFunction(e)){throw new Error("No validators matched for "+t)}var s=i.$form.find(r["selector"])
var n=r["msg"]
if(s.length===0){return function(){return true}}var a=function r(){var a=s.val()
if(!e(a)){i.onInputError(t,n)
return false}else{i.onInputValid(t)
return true}}
var o=r["autocheck"]
if(o==="blur"){s.on("blur",_.bind(i._maybeValidateOnBlur,i,a))}else if(_.isNumber(o)){s.on("input",_.debounce(a,o))}return a})},isEmpty:function r(){return _.all(this.$form.find("input"),function(r){var t=$(r)
var i=t.attr("type").toLowerCase()
if(i==="button"||i==="submit"){return true}return _.isEmpty($.trim(t.val()))})},_maybeValidateOnBlur:function r(t){if(this.isEmpty()&&!this.$form.is(":focus")){return}t()},_getBuiltinValidator:function r(t){if(!_.isString(t["validate"])){return null}if(t["validate"]==="required"){return function(r){return!_.isEmpty($.trim(r))}}return null},_onSubmitRequested:function r(t){t.preventDefault()
if(this._submitDisabled){return}var i=this.validateForm()
if(_.isEmpty(i)){this.submitInternal()
return}var e=_.first(i)
$(this.validatorOptions[e]["selector"]).focus()},submitInternal:function r(){this.disableSubmit()
var t=this
$.ajax({type:"POST",url:this.$form.attr("action"),data:this.$form.serialize(),dataType:"json",success:_.bind(this.onServerResponse,this),error:_.bind(this.onServerError,this),complete:function r(){t.restoreSubmit()}})},disableSubmit:function r(){this._submitDisabled=true
this.$form.find("input[type='submit']").prop("disabled",true)},_submitDisabled:false,restoreSubmit:function r(){this._submitDisabled=false
this.$form.find("input[type='submit']").prop("disabled",false)},onServerResponse:function r(t){var i=t["errors"]
if(_.isEmpty(i)){this.trigger("success",t)
return}var e=this
_.each(i,function(r,t){e.onInputError(t,r)})
var s=_.first(_.keys(i))
$(this.validatorOptions[s]["selector"]).focus()
this.trigger("error",t)},onServerError:function r(t){this.trigger("error",t)},onInputError:function r(t,i){var e=this.validatorOptions[t]
if(!e){return}var s=this.$form.find(e["selector"])
var n=this.$form.find(e["errorSelector"])
s.addClass("error")
if($.trim(n.text())===""){n.hide()}n.addClass("error").text(i).fadeIn("fast")},onInputValid:function r(t){var i=this.validatorOptions[t]
if(!i){return}var e=this.$form.find(i["selector"])
var s=this.$form.find(i["errorSelector"])
e.removeClass("error")
s.fadeOut("fast",function(){s.removeClass("error").html("&nbsp;")})},validateForm:function r(){var t=[]
for(var i=0,e=this.validators.length;i<e;i++){var s=this.validators[i]
if(!s()){t.push(this.validatedInputIds[i])}}return t}})
module.exports=Forms

});
KAdefine("javascript/settings-package/general-section.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var classNames=require("classnames")
var $_=require("../shared-package/i18n.js").$_
var EmailSubscription=require("./email-subscription.jsx")
var i18n=require("../shared-package/i18n.js")
var RP=PropTypes
var GeneralSection=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=classNames({"email-critical":true,disabled:this.props.checked})
return React.createElement("div",{className:"settings-section general"},React.createElement("h3",null,$_(null,"General")),React.createElement("form",{className:"form-horizontal"},React.createElement("p",null,$_(null,"Occasionally we'll send you email that we think you'll appreciate. If you'd rather not receive any email from Khan Academy, turn it off here.")),React.createElement(EmailSubscription,{subscriptionKey:"all-email",description:i18n._("Enable email"),handleToggle:this.props.checkedChanged,error:this.props.error,checked:this.props.checked,classes:"off-red"}),React.createElement("p",{className:r},$_(null,"Note that you may still receive critical email such as forgotten password resets."))))}
return r}(React.Component)
GeneralSection.propTypes={checked:RP.bool.isRequired,error:RP.bool,checkedChanged:RP.func.isRequired}
module.exports=GeneralSection

});
KAdefine("javascript/settings-package/key-subscription.jsx", function(require, module, exports) {
var $=require("jquery")
var React=require("react")
var PropTypes=require("prop-types")
var EmailSubscription=require("./email-subscription.jsx")
var RP=PropTypes
var KeySubscription=function(e){babelHelpers.inherits(r,e)
function r(){var t,s,i
babelHelpers.classCallCheck(this,r)
for(var o=arguments.length,p=Array(o),c=0;c<o;c++){p[c]=arguments[c]}return i=(t=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(p))),s),s.state={checked:s.props.checked,error:false},s.handleToggle=function(e){var r=e.target.checked
s.setState({checked:r,error:false})
var t=r?"PUT":"DELETE"
return $.ajax({type:t,url:"/api/internal/user/subscription/"+s.props.subscriptionKey}).fail(function(){s.setState({checked:!r,error:true})})},t),babelHelpers.possibleConstructorReturn(s,i)}r.prototype.render=function e(){return React.createElement(EmailSubscription,{subscriptionKey:this.props.subscriptionKey,checked:this.state.checked,error:this.state.error,description:this.props.description,url:this.props.url,handleToggle:this.handleToggle})}
return r}(React.Component)
KeySubscription.propTypes={checked:RP.bool.isRequired,subscriptionKey:RP.string.isRequired,description:RP.string.isRequired,url:RP.string}
module.exports=KeySubscription

});
KAdefine("javascript/settings-package/newsletters-section.jsx", function(require, module, exports) {
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query getSubscriptionsByUser {\n        user {\n            id\n            subscriptions {\n                checked\n                description\n                key\n            }\n        }\n    }\n"],["\n    query getSubscriptionsByUser {\n        user {\n            id\n            subscriptions {\n                checked\n                description\n                key\n            }\n        }\n    }\n"]),_templateObject2=babelHelpers.taggedTemplateLiteralLoose(["\n    query getSubscriptionsByToken($token: String!) {\n        subscriptions(token: $token) {\n            checked\n            description\n            key\n        }\n    }\n"],["\n    query getSubscriptionsByToken($token: String!) {\n        subscriptions(token: $token) {\n            checked\n            description\n            key\n        }\n    }\n"])
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _apolloFetch2=babelHelpers.interopRequireDefault(_apolloFetch)
var $=require("jquery")
var PropTypes=require("prop-types")
var React=require("react")
var $_=require("../shared-package/i18n.js").$_
var KeySubscription=require("./key-subscription.jsx")
var Spinner=require("../shared-components-package/spinner.jsx")
var RP=PropTypes
var STATES={LOADING:1,LOADED:2,ERROR:3}
var QUERY_BY_USER=(0,_graphqlTag2.default)(_templateObject)
var QUERY_BY_TOKEN=(0,_graphqlTag2.default)(_templateObject2)
var NewslettersSection=function(e){babelHelpers.inherits(t,e)
function t(){var n,r,a
babelHelpers.classCallCheck(this,t)
for(var s=arguments.length,o=Array(s),i=0;i<s;i++){o[i]=arguments[i]}return a=(n=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),r),r.state={loading:STATES.LOADING},r.loadPreferences=function(){r.setState({loading:STATES.LOADING})
if(r.props.token){(0,_apolloFetch2.default)(QUERY_BY_TOKEN,{token:r.props.token}).then(function(e){var t=e.data.subscriptions
r.setState({subs:t,loading:STATES.LOADED})},function(e){r.setState({loading:STATES.ERROR})})}else{(0,_apolloFetch2.default)(QUERY_BY_USER).then(function(e){var t=e.data.user.subscriptions
r.setState({subs:t,loading:STATES.LOADED})},function(e){r.setState({loading:STATES.ERROR})})}},r.retryClicked=function(e){r.loadPreferences()
e.preventDefault()},n),babelHelpers.possibleConstructorReturn(r,a)}t.prototype.UNSAFE_componentWillMount=function e(){this._loadedDfd=$.Deferred()
this.loadedPromise=this._loadedDfd.promise()
this.loadPreferences()}
t.prototype.render=function e(){var t
if(this.state.loading===STATES.LOADING){t=React.createElement(Spinner,null)}else if(this.state.loading===STATES.ERROR){t=React.createElement("p",null,$_({tryAgain:React.createElement("a",{href:"void 0",onClick:this.retryClicked},$_(null,"click here to try again"))},"Sorry, something went wrong loading your newsletter preferences. Wait a minute or two, then %(tryAgain)s."))}else{t=React.createElement("div",{className:"control-group"},this.state.subs.map(function(e){return React.createElement(KeySubscription,babelHelpers.extends({},e,{subscriptionKey:e.key}))}))}return React.createElement("div",{className:"settings-section newsletters"},React.createElement("h3",null,$_(null,"Newsletters")),React.createElement("form",{className:"form-horizontal"},React.createElement("p",null,$_(null,"Our newsletters keep you up-to-date with what's happening at Khan Academy.")),t))}
t.prototype.componentDidUpdate=function e(t,n){if(n.loading===STATES.LOADING&&this.state.loading===STATES.LOADED){this._loadedDfd.resolve()}}
return t}(React.Component)
NewslettersSection.propTypes={token:RP.string}
module.exports=NewslettersSection

});
KAdefine("javascript/settings-package/notifications-section.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var $_=require("../shared-package/i18n.js").$_
var KeySubscription=require("./key-subscription.jsx")
var RP=PropTypes
var NotificationsSection=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.masteryTask
var i=this.props.answerNotification
var r=this.props.assignmentNotification
var s=this.props.evalNotification
return React.createElement("div",{className:"settings-section notifications"},React.createElement("h3",null,$_(null,"Notifications")),React.createElement("form",{className:"form-horizontal"},React.createElement(KeySubscription,babelHelpers.extends({},t,{subscriptionKey:t.key})),React.createElement(KeySubscription,babelHelpers.extends({},i,{subscriptionKey:i.key})),React.createElement(KeySubscription,babelHelpers.extends({},r,{subscriptionKey:r.key})),React.createElement(KeySubscription,babelHelpers.extends({},s,{subscriptionKey:s.key}))))}
return t}(React.Component)
NotificationsSection.propTypes={masteryTask:RP.object.isRequired,answerNotification:RP.object.isRequired,assignmentNotification:RP.object.isRequired,evalNotification:RP.object.isRequired}
module.exports=NotificationsSection

});
KAdefine("javascript/settings-package/phone_util.js", function(require, module, exports) {
var PHONE_REGEX=[/^\([2-9]\d{2}\)\s?\d{3}-\d{4}$/,/^\+?1\d{10}$/,/^[2-9]\d{2}-?\d{3}-?\d{4}$/]
var PHONE_VERIFICATION_STATUS_MAP={"code-too-many-attempts":"Hmm, looks like you've tried this code too "+"many times. Please wait one hour and try again.","code-denied":"Oh noes! The verification code you entered did not work. "+"Please re-enter it, or we can re-send you the code.","code-confirmed":"Your phone number has been confirmed.","code-resend":"Verification code has been re-sent."}
var PHONE_VALIDATION_STATUS_MAP={not_US_phone:"Invalid Number: Not a US phone number",too_many_attempts:"Too many attempts. Please try again in one hour.",not_unique:"Phone number already linked to another KA account",already_verified:"Phone number already verified",not_sending:"Verification code could not be sent",sent:"sent",invalid_format:"Invalid format. Try entering your number with a XXX-XXX-XXXX format"}
var isValidPhoneNumberFormat=function e(n){var o=PHONE_REGEX.filter(function(e){return e.test(n)})
return o.length!==0}
module.exports={isValidPhoneNumberFormat:isValidPhoneNumberFormat,PHONE_VERIFICATION_STATUS_MAP:PHONE_VERIFICATION_STATUS_MAP,PHONE_VALIDATION_STATUS_MAP:PHONE_VALIDATION_STATUS_MAP}

});
KAdefine("javascript/settings-package/primary-email-section.jsx", function(require, module, exports) {
var $=require("jquery")
var React=require("react")
var PropTypes=require("prop-types")
var $_=require("../shared-package/i18n.js").$_
var Spinner=require("../shared-components-package/spinner.jsx")
var RP=PropTypes
var PrimaryEmailSection=function(e){babelHelpers.inherits(a,e)
function a(){var r,t,l
babelHelpers.classCallCheck(this,a)
for(var n=arguments.length,i=Array(n),s=0;s<n;s++){i[s]=arguments[s]}return l=(r=(t=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(i))),t),t.putEmail=function(e){return $.ajax("/api/internal/user/email",{type:"PUT",data:{email:e}})},r),babelHelpers.possibleConstructorReturn(t,l)}a.prototype.render=function e(){var a
if(this.props.emails.length>1){a=React.createElement("select",{className:"simple-select",id:"email",value:this.props.email,onChange:this.props.emailChanged,disabled:this.props.saving},this.props.emails.map(function(e){return React.createElement("option",{value:e,key:e},e)}))}else{a=React.createElement("input",{type:"text",name:"email",id:"email",value:this.props.email,disabled:true})}var r=React.createElement("a",{href:"/settings/account#linked-accounts"},$_(null,"connect a new email to your account"))
return React.createElement("div",{className:"settings-section primary-email"},React.createElement("form",{className:"form-horizontal"},React.createElement("div",{className:"control-group"},React.createElement("label",{className:"control-label",htmlFor:"email"},$_(null,"Send email to")),React.createElement("div",{className:"controls"},a,this.props.saving?React.createElement(Spinner,null):null)),React.createElement("p",null,$_({connect:r},"To use an email address not listed here, %(connect)s."))))}
return a}(React.Component)
PrimaryEmailSection.propTypes={email:RP.string.isRequired,emails:RP.arrayOf(RP.string).isRequired,emailChanged:RP.func.isRequired,saving:RP.bool.isRequired}
module.exports=PrimaryEmailSection

});
KAdefine("javascript/settings-package/settings.js", function(require, module, exports) {
var _moment=require("moment")
var _moment2=babelHelpers.interopRequireDefault(_moment)
var $=require("jquery")
var Backbone=require("backbone")
var React=require("react")
var ReactDOM=require("react-dom")
var _=require("underscore")
var i18n=require("../shared-package/i18n.js")
var AllowCoachesSetting=React.createFactory(require("./allow-coaches-setting.jsx"))
var Checkbox=React.createFactory(require("./checkbox.jsx"))
var FacebookUtil=require("../shared-package/facebookutil.js")
var Forms=require("./forms.js")
var HoverCardView=require("../hover-card-package/hover-card-view.js")
var KA=require("../shared-package/ka.js")
var ProfileModel=require("../shared-package/profile-model.js")
var SatUtil=require("../sat-mission-package/util.js")
var Spinner=require("../old-throbber-package/spinner.js")
var phoneUtil=require("./phone_util.js")
var Settings={}
var Social
Settings.pageRoot="/settings/"
Settings.initAccount=function(e){Settings._sessionHash=e.sessionHash
new Settings.BasicsForm({el:"#basics-form"})
new Settings.RolesForm({el:"#roles-form"})
new Settings.MobilePhoneNumberForm({el:"#mobile-form"})
new Settings.SatExtraTimeForm({el:"#sat-extra-time-form"})
new Settings.AccessibilityForm({el:"#accessibility-form"})
if(!e["isChildActor"]){new Settings.PasswordForm({el:"#password-form",requiresExisting:!!e["requiresExistingPassword"],isChildView:!!e["isChildView"]})}if(e["isChildView"]){new Settings.ParentEmailForm({el:"#parentemail-form"})}Settings._isModifyingChild=e.isModifyingChild
e.targetProfile.href=e.targetProfile.profileRoot
var t=new HoverCardView({model:new ProfileModel(e.targetProfile)})
$("#delete-modal .user-card").append(t.render().el)
$("#delete-submit").click(function(){$("#delete-modal input").prop("disabled",true)
Settings.deleteAccount(e.targetProfile.userId)})
$("#learn-about-delete").click(function(e){e.preventDefault()}).qtip({content:i18n._("In order to protect students from accidentally "+"deleting their data, we wait a day before "+"fully deleting any account.<br><br>Once you click "+"Delete, your account and all of its history will "+"automatically be deleted directly after this "+"waiting period. <b>You don't have to do anything "+"else.</b>"),position:{my:"bottom center",at:"top center"},style:"qtip-light qtip-shadow"})
new Settings.LinkedAccountsView({el:"#linked-accounts"})
new Settings.CbAccountLinkingView({el:"#cb-link-settings"})
ReactDOM.render(Checkbox({checked:e.targetProfile.soundOn,label:i18n._("Sound effects"),name:"soundOn"}),$(".sound-setting")[0])
ReactDOM.render(Checkbox({checked:e.targetProfile.autocontinueOn,label:i18n._("Video autocontinue"),name:"autocontinueOn"}),$(".autocontinue-setting")[0])
ReactDOM.render(Checkbox({checked:!!e.targetProfile.hideVisual,label:i18n._("Hide visually-dependent content"),name:"hidevisual"}),$(".hide-visual-setting")[0])
ReactDOM.render(Checkbox({checked:e.targetProfile.prefersReducedMotion,label:i18n._("Reduce motion and animations"),name:"prefersReducedMotion"}),$(".reduce-motion-setting")[0])
ReactDOM.render(Checkbox({checked:e.targetProfile.noColorInVideos,label:i18n._("Remove color from videos"),name:"noColorInVideos"}),$(".no-color-in-videos-setting")[0])
if($(".allow-coaches-setting").length>0){ReactDOM.render(AllowCoachesSetting({userId:e.targetProfile.userId,checked:e.targetProfile.canModifyCoaches}),$(".allow-coaches-setting .toggle-switch-container")[0])}}
Settings.initRouter=function(){Settings.router=new Settings.Router({tabView:new Settings.TabView({el:$("#user-settings")})})
Backbone.history.start({root:Settings.pageRoot,pushState:true,hashChange:false})}
Settings.Router=Backbone.Router.extend({initialize:function e(t){this.tabView=t.tabView
_.each(["email","account"],function(e){this.route(e,e,_(this.tabView.showTab).bind(this.tabView,e))},this)}})
Settings.TabView=Backbone.View.extend({events:{"click .tabrow a":"tabClicked","click .child-email-link":"tabClicked"},currentTab:null,tabClicked:function e(t){var i=$(t.target).attr("href")
if(i.indexOf(Settings.pageRoot)===0){i=i.slice(Settings.pageRoot.length)}if(this.showTab(i)){t.preventDefault()}},showTab:function e(t){if(this.currentTab===t){return true}var i=this.$(".settings-tab."+t)
if(!i.length){return false}if(this.currentTab){this.$(".settings-tab."+this.currentTab).hide()
this.$(".tabrow li."+this.currentTab).removeClass("selected")}this.currentTab=t
i.show()
this.$(".tabrow li."+this.currentTab).addClass("selected")
Settings.router.navigate(this.currentTab)
return true}})
Settings.deleteAccount=function(e){$.get("/api/internal/user/deletion_code",{userId:e,casing:"camel"},function(t){if(t.childUsers.length||!t.deletionCode){return}var i=$.param({userId:e,deletion_code:t.deletionCode,casing:"camel"})
$.ajax({url:"/api/internal/user?"+i,type:"DELETE",success:function e(){if(Settings._isModifyingChild){if(window.location.search.indexOf("ref=settings")>-1){window.location.href="/settings/account"}else{window.location.href="/students?listId=childAccounts"}}else{window.location.href="/logout?continue=%2F"}},error:function e(){alert(i18n._("We ran into a problem trying to delete your "+"account. If this happens repeatedly, please let "+"us know via 'Report a Problem' at the bottom of "+"this page so we can help."))
$("#delete-modal input").prop("disabled",false)}})})}
Settings.BasicsForm=Forms.Form.extend({initialUsername:null,initialize:function e(t){this.initialUsername=this.$el.find("#username").val()||""
var i=this
var n={nickname:{validate:"required",msg:i18n._("Please tell us your name")},username:{validate:function e(t){if(i.initialUsername===t){return true}if(t.charAt(0)==="."){return false}var n=t.replace(/\./g,"").toLowerCase()
return/^[a-z][a-z0-9]{2,}$/.test(n)},msg:i18n._("Must be alphanumeric and start with a letter")},birthdate:{validate:function e(t){if(!t){return true}return(0,_moment2.default)((0,_moment2.default)()).diff(t)>0},msg:i18n._("Birthdates must be in the past")}}
_.extend(this.options,{validators:n,validatorDefaults:{autocheck:"blur"}})
Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){if("url"in e){window.location.href=e["url"]}else{var t=this.$form.find(".success-message").text(e["success"])
Settings._fadeInOutElement(t)}})}})
Settings.RolesForm=Forms.Form.extend({initialize:function e(t){if(document.location.hash==="#roles-section"){$("#homepage").qtip({content:{text:"Switch your KA home here"},style:{classes:"dark-round-tip centered",tip:{width:18,height:10,corner:"leftMiddle"}},position:{my:"left center",at:"right center",adjust:{x:10}}})
$("#homepage").qtip("show")}Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){var t=this.$form.find(".success-message").text(i18n._("Roles updated"))
Settings._fadeInOutElement(t)
var i=$(".learning-home > .menulink")
if(e.homepage==="learner"){i.text(i18n._("Home"))
i.attr("href","/")}else{i.text(i18n._("Learning home"))
i.attr("href","/?learn=1")}},this)}})
Settings.MobilePhoneNumberForm=Forms.Form.extend({initialize:function e(t){var i={mobileNumber:{validate:function e(t){return phoneUtil.isValidPhoneNumberFormat(t)||t===""},msg:i18n._("Invalid Mobile Phone Number")}}
_.extend(this.options,{validators:i,validatorDefaults:{autocheck:"blur"}})
Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){var t=this.$form.find(".success-message").text(i18n._("Mobile phone number updated!"))
Settings._fadeInOutElement(t)},this)}})
Settings.SatExtraTimeForm=Forms.Form.extend({events:{"click #submit-sat-extra-time":"onExtraTimeSubmit_"},initialize:function e(t){$("#cb-accommodations-link").attr("href",SatUtil.CB_ACCOMMODATIONS_LINK)},onExtraTimeSubmit_:function e(t){t.preventDefault()
var i=parseInt($("#time")[0].value,10)
var n=$("#sections")[0].value
$.ajax({type:"POST",url:"/api/internal/sat/extra_time",contentType:"application/json",data:JSON.stringify({percent:i,sections:n}),success:function e(){var t=$("#sat-extra-time-form").find(".success-message").text(i18n._("SAT extra time options updated"))
Settings._fadeInOutElement(t)
$("#sat-full-exams-link-text").css("display","inline")},error:function e(t){var i=$("#sat-extra-time-form").find(".success-message").text(i18n._("Failed to update SAT extra time options"))
Settings._fadeInOutElement(i)}})}})
Settings.AccessibilityForm=Forms.Form.extend({initialize:function e(t){Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){var t=this.$form.find(".success-message").text(i18n._("Accessibility options updated"))
Settings._fadeInOutElement(t)},this)}})
var re=/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
Settings.ParentEmailForm=Forms.Form.extend({initialize:function e(t){var i={email:{validate:function e(t){return t.match(re)},msg:i18n._("Invalid email")}}
_.extend(this.options,{validators:i,validatorDefaults:{autocheck:"blur"}})
Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){var t=this.$form.find(".success-message").text(i18n._("Parent invited."))
Settings._fadeInOutElement(t)
this.updateForm()},this)},updateForm:function e(){var t=this.$form.find("#email").val()
this.$form.find("#requested-email").text(t)
this.$form.find("#email").val("")}})
Settings.PasswordForm=Forms.Form.extend({initialize:function e(t){var i={password1:{validate:"required",msg:i18n._("Password cannot be blank")},password2:{validate:function e(t){return t===$("#password1").val()},msg:i18n._("Passwords don't match")}}
if(t["requiresExisting"]){i["existing"]={validate:"required",msg:i18n._("Please enter your existing password")}}_.extend(this.options,{validators:i,validatorDefaults:{autocheck:"blur"}})
Forms.Form.prototype.initialize.call(this,t)
this.on("success",function(e){var i=this.$form.find(".success-message").text(i18n._("Password changed"))
Settings._fadeInOutElement(i)
this.clearForm()
if(!t["isChildView"]&&!t["requiresExisting"]){window.location=window.location}else{this.$form.find("input").first().focus()}},this)},clearForm:function e(){this.$form.find("#existing, #password1, #password2").val("")}})
Settings.LinkedAccountsView=Backbone.View.extend({events:{"click .disconnect-login":"onDisconnectThirdParty_","click .disconnect-email":"onDisconnectEmail_","click #login-google":"onConnectGoogle_"},initialize:function e(t){var i=this
if(window.location.search.indexOf("continue_google_connect=1")>-1){if(window.location.search.indexOf("state="+Settings._sessionHash)!==-1){this.onAfterConnect_("google")()}else{window.location="/settings/account?messageKey="+"didnt_login_successfully"}}require.dynimport("../login-package/social.js").then(function(e){Social=e
if(KA.isZeroRated){i.delegateEvents(babelHelpers.extends({},i.events,{"click #login-facebook":"onZeroRatedConnectFacebook_"}))}else{FacebookUtil.tryFbLoad(function(){i.delegateEvents(babelHelpers.extends({},i.events,{"click #login-facebook":"onConnectFacebook_"}))})}})},showSpinner:function e(){Spinner.show($(".linked-accounts-header"),true)
$("#linked-accounts").find("input").prop("disabled",true).addClass("disabled")},hideSpinner:function e(){Spinner.hide()
$("#linked-accounts").find("input").prop("disabled",false).removeClass("disabled")},onDisconnectEmail_:function e(t){var i=$(t.target).data("email")
return confirm(i18n._("Are you sure you want to remove %(email)s from your account?",{email:i}))},onDisconnectThirdParty_:function e(t){t.preventDefault()
if(!confirm(i18n._("Are you sure you want to disconnect this account?"))){return}this.showSpinner()
var i=$(t.target).data("type")
$.ajax({type:"DELETE",url:"/api/internal/user/settings/third_party_login?type="+i,success:function e(){var t=i==="google"?"successfully_disconnected_google_account":"successfully_disconnected_facebook_account"
window.location="/settings/account?messageKey="+t},error:function e(t){var i=t.status===400&&!!t.responseText?t.responseText:"unable_to_disconnect_account"
window.location="/settings/account?messageKey="+i}})},onZeroRatedConnectFacebook_:function e(){Social.showZeroRatingWarning(function(e){FacebookUtil.loadFb()
e.delegateEvents(babelHelpers.extends({},e.events,{"click #login-facebook":"onConnectFacebook_"}))},this)},onConnectFacebook_:function e(){this.showSpinner()
var t=Social.createFacebookPostLoginUrl("/settings/account")
Social.launchFacebookConnection(t,this.onAfterConnect_("facebook"))
this.hideSpinner()},onConnectGoogle_:function e(){this.showSpinner()
Social.connectWithGoogle("/signup/google","/settings/account?state="+Settings._sessionHash+"&"+"continue_google_connect=1#linked-accounts",this.onAfterConnect_("google"))
this.hideSpinner()},onAfterConnect_:function e(t){this.showSpinner()
return function(){$.ajax({type:"PUT",url:"/api/internal/user/settings/third_party_login?type="+t,success:function e(){var i=t==="google"?"you_can_now_login_with_google":"you_can_now_login_with_facebook"
window.location="/settings/account?messageKey="+i},error:function e(t){window.location="/settings/account?messageKey="+t.responseText}})}}})
Settings.CbAccountLinkingView=Backbone.View.extend({events:{"click .disconnect-cb":"onDisconnectCbAccount_"},onDisconnectCbAccount_:function e(t){t.preventDefault()
if(!confirm(i18n._("Are you sure you want to disconnect this account?"))){return}Spinner.show($(".cb-link-header"),true)
$.ajax({method:"POST",url:"/api/internal/sat/collegeboard/unlink",success:function e(){var t="successfully_disconnected_cb_account"
window.location="/settings/account?messageKey="+t},error:function e(){var t="unable_to_disconnect_account"
window.location="/settings/account?messageKey="+t}})}})
Settings._fadeInOutElement=function(e){e.fadeIn("fast").delay(2e3).fadeOut("slow")}
module.exports=Settings

});
KAdefine("javascript/settings-package/toggle-switch.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var RP=PropTypes
var ToggleSwitch=function(e){babelHelpers.inherits(r,e)
function r(){var t,s,l
babelHelpers.classCallCheck(this,r)
for(var a=arguments.length,c=Array(a),i=0;i<a;i++){c[i]=arguments[i]}return l=(t=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(c))),s),s.handleLabelKeyPress=function(e){if(e.key===" "){e.preventDefault()
e.target.click()}},t),babelHelpers.possibleConstructorReturn(s,l)}r.buildIdForKey=function e(r){return"toggle-switch-"+r}
r.prototype.render=function e(){var t=r.buildIdForKey(this.props.switchKey)
var s="toggle-switch"
if(this.props.classes){s+=" "+this.props.classes}return React.createElement("div",{className:s},React.createElement("input",{type:"checkbox",id:t,name:this.props.switchKey,checked:this.props.checked,onChange:this.props.handleToggle}),React.createElement("label",{"aria-checked":this.props.checked,"aria-labelledby":this.props.labelId,htmlFor:t,onKeyPress:this.handleLabelKeyPress,role:"checkbox",tabIndex:"0"}))}
return r}(React.Component)
ToggleSwitch.propTypes={checked:RP.bool.isRequired,switchKey:RP.string.isRequired,handleToggle:RP.func.isRequired,labelId:RP.string,classes:RP.string}
module.exports=ToggleSwitch

});
; KAdefine.updatePathToPackageMap({"javascript/login-package/social.js": "login.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/settings-package.js.map 