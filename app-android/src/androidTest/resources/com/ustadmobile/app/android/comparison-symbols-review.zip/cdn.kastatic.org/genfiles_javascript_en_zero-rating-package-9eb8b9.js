KAdefine("javascript/zero-rating-package/login-warning-modal.jsx", function(require, module, exports) {
var _modal
var _wonderBlocksButtonV=require("@khanacademy/wonder-blocks-button-v2")
var _wonderBlocksButtonV2=babelHelpers.interopRequireDefault(_wonderBlocksButtonV)
var React=require("react")
var PropTypes=require("prop-types")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet
var mediaQueries=require("../shared-styles-package/media-queries.js")
var DeprecatedModal=require("../shared-components-package/deprecated-modal.jsx")
var i18n=require("../shared-package/i18n.js")
var LoginWarningModal=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=React.createElement("div",null,React.createElement(_wonderBlocksButtonV2.default,{onClick:this.props.onCancel,style:styles.btn,kind:"secondary"},i18n._("Cancel")),React.createElement(_wonderBlocksButtonV2.default,{onClick:this.props.onAccept,style:styles.btn},i18n._("Login")))
return React.createElement(DeprecatedModal,{extraStyles:[styles.modal],footer:r,onClose:this.props.onCancel,forceTop:true,title:i18n._("Accept data charges?")},i18n._("You are about to use a third-party service to log in. Regular data rates apply."))}
return r}(React.Component)
LoginWarningModal.propTypes={onAccept:PropTypes.func,onCancel:PropTypes.func}
var styles=StyleSheet.create({modal:(_modal={},_modal[mediaQueries.smOrSmaller]={border:"none",borderRadius:0,boxSizing:"border-box",height:"100%",left:0,margin:0,position:"fixed",top:0,width:"100%"},_modal),btn:{marginLeft:8}})
module.exports=LoginWarningModal

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/zero-rating-package.js.map 