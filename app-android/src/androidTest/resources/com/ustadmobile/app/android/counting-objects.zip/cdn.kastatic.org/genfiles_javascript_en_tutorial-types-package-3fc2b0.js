KAdefine("javascript/tutorial-types-package/types.js", function(require, module, exports) {

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/tutorial-types-package.js.map 