KAdefine("javascript/bibliotron-package/bibliotron-tutorial-entry.js", function(require, module, exports) {
var KA=require("../shared-package/ka.js")
var tplParams=window["./javascript/bibliotron-package/bibliotron-tutorial-entry.js"]
KA.perseusNeedsExtraWidgets=tplParams.needsExtraWidgets

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/bibliotron-tutorial-entry-package.js.map 