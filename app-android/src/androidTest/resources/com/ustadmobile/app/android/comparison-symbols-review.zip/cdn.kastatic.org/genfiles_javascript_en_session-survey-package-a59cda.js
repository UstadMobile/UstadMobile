KAdefine("javascript/session-survey-package/session-survey.jsx", function(require, module, exports) {
var React=require("react")
var createReactClass=require("create-react-class")
var ReactDOM=require("react-dom")
var BigBingo=require("../shared-package/bigbingo.js")
var Cookies=require("../shared-package/cookies.js")
var LocalStore=require("../shared-package/local-store.js")
var _require=require("../shared-package/khan-fetch.js"),khanFetch=_require.khanFetch
var Survey=require("./survey.jsx")
var i18n=require("../shared-package/i18n.js")
var ga=window.ga||function(){}
var QUESTIONS=[{prompt:i18n._("Was Khan Academy helpful to you today?"),answers:[{text:i18n._("Yes"),onAnswer:function e(){BigBingo.markConversion("session_helpful_yes")
ga("send","event","Session","Helpful","Yes")},nextQuestion:1},{text:i18n._("No"),onAnswer:function e(){BigBingo.markConversion("session_helpful_no")
ga("send","event","Session","Helpful","No")},nextQuestion:1}]},{prompt:i18n._("Did you find what you came here for today?"),answers:[{text:i18n._("Yes, easily"),onAnswer:function e(){BigBingo.markConversion("session_findable_yes_easily")
ga("send","event","Session","Findable","Yes, easily")}},{text:i18n._("Yes, eventually"),onAnswer:function e(){BigBingo.markConversion("session_findable_yes_eventually")
ga("send","event","Session","Findable","Yes, eventually")}},{text:i18n._("No"),onAnswer:function e(){BigBingo.markConversion("session_findable_no")
ga("send","event","Session","Findable","No")}},{text:i18n._("I wasn't looking for anything in particular"),onAnswer:function e(){BigBingo.markConversion("session_findable_not_applicable")
ga("send","event","Session","Findable","Not Applicable")}}]}]
var SESSION_COOKIE_NAME="ka_session"
var SESSION_SURVEY_STORE_KEY="session_survey"
var SESSION_TIMEOUT_LENGTH_IN_SECONDS=30*60
var SESSION_VALIDATION_LOOP_LENGTH_IN_SECONDS=5*60
var SessionSurvey=createReactClass({displayName:"SessionSurvey",getInitialState:function e(){return LocalStore.get(SESSION_SURVEY_STORE_KEY)||{}},setStateAndStore:function e(t,i){var n=LocalStore.get(SESSION_SURVEY_STORE_KEY)||{}
var s=babelHelpers.extends({},n,t)
LocalStore.set(SESSION_SURVEY_STORE_KEY,s)
this.setState(s,i)},render:function e(){var t=this
return React.createElement(Survey,{className:"session-survey",triggered:this.state.triggered,completed:this.state.completed,onComplete:function e(i){t.setStateAndStore({completed:i})},currentQuestion:this.state.currentQuestion,onNextQuestion:function e(i){t.setStateAndStore({currentQuestion:i})},minimized:this.state.minimized,onMinimize:function e(i){t.setStateAndStore({minimized:i})},randomSeed:this.state.randomSeed,questions:this.props.questions})},UNSAFE_componentWillMount:function e(){this.checkForNewSession()},componentDidMount:function e(){this._isMounted=true
if(!this.state.triggered){this.startSessionTriggerTimer()}else{this.startSessionValidationLoop()}window.addEventListener("storage",this.onStorage)
window.addEventListener("focus",this.onFocus)},componentDidUpdate:function e(t,i){if(this.state.triggered&&!i.triggered){this.startSessionValidationLoop()}},componentWillUnmount:function e(){this.clearTimers()
window.removeEventListener("storage",this.onStorage)
window.removeEventListener("focus",this.onFocus)
this._isMounted=false},_isMounted:false,checkForNewSession:function e(){var t=Cookies.readCookie(SESSION_COOKIE_NAME)
var i=t&&t.split(":")[0]
if(!i){return}if(i!==this.state.sessionId){var n=Date.now()/1e3
var s=n+10+(30*60-10)*Math.sqrt(Math.random())
this.setStateAndStore({triggered:false,completed:false,currentQuestion:0,minimized:false,randomSeed:n,sessionId:i,surveyTime:s})}},clearTimers:function e(){if(this.sessionTriggerTimerId!==undefined){clearTimeout(this.sessionTriggerTimerId)
this.sessionTriggerTimerId=undefined}if(this.sessionTimeoutTimerId!==undefined){clearTimeout(this.sessionTimeoutTimerId)
this.sessionTimeoutTimerId=undefined}},startSessionTriggerTimer:function e(){var t=this
var i=Date.now()/1e3
var n=this.state.surveyTime-i+Math.random()
this.sessionTriggerTimerId=setTimeout(function(){t.sessionTriggerTimerId=undefined
if(!t._isMounted){return}var e=LocalStore.get(SESSION_SURVEY_STORE_KEY)||{}
if(!e.triggered){t.setStateAndStore({triggered:true})
BigBingo.markConversion("session_survey_shown")
ga("send","event","Session","Survey","Shown")}},1e3*Math.max(n,0))},startSessionValidationLoop:function e(){var t=this
var i=function e(){return t.setStateAndStore({completed:true})}
var n=function e(){t.sessionTimeoutTimerId=undefined
if(t.state.completed){return}var n=Date.now()/1e3
var s=Cookies.readCookie(SESSION_COOKIE_NAME)
var o=s&&s.split(":")[2]
var r=o&&Number(o)
if(!r){i()}else if(n-r>SESSION_TIMEOUT_LENGTH_IN_SECONDS){i()}else{t.sessionTimeoutTimerId=setTimeout(e,SESSION_VALIDATION_LOOP_LENGTH_IN_SECONDS*1e3)}}
n()},onStorage:function e(t){if(t.key===LocalStore.cacheKey(SESSION_SURVEY_STORE_KEY)){this.setState(LocalStore.get(SESSION_SURVEY_STORE_KEY)||{})}},onFocus:function e(){if(this.state.triggered&&!this.state.completed){return khanFetch("/api/internal/ping")}}})
var initializeSessionSurvey=function e(){if(!LocalStore.isEnabled()){return}var t=document.createElement("div")
document.body.appendChild(t)
return ReactDOM.render(React.createElement(SessionSurvey,{questions:QUESTIONS}),t)}
module.exports=initializeSessionSurvey

});
KAdefine("third_party/javascript-khansrc/seedrandom/seedrandom.js", function(require, module, exports) {
(function(n,t,e,r,i,o,u,a,f){var c=e.pow(r,i),l=e.pow(2,o),h=l*2,p=r-1,s=e["seed"+f]=function(n,o,u){var a=[]
o=o==true?{entropy:true}:o||{}
var p=v(d(o.entropy?[n,y(t)]:n==null?w():n,3),a)
var s=new g(a)
v(y(s.S),t)
return(o.pass||u||function(n,t,r){if(r){e[f]=n
return t}else return n})(function(){var n=s.g(i),t=c,e=0
while(n<l){n=(n+e)*r
t*=r
e=s.g(1)}while(n>=h){n/=2
t/=2
e>>>=1}return(n+e)/t},p,"global"in o?o.global:this==e)}
function g(n){var t,e=n.length,i=this,o=0,u=i.i=i.j=0,a=i.S=[]
if(!e){n=[e++]}while(o<r){a[o]=o++}for(o=0;o<r;o++){a[o]=a[u=p&u+n[o%e]+(t=a[o])]
a[u]=t}(i.g=function(n){var t,e=0,o=i.i,u=i.j,a=i.S
while(n--){t=a[o=p&o+1]
e=e*r+a[p&(a[o]=a[u=p&u+t])+(a[u]=t)]}i.i=o
i.j=u
return e})(r)}function d(n,t){var e=[],r=typeof n,i
if(t&&r=="object"){for(i in n){try{e.push(d(n[i],t-1))}catch(n){}}}return e.length?e:r=="string"?n:n+"\0"}function v(n,t){var e=n+"",r,i=0
while(i<e.length){t[p&i]=p&(r^=t[p&i]*19)+e.charCodeAt(i++)}return y(t)}function w(e){try{n.crypto.getRandomValues(e=new Uint8Array(r))
return y(e)}catch(r){return[+new Date,n,(e=n.navigator)&&e.plugins,n.screen,y(t)]}}function y(n){return String.fromCharCode.apply(0,n)}v(e[f](),t)
if(u&&u.exports){u.exports=s}else if(a&&a.amd){a(function(){return s})}})(this,[],Math,256,6,52,typeof module=="object"&&module,typeof define=="function"&&define,"random")

});
KAdefine("javascript/node_modules/seedrandom/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/seedrandom/seedrandom.js")

});
KAdefine("javascript/session-survey-package/survey.jsx", function(require, module, exports) {
var $=require("jquery")
var classNames=require("classnames")
var React=require("react")
var PropTypes=require("prop-types")
var ReactDOM=require("react-dom")
var seedrandom=require("seedrandom")
var i18n=require("../shared-package/i18n.js")
var shuffleArrayWithSeed=function e(s,t){var r=s.slice()
var i=seedrandom(t!=null?t:Date.now()/1e3)
for(var n=r.length;n>0;n--){var o=Math.floor(i()*n)
var a=r[o]
r[o]=r[n-1]
r[n-1]=a}return r}
var KUISurvey=function(e){babelHelpers.inherits(s,e)
function s(){var t,r,i
babelHelpers.classCallCheck(this,s)
for(var n=arguments.length,o=Array(n),a=0;a<n;a++){o[a]=arguments[a]}return i=(t=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),r),r.state={height:0,showMessage:false},r.calculateHeight=function(){return $(ReactDOM.findDOMNode(r.refs.question)).outerHeight(true)},r.onAnswer=function(e){e.onAnswer&&e.onAnswer()
if(e.nextQuestion!=null){r.props.onNextQuestion(e.nextQuestion)}else{r.setState({showMessage:true},function(){r.props.onComplete(true)
setTimeout(function(){return r.setState({showMessage:false})},1e3*r.props.messageDelay)})}},t),babelHelpers.possibleConstructorReturn(r,i)}s.prototype.componentDidMount=function e(){if(!this.props.minimized){this.setState({height:this.calculateHeight()})}}
s.prototype.componentDidUpdate=function e(s,t){if(!s.minimized&&this.props.minimized){this.setState({height:0})}else if(s.triggered!==this.props.triggered||s.currentQuestion!==this.props.currentQuestion||s.minimized!==this.props.minimized||t.showMessage!==this.state.showMessage){this.setState({height:this.calculateHeight()})}}
s.prototype.render=function e(){var s=this
if(!this.props.triggered||this.props.completed&&!this.state.showMessage){return null}var t
if(this.state.showMessage){t=React.createElement("div",{className:"kui-survey__question kui-survey__message",ref:"question"},i18n._("Thank you!"))}else{var r=this.props.questions[this.props.currentQuestion]
t=React.createElement("div",{className:"kui-survey__question",ref:"question"},React.createElement("div",{className:"kui-survey__prompt"},r.prompt),React.createElement("div",null,shuffleArrayWithSeed(r.answers.map(function(e,t){return React.createElement("div",{className:"kui-survey__answer",key:t,onClick:function t(){return s.onAnswer(e)}},e.text)}),this.props.randomSeed)))}var i=classNames("kui-survey",this.props.className)
return React.createElement("div",{className:i,style:{height:this.state.height}},React.createElement("div",{className:"kui-survey__handle",onClick:function e(){return s.props.onMinimize(!s.props.minimized)}},this.props.minimized?React.createElement("i",{className:"icon-plus",style:{fontSize:14}}):React.createElement("span",{style:{fontSize:20}},"—")),React.createElement("div",{className:"kui-survey__body"},t))}
return s}(React.Component)
KUISurvey.propTypes={className:PropTypes.string,triggered:PropTypes.bool,completed:PropTypes.bool,onComplete:PropTypes.func.isRequired,currentQuestion:PropTypes.number,onNextQuestion:PropTypes.func.isRequired,minimized:PropTypes.bool,onMinimize:PropTypes.func.isRequired,messageDelay:PropTypes.number,randomSeed:PropTypes.number,questions:PropTypes.arrayOf(PropTypes.shape({prompt:PropTypes.node.isRequired,answers:PropTypes.arrayOf(PropTypes.shape({text:PropTypes.node.isRequired,onAnswer:PropTypes.func,nextQuestion:PropTypes.number})).isRequired})).isRequired}
KUISurvey.defaultProps={triggered:false,completed:false,currentQuestion:0,minimized:false,messageDelay:2}
module.exports=KUISurvey

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/session-survey-package.js.map 