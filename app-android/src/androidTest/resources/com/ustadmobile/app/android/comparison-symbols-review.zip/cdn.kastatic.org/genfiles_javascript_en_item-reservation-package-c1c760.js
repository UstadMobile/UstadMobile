KAdefine("javascript/item-reservation-package/item-reservation.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.useItemReservation=undefined
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var useItemReservation=exports.useItemReservation=function e(){return _ka2.default.featureFlag("RESERVE_ASSESSMENT_ITEMS")}

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/item-reservation-package.js.map 