KAdefine("javascript/tutorial-page-package/tutorial-page.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _page,_tutorialNav,_mobileTutorialNav,_exerciseFooterAfford
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(['\n    query getDynamicInfoForTutorial(\n        $tutorialId: String!\n        $encryptedKey: String\n    ) {\n        user {\n            id\n            canEdit: hasPermission(\n                name: "can_edit"\n                scope: ANY_ON_CURRENT_LOCALE\n            )\n            canCurate: hasPermission(\n                name: "can_curate_tags"\n                scope: ANY_ON_CURRENT_LOCALE\n            )\n            contentItemProgresses(topicId: $tutorialId) {\n                content {\n                    id\n                    progressKey\n                }\n                completionStatus\n            }\n            hasAdminRole: hasRole(name: "admin")\n            isPhantom\n            isChild\n        }\n        qaExpandKeyInfo(encryptedQaExpandKey: $encryptedKey) {\n            feedbackType\n            unencryptedKey\n        }\n    }\n'],['\n    query getDynamicInfoForTutorial(\n        $tutorialId: String!\n        $encryptedKey: String\n    ) {\n        user {\n            id\n            canEdit: hasPermission(\n                name: "can_edit"\n                scope: ANY_ON_CURRENT_LOCALE\n            )\n            canCurate: hasPermission(\n                name: "can_curate_tags"\n                scope: ANY_ON_CURRENT_LOCALE\n            )\n            contentItemProgresses(topicId: $tutorialId) {\n                content {\n                    id\n                    progressKey\n                }\n                completionStatus\n            }\n            hasAdminRole: hasRole(name: "admin")\n            isPhantom\n            isChild\n        }\n        qaExpandKeyInfo(encryptedQaExpandKey: $encryptedKey) {\n            feedbackType\n            unencryptedKey\n        }\n    }\n']),_templateObject2=babelHelpers.taggedTemplateLiteralLoose(["\n                mutation muteSpecifiedFeedback($expandKey: String!) {\n                    modifyNotifyOnAnswer(\n                        feedbackKey: $expandKey\n                        notifyOnAnswer: false\n                    ) {\n                        feedback {\n                            notifyOnAnswer\n                        }\n                    }\n                }\n            "],["\n                mutation muteSpecifiedFeedback($expandKey: String!) {\n                    modifyNotifyOnAnswer(\n                        feedbackKey: $expandKey\n                        notifyOnAnswer: false\n                    ) {\n                        feedback {\n                            notifyOnAnswer\n                        }\n                    }\n                }\n            "])
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _reactRouterDom=require("react-router-dom")
var _aphrodite=require("aphrodite")
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _kaQuery=require("../apollo-package/ka-query.jsx")
var _kaQuery2=babelHelpers.interopRequireDefault(_kaQuery)
var _asyncCreateAssignmentHeader=require("../assignments-async-loader-package/async-create-assignment-header.jsx")
var _asyncCreateAssignmentHeader2=babelHelpers.interopRequireDefault(_asyncCreateAssignmentHeader)
var _apiActionResults=require("../shared-package/api-action-results.js")
var _apiActionResults2=babelHelpers.interopRequireDefault(_apiActionResults)
var _bigbingo=require("../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var _contentLibraryModuleList=require("../content-library-package/components/content-library-module-list.jsx")
var _contentLibraryModuleList2=babelHelpers.interopRequireDefault(_contentLibraryModuleList)
var _contentUnavailableError=require("./content-unavailable-error.jsx")
var _contentUnavailableError2=babelHelpers.interopRequireDefault(_contentUnavailableError)
var _lazyLoadComponent=require("../components/lazy-load-package/lazy-load-component.jsx")
var _lazyLoadComponent2=babelHelpers.interopRequireDefault(_lazyLoadComponent)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _mediaQueries=require("../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var _spinner=require("../shared-components-package/spinner.jsx")
var _spinner2=babelHelpers.interopRequireDefault(_spinner)
var _customTestPrepHeader=require("../content-library-package/modules/custom-headers/custom-test-prep-header.jsx")
var _tutorialNav2=require("../tutorial-shared-package/tutorial-nav.jsx")
var _tutorialNav3=babelHelpers.interopRequireDefault(_tutorialNav2)
var _shared=require("../content-library-package/styles/shared.js")
var _shared2=babelHelpers.interopRequireDefault(_shared)
var _updateDocumentTitle=require("../shared-package/update-document-title.js")
var _updateDocumentTitle2=babelHelpers.interopRequireDefault(_updateDocumentTitle)
var _userInfoStore=require("../user-info-store-package/user-info-store.js")
var _userInfoStore2=babelHelpers.interopRequireDefault(_userInfoStore)
var _userInfoConstants=require("../user-info-store-package/user-info-constants.js")
var _routeHistoryContext=require("../app-shell-package/route-history-context.js")
var _routeHistoryContext2=babelHelpers.interopRequireDefault(_routeHistoryContext)
var USER_DATA_QUERY=(0,_graphqlTag2.default)(_templateObject)
var extractURLParam=function e(t,r){if(!t||!t.startsWith("?")){return null}var a="&"+t.slice(1)
var n=new RegExp("&"+r+"=([^&#]+)")
var o=n.exec(a)
return o&&decodeURIComponent(o[1])}
var TutorialPage=function(e){babelHelpers.inherits(t,e)
function t(){var r,a,n
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,s=Array(o),i=0;i<o;i++){s[i]=arguments[i]}return n=(r=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),a),a.state={statusMapUpdates:null},a.progressKeyMap={},a._isMounted=false,a.nextTaskKind=function(){var e=a.props.tutorialNavData.contentModels
var t=a._getCurrentTaskIndex()
var r=t>=e.length-1
if(r){if(a.props.nextTutorial){return a.props.nextTutorial.firstChild.kind}else{return null}}else{return e[t+1].kind}},a.onNavigateToParentTopic=function(){var e=a.props.breadcrumbs
var t=e[e.length-1]
window.location.href=t.href},a.onNextTask=function(){var e=a.props.tutorialNavData,t=e.contentModels,r=e.topicModel
var n=a._getCurrentTaskIndex()
var o=n>=t.length-1
if(o){window.location.href=a.props.nextTutorial.firstChild.topicPath}else{var s=t[n+1].nodeSlug
var i=r.relativeUrl+"/"+s
a.props.history.push(i)}},a.setProgress=function(e){if(!a._isMounted){return}var t=babelHelpers.extends({},a.state.statusMapUpdates);(e||[]).map(function(e){var r=a._findNavContent(e.id)
if(r){t[r.id]=e.progress
a.setState({statusMapUpdates:t})
var n=a.progressKeyMap[r.id]
if(n){_userInfoStore2.default.dispatch({type:_userInfoConstants.UPDATE_STATUS,progressKey:n,status:e.progress})}}})},a.renderWithUserData=function(e,t){var r=a.props,n=r.breadcrumbs,o=r.classUpsell,s=r.domain,i=r.curationByNodeSlug,l=r.nextTutorial,u=r.showTutorialNav,d=r.tutorialNavData,c=r.relatedVideos,p=r.videoAttribution,f=r.sponsorInformation
var m=d.contentModels,g=d.topicModel
var h=false
var v={}
var y=!e.loading&&e.data&&e.data.user
var b=!e.loading&&e.data&&e.data.qaExpandKeyInfo
if(y){h=e.data.user.canEdit||e.data.user.canCurate
e.data.user.contentItemProgresses.forEach(function(e){var t=e.content,r=e.completionStatus
if(t.id){v[t.id]=r.toLowerCase()
a.progressKeyMap[t.id]=t.progressKey}})}Object.assign(v,a.state.statusMapUpdates)
var k=a._getCurrentTaskIndex()
var x=a._getCurrentTask()
if(!x){return _react2.default.createElement(_contentUnavailableError2.default,null)}var T=x.contentKind
var C=null
if(k<m.length-1){C=a._getNavContentAtIndex(k+1)}var N=g.relativeUrl+"/"+a.props.nodeSlug
var E=babelHelpers.extends({},a.props.discussionContext,{isLoadingUserData:e.loading,loggedIn:y&&!y.isPhantom,isDeveloper:y&&y.hasAdminRole,canEdit:y&&y.canEdit,restrictPosting:y&&y.isChild,qaExpandKey:b&&b.unencryptedKey,expandFeedbackType:b&&b.feedbackType,newAskQuestionUi:true,hideMetaPanels:true,focusKind:T.toLowerCase(),focusId:x.id,which:T.toLowerCase()+"-questions",isVideo:T==="Video",isScratchpad:false})
var w=null
var q=null
if(u){w=_react2.default.createElement(_tutorialNav3.default,{tutorialNavData:d,statusMap:v,currentNodeSlug:a.props.nodeSlug,domain:s,nextTutorial:l,style:styles.tutorialNav,breadcrumbs:n,showBreadcrumbs:a.shouldShowBreadcrumbs(),scrollOffset:a._getScrollOffset()})
q=_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.mobileTutorialNav,T==="Exercise"&&styles.mobileTutorialNavExerciseFooterAffordance)},_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.mobileTutorialNavContents)},_react2.default.createElement(_tutorialNav3.default,{tutorialNavData:d,statusMap:v,currentNodeSlug:a.props.nodeSlug,domain:s,nextTutorial:l,withinMobilePage:true,showBreadcrumbs:a.shouldShowBreadcrumbs()})))}var S=null
if(C){var R=C
S=function e(){var t=g.relativeUrl+"/"+R.nodeSlug
a.props.history.push(t)}}var A=a.props.preloadedTranscript
var D=t.length===1
var H=!D
var I=function e(){var t=a.props,r=t.nodeSlug,n=t.match
return n.params.kind+"/"+n.params.slug===r}
var P=_react2.default.createElement("div",{key:"tutorial-page","data-test-id":"tutorial-page"},_react2.default.createElement(_reactRouterDom.Route,{path:"*/v/:slug",render:function e(){return _react2.default.createElement(_lazyLoadComponent2.default,{load:function e(){return[require.dynimport("../tutorial-video-package/video-page.jsx"),require.dynimport("../../stylesheets/video-package/video.less"),require.dynimport("../../stylesheets/discussion-package/discussion.less"),require.dynimport("../../stylesheets/clarifications-package/clarifications.less"),require.dynimport("../../stylesheets/moderation-package/moderation.less")]}},!I()?undefined:function(e){return _react2.default.createElement(e,{video:x,userVideo:a.props.userVideo,task:a.props.task,nextContentItem:C,navigateToNextItem:S,classUpsell:o,breadcrumbs:n,discussionContext:E,domain:s,topic:g,mobileTutorialNav:q,preloadedTranscript:A&&A.videoId===x.id?A:null,showEditorShortcuts:h,attribution:p,shouldAutoplay:H})})}}),_react2.default.createElement(_reactRouterDom.Route,{path:"*/a/:slug",render:function e(){return _react2.default.createElement(_lazyLoadComponent2.default,{load:function e(){return[require.dynimport("../tutorial-article-package/article-page.jsx"),require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/discussion-package/discussion.less"),require.dynimport("../../stylesheets/moderation-package/moderation.less")]}},!I()?undefined:function(e){return _react2.default.createElement(e,{article:x,breadcrumbs:n,classUpsell:o,currentUrl:N,discussionContext:E,domain:s,showEditorShortcuts:h,topic:g,mobileTutorialNav:q,sponsorInformation:f})})}}),_react2.default.createElement(_reactRouterDom.Route,{path:"*/e/:slug",render:function e(){return _react2.default.createElement(_lazyLoadComponent2.default,{load:function e(){return[require.dynimport("../tutorial-exercise-package/exercise-page.jsx"),a.getExtraWidgetsIfNeeded(),require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/odometer-package/odometer.less"),require.dynimport("../../stylesheets/avatar-customizer-package/avatar-customizer.less"),require.dynimport("../../stylesheets/tasks-package/tasks.less")]}},!I()?undefined:function(e){return _react2.default.createElement(e,{key:x.name,exercise:x,breadcrumbs:n,domain:s,showEditorShortcuts:h,tutorial:g,relatedVideos:c,initialCards:a.props.initialCards,initialItem:a.props.initialItem,inFixture:a.props.inFixture,ref:"exercisePage",mobileTutorialNav:q,showTutorialNav:u,onNextTask:a.onNextTask,onNavigateToParentTopic:a.onNavigateToParentTopic,nextTaskKind:a.nextTaskKind,isDeprecated:N.startsWith("/deprecated")})})}}),_react2.default.createElement(_reactRouterDom.Route,{path:"*/(p[a-z]?)/:slug",render:function e(){return _react2.default.createElement(_lazyLoadComponent2.default,{load:function e(){return[require.dynimport("../tutorial-scratchpad-package/scratchpad-page.jsx")]}},!I()?undefined:function(e){return _react2.default.createElement(e,{key:x.name,scratchpad:x,breadcrumbs:n,domain:s,topic:g,nextSlug:C&&C.nodeSlug,showEditorShortcuts:h})})}}))
var U=i[a.props.nodeSlug]
return _react2.default.createElement("div",null,_react2.default.createElement("div",null,a.renderAssignmentHeader()),_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.customHeaderContainer)},a._maybeGetCustomHeader()),_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.wrapper,T==="Exercise"&&styles.exerciseFooterAffordance)},w,_react2.default.createElement("div",{id:x.nodeSlug+"-panel","aria-labelledby":x.slug+"-"+x.contentKind+"-tab",className:(0,_aphrodite.css)(styles.page,u&&styles.pageWithTutorialNav)},P||_react2.default.createElement(_spinner2.default,null),U&&_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.moduleList)},u&&_react2.default.createElement(_contentLibraryModuleList2.default,{domain:s,modules:U.modules})))))},r),babelHelpers.possibleConstructorReturn(a,n)}t.prototype.componentDidMount=function e(){this._isMounted=true
if(extractURLParam(this.props.search,"mute")==="1"){var t=extractURLParam(this.props.search,"qa_expand_key")
var r=(0,_graphqlTag2.default)(_templateObject2)
if(t){(0,_apolloFetch.apolloMutate)(r,{expandKey:t}).then(function(e){})}}if(this.props.mayNeedExtraWidgetsLater){setTimeout(function(){Promise.all([require.dynimport("../perseus-all-package/perseus.js").then(function(e){return e.default}),require.dynimport("../perseus-merged-extra-widgets-package/extra-widgets.js").then(function(e){return e.default})]).then(function(e){var t=e[0]
return t.init({loadExtraWidgets:true,skipMathJax:true})})},1e3)}(0,_updateDocumentTitle2.default)({pageName:this.getTitle(this.props.nodeSlug)})
window._kiq=window._kiq||[]
window._kiq.push(["set",{bibliotron_new_design:"true",window_width:window.innerWidth,window_height:window.innerHeight}])
this.handlePageRender()
_apiActionResults2.default.register("tutorial_node_progress",this.setProgress)}
t.prototype.componentDidUpdate=function e(t){if(t.nodeSlug!==this.props.nodeSlug){this.handlePageRender()}}
t.prototype.componentWillUnmount=function e(){this._isMounted=false}
t.prototype.markConversion=function e(t,r){var a=this._getCurrentTask()
if(a){_bigbingo2.default.markConversion(t,babelHelpers.extends({product:"library",content_id:a.id,slug:a.slug},r))}}
t.prototype.handlePageRender=function e(){this.markPageviewConversion()
var t=this.props.nodeSlug.startsWith("e/")
var r=document.querySelector("#up-next-module")
if(r){var a=t?"none":"block"
r.style.display=a}}
t.prototype._getAlternateContent=function e(t){if(!t){return t}var r=this.props.tutorialNavData
var a=r.experimentalArticles[t.nodeSlug]
if(t.contentKind==="Article"&&a){return a}else{return t}}
t.prototype._maybeGetCustomHeader=function e(){var t=this.props,r=t.customHeaderId,a=t.subject
if(r==="gtp-custom-header"){return _react2.default.createElement(_customTestPrepHeader.TestPrepHeaderWrapper,{showUpsellTooltip:true,examId:a,leftAlign:true})}}
t.prototype._getScrollOffset=function e(){var t=this.props.customHeaderId
if(t==="gtp-custom-header"){return _customTestPrepHeader.HEADER_HEIGHT}else{return 0}}
t.prototype._findNavContent=function e(t){var r=this.props.tutorialNavData
var a=r.contentModels.find(function(e){return e.nodeSlug===t})
return a&&this._getAlternateContent(a)}
t.prototype._getNavContentAtIndex=function e(t){var r=this.props.tutorialNavData
return this._getAlternateContent(r.contentModels[t])}
t.prototype.getTitle=function e(t){var r=this._findNavContent(t)
if(!r){return""}if(r.metaTitle){return r.metaTitle}var a=this.props.breadcrumbs
var n=[r.translatedTitle].concat(a.slice().reverse().map(function(e){return e.title})).join(" | ")
return n}
t.prototype._getCurrentTaskIndex=function e(){var t=this
return this.props.tutorialNavData.contentModels.findIndex(function(e){return e.nodeSlug===t.props.nodeSlug})}
t.prototype._getCurrentTask=function e(){return this._findNavContent(this.props.nodeSlug)}
t.prototype.markPageviewConversion=function e(){var t=this._getCurrentTask()
if(!t){return}switch(t.contentKind){case"Article":this.markConversion("pageview_article")
break
case"Video":this.markConversion("pageview_video")
break
case"Exercise":if(t.isSkillCheck){this.markConversion("pageview_skill_check")}this.markConversion("pageview_exercise")
break
case"Scratchpad":case"Talkthrough":case"Challenge":case"Project":case"Interactive":this.markConversion("pageview_scratchpad")
break}}
t.prototype.renderAssignmentHeader=function e(){var t=this._getCurrentTask()
if(!t){return null}var r=t.kind+":"+t.id
if(t.kind==="Scratchpad"&&!t.defaultUrlPath){return null}return _react2.default.createElement(_asyncCreateAssignmentHeader2.default,{contentDescriptor:r,contentTitle:t.title})}
t.prototype.getExtraWidgetsIfNeeded=function e(){var t=this.props.needsExtraWidgets
if(t){return Promise.all([require.dynimport("../perseus-all-package/perseus.js").then(function(e){return e.default}),require.dynimport("../perseus-merged-extra-widgets-package/extra-widgets.js").then(function(e){return e.default})]).then(function(e){var t=e[0]
t.init({skipMathJax:true,loadExtraWidgets:true})
return{}})}return Promise.resolve({})}
t.prototype.shouldShowBreadcrumbs=function e(){var t=this.props.subject
if(t==="lsat"){return false}return true}
t.prototype.render=function e(){var t=this
var r=this.props.tutorialNavData.topicModel.contentId
return _react2.default.createElement(_kaQuery2.default,{query:USER_DATA_QUERY,variables:{tutorialId:r,encryptedKey:extractURLParam(this.props.search,"qa_expand_key")},onlyFetchesUserData:true,refetchOnClientSideNav:true},function(e){return _react2.default.createElement(_routeHistoryContext2.default.Consumer,null,function(r){var a=r.history
return t.renderWithUserData(e,a)})})}
return t}(_react2.default.Component)
TutorialPage.defaultProps={inFixture:false,relatedVideos:[],showTutorialNav:true}
var TUTORIAL_NAV_WIDTH=256
var styles=_aphrodite.StyleSheet.create({wrapper:{display:"flex",minHeight:800,width:"100%"},page:(_page={background:_shared2.default.colors.white,overflow:"hidden",width:"100%"},_page[_shared2.default.queries.small]={width:"100%"},_page[_shared2.default.queries.medium]={width:"100%"},_page),pageWithTutorialNav:{width:"calc(100% - "+TUTORIAL_NAV_WIDTH+"px)"},tutorialNav:(_tutorialNav={flexShrink:0,borderRight:"1px solid "+_shared2.default.colors.gray85,width:255},_tutorialNav[_shared2.default.queries.small]={display:"none"},_tutorialNav[_shared2.default.queries.medium]={display:"none"},_tutorialNav),mobileTutorialNavContents:{maxWidth:512,margin:"0 auto"},moduleList:{borderTop:"1px solid "+_shared2.default.colors.gray85},mobileTutorialNav:(_mobileTutorialNav={borderBottom:"8px solid "+_shared2.default.colors.gray90,borderTop:"8px solid "+_shared2.default.colors.gray90,display:"none"},_mobileTutorialNav[_shared2.default.queries.small]={display:"block"},_mobileTutorialNav[_shared2.default.queries.medium]={display:"block"},_mobileTutorialNav),mobileTutorialNavExerciseFooterAffordance:{borderBottomWidth:0},exerciseFooterAffordance:(_exerciseFooterAfford={},_exerciseFooterAfford[_mediaQueries2.default.lgOrSmaller]={paddingBottom:_globalStyles2.default.chromeSizes.exercisePhoneFooterHeight},_exerciseFooterAfford),customHeaderContainer:{top:-1,position:"sticky",zIndex:_globalStyles2.default.constants.zindexFixedNavbar}})
exports.default=(0,_reactRouterDom.withRouter)(TutorialPage)

});
KAdefine("javascript/tutorial-page-package/content-unavailable-error.jsx", function(require, module, exports) {
var _reactBalanceText=require("react-balance-text")
var _reactBalanceText2=babelHelpers.interopRequireDefault(_reactBalanceText)
var _aphrodite=require("aphrodite")
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _errorMessageWrapper=require("../components/error-package/error-message-wrapper.jsx")
var _errorMessageWrapper2=babelHelpers.interopRequireDefault(_errorMessageWrapper)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var i18n=require("../shared-package/i18n.js")
var ContentUnavailableError=function e(){return React.createElement(_errorMessageWrapper2.default,{fullPage:true},React.createElement(_reactBalanceText2.default,{className:(0,_aphrodite.css)(styles.errorText)},i18n._("This content is not available in your locale... yet!")))}
var styles=_aphrodite.StyleSheet.create({errorText:babelHelpers.extends({},_globalStyles2.default.typography.bodyXsmallBold)})
module.exports=ContentUnavailableError

});
; KAdefine.updatePathToPackageMap({"javascript/perseus-all-package/perseus.js": "perseus-all.js", "javascript/perseus-merged-extra-widgets-package/extra-widgets.js": "perseus-merged-extra-widgets.js", "javascript/tutorial-article-package/article-page.jsx": "tutorial-article.js", "javascript/tutorial-exercise-package/exercise-page.jsx": "tutorial-exercise.js", "javascript/tutorial-scratchpad-package/scratchpad-page.jsx": "tutorial-scratchpad.js", "javascript/tutorial-video-package/video-page.jsx": "tutorial-video.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/tutorial-page-package.js.map 