KAdefine("javascript/page-template-package/session-survey-entry.js", function(require, module, exports) {
var KA=require("../shared-package/ka.js")
if(!KA.isMobile){require("../session-survey-package/session-survey.jsx")()}
});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/session-survey-entry-package.js.map 