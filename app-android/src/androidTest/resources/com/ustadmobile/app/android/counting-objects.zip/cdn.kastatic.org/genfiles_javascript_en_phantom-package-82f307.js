KAdefine("javascript/phantom-package/change-email-dialog.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="change-signup-email-dialog modal fade hide">\n    <div class="modal-header">\n        <h2>'+i18n._("Sign up using a different email")+'</h2>\n    </div>\n    <div class="modal-body">\n        <div class="field-row">\n            <label for="current">'+i18n._("Current")+'</label>\n            <input id="current" class="simple-input ui-corner-all disabled" disabled value="{{ email }}">\n        </div>\n        <div class="field-row">\n            <label for="new">'+i18n._("New")+'</label>\n            <input id="new" class="simple-input ui-corner-all" tabindex="1">\n        </div>\n        <div class="field-row">\n            <label>&nbsp;</label>\n            <span class="error"></span>\n        </div>\n    </div>\n    <div class="modal-footer">\n        <input type="button" id="button-cancel" class="simple-button" value="'+i18n._("Cancel")+'" tabindex="3">\n        {{! TODO(mattfaus): Make this a "submit", but it\'s not in a form? }}\n        <input type="button" id="button-change" class="simple-button primary" value="'+i18n._("Change email address")+'" tabindex="2">\n    </div>\n</div>')

});
KAdefine("javascript/notifications-package/verify-email-notification.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('{{! The notification at the top of each page shown when a user is mid-signup,\n   but we know they haven\'t checked their email to verify their email address }}\n<div class="notification-bar auto-visible phantom-notification-bar">\n    <div class="notification-bar-inner">\n        <span class="notification-bar-content">\n            {{#if mailServerUrl}}\n                {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n                '+i18n._('<a class="simple-button primary" href="{{ mailServerUrl }}">\n'+'                    <i class="icon-envelope-alt"></i>\n'+'                    <span class="button-text">Open your {{ mailServerName }}</span>\n'+"                </a>\n"+'                <span class="finish-sign-up">\n'+"                    to finish signing up with\n"+"                </span>\n"+'                <span class="email-address">{{ email }}</span>.')+"\n            {{else}}\n            {{! Warning: changing indentation within i18n strings will alter translation keys. }}\n            "+i18n._('<span class="finish-sign-up">\n'+"                Open your email to finish signing up with\n"+"            </span>\n"+'            <span class="email-address">{{ email }}</span>.')+'\n            {{/if}}\n        </span>\n        <a class="resend-link" href="javascript:void(0);">'+i18n._("Resend email")+'</a>\n        <a class="change-link" href="javascript:void(0);">'+i18n._("Change email")+'</a>\n    </div>\n</div>\n<div class="notification-bar-spacer auto-visible"></div>')

});
KAdefine("javascript/phantom-package/notifications.js", function(require, module, exports) {
var React=require("react")
var ReactDOM=require("react-dom")
var $=require("jquery")
var Backbone=require("backbone")
var _=require("underscore")
var i18n=require("../shared-package/i18n.js")
var Analytics=require("../analytics-package/analytics.js")
var ConnectEmail=require("../settings-package/connect-email.jsx")
var KAConsole=require("../shared-package/console.js")
var changeEmailDialogTemplate=require("./change-email-dialog.handlebars.js")
var Phantom={_email:null,_unverifiedAuthEmailToken:null,initLinkFirstEmail:function e(){var n=document.getElementById("add-email-button-notification-mountpoint")
if(n){ReactDOM.render(React.createElement(ConnectEmail.default,{buttonText:i18n._("Add your email address"),buttonClassNames:"simple-button green"}),n)}},initEmailReminder:function e(n){if(Phantom._email){return}Phantom._email=n["email"]
Phantom._unverifiedAuthEmailToken=n["unverifiedAuthEmailToken"]
Phantom.bindEmailReminderEvents(n)},bindEmailReminderEvents:function e(n){Phantom._bindResendEmailEvent(n)
$(".phantom-notification-bar").on("click",".change-link",function(e){require.dynimport("../../stylesheets/shared-package/shared.less").then(function(){var e=_.extend({onChanged:Phantom.updateEmailReminder},n)
new Phantom.ChangeEmailDialog(e).render()})})},_bindResendEmailEvent:function e(n){var a="/signup/resend"
var i={}
if(Phantom._unverifiedAuthEmailToken){a="/settings/managelinkemail"
i={unverifiedAuthEmailToken:Phantom._unverifiedAuthEmailToken}}$(".phantom-notification-bar").one("click",".resend-link",function(e){$.ajax({type:"GET",url:a,data:i,success:function n(){$(e.target).text(i18n._("Email sent (check your junk folder)"))}})
$(e.target).text(i18n._("Sending...")).addClass("no-link")})},updateEmailReminder:function e(n,a,i,t){var o=require("../notifications-package/verify-email-notification.handlebars.js")
var r=o({email:n,mailServerUrl:a,mailServerName:i})
var l=$(r).filter(".phantom-notification-bar").html()
$(".phantom-notification-bar").html(l)
Phantom._email=n
Phantom._unverifiedAuthEmailToken=t},initBouncedEmailNotice:function e(n){$(".phantom-notification-bar").on("click",".change-button",function(e){var a=_.extend({onChanged:Phantom.removeBouncedEmailNotice},n)
new Phantom.ChangeEmailDialog(a).render()})
Phantom._email=n["email"]},removeBouncedEmailNotice:function e(n,a,i){$(".phantom-notification-bar.error").removeClass("error")
Phantom.updateEmailReminder(n,a,i)
Phantom.bindEmailReminderEvents()},initAcceptTermsOfService:function e(){$("#tos").change(function(){$("#tos-ok-button").prop("disabled",!$(this).prop("checked"))})
$("#tos-ok-button").click(Phantom.submitTermsOfServiceAgreement)
Analytics.trackSingleEvent("Show Terms of Service Dialog")},submitTermsOfServiceAgreement:function e(){$.ajax({type:"POST",url:"/settings/accepttos",success:function e(n){$("#accept-tos-modal").modal("hide")},error:function e(){KAConsole.log("Could not complete acceptance.")}})},ChangeEmailDialog:Backbone.View.extend({events:{"click #button-cancel":"_onCancel","click #button-change":"_onSubmit"},render:function e(){var n={email:Phantom._email}
var a=changeEmailDialogTemplate(n)
this.setElement($(a))
var i=this
this.$el.modal({backdrop:"static",show:true}).on("shown",function(){i.$el.find("#current").val(Phantom._email)
i.$el.find("#new").val("").focus()}).on("hidden",function(){i.remove()})
return this},_onCancel:function e(){this.$el.modal("hide")},_onSubmit:function e(){var n=$.trim(this.$el.find("#new").val())
var a="/signup/email"
var i={casing:"camel",email:n}
if(Phantom._unverifiedAuthEmailToken){a="/settings/managelinkemail"
i={email:n,unverifiedAuthEmailToken:Phantom._unverifiedAuthEmailToken}}var t=this
$.ajax({type:"POST",url:a,data:i,dataType:"json",success:function e(n){if(n["error"]){t.$(".field-row .error").text(n["error"])
t.$("#new").focus()}else{var a=t.options["onChanged"]||$.noop
a(n["email"],n["mailServerUrl"],n["mailServerName"],n["newToken"])
t.$el.modal("hide")
Phantom._bindResendEmailEvent()}},complete:function e(){t.$("#button-change").prop("disabled",false).val(i18n._("Change email address"))}})
this.$("#button-change").prop("disabled",true).val(i18n._("Changing..."))}})}
module.exports=Phantom

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/phantom-package.js.map 