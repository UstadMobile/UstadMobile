KAdefine("javascript/signup-link-package/bind-signup-links.js", function(require, module, exports) {
var Cookies=require("../shared-package/cookies.js")
var KA=require("../shared-package/ka.js")
var launchSignupLoginInModal=require("./launch-signup-login-in-modal.js")
var bindSignupLinks=function n(e,i,o,r){if(!KA.isPhantom()){return}if(Cookies.readCookie("u13")){return}if(window.location.pathname==="/signup"){return}if(KA.isPhone){return}if(!e||e.length===0){return}Array.from(e).forEach(function(n){n.addEventListener("click",function(n){n.preventDefault()
if(i){i()}launchSignupLoginInModal(o,r)},false)
n.addEventListener("mouseenter",function(n){Promise.all([require.dynimport("../login-legacy-package/login-legacy.js").then(function(n){return n.default}),require.dynimport("../login-package/signup-modal.jsx")]).then(function(){})},{once:true})})}
module.exports=bindSignupLinks

});
KAdefine("javascript/signup-link-package/launch-signup-login-in-modal.js", function(require, module, exports) {
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _reactDom=require("react-dom")
var _reactDom2=babelHelpers.interopRequireDefault(_reactDom)
var launchSignupLoginInModal=function e(n,t){var a=arguments.length>2&&arguments[2]!==undefined?arguments[2]:"signup"
var o=arguments.length>3&&arguments[3]!==undefined?arguments[3]:document.body
require.dynimport("../login-package/signup-modal.jsx").then(function(e){var r=document.querySelector("#modal-signup-container")
if(!r){r=document.createElement("div")
r.setAttribute("id","modal-signup-container")
o.appendChild(r)}_reactDom2.default.unmountComponentAtNode(r)
_reactDom2.default.render(_react2.default.createElement(e.default,{initialPurpose:a,initialRole:n,continueUrl:t,onClose:function e(){_reactDom2.default.unmountComponentAtNode(r)
o.removeChild(r)}}),r)})}
module.exports=launchSignupLoginInModal

});
; KAdefine.updatePathToPackageMap({"javascript/login-legacy-package/login-legacy.js": "login-legacy.js", "javascript/login-package/signup-modal.jsx": "login.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/signup-link-package.js.map 