KAdefine("javascript/standards-package/standards.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query getDescriptionForStandard($setId: String!, $standardId: String!) {\n        publishedStandard(setId: $setId, standardId: $standardId) {\n            id\n            description\n        }\n    }\n"],["\n    query getDescriptionForStandard($setId: String!, $standardId: String!) {\n        publishedStandard(setId: $setId, standardId: $standardId) {\n            id\n            description\n        }\n    }\n"])
var _aphrodite=require("aphrodite")
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactApollo=require("react-apollo")
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _wonderBlocksTypographyV=require("@khanacademy/wonder-blocks-typography-v1")
var _bigBingoLinks=require("../page-package/big-bingo-links.js")
var _bigBingoLinks2=babelHelpers.interopRequireDefault(_bigBingoLinks)
var _newTooltip=require("../components/new-tooltip-package/new-tooltip.jsx")
var _newTooltip2=babelHelpers.interopRequireDefault(_newTooltip)
var groupBy=function e(r,t){return r.reduce(function(e,r){var a=t(r);(e[a]=e[a]||[]).push(r)
return e},{})}
var keepMostSpecificCommonCoreMathStandards=function e(r){var t=r.map(function(e){return e.code})
var a=t.filter(function(e){return/[a-z]$/.test(e)})
var l=a.map(function(e){return e.slice(0,-1)})
return r.filter(function(e){return!l.includes(e.code)})}
function getStandardURL(e){if(e.set.id!=="CCSS.Math"){return null}var r=e.code
var t=r.split(".")
var a=""
if(t.length<2){return"/commoncore/map"}if(t.length>=4){t.length=4
a="#"+t.join(".")}if(!t[0].startsWith("HS")){return"/commoncore/grade-"+t[0]+"-"+t[1]+a}else{return"/commoncore/grade-"+t[0]+"-"+t[0][t[0].length-1]+"-"+t[1]+a.replace(".","-")}}var STANDARD_DESCRIPTION_QUERY=(0,_graphqlTag2.default)(_templateObject)
var TooltipWrapper=function e(r){return React.createElement(_newTooltip2.default,{content:React.createElement(_wonderBlocksTypographyV.Body,{style:[styles.description,r.small&&styles.small]},React.createElement("span",{dangerouslySetInnerHTML:{__html:r.tooltip}})),side:"bottom",offset:12},React.createElement("span",{className:(0,_aphrodite.css)(styles.tooltipChild)},r.child))}
var StandardCodeWithDescription=function e(r){var t=r.standard,a=r.small,l=r.linkColor
var o=t.code.replace(/-/g,"‑")
var n=t.link||getStandardURL(t)
var i=n?React.createElement("a",babelHelpers.extends({className:(0,_aphrodite.css)(l!==_wonderBlocksColorV2.default.white&&styles.linkColorBlue,l===_wonderBlocksColorV2.default.white&&styles.linkColorWhite,styles.link,a&&styles.small),href:n,target:"_blank"},_bigBingoLinks2.default.handlersWithExtras([{id:"standard_click",extra:{code:t.code}}])),o):React.createElement("span",{className:(0,_aphrodite.css)(a&&styles.small)},o)
if(t.descriptionHtml){return React.createElement(TooltipWrapper,{tooltip:t.descriptionHtml,small:a,child:i})}else{return React.createElement(_reactApollo.Query,{query:STANDARD_DESCRIPTION_QUERY,variables:{setId:t.set.id,standardId:t.code}},function(e){if(!e.loading&&!e.error&&e.data&&e.data.publishedStandard){return React.createElement(TooltipWrapper,{tooltip:e.data.publishedStandard.description,small:a,child:i})}else{return i}})}}
var Standards=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props,t=r.standards,a=r.showSetPrefix,l=r.small,o=r.linkColor
var n=groupBy(t,function(e){return e.set.prefix})
var i=Object.keys(n)
for(var s=i,d=Array.isArray(s),c=0,s=d?s:s[Symbol.iterator]();;){var p
if(d){if(c>=s.length)break
p=s[c++]}else{c=s.next()
if(c.done)break
p=c.value}var u=p
if(u.startsWith("Common Core")){n[u]=keepMostSpecificCommonCoreMathStandards(n[u])}}return React.createElement("div",null,i.map(function(e,r){return React.createElement(_wonderBlocksTypographyV.Body,{key:e,style:[styles.set,l&&styles.small,o===_wonderBlocksColorV2.default.white&&styles.linkColorWhite]},a&&e+": ",n[e].map(function(r,t){return React.createElement("span",{key:r.code},React.createElement(StandardCodeWithDescription,{standard:r,small:l,linkColor:o}),t!==n[e].length-1&&", ")}),r!==i.length-1&&" ")}))}
return r}(_react.Component)
Standards.defaultProps={showSetPrefix:true,small:false,linkColor:_wonderBlocksColorV2.default.blue}
exports.default=Standards
var styles=_aphrodite.StyleSheet.create({description:{display:"block",maxWidth:360},tooltipChild:{display:"inline-block"},linkColorBlue:{color:_wonderBlocksColorV2.default.blue},linkColorWhite:{color:_wonderBlocksColorV2.default.white},link:{textDecoration:"none",":hover":{textDecoration:"underline"}},set:{display:"block"},small:{fontSize:12,lineHeight:"14px"}})

});
KAdefine("javascript/standards-package/standards-data.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query getStandardsDataForLocaleAndDomain(\n        $locale: String!\n        $domain: String\n    ) {\n        allSetsOfStandards(locale: $locale, domain: $domain) {\n            id\n            name\n            shortName\n            standards {\n                id\n                standardId\n                description\n                children\n            }\n        }\n    }\n"],["\n    query getStandardsDataForLocaleAndDomain(\n        $locale: String!\n        $domain: String\n    ) {\n        allSetsOfStandards(locale: $locale, domain: $domain) {\n            id\n            name\n            shortName\n            standards {\n                id\n                standardId\n                description\n                children\n            }\n        }\n    }\n"]),_templateObject2=babelHelpers.taggedTemplateLiteralLoose(["\n    query getContentForStandard($set: String!, $standard: String) {\n        contentForStandardMappings(setId: $set, standardId: $standard)\n    }\n"],["\n    query getContentForStandard($set: String!, $standard: String) {\n        contentForStandardMappings(setId: $set, standardId: $standard)\n    }\n"])
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _apolloFetch2=babelHelpers.interopRequireDefault(_apolloFetch)
var STANDARDS_DATA_QUERY=(0,_graphqlTag2.default)(_templateObject)
var STANDARDS_CONTENT_QUERY=(0,_graphqlTag2.default)(_templateObject2)
var StandardsData=function(){a.fetch=function r(e,t){return(0,_apolloFetch2.default)(STANDARDS_DATA_QUERY,{locale:e,domain:t}).then(function(r){return new a(r)})}
a.fetchContent=function a(r,e){return(0,_apolloFetch2.default)(STANDARDS_CONTENT_QUERY,{set:r,standard:e}).then(function(a){return a})}
function a(r){babelHelpers.classCallCheck(this,a)
var e={}
var t=function a(){if(d){if(s>=n.length)return"break"
o=n[s++]}else{s=n.next()
if(s.done)return"break"
o=s.value}var r=o
e[r.id]={name:r.name,shortName:r.shortName,standards:{}}
r.standards.forEach(function(a,t){e[r.id].standards[a.standardId]={description:a.description,children:a.children,index:t}})}
for(var n=r.data.allSetsOfStandards,d=Array.isArray(n),s=0,n=d?n:n[Symbol.iterator]();;){var o
var i=t()
if(i==="break")break}for(var l=Object.keys(e),p=Array.isArray(l),c=0,l=p?l:l[Symbol.iterator]();;){var u
if(p){if(c>=l.length)break
u=l[c++]}else{c=l.next()
if(c.done)break
u=c.value}var f=u
var v=e[f]
for(var S=Object.keys(v.standards),h=Array.isArray(S),g=0,S=h?S:S[Symbol.iterator]();;){var m
if(h){if(g>=S.length)break
m=S[g++]}else{g=S.next()
if(g.done)break
m=g.value}var b=m
var y=v.standards[b]
for(var A=y.children||[],D=Array.isArray(A),T=0,A=D?A:A[Symbol.iterator]();;){var N
if(D){if(T>=A.length)break
N=A[T++]}else{T=A.next()
if(T.done)break
N=T.value}var k=N
var q=v.standards[k]
if(q.parent){console.warn("Standard "+f+"|"+k+" has too many","parents: "+q.parent.id+", "+b)}q.parent=b}}}this.sets=e}a.prototype.getSetName=function a(r){var e=r.split("|"),t=e[0]
var n=this.sets[t]
if(n){return n.shortName||n.name}else{console.warn("Standard set "+t+" not found.")
return null}}
a.prototype.getStandardDescription=function a(r){var e=r.split("|"),t=e[0],n=e[1]
var d=this.sets[t]
if(d){var s=d.standards[n]
if(s){return s.description}}console.warn("Standard "+t+"|"+n+" not found.")
return null}
a.prototype.getParentStandard=function a(r){var e=r.split("|"),t=e[0],n=e[1]
var d=this.sets[t]
if(d){var s=d.standards[n]
if(s&&s.parent){return t+"|"+s.parent}}return null}
a.prototype.toObject=function a(r){var e=r.split("|"),t=e[0],n=e[1]
return{code:n,descriptionHtml:this.getStandardDescription(r)||"",set:{id:t,prefix:this.getSetName(r)||""}}}
a.prototype.sorted=function a(r){var e=this
r=Array.from(r)
r.sort(function(a,r){var t=a.split("|"),n=t[0],d=t[1]
var s=r.split("|"),o=s[0],i=s[1]
var l=e.sets[n]
var p=e.sets[o]
if(!l||!p){return 0}if(n!==o){return l.name<p.name?-1:1}else{var c=l.standards[d]
var u=p.standards[i]
if(!c||!u){return 0}return c.index-u.index}})
return r}
return a}()
exports.default=StandardsData

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/standards-package.js.map 