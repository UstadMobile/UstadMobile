KAdefine("javascript/analytics-package/analytics.js", function(require, module, exports) {
var _constants=require("./constants.js")
var constants=babelHelpers.interopRequireWildcard(_constants)
var _googleAnalytics=require("./google-analytics.js")
var googleAnalytics=babelHelpers.interopRequireWildcard(_googleAnalytics)
var _mixpanel=require("./mixpanel.js")
var mixpanel=babelHelpers.interopRequireWildcard(_mixpanel)
var _pageLifecycle=require("./page-lifecycle.js")
var pageLifecycle=babelHelpers.interopRequireWildcard(_pageLifecycle)
var _pageloadTiming=require("./pageload-timing.js")
var pageloadTiming=babelHelpers.interopRequireWildcard(_pageloadTiming)
module.exports=babelHelpers.extends({},constants,googleAnalytics,mixpanel,pageLifecycle,pageloadTiming)

});
KAdefine("javascript/analytics-package/pageload-marker.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _analytics=require("./analytics.js")
var _analytics2=babelHelpers.interopRequireDefault(_analytics)
var earlyUsableWindowProp=_analytics2.default.getEarlyUsableWindowProp()
var timingSummaryProp=_analytics2.default.getTimingSummaryProp()
var makeEventMarker=function e(r){return["window['"+earlyUsableWindowProp+"'] = window['"+earlyUsableWindowProp+"'] || {}","window['"+earlyUsableWindowProp+"']['"+r+"'] = window.performance && "+"window.performance.now && window.performance.now()","window['"+timingSummaryProp+"'] = { "+("pageName: '"+r+"', nav: 'server', sufficientlyUsable: 0}")].join(";")+";"}
var PageloadMarker=function(e){babelHelpers.inherits(r,e)
function r(){var a,t,i
babelHelpers.classCallCheck(this,r)
for(var n=arguments.length,l=Array(n),s=0;s<n;s++){l[s]=arguments[s]}return i=(a=(t=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),t),t._didMount=false,t._didMarkInteractive=false,t._didMarkUsable=false,a),babelHelpers.possibleConstructorReturn(t,i)}r.prototype.componentDidMount=function e(){var r=this.props,a=r.markFullyInteractiveOnMount,t=r.markSufficientlyUsable,i=r.pageName,n=r.fullyInteractive,l=r.sufficientlyUsable
this._didMount=true
this._didMarkUsable=t!=="other"||l
this._didMarkInteractive=a||n
_analytics2.default.reportPageLifecycleTiming(i,{interactive:this._didMarkInteractive,usable:this._didMarkUsable})}
r.prototype.UNSAFE_componentWillUpdate=function e(r){var a=this.props.pageName
if(!this._didMarkUsable&&r.sufficientlyUsable||!this._didMarkInteractive&&r.fullyInteractive){this._didMarkUsable=r.sufficientlyUsable
this._didMarkInteractive=r.fullyInteractive
_analytics2.default.reportPageLifecycleTiming(a,{interactive:this._didMarkInteractive,usable:this._didMarkUsable})}}
r.prototype.renderEarlyMarkerScript=function e(){var r=this.props.pageName
return React.createElement("script",{dangerouslySetInnerHTML:{__html:makeEventMarker(r)}})}
r.prototype.render=function e(){var r=this.props.markSufficientlyUsable
return!this._didMount&&r==="markup"?this.renderEarlyMarkerScript():null}
return r}(React.Component)
PageloadMarker.defaultProps={markFullyInteractiveOnMount:false,markSufficientlyUsable:"other"}
exports.default=PageloadMarker

});
KAdefine("javascript/analytics-package/constants.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var timingStats=exports.timingStats={REDIRECT_MS:"stats.time.client.redirect_ms",DNS_MS:"stats.time.client.dns_ms",CONNECT_MS:"stats.time.client.connect_ms",REQUEST_MS:"stats.time.client.request_ms",RESPONSE_MS:"stats.time.client.response_ms",DOCUMENT_MS:"stats.time.client.document_ms",CONTENT_LOADED_MS:"stats.time.client.content_loaded_ms",START_TO_CONTENT_LOADED_MS:"stats.time.client.start_to_content_loaded_ms",RESOURCE_NET_MS:"stats.time.client.resource_net_ms",STATIC_JSCSS_NET_MS:"stats.time.client.static_jscss_net_ms",SUFFICIENTLY_USABLE_MS:"stats.time.client.sufficiently_usable_ms",FULLY_INTERACTIVE_MS:"stats.time.client.fully_interactive_ms",FIRST_BYTE_MS:"stats.time.client.first_byte_ms"}

});
KAdefine("javascript/analytics-package/conversion-context.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.withConversionContext=undefined
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _bigbingo=require("../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var ConversionExtrasContext=React.createContext({tzOffset:(new Date).getTimezoneOffset()})
var ConversionContext=function(e){babelHelpers.inherits(n,e)
function n(){var t,r,o
babelHelpers.classCallCheck(this,n)
for(var a=arguments.length,i=Array(a),s=0;s<a;s++){i[s]=arguments[s]}return o=(t=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(i))),r),r.getMarkConversionFunc=function(e){return function(n){_bigbingo2.default.markConversion(n.id,babelHelpers.extends({},e,n.extras||{})).then(function(){r.props.onMarkConversion(n,e)})}},t),babelHelpers.possibleConstructorReturn(r,o)}n.prototype.render=function e(){var n=this
var t=this.props,r=t.children,o=t.extras
return React.createElement(ConversionExtrasContext.Consumer,null,function(e){var t=babelHelpers.extends({},e,o)
return React.createElement(ConversionExtrasContext.Provider,{value:t},typeof r==="function"?r(n.getMarkConversionFunc(t)):r)})}
return n}(React.Component)
ConversionContext.defaultProps={extras:{},onMarkConversion:function e(n,t){}}
exports.default=ConversionContext
var withConversionContext=exports.withConversionContext=function e(n){return function(e){return function(t){return React.createElement(ConversionContext,{extras:typeof n==="function"?n(t):n},function(n){return React.createElement(e,babelHelpers.extends({markConversion:n},t))})}}}

});
KAdefine("javascript/analytics-package/google-analytics.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var sendEventToGA=exports.sendEventToGA=function e(r,t){if(!window.ga){return}switch(r){case"videoStart":window.ga("send","event","Learning-Action","Video-Start",t.videoSlug)
break}}
var getGAReferrer=exports.getGAReferrer=function e(){var r=""
if(window.ga){window.ga(function(e){r=e.get("referrer")})}return r}

});
KAdefine("javascript/analytics-package/ka-client-timing.js", function(require, module, exports) {
var KAClientTiming={clientHasResourceTimingAPI:function e(){return Boolean(window.performance&&typeof window.performance.getEntriesByType==="function")},getResourceEntries:function e(n){if(!this.clientHasResourceTimingAPI()||!window.performance.timing){return[]}var r=window.performance.getEntriesByType("resource")
if(n){r=r.filter(function(e){return n.test(e.name)})}var t=window.performance.timing.navigationStart
return r.map(function(e){return{name:e.name,startTime:t+e.startTime,endTime:t+e.startTime+e.duration}})},wallTime:function e(n,r){r=r||Number.MAX_VALUE
n=(n||[]).sort(function(e,n){return e.startTime-n.startTime})
var t=0
var i=0
var a=0
n.forEach(function(e){var n=e.startTime
var o=e.endTime
if(o>r){return}if(n<=a){a=Math.max(a,o)}else{t+=a-i
i=n
a=o}})
t+=a-i
return Math.round(t)}}
module.exports=KAClientTiming

});
KAdefine("javascript/analytics-package/mixpanel.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var trackInitialPageLoad=exports.trackInitialPageLoad=function t(e){}
var trackPageView=exports.trackPageView=function t(e,r){}
var trackActivityBegin=exports.trackActivityBegin=function t(e,r){}
var trackActivityEnd=exports.trackActivityEnd=function t(e){}
var trackSingleEvent=exports.trackSingleEvent=function t(e,r){return Promise.resolve()}

});
KAdefine("javascript/analytics-package/page-lifecycle.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.reportPageUsableTiming=exports.reportPageInteractiveTiming=exports.reportPageLifecycleTiming=exports.handleRouterNavigation=exports.handleStartRouterNavigation=exports.init=exports.getTimingSummaryProp=exports.getEarlyUsableWindowProp=undefined
var _bigbingo=require("../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _khanFetch=require("../shared-package/khan-fetch.js")
var state={epoch:0,clientSide:false,path:null,startTime:0,hasReportedSufficientlyUsable:false,hasReportedFullyInteractive:false,hasReportedFirstByte:false}
var update=function e(a){return state=a}
var EARLY_USABLE_WINDOW_PROP="__analyticsPageUsableTimings"
var CURRENT_ANALYTICS_WINDOW_PROP="__analyticsTimings"
var getEarlyUsableWindowProp=exports.getEarlyUsableWindowProp=function e(){return EARLY_USABLE_WINDOW_PROP}
var resetEarlyUsableIndicators=function e(){window[EARLY_USABLE_WINDOW_PROP]={}}
var earlyUsableTimeForPage=function e(a){return window[EARLY_USABLE_WINDOW_PROP]&&window[EARLY_USABLE_WINDOW_PROP][a]}
var getTimingSummaryProp=exports.getTimingSummaryProp=function e(){return CURRENT_ANALYTICS_WINDOW_PROP}
var resetTimingSummaryGlobal=function e(){window[CURRENT_ANALYTICS_WINDOW_PROP]={}}
var updateTimingSummaryGlobal=function e(a){window[CURRENT_ANALYTICS_WINDOW_PROP]=a}
var markPageviewConversion=function e(a){return _bigbingo2.default.markConversion("pageview",{path:a,qs:window.location.search.slice(1),utc:-(new Date).getTimezoneOffset()})}
var checkMarkHomepageConversion=function e(a){var t=!!a&&a.split("/").join("")===""
if(t){var r=_ka2.default.isLoggedIn()
if(r){_bigbingo2.default.markConversion("pageview_logged_in_homepage")}else{_bigbingo2.default.markConversion("pageview_logged_out_homepage")}}}
var markNavConversions=function e(a){var t={path:a,qs:window.location.search.slice(1),utc:-(new Date).getTimezoneOffset()}
var r=[{id:"pageview",extra:t},{id:"pagerequest",extra:t}]
_bigbingo2.default.markConversionsWithExtras(r)}
var init=exports.init=function e(){var a=window.location.pathname
markPageviewConversion(a)
update(babelHelpers.extends({},state,{currentPath:a}))
resetTimingSummaryGlobal()}
var handleStartRouterNavigation=exports.handleStartRouterNavigation=function e(){resetEarlyUsableIndicators()
resetTimingSummaryGlobal()
if(window.performance){update(babelHelpers.extends({},state,{clientSide:true,epoch:state.epoch+1,startTime:window.performance.now(),hasReportedSufficientlyUsable:false,hasReportedFullyInteractive:false}))}}
var handleRouterNavigation=exports.handleRouterNavigation=function e(){var a=window.location.pathname
if(state.currentPath===a){return state}markNavConversions(a)
checkMarkHomepageConversion(a)
if(window.ga){window.ga("send","pageview",a)}update(babelHelpers.extends({},state,{currentPath:a}))}
var reportPageLifecycleTiming=exports.reportPageLifecycleTiming=function e(a,t){var r=arguments.length>2&&arguments[2]!==undefined?arguments[2]:1
if(!window.performance){return Promise.resolve()}var i=babelHelpers.extends({},state)
var n=window.performance.now()
var o=state.clientSide?"client":"server"
var s=null
var l=null
var u=null
if(t.interactive&&!state.hasReportedFullyInteractive){s=Math.round(n-state.startTime)
i.hasReportedFullyInteractive=true}if(t.usable&&!state.hasReportedSufficientlyUsable){l=Math.round((earlyUsableTimeForPage(a)||n)-state.startTime)
i.hasReportedSufficientlyUsable=true}if(!state.clientSide&&!state.hasReportedFirstByte){u=window.performance.timing.responseStart-window.performance.timing.navigationStart
i.hasReportedFirstByte=true}update(i)
if(s===null&&l===null&&u===null||Math.random()>=r){return Promise.resolve()}var g=_ka2.default.featureFlag("GANDALF_USE_PAGE_PERF_LOG_SERVICE")?"/api/internal/_bb/page_perf_log":"/api/internal/_mt/page_perf_log"
var p={originalRequestId:_ka2.default.requestLogId,pageName:a,navigation:o,sufficientlyUsable:l,fullyInteractive:s,firstByte:u}
updateTimingSummaryGlobal(p)
return(0,_khanFetch.khanFetch)(g,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(p)})}
var reportPageInteractiveTiming=exports.reportPageInteractiveTiming=function e(a){return reportPageLifecycleTiming(a,{interactive:true})}
var reportPageUsableTiming=exports.reportPageUsableTiming=function e(a){var t=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false
return t&&!state.clientSide?Promise.resolve():reportPageLifecycleTiming(a,{usable:true})}

});
KAdefine("javascript/analytics-package/pageload-timing.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.reportTiming=undefined
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _kaClientTiming=require("./ka-client-timing.js")
var _kaClientTiming2=babelHelpers.interopRequireDefault(_kaClientTiming)
var _constants=require("./constants.js")
var _util=require("./util.js")
var reportTiming=exports.reportTiming=function e(){if(!window.performance||!window.performance.timing){return}var t=function e(t){return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")}
var r=window.performance.timing
var n=r.navigationStart
var a=r.redirectEnd-r.redirectStart
var i=r.domainLookupEnd-r.domainLookupStart
var s=r.connectEnd-r.connectStart
var o=r.responseStart-r.requestStart
var d=r.responseEnd-r.responseStart
var l=r.domContentLoadedEventStart-r.responseEnd
var c=r.domContentLoadedEventEnd-r.domContentLoadedEventStart
var u=r.domContentLoadedEventEnd-n
var v=r.domContentLoadedEventStart
var E={}
if(_kaClientTiming2.default.clientHasResourceTimingAPI()){var S=_kaClientTiming2.default.getResourceEntries(/\.js$|\.css$/)
E["net"]=_kaClientTiming2.default.wallTime(S,v)
var T=new RegExp(t((0,_staticUrl2.default)(""))+"/.+\\.(?:css|js)$")
var m=_kaClientTiming2.default.getResourceEntries(T)
E["static_jscss_net"]=_kaClientTiming2.default.wallTime(m,v)}var p={}
var g={}
var C=_constants.timingStats
g[C.REDIRECT_MS]=a
g[C.DNS_MS]=i
g[C.CONNECT_MS]=s
g[C.REQUEST_MS]=o
g[C.RESPONSE_MS]=d
g[C.DOCUMENT_MS]=l
g[C.CONTENT_LOADED_MS]=c
g[C.START_TO_CONTENT_LOADED_MS]=u
if(E){g[C.RESOURCE_NET_MS]=E["net"]
g[C.STATIC_JSCSS_NET_MS]=E["static_jscss_net"]}return(0,_util.postTimings)(p,g)}

});
KAdefine("javascript/analytics-package/types.js", function(require, module, exports) {

});
KAdefine("javascript/analytics-package/util.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.postTimings=undefined
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _khanFetch=require("../shared-package/khan-fetch.js")
var postTimings=exports.postTimings=function e(a,r){var t=arguments.length>2&&arguments[2]!==undefined?arguments[2]:null
return(0,_khanFetch.khanFetch)("/api/internal/_mt/elog",babelHelpers.extends({method:"POST"},(0,_khanFetch.formUrlencode)(babelHelpers.extends({},a,r,{_request_id:_ka2.default.requestLogId,_graphite_key_prefix:t||_ka2.default.gaeStatsKeyPrefix,_graphite_keys:Object.keys(r).join()}))))}

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/analytics-package.js.map 