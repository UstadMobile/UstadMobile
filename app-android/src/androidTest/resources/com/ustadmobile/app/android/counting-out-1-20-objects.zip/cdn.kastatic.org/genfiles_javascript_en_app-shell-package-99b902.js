KAdefine("javascript/app-shell-package/app.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _reactRouterDom=require("react-router-dom")
var _reactRedux=require("react-redux")
var _aphrodite=require("aphrodite")
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _appStore=require("./store/app-store.js")
var _statefulHeader=require("../page-package/stateful-header.jsx")
var _statefulHeader2=babelHelpers.interopRequireDefault(_statefulHeader)
var _statefulFooter=require("./stateful-footer.jsx")
var _statefulFooter2=babelHelpers.interopRequireDefault(_statefulFooter)
var _topLevelRoute=require("./top-level-route.jsx")
var _topLevelRoute2=babelHelpers.interopRequireDefault(_topLevelRoute)
var _topLevelContentRoute=require("./top-level-content-route.jsx")
var _topLevelContentRoute2=babelHelpers.interopRequireDefault(_topLevelContentRoute)
var _topLevelCoachRoute=require("./top-level-coach-route.jsx")
var _topLevelCoachRoute2=babelHelpers.interopRequireDefault(_topLevelCoachRoute)
var _utils=require("./utils.js")
var _parseQueryString2=require("../shared-package/parse-query-string.js")
var _parseQueryString3=babelHelpers.interopRequireDefault(_parseQueryString2)
var _footerUtils=require("./store/footer-utils.js")
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v2")
var _isSsr=require("../ssr-package/is-ssr.js")
var _isSsr2=babelHelpers.interopRequireDefault(_isSsr)
var _routeHistory=require("./route-history.jsx")
var _routeHistory2=babelHelpers.interopRequireDefault(_routeHistory)
var _routeHistoryContext=require("./route-history-context.js")
var _routeHistoryContext2=babelHelpers.interopRequireDefault(_routeHistoryContext)
var Router=_isSsr2.default?_reactRouterDom.StaticRouter:_reactRouterDom.BrowserRouter
function maybeGetServersideProps(){if(_isSsr2.default){return{location:location.pathname,context:{}}}return{}}var App=function(e){babelHelpers.inherits(t,e)
function t(r){babelHelpers.classCallCheck(this,t)
var a=babelHelpers.possibleConstructorReturn(this,e.call(this))
a.state={extraHeaderProps:{}}
a.updateHeaderProps=function(e){a.setState({extraHeaderProps:e})}
var o={footer:{attribution:(0,_footerUtils.extractAttribution)(r.componentProps),hideFooter:false}}
a._store=(0,_appStore.createAppStore)(o)
return a}t.prototype.componentDidMount=function e(){this.promptLoginIfRequested(window.location)}
t.prototype.componentWillUnmount=function e(){if(this._unlisten){this._unlisten()}}
t.prototype.promptLoginIfRequested=function e(t){var r=(0,_parseQueryString3.default)(t.search),a=r.prompt_login
if(a==="true"&&!this.props.loggedIn){require.dynimport("../signup-link-package/launch-signup-login-in-modal.js").then(function(e){return e.default}).then(function(e){var r=t.pathname+t.search+t.hash
e(undefined,r,"login")})}}
t.prototype.renderRoutes=function e(t,r){var a=this
var o={initialComponentProps:r.length===1?t:undefined,updateHeaderProps:this.updateHeaderProps}
return _react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.mainContent)},_react2.default.createElement(_reactRouterDom.Switch,null,_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/app-shell-example",component:function e(){return require.dynimport("../app-shell-example-package/example.jsx")}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/bncc",component:function e(){return require.dynimport("../bncc-package/bncc-page.jsx")}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/campaign/:campaignId/videos/:stepId",component:function e(){return require.dynimport("../teacher-campaign-package/video-page.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/campaign/:campaignId/response/:stepId",component:function e(){return require.dynimport("../teacher-campaign-package/response-page.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/demo/program/lsc-:campaignId",component:function e(){return require.dynimport("../learnstorm-dashboard-package/level-zero.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true},hideFooter:true})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/__demo__/program/lsc-:campaignId",component:function e(){return require.dynimport("../learnstorm-dashboard-package/demo-dashboard.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true},hideFooter:true})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/:classId/program/lsc-:campaignId",component:function e(){return require.dynimport("../learnstorm-dashboard-package/class-dashboard.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true},hideFooter:true})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/__demo__/program/:campaignId",component:function e(){return require.dynimport("../brain-training-package/demo-dashboard.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/:classId/program/:campaignId",component:function e(){return require.dynimport("../brain-training-package/class-dashboard.jsx")},extraHeaderProps:{pageDomain:"default",transparent:true}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/:classId/student/:studentKaid",component:function e(){return require.dynimport("../class-package/student/student-page.jsx")},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/:classId/progress/unit-mastery/subject/:subjectId/unit/:unitId",component:function e(){return require.dynimport("../class-package/new-progress/unit-mastery-progress.jsx")},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/coach/class/:classId",component:function e(){return require.dynimport("../class-package/class.jsx")},dependencies:function e(){return Promise.all([require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/assignments-package/assignments.less")])},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/devadmin/mpp/learnstorm/:id",component:function e(){return require.dynimport("../learnstorm-common-package/admin/editor.jsx")},extraHeaderProps:{pageDomain:"default",fullBleed:true}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/devadmin/mpp/learnstorm",component:function e(){return require.dynimport("../learnstorm-common-package/admin/editor.jsx")},extraHeaderProps:{pageDomain:"default",fullBleed:true}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/devadmin/mpp/teacher-campaign/:id",component:function e(){return require.dynimport("../teacher-campaign-package/admin/editor.jsx")},extraHeaderProps:{pageDomain:"default",fullBleed:true}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/devadmin/mpp/teacher-campaign",component:function e(){return require.dynimport("../teacher-campaign-package/admin/editor.jsx")},extraHeaderProps:{pageDomain:"default",fullBleed:true}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/donate/sub_:subscriptionId/edit",component:function e(){return require.dynimport("../donate-edit-subscription-package/index.jsx")},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/report/assignment/:assignmentId",component:function e(){return require.dynimport("../coach-report-exercise-package/coach-report.jsx")},dependencies:function e(){return Promise.all([require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/odometer-package/odometer.less"),require.dynimport("../../stylesheets/avatar-customizer-package/avatar-customizer.less"),require.dynimport("../../stylesheets/tasks-package/tasks.less")])},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/*/:kind(e|q|u)/:slug/:maybeDemoSlug(report|demo-report)",component:function e(){return require.dynimport("../coach-report-exercise-package/exercise.jsx")},dependencies:function e(){return Promise.all([require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/odometer-package/odometer.less"),require.dynimport("../../stylesheets/avatar-customizer-package/avatar-customizer.less"),require.dynimport("../../stylesheets/tasks-package/tasks.less")])},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{showComponentBeforeProps:true,path:"/:domain/*/modal/:type(v|a|p[a-z]?)/:id",component:function e(){return require.dynimport("../content-library-package/content-library-curation-page.jsx")},maintainScrollPosition:true,maintainExistingRouteDuringTransition:"always",canReuseProps:true,getPropsViaCDN:true})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{showComponentBeforeProps:true,path:"/:domain/*/modal/:type/:id",component:function e(){return require.dynimport("../content-library-package/content-library-curation-page.jsx")},maintainScrollPosition:true,maintainExistingRouteDuringTransition:"always",canReuseProps:true,getPropsViaCDN:false})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{path:"/:domain/*/:kind(v|a|p[a-z]?)/:slug",maintainExistingRouteDuringTransition:"between-same-path",component:function e(){return require.dynimport("../tutorial-page-package/tutorial-page.jsx")},dependencies:_utils.getDependenciesForLessonRoute,getPropsViaCDN:true})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{path:"/:domain/*/:kind(e)/:slug",maintainExistingRouteDuringTransition:"between-same-path",component:function e(){return require.dynimport("../tutorial-page-package/tutorial-page.jsx")},dependencies:_utils.getDependenciesForLessonRoute,getPropsViaCDN:false})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{path:"/:domain/:subject/:unit",component:function e(){return require.dynimport("../content-library-package/content-library-curation-page.jsx")},getPropsViaCDN:true})),_react2.default.createElement(_topLevelCoachRoute2.default,babelHelpers.extends({},o,{path:"/coach/*",component:function e(){return require.dynimport("../coach-dashboard-package/coach.jsx")},extraHeaderProps:{pageDomain:"default"}})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{path:"/:domain/:subject",component:function e(){return require.dynimport("../content-library-package/content-library-curation-page.jsx")},getPropsViaCDN:true})),_react2.default.createElement(_topLevelContentRoute2.default,babelHelpers.extends({},o,{path:"/:domain",component:function e(){return require.dynimport("../content-library-package/content-library-curation-page.jsx")},getPropsViaCDN:true})),_react2.default.createElement(_topLevelRoute2.default,babelHelpers.extends({},o,{path:"/",component:function e(){return a.props.loggedIn?require.dynimport("../dashboard-package/bibliotron-homepage-with-nav.jsx"):require.dynimport("../logged-out-homepage-package/logged-out-homepage-module-list.jsx").then(function(e){return e.default})},dependencies:function e(){return(0,_utils.getDependenciesForHomePageRoute)(a.props.loggedIn)},propsUrl:"/",extraHeaderProps:this.props.loggedIn?null:{transparent:true}}))))}
t.prototype.renderHeader=function e(){var t=this
var r=_wonderBlocksColorV2.default.darkBlue
return _react2.default.createElement(_wonderBlocksCoreV.WithSSRPlaceholder,{placeholder:function e(){return _react2.default.createElement(HeaderPlaceholder,{color:r})}},function(){return _react2.default.createElement(_statefulHeader2.default,babelHelpers.extends({},t.props.headerProps,t.state.extraHeaderProps,{allowDomainTheming:true}))})}
t.prototype.renderFooter=function e(){var t=this
return _react2.default.createElement(_wonderBlocksCoreV.WithSSRPlaceholder,{placeholder:null},function(){return _react2.default.createElement("div",{id:"footer"},_react2.default.createElement(_statefulFooter2.default,t.props.footerProps))})}
t.prototype.renderRouter=function e(t){var r=this
return _react2.default.createElement(Router,maybeGetServersideProps(),_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.wrapper)},_react2.default.createElement(_routeHistory2.default,null,function(e){var a=e.history
return _react2.default.createElement(_routeHistoryContext2.default.Provider,{value:{history:a}},r.renderHeader(),r.renderRoutes(t,a),r.renderFooter())})))}
t.prototype.render=function e(){var t=this.props
return _react2.default.createElement(_reactRedux.Provider,{store:this._store},this.renderRouter(t.componentProps))}
return t}(_react.PureComponent)
var HeaderPlaceholder=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props.color
return _react2.default.createElement("div",{style:{height:62,backgroundColor:t}})}
return t}(_react2.default.Component)
var styles=_aphrodite.StyleSheet.create({wrapper:{display:"flex",flexDirection:"column",minHeight:"100vh"},mainContent:{}})
exports.default=App

});
KAdefine("javascript/app-shell-package/store/app-store.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.createAppStore=createAppStore
var _redux=require("redux")
var _footerReducer=require("./footer-reducer.js")
var _footerReducer2=babelHelpers.interopRequireDefault(_footerReducer)
var reducers={footer:_footerReducer2.default}
function createAppStore(e){return(0,_redux.createStore)((0,_redux.combineReducers)(reducers),e)}
});
KAdefine("javascript/app-shell-package/store/footer-reducer.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _footerUtils=require("./footer-utils.js")
var defaultFooterState={attribution:undefined,hideFooter:false}
var footer=function e(){var t=arguments.length>0&&arguments[0]!==undefined?arguments[0]:defaultFooterState
var o=arguments[1]
switch(o.type){case"COMPLETE_LOADING_NEW_ROUTE":return babelHelpers.extends({},t,{attribution:o.componentProps?(0,_footerUtils.extractAttribution)(o.componentProps):t.attribution,hideFooter:o.hideFooter})
default:return t}}
exports.default=footer

});
KAdefine("javascript/app-shell-package/store/footer-utils.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.extractAttribution=extractAttribution
function extractAttribution(t){if(!t){return undefined}return t.attribution||t.curation&&t.curation.attribution}
});
KAdefine("javascript/app-shell-package/store/actions.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.startLoadingRoute=startLoadingRoute
exports.completeLoadingRoute=completeLoadingRoute
function startLoadingRoute(){return{type:"START_LOADING_NEW_ROUTE"}}function completeLoadingRoute(e,t){return{type:"COMPLETE_LOADING_NEW_ROUTE",componentProps:e,hideFooter:t}}
});
KAdefine("javascript/app-shell-package/lazy-route-handler.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.LazyRouteHandler=undefined
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactRedux=require("react-redux")
var _aphrodite=require("aphrodite")
var _reactRouterDom=require("react-router-dom")
var _analytics=require("../analytics-package/analytics.js")
var _analytics2=babelHelpers.interopRequireDefault(_analytics)
var _formatQueryString=require("../shared-package/format-query-string.js")
var _formatQueryString2=babelHelpers.interopRequireDefault(_formatQueryString)
var _khanFetch=require("../shared-package/khan-fetch.js")
var _parseQueryString=require("../shared-package/parse-query-string.js")
var _parseQueryString2=babelHelpers.interopRequireDefault(_parseQueryString)
var _scrollUtils=require("../scroll-utils-package/scroll-utils.js")
var _timeoutSpinner=require("../shared-components-package/timeout-spinner.jsx")
var _timeoutSpinner2=babelHelpers.interopRequireDefault(_timeoutSpinner)
var _eagerPromise=require("../ssr-package/eager-promise.js")
var _eagerPromise2=babelHelpers.interopRequireDefault(_eagerPromise)
var _routeHistoryContext=require("./route-history-context.js")
var _routeHistoryContext2=babelHelpers.interopRequireDefault(_routeHistoryContext)
var _actions=require("./store/actions.js")
var maybeDefault=function e(t){return t&&t.default||t}
var LazyRouteHandler=exports.LazyRouteHandler=function(e){babelHelpers.inherits(t,e)
function t(r){babelHelpers.classCallCheck(this,t)
var a=babelHelpers.possibleConstructorReturn(this,e.call(this,r))
_initialiseProps.call(a)
var o=r.initialComponentProps,n=r.component
var i={componentProps:o}
var s=n()
if(a.isInitialPageLoad()){try{var p=maybeDefault(_eagerPromise2.default.unwrap(s))
a.state=babelHelpers.extends({},i,{Component:p,showLoadingIndicator:false})
return babelHelpers.possibleConstructorReturn(a)}catch(e){if(!(e instanceof _eagerPromise.NotAnEagerPromiseError)){throw e}}}a.state=babelHelpers.extends({},i,{showLoadingIndicator:true})
return a}t.prototype.componentDidMount=function e(){this._mounted=true
if(this.state.Component){return}this.processRouteChange({needsPackages:true,propsUrl:this.props.initialComponentProps?null:this.props.propsUrl,pathname:this.props.pathname,search:this.props.search,component:this.props.component,dependencies:this.props.dependencies,isLoadingIndicatorRequired:true,isScrollPositionMaintained:false,computedMatch:this.props.computedMatch,extraHeaderProps:this.props.extraHeaderProps,isInitialPageLoad:this.isInitialPageLoad(),showComponentBeforeProps:this.props.showComponentBeforeProps})}
t.prototype.UNSAFE_componentWillReceiveProps=function e(t){if(this.props.pathname===t.pathname){if(t.initialComponentProps!==undefined&&t.initialComponentProps!==this.props.initialComponentProps&&this._mounted){this.setState({componentProps:t.initialComponentProps})}return}var r=this.props.path!==t.path
var a=t.propsUrl,o=t.canReuseProps
var n=this.isInitialPageLoad()
var i=a
if(!n&&o){i=null}var s=this.calculateLoadingIndicatorNecessary(t)
var p=this.props.maintainScrollPosition||t.maintainScrollPosition
this.processRouteChange({needsPackages:r,propsUrl:i,pathname:t.pathname,search:t.search,component:t.component,dependencies:t.dependencies,isLoadingIndicatorRequired:s,isScrollPositionMaintained:p,computedMatch:t.computedMatch,extraHeaderProps:t.extraHeaderProps,isInitialPageLoad:n,showComponentBeforeProps:t.showComponentBeforeProps,forceUpdate:!i})}
t.prototype.shouldComponentUpdate=function e(t,r){var a=this.props.propsUrl
if(this.state.Component===r.Component&&a&&this.state.componentProps===r.componentProps&&this.state.showLoadingIndicator===r.showLoadingIndicator){return false}return true}
t.prototype.componentWillUnmount=function e(){this._mounted=false}
t.prototype.isInitialPageLoad=function e(){return this.props.history.length===1}
t.prototype.calculateLoadingIndicatorNecessary=function e(t){var r=this.props.path===t.path
var a=!r
var o=["always","between-same-path"]
var n=["always","between-different-path"]
var i=o.includes(t.maintainExistingRouteDuringTransition)
var s=n.includes(this.props.maintainExistingRouteDuringTransition)||n.includes(t.maintainExistingRouteDuringTransition)
if(r&&i){return false}if(a&&s){return false}return a||!!t.propsUrl}
t.prototype.processRouteChange=function e(t){var r=this
var a=t.needsPackages,o=t.propsUrl,n=t.component,i=t.dependencies,s=t.pathname,p=t.search,l=t.isLoadingIndicatorRequired,u=t.isScrollPositionMaintained,c=t.computedMatch,d=t.extraHeaderProps,h=t.isInitialPageLoad,m=t.showComponentBeforeProps,f=t.forceUpdate
this.handleRouteChangeStart(l,h)
var g=this.props.updateHeaderProps
var v=null
if(c){v=d&&d.pageDomain||c.params.domain
g({pageDomain:v})}var P=a&&!!n&&this.fetchPackages(n,i)
var y=!!o&&this.fetchProps(o,s,p)
var R=[P,y]
var b=false
if(m&&P){P.then(function(e){if(b){return}r.handleRouteChangeEnd({Component:e},u,h)})}Promise.all(R).then(this.extractFetchResults).then(function(e){b=true
if(f&&r._mounted){r.forceUpdate()}r.handleRouteChangeEnd(e,u,h)
g(babelHelpers.extends({pageDomain:v},d))})}
t.prototype.fetchProps=function e(t,r,a){var o=void 0
if(t===r){o={"defeat-browser-cache":1}}var n=t.split("?",2),i=n[0],s=n[1]
var p=babelHelpers.extends({},o,(0,_parseQueryString2.default)(a),(0,_parseQueryString2.default)(s||""))
var l=(0,_formatQueryString2.default)(p,true)
var u=""+i+l
return(0,_khanFetch.khanFetch)(u,{headers:{Accept:"application/json"},method:"GET"}).then(function(e){return e.json()}).then(function(e){return e.componentProps})}
t.prototype.render=function e(){var t=this.props,r=t.computedMatch,a=t.pathname
var o=this.state,n=o.Component,i=o.componentProps,s=o.showLoadingIndicator
var p=false
if(i&&i.redirectTo){if(i.redirectIsServerSide){window.location=i.redirectTo
p=true}else{return React.createElement(_reactRouterDom.Redirect,{to:i.redirectTo})}}if(s||!n||p){return React.createElement(_timeoutSpinner2.default,{sentryId:"lazy_route_handler_load",description:"Client-side page load",timeoutSeconds:30,size:"medium",style:styles.spinnerWrapper,sentryTeam:"learning-platform",sentryExtras:{loadPath:a}})}var l=r?r.params:{}
return React.createElement(n,babelHelpers.extends({"aria-live":"polite",search:this.props.search},l,i))}
return t}(_react.Component)
LazyRouteHandler.defaultProps={maintainScrollPosition:false,maintainExistingRouteDuringTransition:"never",propsUrl:null}
var _initialiseProps=function e(){var t=this
this.handleRouteChangeStart=function(e,r){if(e&&t._mounted){t.setState({showLoadingIndicator:true})}if(!r){_analytics2.default.handleStartRouterNavigation()}}
this.handleRouteChangeEnd=function(e,r,a){var o=t.props,n=o.onRouteChangeComplete,i=o.hideFooter
if(t._mounted){t.setState(babelHelpers.extends({showLoadingIndicator:false},e))}if(!a){_analytics2.default.handleRouterNavigation()}if(!r){(0,_scrollUtils.scrollToOffset)(0,0)}n(e.componentProps,i||false)}
this.extractFetchResults=function(e){var t=e[0],r=e[1]
if(t&&r){return{Component:t,componentProps:r}}else if(r){return{componentProps:r}}else if(t){return{Component:t}}else{return{}}}
this.fetchPackages=function(e,r){var a=t.props.computedMatch
var o=[e()]
if(r){var n=a?a.params:{}
o.push(r(n))}return Promise.all(o).then(function(e){var t=e[0]
return maybeDefault(t)})}}
var styles=_aphrodite.StyleSheet.create({spinnerWrapper:{marginTop:"40px",marginBottom:"40px",marginLeft:"12px",marginRight:"12px"}})
var mapDispatchToProps={onRouteChangeComplete:_actions.completeLoadingRoute}
var LazyRouteHandlerWithHistory=function e(t){return React.createElement(_routeHistoryContext2.default.Consumer,null,function(e){var r=e.history
return React.createElement(LazyRouteHandler,babelHelpers.extends({},t,{history:r}))})}
exports.default=(0,_reactRedux.connect)(null,mapDispatchToProps)(LazyRouteHandlerWithHistory)

});
KAdefine("javascript/app-shell-package/stateful-footer.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _reactRedux=require("react-redux")
var _footer=require("../page-package/footer.jsx")
var _footer2=babelHelpers.interopRequireDefault(_footer)
var mapStateToFooterProps=function e(r){var t=r.footer,o=t.attribution,a=t.hideFooter
return{attribution:o,hideFooter:a}}
exports.default=(0,_reactRedux.connect)(mapStateToFooterProps)(_footer2.default)

});
KAdefine("javascript/app-shell-package/route-history.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactRouterDom=require("react-router-dom")
var toString=function t(r){var e=r.pathname,o=r.search,i=r.hash
return""+e+o+i}
var RouteHistory=function(t){babelHelpers.inherits(r,t)
function r(e){babelHelpers.classCallCheck(this,r)
var o=babelHelpers.possibleConstructorReturn(this,t.call(this,e))
o._history=[toString(e.location)]
return o}r.prototype.UNSAFE_componentWillUpdate=function t(r){var e=toString(this.props.location)
var o=toString(r.location)
if(e!==o){this._history.push(o)}}
r.prototype.render=function t(){return this.props.children({history:this._history})}
return r}(React.Component)
exports.default=(0,_reactRouterDom.withRouter)(RouteHistory)

});
KAdefine("javascript/app-shell-package/route-history-context.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
exports.default=React.createContext({history:[]})

});
KAdefine("javascript/app-shell-package/top-level-coach-route.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactRouterDom=require("react-router-dom")
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _topLevelRoute=require("./top-level-route.jsx")
var _topLevelRoute2=babelHelpers.interopRequireDefault(_topLevelRoute)
var TopLevelCoachRoute=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.shouldRedirect=function e(){var r=_ka2.default.getUserProfile()
if(!r){return true}return r.get("isChildAccount")||r.get("isPhantom")}
r.prototype.render=function e(){if(this.shouldRedirect()){return React.createElement(_reactRouterDom.Redirect,{to:"/"})}return React.createElement(_topLevelRoute2.default,this.props)}
return r}(React.Component)
exports.default=TopLevelCoachRoute

});
KAdefine("javascript/app-shell-package/top-level-route.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactRouterDom=require("react-router-dom")
var _lazyRouteHandler=require("./lazy-route-handler.jsx")
var _lazyRouteHandler2=babelHelpers.interopRequireDefault(_lazyRouteHandler)
exports.default=function(e){return React.createElement(_reactRouterDom.Route,{path:e.path,render:function r(a){return React.createElement(_lazyRouteHandler2.default,babelHelpers.extends({pathname:a.location.pathname,search:a.location.search},e))}})}

});
KAdefine("javascript/app-shell-package/top-level-content-route.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactRouterDom=require("react-router-dom")
var _staticUrl=require("../shared-package/static-url.js")
var _conversionContext=require("../analytics-package/conversion-context.jsx")
var _conversionContext2=babelHelpers.interopRequireDefault(_conversionContext)
var _lazyRouteHandler=require("./lazy-route-handler.jsx")
var _lazyRouteHandler2=babelHelpers.interopRequireDefault(_lazyRouteHandler)
var _kaProvider=require("../components/ssr-package/ka-provider.jsx")
var _kaProvider2=babelHelpers.interopRequireDefault(_kaProvider)
var urlForContent=function e(r,t,a){return r?(0,_staticUrl.contentUrl)(t,a):a}
exports.default=function(e){return React.createElement(_reactRouterDom.Route,{path:e.path,render:function r(t){return React.createElement(_kaProvider2.default,{mockOnFirstRender:true},function(r){return React.createElement(_conversionContext2.default,{extras:{kaid:r.getKaid(),product:"library"}},function(){return React.createElement(_lazyRouteHandler2.default,babelHelpers.extends({pathname:t.location.pathname,search:t.location.search,propsUrl:urlForContent(e.getPropsViaCDN,r.kaLocale,t.location.pathname)},e))})})}})}

});
KAdefine("javascript/app-shell-package/utils.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var getDependenciesForHomePageRoute=exports.getDependenciesForHomePageRoute=function e(s){if(s){return Promise.all([require.dynimport("../../stylesheets/odometer-package/odometer.less"),require.dynimport("../../stylesheets/dashboard-package/dashboard.less"),require.dynimport("../../stylesheets/avatar-customizer-package/avatar-customizer.less"),require.dynimport("../../stylesheets/homepage-package/homepage.less")])}return Promise.resolve()}
var getDependenciesForLessonRoute=exports.getDependenciesForLessonRoute=function e(s){var t=s.kind
switch(t){case"v":return Promise.all([require.dynimport("../tutorial-video-package/video-page.jsx").then(function(e){return e.default}),require.dynimport("../../stylesheets/video-package/video.less"),require.dynimport("../../stylesheets/discussion-package/discussion.less"),require.dynimport("../../stylesheets/clarifications-package/clarifications.less"),require.dynimport("../../stylesheets/moderation-package/moderation.less")])
case"e":{return Promise.all([require.dynimport("../tutorial-exercise-package/exercise-page.jsx").then(function(e){return e.default}),require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/odometer-package/odometer.less"),require.dynimport("../../stylesheets/avatar-customizer-package/avatar-customizer.less"),require.dynimport("../../stylesheets/tasks-package/tasks.less")])}case"a":return Promise.all([require.dynimport("../tutorial-article-package/article-page.jsx").then(function(e){return e.default}),require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less"),require.dynimport("../../stylesheets/exercises-package/exercises.less"),require.dynimport("../../stylesheets/katex-package/katex.less"),require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less"),require.dynimport("../../stylesheets/discussion-package/discussion.less"),require.dynimport("../../stylesheets/moderation-package/moderation.less")])
case"p":case"pc":case"pi":case"pp":case"pt":return Promise.all([require.dynimport("../tutorial-scratchpad-package/scratchpad-page.jsx").then(function(e){return e.default})])}}

});
KAdefine("javascript/app-shell-package/types.js", function(require, module, exports) {

});
; KAdefine.updatePathToPackageMap({"javascript/app-shell-example-package/example.jsx": "app-shell-example.js", "javascript/bncc-package/bncc-page.jsx": "bncc.js", "javascript/brain-training-package/class-dashboard.jsx": "brain-training.js", "javascript/brain-training-package/demo-dashboard.jsx": "brain-training.js", "javascript/class-package/class.jsx": "class.js", "javascript/class-package/new-progress/unit-mastery-progress.jsx": "class.js", "javascript/class-package/student/student-page.jsx": "class.js", "javascript/coach-dashboard-package/coach.jsx": "coach-dashboard.js", "javascript/coach-report-exercise-package/coach-report.jsx": "coach-report-exercise.js", "javascript/coach-report-exercise-package/exercise.jsx": "coach-report-exercise.js", "javascript/content-library-package/content-library-curation-page.jsx": "content-library.js", "javascript/dashboard-package/bibliotron-homepage-with-nav.jsx": "dashboard.js", "javascript/donate-edit-subscription-package/index.jsx": "donate-edit-subscription.js", "javascript/learnstorm-common-package/admin/editor.jsx": "learnstorm-editable-admin.js", "javascript/learnstorm-dashboard-package/class-dashboard.jsx": "learnstorm-dashboard.js", "javascript/learnstorm-dashboard-package/demo-dashboard.jsx": "learnstorm-dashboard.js", "javascript/learnstorm-dashboard-package/level-zero.jsx": "learnstorm-dashboard.js", "javascript/logged-out-homepage-package/logged-out-homepage-module-list.jsx": "logged-out-homepage.js", "javascript/signup-link-package/launch-signup-login-in-modal.js": "signup-link.js", "javascript/teacher-campaign-package/admin/editor.jsx": "teacher-campaign-admin.js", "javascript/teacher-campaign-package/response-page.jsx": "teacher-campaign.js", "javascript/teacher-campaign-package/video-page.jsx": "teacher-campaign.js", "javascript/tutorial-article-package/article-page.jsx": "tutorial-article.js", "javascript/tutorial-exercise-package/exercise-page.jsx": "tutorial-exercise.js", "javascript/tutorial-page-package/tutorial-page.jsx": "tutorial-page.js", "javascript/tutorial-scratchpad-package/scratchpad-page.jsx": "tutorial-scratchpad.js", "javascript/tutorial-video-package/video-page.jsx": "tutorial-video.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/app-shell-package.js.map 