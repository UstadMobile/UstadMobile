KAdefine("javascript/reusable-components-package/back-icon.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var i18n=require("../shared-package/i18n.js")
var BackIcon=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.componentDidMount=function e(){this.node.setAttribute("stroke-linejoin","round")}
t.prototype.render=function e(){var t=this
var r=i18n._("Back")
return _react2.default.createElement("svg",{width:"24",height:"24"},_react2.default.createElement("g",{ref:function e(r){return t.node=r},id:"source",fill:"none",transform:"translate(5, 5)",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"},_react2.default.createElement("title",null,r),_react2.default.createElement("path",{d:"M1,7 L14,7"}),_react2.default.createElement("polyline",{points:"7 0 0 7 7 14"})))}
return t}(_react2.default.Component)
exports.default=BackIcon

});
KAdefine("javascript/reusable-components-package/close-icon.jsx", function(require, module, exports) {
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var i18n=require("../shared-package/i18n.js")
var CloseIcon=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.componentDidMount=function e(){this.refs.g.setAttribute("stroke-linejoin","round")}
t.prototype.render=function e(){var t=this.props,r=t.size,a=t.iconSize,l=t.color
var o={stroke:l,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round",fill:"none",fillRule:"evenodd"}
var n=(r-a)/2
var i=(r+a)/2
var s=i18n._("Close")
var c=i18n._("Closes this module.")
var u=s+" "+c
return _react2.default.createElement("svg",{width:r,height:r,viewBox:"0 0 "+r+" "+r,role:"img","aria-label":u},_react2.default.createElement("title",null,s),_react2.default.createElement("desc",null,c),_react2.default.createElement("g",babelHelpers.extends({ref:"g"},o),_react2.default.createElement("path",{d:"M"+i+","+n+" L"+n+","+i}),_react2.default.createElement("path",{d:"M"+n+","+n+" L"+i+","+i})))}
return t}(_react2.default.Component)
CloseIcon.defaultProps={color:"currentColor"}
module.exports=CloseIcon

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/reusable-components-package.js.map 