"undefined"==typeof CE2&&(CE2={}),CE2.uid=260255,CE2.status="no data available";
