KAdefine("javascript/node_modules/react-apollo/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ReactApollo

});
KAdefine("javascript/node_modules/apollo-client/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloClient

});
KAdefine("javascript/node_modules/graphql-tag/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").gql

});
KAdefine("javascript/node_modules/apollo-cache-inmemory/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloCacheInMemory

});
KAdefine("javascript/node_modules/apollo-link-http/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloLinkHTTP

});
KAdefine("javascript/node_modules/apollo-link-batch-http/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloLinkBatchHTTP

});
KAdefine("javascript/node_modules/apollo-link-error/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloLinkError

});
KAdefine("javascript/node_modules/apollo-link/index.js", function(require, module, exports) {
module.exports=require("../../../third_party/javascript-khansrc/apollo-khansrc/apollo.js").ApolloLink

});
KAdefine("third_party/javascript-khansrc/apollo-khansrc/apollo.js", function(require, module, exports) {
module.exports=function(t){var e={}
function r(n){if(e[n])return e[n].exports
var o=e[n]={i:n,l:!1,exports:{}}
return t[n].call(o.exports,o,o.exports,r),o.l=!0,o.exports}return r.m=t,r.c=e,r.d=function(t,e,n){r.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:n})},r.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},r.t=function(t,e){if(1&e&&(t=r(t)),8&e)return t
if(4&e&&"object"==typeof t&&t&&t.__esModule)return t
var n=Object.create(null)
if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var o in t)r.d(n,o,function(e){return t[e]}.bind(null,o))
return n},r.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t}
return r.d(e,"a",e),e},r.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},r.p="/",r(r.s=54)}([function(t,e,r){"use strict"
var n={Name:[],Document:["definitions"],OperationDefinition:["name","variableDefinitions","directives","selectionSet"],VariableDefinition:["variable","type","defaultValue"],Variable:["name"],SelectionSet:["selections"],Field:["alias","name","arguments","directives","selectionSet"],Argument:["name","value"],FragmentSpread:["name","directives"],InlineFragment:["typeCondition","directives","selectionSet"],FragmentDefinition:["name","variableDefinitions","typeCondition","directives","selectionSet"],IntValue:[],FloatValue:[],StringValue:[],BooleanValue:[],NullValue:[],EnumValue:[],ListValue:["values"],ObjectValue:["fields"],ObjectField:["name","value"],Directive:["name","arguments"],NamedType:["name"],ListType:["type"],NonNullType:["type"],SchemaDefinition:["directives","operationTypes"],OperationTypeDefinition:["type"],ScalarTypeDefinition:["description","name","directives"],ObjectTypeDefinition:["description","name","interfaces","directives","fields"],FieldDefinition:["description","name","arguments","type","directives"],InputValueDefinition:["description","name","type","defaultValue","directives"],InterfaceTypeDefinition:["description","name","directives","fields"],UnionTypeDefinition:["description","name","directives","types"],EnumTypeDefinition:["description","name","directives","values"],EnumValueDefinition:["description","name","directives"],InputObjectTypeDefinition:["description","name","directives","fields"],ScalarTypeExtension:["name","directives"],ObjectTypeExtension:["name","interfaces","directives","fields"],InterfaceTypeExtension:["name","directives","fields"],UnionTypeExtension:["name","directives","types"],EnumTypeExtension:["name","directives","values"],InputObjectTypeExtension:["name","directives","fields"],DirectiveDefinition:["description","name","arguments","locations"]},o={}
function i(t){return Boolean(t&&"string"==typeof t.kind)}function a(t,e,r){var n=t[e]
if(n){if(!r&&"function"==typeof n)return n
var o=r?n.leave:n.enter
if("function"==typeof o)return o}else{var i=r?t.leave:t.enter
if(i){if("function"==typeof i)return i
var a=i[e]
if("function"==typeof a)return a}}}function u(t){return function(t,e){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:n,u=void 0,c=Array.isArray(t),s=[t],l=-1,f=[],p=void 0,h=void 0,d=void 0,v=[],y=[],b=t
do{var m=++l===s.length,_=m&&0!==f.length
if(m){if(h=0===y.length?void 0:v[v.length-1],p=d,d=y.pop(),_){if(c)p=p.slice()
else{var g={}
for(var w in p)p.hasOwnProperty(w)&&(g[w]=p[w])
p=g}for(var O=0,E=0;E<f.length;E++){var k=f[E][0],x=f[E][1]
c&&(k-=O),c&&null===x?(p.splice(k,1),O++):p[k]=x}}l=u.index,s=u.keys,f=u.edits,c=u.inArray,u=u.prev}else{if(h=d?c?l:s[l]:void 0,null===(p=d?d[h]:b)||void 0===p)continue
d&&v.push(h)}var S=void 0
if(!Array.isArray(p)){if(!i(p))throw new Error("Invalid AST Node: "+JSON.stringify(p))
var j=a(e,p.kind,m)
if(j){if((S=j.call(e,p,h,d,v,y))===o)break
if(!1===S){if(!m){v.pop()
continue}}else if(void 0!==S&&(f.push([h,S]),!m)){if(!i(S)){v.pop()
continue}p=S}}}void 0===S&&_&&f.push([h,p]),m?v.pop():(u={inArray:c,index:l,keys:s,edits:f,prev:u},s=(c=Array.isArray(p))?p:r[p.kind]||[],l=-1,f=[],d&&y.push(d),d=p)}while(void 0!==u)
return 0!==f.length&&(b=f[f.length-1][1]),b}(t,{leave:c})}r.d(e,"a",function(){return u})
var c={Name:function(t){return t.value},Variable:function(t){return"$"+t.name},Document:function(t){return l(t.definitions,"\n\n")+"\n"},OperationDefinition:function(t){var e=t.operation,r=t.name,n=p("(",l(t.variableDefinitions,", "),")"),o=l(t.directives," "),i=t.selectionSet
return r||o||n||"query"!==e?l([e,l([r,n]),o,i]," "):i},VariableDefinition:function(t){return t.variable+": "+t.type+p(" = ",t.defaultValue)},SelectionSet:function(t){return f(t.selections)},Field:function(t){var e=t.alias,r=t.name,n=t.arguments,o=t.directives,i=t.selectionSet
return l([p("",e,": ")+r+p("(",l(n,", "),")"),l(o," "),i]," ")},Argument:function(t){return t.name+": "+t.value},FragmentSpread:function(t){return"..."+t.name+p(" ",l(t.directives," "))},InlineFragment:function(t){var e=t.typeCondition,r=t.directives,n=t.selectionSet
return l(["...",p("on ",e),l(r," "),n]," ")},FragmentDefinition:function(t){var e=t.name,r=t.typeCondition,n=t.variableDefinitions,o=t.directives,i=t.selectionSet
return"fragment "+e+p("(",l(n,", "),")")+" on "+r+" "+p("",l(o," ")," ")+i},IntValue:function(t){return t.value},FloatValue:function(t){return t.value},StringValue:function(t,e){var r=t.value
return t.block?function(t,e){var r=t.replace(/"""/g,'\\"""')
return" "!==t[0]&&"\t"!==t[0]||-1!==t.indexOf("\n")?'"""\n'+(e?r:h(r))+'\n"""':'"""'+r.replace(/"$/,'"\n')+'"""'}(r,"description"===e):JSON.stringify(r)},BooleanValue:function(t){return t.value?"true":"false"},NullValue:function(){return"null"},EnumValue:function(t){return t.value},ListValue:function(t){return"["+l(t.values,", ")+"]"},ObjectValue:function(t){return"{"+l(t.fields,", ")+"}"},ObjectField:function(t){return t.name+": "+t.value},Directive:function(t){return"@"+t.name+p("(",l(t.arguments,", "),")")},NamedType:function(t){return t.name},ListType:function(t){return"["+t.type+"]"},NonNullType:function(t){return t.type+"!"},SchemaDefinition:function(t){var e=t.directives,r=t.operationTypes
return l(["schema",l(e," "),f(r)]," ")},OperationTypeDefinition:function(t){return t.operation+": "+t.type},ScalarTypeDefinition:s(function(t){return l(["scalar",t.name,l(t.directives," ")]," ")}),ObjectTypeDefinition:s(function(t){var e=t.name,r=t.interfaces,n=t.directives,o=t.fields
return l(["type",e,p("implements ",l(r," & ")),l(n," "),f(o)]," ")}),FieldDefinition:s(function(t){var e=t.name,r=t.arguments,n=t.type,o=t.directives
return e+p("(",l(r,", "),")")+": "+n+p(" ",l(o," "))}),InputValueDefinition:s(function(t){var e=t.name,r=t.type,n=t.defaultValue,o=t.directives
return l([e+": "+r,p("= ",n),l(o," ")]," ")}),InterfaceTypeDefinition:s(function(t){var e=t.name,r=t.directives,n=t.fields
return l(["interface",e,l(r," "),f(n)]," ")}),UnionTypeDefinition:s(function(t){var e=t.name,r=t.directives,n=t.types
return l(["union",e,l(r," "),n&&0!==n.length?"= "+l(n," | "):""]," ")}),EnumTypeDefinition:s(function(t){var e=t.name,r=t.directives,n=t.values
return l(["enum",e,l(r," "),f(n)]," ")}),EnumValueDefinition:s(function(t){return l([t.name,l(t.directives," ")]," ")}),InputObjectTypeDefinition:s(function(t){var e=t.name,r=t.directives,n=t.fields
return l(["input",e,l(r," "),f(n)]," ")}),ScalarTypeExtension:function(t){return l(["extend scalar",t.name,l(t.directives," ")]," ")},ObjectTypeExtension:function(t){var e=t.name,r=t.interfaces,n=t.directives,o=t.fields
return l(["extend type",e,p("implements ",l(r," & ")),l(n," "),f(o)]," ")},InterfaceTypeExtension:function(t){var e=t.name,r=t.directives,n=t.fields
return l(["extend interface",e,l(r," "),f(n)]," ")},UnionTypeExtension:function(t){var e=t.name,r=t.directives,n=t.types
return l(["extend union",e,l(r," "),n&&0!==n.length?"= "+l(n," | "):""]," ")},EnumTypeExtension:function(t){var e=t.name,r=t.directives,n=t.values
return l(["extend enum",e,l(r," "),f(n)]," ")},InputObjectTypeExtension:function(t){var e=t.name,r=t.directives,n=t.fields
return l(["extend input",e,l(r," "),f(n)]," ")},DirectiveDefinition:s(function(t){var e=t.name,r=t.arguments,n=t.locations
return"directive @"+e+p("(",l(r,", "),")")+" on "+l(n," | ")})}
function s(t){return function(e){return l([e.description,t(e)],"\n")}}function l(t,e){return t?t.filter(function(t){return t}).join(e||""):""}function f(t){return t&&0!==t.length?"{\n"+h(l(t,"\n"))+"\n}":""}function p(t,e,r){return e?t+e+(r||""):""}function h(t){return t&&"  "+t.replace(/\n/g,"\n  ")}},function(t,e,r){"use strict"
r.r(e)
var n=r(51),o=r.n(n).a,i=r(10),a=r(0),u=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),c=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}
var s=function(t){function e(e,r){var n=t.call(this,e)||this
return n.link=r,n}return u(e,t),e}(Error)
function l(t){return t.request.length<=1}function f(t){var e=!1
return new Promise(function(r,n){t.subscribe({next:function(t){e?console.warn("Promise Wrapper does not support multiple results from Observable"):(e=!0,r(t))},error:n})})}var p=f
function h(t){return new o(function(e){t.then(function(t){e.next(t),e.complete()}).catch(e.error.bind(e))})}function d(t){return new o(function(e){e.error(t)})}function v(t,e){var r=c({},t)
return Object.defineProperty(e,"setContext",{enumerable:!1,value:function(t){r=c({},r,"function"==typeof t?t(r):t)}}),Object.defineProperty(e,"getContext",{enumerable:!1,value:function(){return c({},r)}}),Object.defineProperty(e,"toKey",{enumerable:!1,value:function(){return function(t){return Object(a.a)(t.query)+"|"+JSON.stringify(t.variables)+"|"+t.operationName}(e)}}),e}var y=function(t,e){return e?e(t):o.of()},b=function(t){return"function"==typeof t?new O(t):t},m=function(){return new O(function(t,e){return o.of()})},_=function(t){return 0===t.length?m():t.map(b).reduce(function(t,e){return t.concat(e)})},g=function(t,e,r){void 0===r&&(r=new O(y))
var n=b(e),i=b(r)
return l(n)&&l(i)?new O(function(e){return t(e)?n.request(e)||o.of():i.request(e)||o.of()}):new O(function(e,r){return t(e)?n.request(e,r)||o.of():i.request(e,r)||o.of()})},w=function(t,e){var r=b(t)
if(l(r))return console.warn(new s("You are calling concat on a terminating link, which will have no effect",r)),r
var n=b(e)
return l(n)?new O(function(t){return r.request(t,function(t){return n.request(t)||o.of()})||o.of()}):new O(function(t,e){return r.request(t,function(t){return n.request(t,e)||o.of()})||o.of()})},O=function(){function t(t){t&&(this.request=t)}return t.prototype.split=function(e,r,n){return void 0===n&&(n=new t(y)),this.concat(g(e,r,n))},t.prototype.concat=function(t){return w(this,t)},t.prototype.request=function(t,e){throw new Error("request is not implemented")},t.empty=m,t.from=_,t.split=g,t.execute=E,t}()
function E(t,e){return t.request(v(e.context,function(t){var e={variables:t.variables||{},extensions:t.extensions||{},operationName:t.operationName,query:t.query}
return e.operationName||(e.operationName="string"!=typeof e.query?Object(i.a)(e.query):""),e}(function(t){for(var e=["query","operationName","variables","extensions","context"],r=0,n=Object.keys(t);r<n.length;r++){var o=n[r]
if(e.indexOf(o)<0)throw new Error("illegal argument: "+o)}return t}(e))))||o.of()}r.d(e,"empty",function(){return m}),r.d(e,"from",function(){return _}),r.d(e,"split",function(){return g}),r.d(e,"concat",function(){return w}),r.d(e,"ApolloLink",function(){return O}),r.d(e,"execute",function(){return E}),r.d(e,"createOperation",function(){return v}),r.d(e,"makePromise",function(){return p}),r.d(e,"toPromise",function(){return f}),r.d(e,"fromPromise",function(){return h}),r.d(e,"fromError",function(){return d}),r.d(e,"Observable",function(){return o})},function(t,e,r){"use strict"
var n=r(12)
t.exports=function(t){if(!n(t))throw new TypeError("Cannot use null or undefined")
return t}},function(t,e,r){"use strict"
t.exports=r(74)()?Symbol:r(75)},function(t,e,r){"use strict"
t.exports=function(t){if("function"!=typeof t)throw new TypeError(t+" is not a function")
return t}},function(t,e,r){"use strict"
var n=r(20),o=r(40),i=r(71),a=r(21);(t.exports=function(t,e){var r,i,u,c,s
return arguments.length<2||"string"!=typeof t?(c=e,e=t,t=null):c=arguments[2],null==t?(r=u=!0,i=!1):(r=a.call(t,"c"),i=a.call(t,"e"),u=a.call(t,"w")),s={value:e,configurable:r,enumerable:i,writable:u},c?n(o(c),s):s}).gs=function(t,e,r){var u,c,s,l
return"string"!=typeof t?(s=r,r=e,e=t,t=null):s=arguments[3],null==e?e=void 0:i(e)?null==r?r=void 0:i(r)||(s=r,r=void 0):(s=e,e=r=void 0),null==t?(u=!0,c=!1):(u=a.call(t,"c"),c=a.call(t,"e")),l={get:e,set:r,configurable:u,enumerable:c},s?n(o(s),l):l}},function(t,e,r){"use strict"
t.exports=function(t,e,r,n,o,i,a,u){if(!t){var c
if(void 0===e)c=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.")
else{var s=[r,n,o,i,a,u],l=0;(c=new Error(e.replace(/%s/g,function(){return s[l++]}))).name="Invariant Violation"}throw c.framesToPop=1,c}}},function(t,e,r){"use strict";(function(t){function n(e){return(void 0!==t?"production":"development")===e}function o(){return!0===n("production")}function i(){return!0===n("development")}function a(){return!0===n("test")}r.d(e,"b",function(){return o}),r.d(e,"a",function(){return i}),r.d(e,"c",function(){return a})}).call(this,r(24))},function(t,e,r){"use strict";(function(t){function n(e){return(void 0!==t?"production":"development")===e}function o(){return!0===n("production")}function i(){return!0===n("development")}function a(){return!0===n("test")}r.d(e,"b",function(){return o}),r.d(e,"a",function(){return i}),r.d(e,"c",function(){return a})}).call(this,r(24))},function(t,e,r){"use strict";(function(t){function n(e){return(void 0!==t?"production":"development")===e}function o(){return!0===n("production")}function i(){return!0===n("development")}function a(){return!0===n("test")}r.d(e,"b",function(){return o}),r.d(e,"a",function(){return i}),r.d(e,"c",function(){return a})}).call(this,r(24))},function(t,e,r){"use strict"
new Map
Object.assign
function n(t){return t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&t.name}).map(function(t){return t.name.value})[0]||null}new Map
new Map
r(8)
Object.create({})
r.d(e,"a",function(){return n})},function(t,e,r){"use strict"
t.exports=r(37)()?Object.setPrototypeOf:r(38)},function(t,e,r){"use strict"
var n=r(34)()
t.exports=function(t){return t!==n&&null!==t}},function(t,e,r){"use strict"
var n=Object.prototype.toString,o=n.call(function(){return arguments}())
t.exports=function(t){return n.call(t)===o}},function(t,e,r){"use strict"
var n=Object.prototype.toString,o=n.call("")
t.exports=function(t){return"string"==typeof t||t&&"object"==typeof t&&(t instanceof String||n.call(t)===o)||!1}},function(t,e,r){"use strict"
var n,o=r(19),i=r(20),a=r(4),u=r(2),c=r(5),s=r(80),l=r(3),f=Object.defineProperty,p=Object.defineProperties
t.exports=n=function(t,e){if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
p(this,{__list__:c("w",u(t)),__context__:c("w",e),__nextIndex__:c("w",0)}),e&&(a(e.on),e.on("_add",this._onAdd),e.on("_delete",this._onDelete),e.on("_clear",this._onClear))},delete n.prototype.constructor,p(n.prototype,i({_next:c(function(){var t
if(this.__list__)return this.__redo__&&void 0!==(t=this.__redo__.shift())?t:this.__nextIndex__<this.__list__.length?this.__nextIndex__++:void this._unBind()}),next:c(function(){return this._createResult(this._next())}),_createResult:c(function(t){return void 0===t?{done:!0,value:void 0}:{done:!1,value:this._resolve(t)}}),_resolve:c(function(t){return this.__list__[t]}),_unBind:c(function(){this.__list__=null,delete this.__redo__,this.__context__&&(this.__context__.off("_add",this._onAdd),this.__context__.off("_delete",this._onDelete),this.__context__.off("_clear",this._onClear),this.__context__=null)}),toString:c(function(){return"[object "+(this[l.toStringTag]||"Object")+"]"})},s({_onAdd:c(function(t){t>=this.__nextIndex__||(++this.__nextIndex__,this.__redo__?(this.__redo__.forEach(function(e,r){e>=t&&(this.__redo__[r]=++e)},this),this.__redo__.push(t)):f(this,"__redo__",c("c",[t])))}),_onDelete:c(function(t){var e
t>=this.__nextIndex__||(--this.__nextIndex__,this.__redo__&&(-1!==(e=this.__redo__.indexOf(t))&&this.__redo__.splice(e,1),this.__redo__.forEach(function(e,r){e>t&&(this.__redo__[r]=--e)},this)))}),_onClear:c(function(){this.__redo__&&o.call(this.__redo__),this.__nextIndex__=0})}))),f(n.prototype,l.iterator,c(function(){return this}))},function(t,e,r){"use strict"
var n={childContextTypes:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},o={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},i=Object.defineProperty,a=Object.getOwnPropertyNames,u=Object.getOwnPropertySymbols,c=Object.getOwnPropertyDescriptor,s=Object.getPrototypeOf,l=s&&s(Object)
t.exports=function t(e,r,f){if("string"!=typeof r){if(l){var p=s(r)
p&&p!==l&&t(e,p,f)}var h=a(r)
u&&(h=h.concat(u(r)))
for(var d=0;d<h.length;++d){var v=h[d]
if(!(n[v]||o[v]||f&&f[v])){var y=c(r,v)
try{i(e,v,y)}catch(t){}}}return e}return e}},function(t,e,r){t.exports=r(150).Observable},function(t,e){t.exports=function(){return this}()},function(t,e,r){"use strict"
var n=r(2)
t.exports=function(){return n(this).length=0,this}},function(t,e,r){"use strict"
t.exports=r(66)()?Object.assign:r(67)},function(t,e,r){"use strict"
t.exports=r(72)()?String.prototype.contains:r(73)},function(t,e,r){"use strict"
var n=r(78)
t.exports=function(t){if(!n(t))throw new TypeError(t+" is not iterable")
return t}},function(t,e,r){"use strict"
var n=r(13),o=r(4),i=r(14),a=r(42),u=Array.isArray,c=Function.prototype.call,s=Array.prototype.some
t.exports=function(t,e){var r,l,f,p,h,d,v,y,b=arguments[2]
if(u(t)||n(t)?r="array":i(t)?r="string":t=a(t),o(e),f=function(){p=!0},"array"!==r)if("string"!==r)for(l=t.next();!l.done;){if(c.call(e,b,l.value,f),p)return
l=t.next()}else for(d=t.length,h=0;h<d&&(v=t[h],h+1<d&&(y=v.charCodeAt(0))>=55296&&y<=56319&&(v+=t[++h]),c.call(e,b,v,f),!p);++h);else s.call(t,function(t){return c.call(e,b,t,f),p})}},function(t,e){var r,n,o=t.exports={}
function i(){throw new Error("setTimeout has not been defined")}function a(){throw new Error("clearTimeout has not been defined")}function u(t){if(r===setTimeout)return setTimeout(t,0)
if((r===i||!r)&&setTimeout)return r=setTimeout,setTimeout(t,0)
try{return r(t,0)}catch(e){try{return r.call(null,t,0)}catch(e){return r.call(this,t,0)}}}!function(){try{r="function"==typeof setTimeout?setTimeout:i}catch(t){r=i}try{n="function"==typeof clearTimeout?clearTimeout:a}catch(t){n=a}}()
var c,s=[],l=!1,f=-1
function p(){l&&c&&(l=!1,c.length?s=c.concat(s):f=-1,s.length&&h())}function h(){if(!l){var t=u(p)
l=!0
for(var e=s.length;e;){for(c=s,s=[];++f<e;)c&&c[f].run()
f=-1,e=s.length}c=null,l=!1,function(t){if(n===clearTimeout)return clearTimeout(t)
if((n===a||!n)&&clearTimeout)return n=clearTimeout,clearTimeout(t)
try{n(t)}catch(e){try{return n.call(null,t)}catch(e){return n.call(this,t)}}}(t)}}function d(t,e){this.fun=t,this.array=e}function v(){}o.nextTick=function(t){var e=new Array(arguments.length-1)
if(arguments.length>1)for(var r=1;r<arguments.length;r++)e[r-1]=arguments[r]
s.push(new d(t,e)),1!==s.length||l||u(h)},d.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=v,o.addListener=v,o.once=v,o.off=v,o.removeListener=v,o.removeAllListeners=v,o.emit=v,o.prependListener=v,o.prependOnceListener=v,o.listeners=function(t){return[]},o.binding=function(t){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(t){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},function(t,e,r){"use strict"
var n=Object.prototype.hasOwnProperty
function o(t,e){return t===e?0!==t||0!==e||1/t==1/e:t!=t&&e!=e}t.exports=function(t,e){if(o(t,e))return!0
if("object"!=typeof t||null===t||"object"!=typeof e||null===e)return!1
var r=Object.keys(t),i=Object.keys(e)
if(r.length!==i.length)return!1
for(var a=0;a<r.length;a++)if(!n.call(e,r[a])||!o(t[r[a]],e[r[a]]))return!1
return!0}},function(t,e,r){var n=r(45),o=r(28)
function i(t,e){this.__wrapped__=t,this.__actions__=[],this.__chain__=!!e,this.__index__=0,this.__values__=void 0}i.prototype=n(o.prototype),i.prototype.constructor=i,t.exports=i},function(t,e){t.exports=function(t){var e=typeof t
return null!=t&&("object"==e||"function"==e)}},function(t,e){t.exports=function(){}},function(t,e,r){var n=r(30).Symbol
t.exports=n},function(t,e,r){var n=r(122),o="object"==typeof self&&self&&self.Object===Object&&self,i=n||o||Function("return this")()
t.exports=i},function(t,e){t.exports=function(t){return null!=t&&"object"==typeof t}},function(t,e){var r=Array.isArray
t.exports=r},function(t,e,r){var n=r(45),o=r(28),i=4294967295
function a(t){this.__wrapped__=t,this.__actions__=[],this.__dir__=1,this.__filtered__=!1,this.__iteratees__=[],this.__takeCount__=i,this.__views__=[]}a.prototype=n(o.prototype),a.prototype.constructor=a,t.exports=a},function(t,e,r){"use strict"
t.exports=function(){}},function(t,e,r){"use strict"
var n=r(58),o=r(36),i=r(2),a=Array.prototype.indexOf,u=Object.prototype.hasOwnProperty,c=Math.abs,s=Math.floor
t.exports=function(t){var e,r,l,f
if(!n(t))return a.apply(this,arguments)
for(r=o(i(this).length),l=arguments[1],e=l=isNaN(l)?0:l>=0?s(l):o(this.length)-s(c(l));e<r;++e)if(u.call(this,e)&&(f=this[e],n(f)))return e
return-1}},function(t,e,r){"use strict"
var n=r(61),o=Math.max
t.exports=function(t){return o(0,n(t))}},function(t,e,r){"use strict"
var n=Object.create,o=Object.getPrototypeOf,i={}
t.exports=function(){var t=Object.setPrototypeOf,e=arguments[0]||n
return"function"==typeof t&&o(t(e(null),i))===i}},function(t,e,r){"use strict"
var n,o=r(39),i=r(2),a=Object.prototype.isPrototypeOf,u=Object.defineProperty,c={configurable:!0,enumerable:!1,writable:!0,value:void 0}
n=function(t,e){if(i(t),null===e||o(e))return t
throw new TypeError("Prototype must be null or an object")},t.exports=function(t){var e,r
return t?(2===t.level?t.set?(r=t.set,e=function(t,e){return r.call(n(t,e),e),t}):e=function(t,e){return n(t,e).__proto__=e,t}:e=function t(e,r){var o
return n(e,r),(o=a.call(t.nullPolyfill,e))&&delete t.nullPolyfill.__proto__,null===r&&(r=t.nullPolyfill),e.__proto__=r,o&&u(t.nullPolyfill,"__proto__",c),e},Object.defineProperty(e,"level",{configurable:!1,enumerable:!1,writable:!1,value:t.level})):null}(function(){var t,e=Object.create(null),r={},n=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__")
if(n){try{(t=n.set).call(e,r)}catch(t){}if(Object.getPrototypeOf(e)===r)return{set:t,level:2}}return e.__proto__=r,Object.getPrototypeOf(e)===r?{level:2}:((e={}).__proto__=r,Object.getPrototypeOf(e)===r&&{level:1})}()),r(65)},function(t,e,r){"use strict"
var n=r(12),o={function:!0,object:!0}
t.exports=function(t){return n(t)&&o[typeof t]||!1}},function(t,e,r){"use strict"
var n=r(12),o=Array.prototype.forEach,i=Object.create
t.exports=function(t){var e=i(null)
return o.call(arguments,function(t){n(t)&&function(t,e){var r
for(r in t)e[r]=t[r]}(Object(t),e)}),e}},function(t,e,r){"use strict"
var n,o,i,a,u,c,s,l=r(5),f=r(4),p=Function.prototype.apply,h=Function.prototype.call,d=Object.create,v=Object.defineProperty,y=Object.defineProperties,b=Object.prototype.hasOwnProperty,m={configurable:!0,enumerable:!1,writable:!0}
u={on:n=function(t,e){var r
return f(e),b.call(this,"__ee__")?r=this.__ee__:(r=m.value=d(null),v(this,"__ee__",m),m.value=null),r[t]?"object"==typeof r[t]?r[t].push(e):r[t]=[r[t],e]:r[t]=e,this},once:o=function(t,e){var r,o
return f(e),o=this,n.call(this,t,r=function(){i.call(o,t,r),p.call(e,this,arguments)}),r.__eeOnceListener__=e,this},off:i=function(t,e){var r,n,o,i
if(f(e),!b.call(this,"__ee__"))return this
if(!(r=this.__ee__)[t])return this
if("object"==typeof(n=r[t]))for(i=0;o=n[i];++i)o!==e&&o.__eeOnceListener__!==e||(2===n.length?r[t]=n[i?0:1]:n.splice(i,1))
else n!==e&&n.__eeOnceListener__!==e||delete r[t]
return this},emit:a=function(t){var e,r,n,o,i
if(b.call(this,"__ee__")&&(o=this.__ee__[t]))if("object"==typeof o){for(r=arguments.length,i=new Array(r-1),e=1;e<r;++e)i[e-1]=arguments[e]
for(o=o.slice(),e=0;n=o[e];++e)p.call(n,this,i)}else switch(arguments.length){case 1:h.call(o,this)
break
case 2:h.call(o,this,arguments[1])
break
case 3:h.call(o,this,arguments[1],arguments[2])
break
default:for(r=arguments.length,i=new Array(r-1),e=1;e<r;++e)i[e-1]=arguments[e]
p.call(o,this,i)}}},c={on:l(n),once:l(o),off:l(i),emit:l(a)},s=y({},c),t.exports=e=function(t){return null==t?d(s):y(Object(t),c)},e.methods=u},function(t,e,r){"use strict"
var n=r(13),o=r(14),i=r(79),a=r(89),u=r(22),c=r(3).iterator
t.exports=function(t){return"function"==typeof u(t)[c]?t[c]():n(t)?new i(t):o(t)?new a(t):new i(t)}},function(t,e){var r
r=function(){return this}()
try{r=r||Function("return this")()||(0,eval)("this")}catch(t){"object"==typeof window&&(r=window)}t.exports=r},function(t,e){t.exports=function(t){return t.webpackPolyfill||(t.deprecate=function(){},t.paths=[],t.children||(t.children=[]),Object.defineProperty(t,"loaded",{enumerable:!0,get:function(){return t.l}}),Object.defineProperty(t,"id",{enumerable:!0,get:function(){return t.i}}),t.webpackPolyfill=1),t}},function(t,e,r){var n=r(27),o=Object.create,i=function(){function t(){}return function(e){if(!n(e))return{}
if(o)return o(e)
t.prototype=e
var r=new t
return t.prototype=void 0,r}}()
t.exports=i},function(t,e,r){var n=r(29),o=r(125),i=r(126),a="[object Null]",u="[object Undefined]",c=n?n.toStringTag:void 0
t.exports=function(t){return null==t?void 0===t?u:a:c&&c in Object(t)?o(t):i(t)}},function(t,e,r){var n=r(133),o=r(138)
t.exports=function(t,e){var r=o(t,e)
return n(r)?r:void 0}},function(t,e,r){var n=r(141),o=r(143),i=n?function(t){return n.get(t)}:o
t.exports=i},function(t,e,r){var n=r(144),o=Object.prototype.hasOwnProperty
t.exports=function(t){for(var e=t.name+"",r=n[e],i=o.call(n,e)?r.length:0;i--;){var a=r[i],u=a.func
if(null==u||u==t)return a.name}return e}},function(t,e,r){"use strict"
r.r(e)
var n=r(0)
function o(t,e,r,n){if(function(t){return"IntValue"===t.kind}(r)||function(t){return"FloatValue"===t.kind}(r))t[e.value]=Number(r.value)
else if(function(t){return"BooleanValue"===t.kind}(r)||function(t){return"StringValue"===t.kind}(r))t[e.value]=r.value
else if(function(t){return"ObjectValue"===t.kind}(r)){var i={}
r.fields.map(function(t){return o(i,t.name,t.value,n)}),t[e.value]=i}else if(function(t){return"Variable"===t.kind}(r)){var a=(n||{})[r.name.value]
t[e.value]=a}else if(function(t){return"ListValue"===t.kind}(r))t[e.value]=r.values.map(function(t){var r={}
return o(r,e,t,n),r[e.value]})
else if(function(t){return"EnumValue"===t.kind}(r))t[e.value]=r.value
else{if(!function(t){return"NullValue"===t.kind}(r))throw new Error('The inline argument "'+e.value+'" of kind "'+r.kind+'" is not supported.\n                    Use variables instead of inline arguments to overcome this limitation.')
t[e.value]=null}}var i=new Map
function a(t){var e=i.get(t)
if(e)return e
var r=t.definitions.filter(function(t){return t.selectionSet&&t.selectionSet.selections}).map(function(t){return function t(e){return e.selectionSet&&e.selectionSet.selections.length>0?[e].concat(e.selectionSet.selections.map(function(e){return[e].concat(t(e))}).reduce(function(t,e){return t.concat(e)},[])):[e]}(t)}).reduce(function(t,e){return t.concat(e)},[]).filter(function(t){return t.directives&&t.directives.length>0}).map(function(t){return t.directives}).reduce(function(t,e){return t.concat(e)},[]).map(function(t){return t.name.value})
return i.set(t,r),r}Object.assign
function u(t){for(var e=[],r=1;r<arguments.length;r++)e[r-1]=arguments[r]
return e.forEach(function(e){void 0!==e&&null!==e&&Object.keys(e).forEach(function(r){t[r]=e[r]})}),t}function c(t){if("Document"!==t.kind)throw new Error('Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a "gql" tag? http://docs.apollostack.com/apollo-client/core.html#gql')
var e=t.definitions.filter(function(t){return"FragmentDefinition"!==t.kind}).map(function(t){if("OperationDefinition"!==t.kind)throw new Error('Schema type definitions not allowed in queries. Found: "'+t.kind+'"')
return t})
if(e.length>1)throw new Error("Ambiguous GraphQL document: contains "+e.length+" operations")}function s(t){return c(t),t.definitions.filter(function(t){return"OperationDefinition"===t.kind})[0]}function l(t){var e=s(t)
if(!e)throw new Error("GraphQL document is missing an operation")
return e}function f(t){return t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&t.name}).map(function(t){return t.name.value})[0]||null}function p(t){return t.definitions.filter(function(t){return"FragmentDefinition"===t.kind})}function h(t){var e=s(t)
if(!e||"query"!==e.operation)throw new Error("Must contain a query definition.")
return e}function d(t){void 0===t&&(t=[])
var e={}
return t.forEach(function(t){e[t.name.value]=t}),e}function v(t){if(t&&t.variableDefinitions&&t.variableDefinitions.length){var e=t.variableDefinitions.filter(function(t){return t.defaultValue}).map(function(t){var e=t.variable,r=t.defaultValue,n={}
return o(n,e.name,r),n})
return u.apply(void 0,[{}].concat(e))}return{}}function y(t){if(Array.isArray(t))return t.map(function(t){return y(t)})
if(null!==t&&"object"==typeof t){var e={}
for(var r in t)t.hasOwnProperty(r)&&(e[r]=y(t[r]))
return e}return t}function b(t,e){return t.selectionSet.selections.filter(function(t){return!(t&&"FragmentSpread"===t.kind&&!b(e[t.name.value],e))}).length>0}function m(t){return function(e){return t.some(function(t){return!(!t.name||t.name!==e.name.value)||!(!t.test||!t.test(e))})}}function _(t,e){var r=y(e)
return r.definitions.forEach(function(e){!function t(e,r){if(!r.selections)return r
var n=e.some(function(t){return t.remove})
return r.selections=r.selections.map(function(t){if("Field"!==t.kind||!t||!t.directives)return t
var r,o=m(e)
return t.directives=t.directives.filter(function(t){var e=!o(t)
return r||e||!n||(r=!0),e}),r?null:t}).filter(function(t){return!!t}),r.selections.forEach(function(r){"Field"!==r.kind&&"InlineFragment"!==r.kind||!r.selectionSet||t(e,r.selectionSet)}),r}(t,e.selectionSet)}),b(l(r),d(p(r)))?r:null}new Map
var g={test:function(t){var e="connection"===t.name.value
return e&&(t.arguments&&t.arguments.some(function(t){return"key"===t.name.value})||console.warn("Removing an @connection directive even though it does not have a key. You may want to use the key parameter to specify a store key.")),e}},w=new Map
var O=r(7)
function E(t){try{return t()}catch(t){console.error&&console.error(t)}}function k(t){return t.errors&&t.errors.length}function x(t,e){if(t===e)return!0
if(t instanceof Date&&e instanceof Date)return t.getTime()===e.getTime()
if(null!=t&&"object"==typeof t&&null!=e&&"object"==typeof e){for(var r in t)if(Object.prototype.hasOwnProperty.call(t,r)){if(!Object.prototype.hasOwnProperty.call(e,r))return!1
if(!x(t[r],e[r]))return!1}for(var r in e)if(!Object.prototype.hasOwnProperty.call(t,r))return!1
return!0}return!1}function S(t){return Object(O.a)()||Object(O.c)()?function t(e){return Object.freeze(e),Object.getOwnPropertyNames(e).forEach(function(r){!e.hasOwnProperty(r)||null===e[r]||"object"!=typeof e[r]&&"function"!=typeof e[r]||Object.isFrozen(e[r])||t(e[r])}),e}(t):t}var j
Object.create({})
function P(t){return t<7}!function(t){t[t.loading=1]="loading",t[t.setVariables=2]="setVariables",t[t.fetchMore=3]="fetchMore",t[t.refetch=4]="refetch",t[t.poll=6]="poll",t[t.ready=7]="ready",t[t.error=8]="error"}(j||(j={}))
var I=r(1),T=r(52),q=r.n(T),N=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),R=function(t){function e(){return null!==t&&t.apply(this,arguments)||this}return N(e,t),e.prototype[q.a]=function(){return this},e}(I.Observable),A=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}()
var M,Q=function(t){var e=""
return Array.isArray(t.graphQLErrors)&&0!==t.graphQLErrors.length&&t.graphQLErrors.forEach(function(t){var r=t?t.message:"Error message not found."
e+="GraphQL error: "+r+"\n"}),t.networkError&&(e+="Network error: "+t.networkError.message+"\n"),e=e.replace(/\n$/,"")},D=function(t){function e(e){var r=e.graphQLErrors,n=e.networkError,o=e.errorMessage,i=e.extraInfo,a=t.call(this,o)||this
return a.graphQLErrors=r||[],a.networkError=n||null,a.message=o||Q(a),a.extraInfo=i,a}return A(e,t),e}(Error)
!function(t){t[t.normal=1]="normal",t[t.refetch=2]="refetch",t[t.poll=3]="poll"}(M||(M={}))
var C=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),F=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},L=function(t){function e(e){var r=e.scheduler,n=e.options,o=e.shouldSubscribe,i=void 0===o||o,a=t.call(this,function(t){return a.onSubscribe(t)})||this
return a.isCurrentlyPolling=!1,a.isTornDown=!1,a.options=n,a.variables=n.variables||{},a.queryId=r.queryManager.generateQueryId(),a.shouldSubscribe=i,a.scheduler=r,a.queryManager=r.queryManager,a.observers=[],a.subscriptionHandles=[],a}return C(e,t),e.prototype.result=function(){var t=this
return new Promise(function(e,r){var n,o={next:function(r){e(r),t.observers.some(function(t){return t!==o})||t.queryManager.removeQuery(t.queryId),setTimeout(function(){n.unsubscribe()},0)},error:function(t){r(t)}}
n=t.subscribe(o)})},e.prototype.currentResult=function(){if(this.isTornDown)return{data:this.lastError?{}:this.lastResult?this.lastResult.data:{},error:this.lastError,loading:!1,networkStatus:j.error}
var t=this.queryManager.queryStore.get(this.queryId)
if(function(t,e){return void 0===e&&(e="none"),t&&(t.graphQLErrors&&t.graphQLErrors.length>0&&"none"===e||t.networkError)}(t,this.options.errorPolicy))return{data:{},loading:!1,networkStatus:t.networkStatus,error:new D({graphQLErrors:t.graphQLErrors,networkError:t.networkError})}
var e,r=this.queryManager.getCurrentQueryResult(this),n=r.data,o=r.partial,i=!t||t.networkStatus===j.loading,a="network-only"===this.options.fetchPolicy&&i||o&&"cache-only"!==this.options.fetchPolicy,u={data:n,loading:P(e=t?t.networkStatus:a?j.loading:j.ready),networkStatus:e}
if(t&&t.graphQLErrors&&"all"===this.options.errorPolicy&&(u.errors=t.graphQLErrors),!o){this.lastResult=F({},u,{stale:!1})}return F({},u,{partial:o})},e.prototype.getLastResult=function(){return this.lastResult},e.prototype.getLastError=function(){return this.lastError},e.prototype.resetLastResults=function(){delete this.lastResult,delete this.lastError,this.isTornDown=!1},e.prototype.refetch=function(t){if("cache-only"===this.options.fetchPolicy)return Promise.reject(new Error("cache-only fetchPolicy option should not be used together with query refetch."))
x(this.variables,t)||(this.variables=F({},this.variables,t)),x(this.options.variables,this.variables)||(this.options.variables=F({},this.options.variables,this.variables))
var e=F({},this.options,{fetchPolicy:"network-only"})
return this.queryManager.fetchQuery(this.queryId,e,M.refetch).then(function(t){return S(t)})},e.prototype.fetchMore=function(t){var e=this
if(!t.updateQuery)throw new Error("updateQuery option is required. This function defines how to update the query data with the new results.")
return Promise.resolve().then(function(){var r,n=e.queryManager.generateQueryId()
return(r=t.query?t:F({},e.options,t,{variables:F({},e.variables,t.variables)})).fetchPolicy="network-only",e.queryManager.fetchQuery(n,r,M.normal,e.queryId)}).then(function(r){return e.updateQuery(function(e,n){var o=n.variables
return t.updateQuery(e,{fetchMoreResult:r.data,variables:o})}),r})},e.prototype.subscribeToMore=function(t){var e=this,r=this.queryManager.startGraphQLSubscription({query:t.document,variables:t.variables}).subscribe({next:function(r){t.updateQuery&&e.updateQuery(function(e,n){var o=n.variables
return t.updateQuery(e,{subscriptionData:r,variables:o})})},error:function(e){t.onError?t.onError(e):console.error("Unhandled GraphQL subscription error",e)}})
return this.subscriptionHandles.push(r),function(){var t=e.subscriptionHandles.indexOf(r)
t>=0&&(e.subscriptionHandles.splice(t,1),r.unsubscribe())}},e.prototype.setOptions=function(t){var e=this.options
this.options=F({},this.options,t),t.pollInterval?this.startPolling(t.pollInterval):0===t.pollInterval&&this.stopPolling()
var r="network-only"!==e.fetchPolicy&&"network-only"===t.fetchPolicy||"cache-only"===e.fetchPolicy&&"cache-only"!==t.fetchPolicy||"standby"===e.fetchPolicy&&"standby"!==t.fetchPolicy||!1
return this.setVariables(this.options.variables,r,t.fetchResults)},e.prototype.setVariables=function(t,e,r){void 0===e&&(e=!1),void 0===r&&(r=!0),this.isTornDown=!1
var n=F({},this.variables,t)
return x(n,this.variables)&&!e?0!==this.observers.length&&r?this.result():new Promise(function(t){return t()}):(this.lastVariables=this.variables,this.variables=n,this.options.variables=n,0===this.observers.length?new Promise(function(t){return t()}):this.queryManager.fetchQuery(this.queryId,F({},this.options,{variables:this.variables})).then(function(t){return S(t)}))},e.prototype.updateQuery=function(t){var e=this.queryManager.getQueryWithPreviousResult(this.queryId),r=e.previousResult,n=e.variables,o=e.document,i=E(function(){return t(r,{variables:n})})
i&&(this.queryManager.dataStore.markUpdateQueryResult(o,n,i),this.queryManager.broadcastQueries())},e.prototype.stopPolling=function(){this.isCurrentlyPolling&&(this.scheduler.stopPollingQuery(this.queryId),this.options.pollInterval=void 0,this.isCurrentlyPolling=!1)},e.prototype.startPolling=function(t){if("cache-first"===this.options.fetchPolicy||"cache-only"===this.options.fetchPolicy)throw new Error("Queries that specify the cache-first and cache-only fetchPolicies cannot also be polling queries.")
this.isCurrentlyPolling&&(this.scheduler.stopPollingQuery(this.queryId),this.isCurrentlyPolling=!1),this.options.pollInterval=t,this.isCurrentlyPolling=!0,this.scheduler.startPollingQuery(this.options,this.queryId)},e.prototype.onSubscribe=function(t){var e=this
return t._subscription&&t._subscription._observer&&!t._subscription._observer.error&&(t._subscription._observer.error=function(t){console.error("Unhandled error",t.message,t.stack)}),this.observers.push(t),t.next&&this.lastResult&&t.next(this.lastResult),t.error&&this.lastError&&t.error(this.lastError),1===this.observers.length&&this.setUpQuery(),function(){e.observers=e.observers.filter(function(e){return e!==t}),0===e.observers.length&&e.tearDownQuery()}},e.prototype.setUpQuery=function(){var t=this
if(this.shouldSubscribe&&this.queryManager.addObservableQuery(this.queryId,this),this.options.pollInterval){if("cache-first"===this.options.fetchPolicy||"cache-only"===this.options.fetchPolicy)throw new Error("Queries that specify the cache-first and cache-only fetchPolicies cannot also be polling queries.")
this.isCurrentlyPolling=!0,this.scheduler.startPollingQuery(this.options,this.queryId)}var e={next:function(e){t.lastResult=e,t.observers.forEach(function(t){return t.next&&t.next(e)})},error:function(e){t.lastError=e,t.observers.forEach(function(t){return t.error&&t.error(e)})}}
this.queryManager.startQuery(this.queryId,this.options,this.queryManager.queryListenerForObserver(this.queryId,this.options,e))},e.prototype.tearDownQuery=function(){this.isTornDown=!0,this.isCurrentlyPolling&&(this.scheduler.stopPollingQuery(this.queryId),this.isCurrentlyPolling=!1),this.subscriptionHandles.forEach(function(t){return t.unsubscribe()}),this.subscriptionHandles=[],this.queryManager.removeObservableQuery(this.queryId),this.queryManager.stopQuery(this.queryId),this.observers=[]},e}(R),V=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),B=function(t){function e(){var e=null!==t&&t.apply(this,arguments)||this
return e.inFlightRequestObservables=new Map,e.subscribers=new Map,e}return V(e,t),e.prototype.request=function(t,e){var r=this
if(t.getContext().forceFetch)return e(t)
var n=t.toKey(),o=function(t){return r.inFlightRequestObservables.delete(t),r.subscribers.get(t)}
if(!this.inFlightRequestObservables.get(n)){var i,a=e(t),u=new I.Observable(function(t){var e=r.subscribers.get(n)
return e||(e={next:[],error:[],complete:[]}),r.subscribers.set(n,{next:e.next.concat([t.next.bind(t)]),error:e.error.concat([t.error.bind(t)]),complete:e.complete.concat([t.complete.bind(t)])}),i||(i=a.subscribe({next:function(t){var e=o(n)
r.subscribers.delete(n),e&&(e.next.forEach(function(e){return e(t)}),e.complete.forEach(function(t){return t()}))},error:function(t){var e=o(n)
r.subscribers.delete(n),e&&e.error.forEach(function(e){return e(t)})}})),function(){i&&i.unsubscribe(),r.inFlightRequestObservables.delete(n)}})
this.inFlightRequestObservables.set(n,u)}return this.inFlightRequestObservables.get(n)},e}(I.ApolloLink),U=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},W=function(){function t(t){var e=t.queryManager,r=t.ssrMode
this.inFlightQueries={},this.registeredQueries={},this.intervalQueries={},this.pollingTimers={},this.ssrMode=!1,this.queryManager=e,this.ssrMode=r||!1}return t.prototype.checkInFlight=function(t){var e=this.queryManager.queryStore.get(t)
return e&&e.networkStatus!==j.ready&&e.networkStatus!==j.error},t.prototype.fetchQuery=function(t,e,r){var n=this
return new Promise(function(o,i){n.queryManager.fetchQuery(t,e,r).then(function(t){o(t)}).catch(function(t){i(t)})})},t.prototype.startPollingQuery=function(t,e,r){if(!t.pollInterval)throw new Error("Attempted to start a polling query without a polling interval.")
return this.ssrMode?e:(this.registeredQueries[e]=t,r&&this.queryManager.addQueryListener(e,r),this.addQueryOnInterval(e,t),e)},t.prototype.stopPollingQuery=function(t){delete this.registeredQueries[t]},t.prototype.fetchQueriesOnInterval=function(t){var e=this
this.intervalQueries[t]=this.intervalQueries[t].filter(function(r){if(!e.registeredQueries.hasOwnProperty(r)||e.registeredQueries[r].pollInterval!==t)return!1
if(e.checkInFlight(r))return!0
var n=e.registeredQueries[r],o=U({},n)
return o.fetchPolicy="network-only",e.fetchQuery(r,o,M.poll).catch(function(){}),!0}),0===this.intervalQueries[t].length&&(clearInterval(this.pollingTimers[t]),delete this.intervalQueries[t])},t.prototype.addQueryOnInterval=function(t,e){var r=this,n=e.pollInterval
if(!n)throw new Error("A poll interval is required to start polling query with id '"+t+"'.")
this.intervalQueries.hasOwnProperty(n.toString())&&this.intervalQueries[n].length>0?this.intervalQueries[n].push(t):(this.intervalQueries[n]=[t],this.pollingTimers[n]=setInterval(function(){r.fetchQueriesOnInterval(n)},n))},t.prototype.registerPollingQuery=function(t){if(!t.pollInterval)throw new Error("Attempted to register a non-polling query with the scheduler.")
return new L({scheduler:this,options:t})},t}(),G=function(){function t(){this.store={}}return t.prototype.getStore=function(){return this.store},t.prototype.get=function(t){return this.store[t]},t.prototype.initMutation=function(t,e,r){this.store[t]={mutationString:e,variables:r||{},loading:!0,error:null}},t.prototype.markMutationError=function(t,e){var r=this.store[t]
r&&(r.loading=!1,r.error=e)},t.prototype.markMutationResult=function(t){var e=this.store[t]
e&&(e.loading=!1,e.error=null)},t.prototype.reset=function(){this.store={}},t}(),Y=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},K=function(){function t(){this.store={}}return t.prototype.getStore=function(){return this.store},t.prototype.get=function(t){return this.store[t]},t.prototype.initQuery=function(t){var e=this.store[t.queryId]
if(e&&e.queryString!==t.queryString)throw new Error("Internal Error: may not update existing query string in store")
var r,n=!1,o=null
t.storePreviousVariables&&e&&e.networkStatus!==j.loading&&(x(e.variables,t.variables)||(n=!0,o=e.variables)),r=n?j.setVariables:t.isPoll?j.poll:t.isRefetch?j.refetch:j.loading
var i=[]
e&&e.graphQLErrors&&(i=e.graphQLErrors),this.store[t.queryId]={queryString:t.queryString,document:t.document,variables:t.variables,previousVariables:o,networkError:null,graphQLErrors:i,networkStatus:r,metadata:t.metadata},"string"==typeof t.fetchMoreForQueryId&&(this.store[t.fetchMoreForQueryId].networkStatus=j.fetchMore)},t.prototype.markQueryResult=function(t,e,r){this.store[t]&&(this.store[t].networkError=null,this.store[t].graphQLErrors=e.errors&&e.errors.length?e.errors:[],this.store[t].previousVariables=null,this.store[t].networkStatus=j.ready,"string"==typeof r&&(this.store[r].networkStatus=j.ready))},t.prototype.markQueryError=function(t,e,r){this.store[t]&&(this.store[t].networkError=e,this.store[t].networkStatus=j.error,"string"==typeof r&&this.markQueryError(r,e,void 0))},t.prototype.markQueryResultClient=function(t,e){this.store[t]&&(this.store[t].networkError=null,this.store[t].previousVariables=null,this.store[t].networkStatus=e?j.ready:j.loading)},t.prototype.stopQuery=function(t){delete this.store[t]},t.prototype.reset=function(t){var e=this
this.store=Object.keys(this.store).filter(function(e){return t.indexOf(e)>-1}).reduce(function(t,r){return t[r]=Y({},e.store[r],{networkStatus:j.loading}),t},{})},t}(),z=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},H={listeners:[],invalidated:!1,document:null,newData:null,lastRequestId:null,observableQuery:null,subscriptions:[]},J=function(){function t(t){var e=t.link,r=t.queryDeduplication,n=void 0!==r&&r,o=t.store,i=t.onBroadcast,a=void 0===i?function(){}:i,u=t.ssrMode,c=void 0!==u&&u
this.mutationStore=new G,this.queryStore=new K,this.idCounter=1,this.queries=new Map,this.fetchQueryPromises=new Map,this.queryIdsByName={},this.link=e,this.deduplicator=I.ApolloLink.from([new B,e]),this.queryDeduplication=n,this.dataStore=o,this.onBroadcast=a,this.scheduler=new W({queryManager:this,ssrMode:c})}return t.prototype.mutate=function(t){var e=this,r=t.mutation,o=t.variables,i=t.optimisticResponse,a=t.updateQueries,s=t.refetchQueries,l=void 0===s?[]:s,f=t.update,p=t.errorPolicy,h=void 0===p?"none":p,d=t.fetchPolicy,y=t.context,b=void 0===y?{}:y
if(!r)throw new Error("mutation option is required. You must specify your GraphQL document in the mutation option.")
if(d&&"no-cache"!==d)throw new Error("fetchPolicy for mutations currently only supports the 'no-cache' policy")
var m=this.generateQueryId(),_=this.dataStore.getCache()
r=_.transformDocument(r),o=u({},v(function(t){c(t)
var e=t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&"mutation"===t.operation})[0]
if(!e)throw new Error("Must contain a mutation definition.")
return e}(r)),o)
var g=Object(n.a)(r)
this.setQuery(m,function(){return{document:r}})
var w=function(){var t={}
return a&&Object.keys(a).forEach(function(r){return(e.queryIdsByName[r]||[]).forEach(function(n){t[n]={updater:a[r],query:e.queryStore.get(n)}})}),t}
return this.mutationStore.initMutation(m,g,o),this.dataStore.markMutationInit({mutationId:m,document:r,variables:o||{},updateQueries:w(),update:f,optimisticResponse:i}),this.broadcastQueries(),new Promise(function(t,n){var a,u,c=e.buildOperationForLink(r,o,z({},b,{optimisticResponse:i}))
Object(I.execute)(e.link,c).subscribe({next:function(t){t.errors&&"none"===h?u=new D({graphQLErrors:t.errors}):(e.mutationStore.markMutationResult(m),"no-cache"!==d&&e.dataStore.markMutationResult({mutationId:m,result:t,document:r,variables:o||{},updateQueries:w(),update:f}),a=t)},error:function(t){e.mutationStore.markMutationError(m,t),e.dataStore.markMutationComplete({mutationId:m,optimisticResponse:i}),e.broadcastQueries(),e.setQuery(m,function(){return{document:void 0}}),n(new D({networkError:t}))},complete:function(){u&&e.mutationStore.markMutationError(m,u),e.dataStore.markMutationComplete({mutationId:m,optimisticResponse:i}),e.broadcastQueries(),u?n(u):("function"==typeof l&&(l=l(a)),l.forEach(function(t){"string"!=typeof t?e.query({query:t.query,variables:t.variables,fetchPolicy:"network-only"}):e.refetchQueryByName(t)}),e.setQuery(m,function(){return{document:void 0}}),"ignore"===h&&a&&a.errors&&delete a.errors,t(a))}})})},t.prototype.fetchQuery=function(t,e,r,o){var i,u=this,c=e.variables,s=void 0===c?{}:c,l=e.metadata,f=void 0===l?null:l,p=e.fetchPolicy,h=void 0===p?"cache-first":p,d=this.dataStore.getCache().transformDocument(e.query),v="network-only"===h||"no-cache"===h
if(r!==M.refetch&&"network-only"!==h&&"no-cache"!==h){var y=this.dataStore.getCache().diff({query:d,variables:s,returnPartialData:!0,optimistic:!1}),b=y.complete,m=y.result
v=!b||"cache-and-network"===h,i=m}var _=v&&"cache-only"!==h&&"standby"!==h;(function(t,e){return a(e).some(function(e){return t.indexOf(e)>-1})})(["live"],d)&&(_=!0)
var g=this.generateRequestId(),w=this.updateQueryWatch(t,d,e)
if(this.setQuery(t,function(){return{document:d,lastRequestId:g,invalidated:!0,cancel:w}}),this.invalidate(!0,o),this.queryStore.initQuery({queryId:t,queryString:Object(n.a)(d),document:d,storePreviousVariables:_,variables:s,isPoll:r===M.poll,isRefetch:r===M.refetch,metadata:f,fetchMoreForQueryId:o}),this.broadcastQueries(),(!_||"cache-and-network"===h)&&(this.queryStore.markQueryResultClient(t,!_),this.invalidate(!0,t,o),this.broadcastQueries()),_){var O=this.fetchRequest({requestId:g,queryId:t,document:d,options:e,fetchMoreForQueryId:o}).catch(function(e){if(function(t){return t.hasOwnProperty("graphQLErrors")}(e))throw e
var r=u.getQuery(t).lastRequestId
throw g>=(r||1)&&(u.queryStore.markQueryError(t,e,o),u.invalidate(!0,t,o),u.broadcastQueries()),u.removeFetchQueryPromise(g),new D({networkError:e})})
if("cache-and-network"!==h)return O
O.catch(function(){})}return Promise.resolve({data:i})},t.prototype.queryListenerForObserver=function(t,e,r){var n=this,o=!1
return function(i,a){if(n.invalidate(!1,t),i){var u=n.getQuery(t).observableQuery,c=u?u.options.fetchPolicy:e.fetchPolicy
if("standby"!==c){var s=u?u.options.errorPolicy:e.errorPolicy,l=u?u.getLastResult():null,f=u?u.getLastError():null,p=!a&&null!=i.previousVariables||"cache-only"===c||"cache-and-network"===c,h=Boolean(l&&i.networkStatus!==l.networkStatus),d=s&&(f&&f.graphQLErrors)!==i.graphQLErrors&&"none"!==s
if(!P(i.networkStatus)||h&&e.notifyOnNetworkStatusChange||p){if((!s||"none"===s)&&i.graphQLErrors&&i.graphQLErrors.length>0||i.networkError){var v=new D({graphQLErrors:i.graphQLErrors,networkError:i.networkError})
if(o=!0,r.error)try{r.error(v)}catch(t){setTimeout(function(){throw t},0)}else setTimeout(function(){throw v},0),Object(O.b)()||console.info("An unhandled error was thrown because no error handler is registered for the query "+i.queryString)
return}try{var y=void 0,b=void 0
if(a)n.setQuery(t,function(){return{newData:null}}),y=a.result,b=!a.complete&&!a.complete
else if(l&&l.data&&!d)y=l.data,b=!1
else{var m=n.getQuery(t).document,_=n.dataStore.getCache().diff({query:m,variables:i.previousVariables||i.variables,optimistic:!0})
y=_.result,b=!_.complete}var g=void 0
if(g=b&&"cache-only"!==c?{data:l&&l.data,loading:P(i.networkStatus),networkStatus:i.networkStatus,stale:!0}:{data:y,loading:P(i.networkStatus),networkStatus:i.networkStatus,stale:!1},"all"===s&&i.graphQLErrors&&i.graphQLErrors.length>0&&(g.errors=i.graphQLErrors),r.next)if(!(l&&g&&l.networkStatus===g.networkStatus&&l.stale===g.stale&&l.data===g.data)||o)try{r.next(S(g))}catch(t){setTimeout(function(){throw t},0)}o=!1}catch(t){return o=!0,void(r.error&&r.error(new D({networkError:t})))}}}}}},t.prototype.watchQuery=function(t,e){if(void 0===e&&(e=!0),"standby"===t.fetchPolicy)throw new Error('client.watchQuery cannot be called with fetchPolicy set to "standby"')
var r=h(t.query)
if(r.variableDefinitions&&r.variableDefinitions.length){var n=v(r)
t.variables=u({},n,t.variables)}void 0===t.notifyOnNetworkStatusChange&&(t.notifyOnNetworkStatusChange=!1)
var o=z({},t)
return new L({scheduler:this.scheduler,options:o,shouldSubscribe:e})},t.prototype.query=function(t){var e=this
if(!t.query)throw new Error("query option is required. You must specify your GraphQL document in the query option.")
if("Document"!==t.query.kind)throw new Error('You must wrap the query string in a "gql" tag.')
if(t.returnPartialData)throw new Error("returnPartialData option only supported on watchQuery.")
if(t.pollInterval)throw new Error("pollInterval option only supported on watchQuery.")
if(void 0!==t.notifyOnNetworkStatusChange)throw new Error('Cannot call "query" with "notifyOnNetworkStatusChange" option. Only "watchQuery" has that option.')
t.notifyOnNetworkStatusChange=!1
var r=this.idCounter,n=new Promise(function(o,i){return e.addFetchQueryPromise(r,n,o,i),e.watchQuery(t,!1).result().then(function(t){e.removeFetchQueryPromise(r),o(t)}).catch(function(t){e.removeFetchQueryPromise(r),i(t)})})
return n},t.prototype.generateQueryId=function(){var t=this.idCounter.toString()
return this.idCounter++,t},t.prototype.stopQueryInStore=function(t){this.queryStore.stopQuery(t),this.invalidate(!0,t),this.broadcastQueries()},t.prototype.addQueryListener=function(t,e){this.setQuery(t,function(t){var r=t.listeners
return{listeners:(void 0===r?[]:r).concat([e]),invalidate:!1}})},t.prototype.updateQueryWatch=function(t,e,r){var n=this,o=this.getQuery(t).cancel
o&&o()
return this.dataStore.getCache().watch({query:e,variables:r.variables,optimistic:!0,previousResult:function(){var e=null,r=n.getQuery(t).observableQuery
if(r){var o=r.getLastResult()
o&&(e=o.data)}return e},callback:function(e){n.setQuery(t,function(){return{invalidated:!0,newData:e}})}})},t.prototype.addFetchQueryPromise=function(t,e,r,n){this.fetchQueryPromises.set(t.toString(),{promise:e,resolve:r,reject:n})},t.prototype.removeFetchQueryPromise=function(t){this.fetchQueryPromises.delete(t.toString())},t.prototype.addObservableQuery=function(t,e){this.setQuery(t,function(){return{observableQuery:e}})
var r=h(e.options.query)
if(r.name&&r.name.value){var n=r.name.value
this.queryIdsByName[n]=this.queryIdsByName[n]||[],this.queryIdsByName[n].push(e.queryId)}},t.prototype.removeObservableQuery=function(t){var e=this.getQuery(t),r=e.observableQuery,n=e.cancel
if(n&&n(),r){var o=h(r.options.query),i=o.name?o.name.value:null
this.setQuery(t,function(){return{observableQuery:null}}),i&&(this.queryIdsByName[i]=this.queryIdsByName[i].filter(function(t){return!(r.queryId===t)}))}},t.prototype.clearStore=function(){this.fetchQueryPromises.forEach(function(t){(0,t.reject)(new Error("Store reset while query was in flight(not completed in link chain)"))})
var t=[]
return this.queries.forEach(function(e,r){e.observableQuery&&t.push(r)}),this.queryStore.reset(t),this.mutationStore.reset(),this.dataStore.reset()},t.prototype.resetStore=function(){var t=this
return this.clearStore().then(function(){return t.reFetchObservableQueries()})},t.prototype.getObservableQueryPromises=function(t){var e=this,r=[]
return this.queries.forEach(function(n,o){var i=n.observableQuery
if(i){var a=i.options.fetchPolicy
i.resetLastResults(),"cache-only"===a||!t&&"standby"===a||r.push(i.refetch()),e.setQuery(o,function(){return{newData:null}}),e.invalidate(!0,o)}}),r},t.prototype.reFetchObservableQueries=function(t){var e=this.getObservableQueryPromises(t)
return this.broadcastQueries(),Promise.all(e)},t.prototype.startQuery=function(t,e,r){return this.addQueryListener(t,r),this.fetchQuery(t,e).catch(function(){}),t},t.prototype.startGraphQLSubscription=function(t){var e,r=this,n=t.query,o=this.dataStore.getCache().transformDocument(n),i=u({},v(s(n)),t.variables),a=[]
return new R(function(t){if(a.push(t),1===a.length){var n={next:function(t){r.dataStore.markSubscriptionResult(t,o,i),r.broadcastQueries(),a.forEach(function(e){e.next&&e.next(t)})},error:function(t){a.forEach(function(e){e.error&&e.error(t)})}},u=r.buildOperationForLink(o,i)
e=Object(I.execute)(r.link,u).subscribe(n)}return function(){0===(a=a.filter(function(e){return e!==t})).length&&e&&e.unsubscribe()}})},t.prototype.stopQuery=function(t){this.stopQueryInStore(t),this.removeQuery(t)},t.prototype.removeQuery=function(t){this.getQuery(t).subscriptions.forEach(function(t){return t.unsubscribe()}),this.queries.delete(t)},t.prototype.getCurrentQueryResult=function(t,e){void 0===e&&(e=!0)
var r=t.options,n=r.variables,o=r.query,i=t.getLastResult(),a=this.getQuery(t.queryId).newData
if(a)return S({data:a.result,partial:!1})
try{return S({data:this.dataStore.getCache().read({query:o,variables:n,previousResult:i?i.data:void 0,optimistic:e}),partial:!1})}catch(t){return S({data:{},partial:!0})}},t.prototype.getQueryWithPreviousResult=function(t){var e
if("string"==typeof t){var r=this.getQuery(t).observableQuery
if(!r)throw new Error("ObservableQuery with this id doesn't exist: "+t)
e=r}else e=t
var n=e.options,o=n.variables,i=n.query
return{previousResult:this.getCurrentQueryResult(e,!1).data,variables:o,document:i}},t.prototype.broadcastQueries=function(){var t=this
this.onBroadcast(),this.queries.forEach(function(e,r){e.invalidated&&e.listeners&&e.listeners.filter(function(t){return!!t}).forEach(function(n){n(t.queryStore.get(r),e.newData)})})},t.prototype.fetchRequest=function(t){var e,r,n=this,o=t.requestId,i=t.queryId,a=t.document,u=t.options,c=t.fetchMoreForQueryId,s=u.variables,l=u.context,f=u.errorPolicy,p=void 0===f?"none":f,h=u.fetchPolicy,d=this.buildOperationForLink(a,s,z({},l,{forceFetch:!this.queryDeduplication})),v=new Promise(function(t,u){n.addFetchQueryPromise(o,v,t,u)
var l=Object(I.execute)(n.deduplicator,d).subscribe({next:function(t){var l=n.getQuery(i).lastRequestId
if(o>=(l||1)){if("no-cache"!==h)try{n.dataStore.markQueryResult(t,a,s,c,"ignore"===p||"all"===p)}catch(t){return void u(t)}n.queryStore.markQueryResult(i,t,c),n.invalidate(!0,i,c),n.broadcastQueries()}if(t.errors&&"none"===p)u(new D({graphQLErrors:t.errors}))
else if("all"===p&&(r=t.errors),c)e=t.data
else try{e=n.dataStore.getCache().read({variables:s,query:a,optimistic:!1})}catch(t){}},error:function(t){n.removeFetchQueryPromise(o),n.setQuery(i,function(t){return{subscriptions:t.subscriptions.filter(function(t){return t!==l})}}),u(t)},complete:function(){n.removeFetchQueryPromise(o),n.setQuery(i,function(t){return{subscriptions:t.subscriptions.filter(function(t){return t!==l})}}),t({data:e,errors:r,loading:!1,networkStatus:j.ready,stale:!1})}})
n.setQuery(i,function(t){return{subscriptions:t.subscriptions.concat([l])}})})
return v},t.prototype.refetchQueryByName=function(t){var e=this,r=this.queryIdsByName[t]
if(void 0!==r)return Promise.all(r.map(function(t){return e.getQuery(t).observableQuery}).filter(function(t){return!!t}).map(function(t){return t.refetch()}))},t.prototype.generateRequestId=function(){var t=this.idCounter
return this.idCounter++,t},t.prototype.getQuery=function(t){return this.queries.get(t)||z({},H)},t.prototype.setQuery=function(t,e){var r=this.getQuery(t),n=z({},r,e(r))
this.queries.set(t,n)},t.prototype.invalidate=function(t,e,r){e&&this.setQuery(e,function(){return{invalidated:t}}),r&&this.setQuery(r,function(){return{invalidated:t}})},t.prototype.buildOperationForLink=function(t,e,r){var n=this.dataStore.getCache()
return{query:n.transformForLink?n.transformForLink(t):t,variables:e,operationName:f(t)||void 0,context:z({},r,{cache:n,getCacheKey:function(t){if(n.config)return n.config.dataIdFromObject(t)
throw new Error("To use context.getCacheKey, you need to use a cache that has a configurable dataIdFromObject, like apollo-cache-inmemory.")}})}},t}(),$=function(){function t(t){this.cache=t}return t.prototype.getCache=function(){return this.cache},t.prototype.markQueryResult=function(t,e,r,n,o){void 0===o&&(o=!1)
var i=!k(t)
o&&k(t)&&t.data&&(i=!0),!n&&i&&this.cache.write({result:t.data,dataId:"ROOT_QUERY",query:e,variables:r})},t.prototype.markSubscriptionResult=function(t,e,r){k(t)||this.cache.write({result:t.data,dataId:"ROOT_SUBSCRIPTION",query:e,variables:r})},t.prototype.markMutationInit=function(t){var e=this
if(t.optimisticResponse){var r
r="function"==typeof t.optimisticResponse?t.optimisticResponse(t.variables):t.optimisticResponse
this.cache.recordOptimisticTransaction(function(n){var o=e.cache
e.cache=n
try{e.markMutationResult({mutationId:t.mutationId,result:{data:r},document:t.document,variables:t.variables,updateQueries:t.updateQueries,update:t.update})}finally{e.cache=o}},t.mutationId)}},t.prototype.markMutationResult=function(t){var e=this
if(!k(t.result)){var r=[]
r.push({result:t.result.data,dataId:"ROOT_MUTATION",query:t.document,variables:t.variables}),t.updateQueries&&Object.keys(t.updateQueries).filter(function(e){return t.updateQueries[e]}).forEach(function(n){var o=t.updateQueries[n],i=o.query,a=o.updater,u=e.cache.diff({query:i.document,variables:i.variables,returnPartialData:!0,optimistic:!1}),c=u.result
if(u.complete){var s=E(function(){return a(c,{mutationResult:t.result,queryName:f(i.document)||void 0,queryVariables:i.variables})})
s&&r.push({result:s,dataId:"ROOT_QUERY",query:i.document,variables:i.variables})}}),this.cache.performTransaction(function(t){r.forEach(function(e){return t.write(e)})})
var n=t.update
n&&this.cache.performTransaction(function(e){E(function(){return n(e,t.result)})})}},t.prototype.markMutationComplete=function(t){var e=t.mutationId
t.optimisticResponse&&this.cache.removeOptimistic(e)},t.prototype.markUpdateQueryResult=function(t,e,r){this.cache.write({result:r,dataId:"ROOT_QUERY",variables:e,query:t})},t.prototype.reset=function(){return this.cache.reset()},t}(),X=r(53),Z=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},tt=!1,et=new I.ApolloLink(function(t,e){return t.query=function(t){c(t)
var e=w.get(t)
if(e)return e
var r=_([g],t)
return w.set(t,r),r}(t.query),e(t)}),rt=function(){function t(t){var e=this
this.defaultOptions={},this.resetStoreCallbacks=[]
var r=t.link,n=t.cache,o=t.ssrMode,i=void 0!==o&&o,a=t.ssrForceFetchDelay,u=void 0===a?0:a,c=t.connectToDevTools,s=t.queryDeduplication,l=void 0===s||s,f=t.defaultOptions
if(!r||!n)throw new Error("\n        In order to initialize Apollo Client, you must specify link & cache properties on the config object.\n        This is part of the required upgrade when migrating from Apollo Client 1.0 to Apollo Client 2.0.\n        For more information, please visit:\n          https://www.apollographql.com/docs/react/basics/setup.html\n        to help you get started.\n      ")
this.link=et.concat(r),this.cache=n,this.store=new $(n),this.disableNetworkFetches=i||u>0,this.queryDeduplication=l,this.ssrMode=i,this.defaultOptions=f||{},u&&setTimeout(function(){return e.disableNetworkFetches=!1},u),this.watchQuery=this.watchQuery.bind(this),this.query=this.query.bind(this),this.mutate=this.mutate.bind(this),this.resetStore=this.resetStore.bind(this),this.reFetchObservableQueries=this.reFetchObservableQueries.bind(this)
var p=!Object(O.b)()&&"undefined"!=typeof window&&!window.__APOLLO_CLIENT__;(void 0===c?p:c&&"undefined"!=typeof window)&&(window.__APOLLO_CLIENT__=this),tt||Object(O.b)()||(tt=!0,"undefined"!=typeof window&&window.document&&window.top===window.self&&void 0===window.__APOLLO_DEVTOOLS_GLOBAL_HOOK__&&navigator.userAgent.indexOf("Chrome")>-1&&console.debug("Download the Apollo DevTools for a better development experience: https://chrome.google.com/webstore/detail/apollo-client-developer-t/jdkknkkbebbapilgoeccciglkfbmbnfm")),this.version=X.version}return t.prototype.watchQuery=function(t){return this.initQueryManager(),this.defaultOptions.watchQuery&&(t=Z({},this.defaultOptions.watchQuery,t)),this.disableNetworkFetches&&"network-only"===t.fetchPolicy&&(t=Z({},t,{fetchPolicy:"cache-first"})),this.queryManager.watchQuery(t)},t.prototype.query=function(t){if(this.initQueryManager(),this.defaultOptions.query&&(t=Z({},this.defaultOptions.query,t)),"cache-and-network"===t.fetchPolicy)throw new Error("cache-and-network fetchPolicy can only be used with watchQuery")
return this.disableNetworkFetches&&"network-only"===t.fetchPolicy&&(t=Z({},t,{fetchPolicy:"cache-first"})),this.queryManager.query(t)},t.prototype.mutate=function(t){return this.initQueryManager(),this.defaultOptions.mutate&&(t=Z({},this.defaultOptions.mutate,t)),this.queryManager.mutate(t)},t.prototype.subscribe=function(t){return this.initQueryManager(),this.queryManager.startGraphQLSubscription(t)},t.prototype.readQuery=function(t){return this.initProxy().readQuery(t)},t.prototype.readFragment=function(t){return this.initProxy().readFragment(t)},t.prototype.writeQuery=function(t){var e=this.initProxy().writeQuery(t)
return this.queryManager.broadcastQueries(),e},t.prototype.writeFragment=function(t){var e=this.initProxy().writeFragment(t)
return this.queryManager.broadcastQueries(),e},t.prototype.writeData=function(t){var e=this.initProxy().writeData(t)
return this.queryManager.broadcastQueries(),e},t.prototype.__actionHookForDevTools=function(t){this.devToolsHookCb=t},t.prototype.__requestRaw=function(t){return Object(I.execute)(this.link,t)},t.prototype.initQueryManager=function(){var t=this
this.queryManager||(this.queryManager=new J({link:this.link,store:this.store,queryDeduplication:this.queryDeduplication,ssrMode:this.ssrMode,onBroadcast:function(){t.devToolsHookCb&&t.devToolsHookCb({action:{},state:{queries:t.queryManager.queryStore.getStore(),mutations:t.queryManager.mutationStore.getStore()},dataWithOptimisticResults:t.cache.extract(!0)})}}))},t.prototype.resetStore=function(){var t=this
return Promise.resolve().then(function(){return t.queryManager?t.queryManager.clearStore():Promise.resolve(null)}).then(function(){return Promise.all(t.resetStoreCallbacks.map(function(t){return t()}))}).then(function(){return t.queryManager?t.queryManager.reFetchObservableQueries():Promise.resolve(null)})},t.prototype.onResetStore=function(t){var e=this
return this.resetStoreCallbacks.push(t),function(){e.resetStoreCallbacks=e.resetStoreCallbacks.filter(function(e){return e!==t})}},t.prototype.reFetchObservableQueries=function(t){return this.queryManager?this.queryManager.reFetchObservableQueries(t):Promise.resolve(null)},t.prototype.extract=function(t){return this.initProxy().extract(t)},t.prototype.restore=function(t){return this.initProxy().restore(t)},t.prototype.initProxy=function(){return this.proxy||(this.initQueryManager(),this.proxy=this.cache),this.proxy},t}()
r.d(e,"printAST",function(){return n.a}),r.d(e,"ObservableQuery",function(){return L}),r.d(e,"NetworkStatus",function(){return j}),r.d(e,"FetchType",function(){return M}),r.d(e,"ApolloError",function(){return D}),r.d(e,"ApolloClient",function(){return rt})
e.default=rt},function(t,e,r){t.exports=r(112).Observable},function(t,e,r){t.exports=r(113)},function(t,e){e.version="2.2.7"},function(t,e,r){r(55),r(94),r(100)
var n=r(105),o=r(50),i=r(149),a=r(153),u=r(157),c=r(154),s=r(156),l=r(1)
t.exports={ReactApollo:n,ApolloClient:o,gql:i,ApolloCacheInMemory:a,ApolloLinkHTTP:u,ApolloLinkBatchHTTP:c,ApolloLinkError:s,ApolloLink:l}},function(t,e,r){"use strict"
r(56)()||Object.defineProperty(r(18),"Map",{value:r(57),configurable:!0,enumerable:!1,writable:!0})},function(t,e,r){"use strict"
t.exports=function(){var t,e
if("function"!=typeof Map)return!1
try{t=new Map([["raz","one"],["dwa","two"],["trzy","three"]])}catch(t){return!1}return"[object Map]"===String(t)&&(3===t.size&&("function"==typeof t.clear&&("function"==typeof t.delete&&("function"==typeof t.entries&&("function"==typeof t.forEach&&("function"==typeof t.get&&("function"==typeof t.has&&("function"==typeof t.keys&&("function"==typeof t.set&&("function"==typeof t.values&&(!1===(e=t.entries().next()).done&&(!!e.value&&("raz"===e.value[0]&&"one"===e.value[1])))))))))))))}},function(t,e,r){"use strict"
var n,o=r(19),i=r(35),a=r(11),u=r(4),c=r(2),s=r(5),l=r(41),f=r(3),p=r(22),h=r(23),d=r(90),v=r(93),y=Function.prototype.call,b=Object.defineProperties,m=Object.getPrototypeOf
t.exports=n=function(){var t,e,r,o=arguments[0]
if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
return r=v&&a&&Map!==n?a(new Map,m(this)):this,null!=o&&p(o),b(r,{__mapKeysData__:s("c",t=[]),__mapValuesData__:s("c",e=[])}),o?(h(o,function(r){var n=c(r)[0]
r=r[1],-1===i.call(t,n)&&(t.push(n),e.push(r))},r),r):r},v&&(a&&a(n,Map),n.prototype=Object.create(Map.prototype,{constructor:s(n)})),l(b(n.prototype,{clear:s(function(){this.__mapKeysData__.length&&(o.call(this.__mapKeysData__),o.call(this.__mapValuesData__),this.emit("_clear"))}),delete:s(function(t){var e=i.call(this.__mapKeysData__,t)
return-1!==e&&(this.__mapKeysData__.splice(e,1),this.__mapValuesData__.splice(e,1),this.emit("_delete",e,t),!0)}),entries:s(function(){return new d(this,"key+value")}),forEach:s(function(t){var e,r,n=arguments[1]
for(u(t),r=(e=this.entries())._next();void 0!==r;)y.call(t,n,this.__mapValuesData__[r],this.__mapKeysData__[r],this),r=e._next()}),get:s(function(t){var e=i.call(this.__mapKeysData__,t)
if(-1!==e)return this.__mapValuesData__[e]}),has:s(function(t){return-1!==i.call(this.__mapKeysData__,t)}),keys:s(function(){return new d(this,"key")}),set:s(function(t,e){var r,n=i.call(this.__mapKeysData__,t)
return-1===n&&(n=this.__mapKeysData__.push(t)-1,r=!0),this.__mapValuesData__[n]=e,r&&this.emit("_add",n,t),this}),size:s.gs(function(){return this.__mapKeysData__.length}),values:s(function(){return new d(this,"value")}),toString:s(function(){return"[object Map]"})})),Object.defineProperty(n.prototype,f.iterator,s(function(){return this.entries()})),Object.defineProperty(n.prototype,f.toStringTag,s("c","Map"))},function(t,e,r){"use strict"
t.exports=r(59)()?Number.isNaN:r(60)},function(t,e,r){"use strict"
t.exports=function(){var t=Number.isNaN
return"function"==typeof t&&(!t({})&&t(NaN)&&!t(34))}},function(t,e,r){"use strict"
t.exports=function(t){return t!=t}},function(t,e,r){"use strict"
var n=r(62),o=Math.abs,i=Math.floor
t.exports=function(t){return isNaN(t)?0:0!==(t=Number(t))&&isFinite(t)?n(t)*i(o(t)):t}},function(t,e,r){"use strict"
t.exports=r(63)()?Math.sign:r(64)},function(t,e,r){"use strict"
t.exports=function(){var t=Math.sign
return"function"==typeof t&&(1===t(10)&&-1===t(-20))}},function(t,e,r){"use strict"
t.exports=function(t){return t=Number(t),isNaN(t)||0===t?t:t>0?1:-1}},function(t,e,r){"use strict"
var n,o=Object.create
r(37)()||(n=r(38)),t.exports=function(){var t,e,r
return n?1!==n.level?o:(t={},e={},r={configurable:!1,enumerable:!1,writable:!0,value:void 0},Object.getOwnPropertyNames(Object.prototype).forEach(function(t){e[t]="__proto__"!==t?r:{configurable:!0,enumerable:!1,writable:!0,value:void 0}}),Object.defineProperties(t,e),Object.defineProperty(n,"nullPolyfill",{configurable:!1,enumerable:!1,writable:!1,value:t}),function(e,r){return o(null===e?t:e,r)}):o}()},function(t,e,r){"use strict"
t.exports=function(){var t,e=Object.assign
return"function"==typeof e&&(e(t={foo:"raz"},{bar:"dwa"},{trzy:"trzy"}),t.foo+t.bar+t.trzy==="razdwatrzy")}},function(t,e,r){"use strict"
var n=r(68),o=r(2),i=Math.max
t.exports=function(t,e){var r,a,u,c=i(arguments.length,2)
for(t=Object(o(t)),u=function(n){try{t[n]=e[n]}catch(t){r||(r=t)}},a=1;a<c;++a)e=arguments[a],n(e).forEach(u)
if(void 0!==r)throw r
return t}},function(t,e,r){"use strict"
t.exports=r(69)()?Object.keys:r(70)},function(t,e,r){"use strict"
t.exports=function(){try{return Object.keys("primitive"),!0}catch(t){return!1}}},function(t,e,r){"use strict"
var n=r(12),o=Object.keys
t.exports=function(t){return o(n(t)?Object(t):t)}},function(t,e,r){"use strict"
t.exports=function(t){return"function"==typeof t}},function(t,e,r){"use strict"
var n="razdwatrzy"
t.exports=function(){return"function"==typeof n.contains&&(!0===n.contains("dwa")&&!1===n.contains("foo"))}},function(t,e,r){"use strict"
var n=String.prototype.indexOf
t.exports=function(t){return n.call(this,t,arguments[1])>-1}},function(t,e,r){"use strict"
var n={object:!0,symbol:!0}
t.exports=function(){var t
if("function"!=typeof Symbol)return!1
t=Symbol("test symbol")
try{String(t)}catch(t){return!1}return!!n[typeof Symbol.iterator]&&(!!n[typeof Symbol.toPrimitive]&&!!n[typeof Symbol.toStringTag])}},function(t,e,r){"use strict"
var n,o,i,a,u=r(5),c=r(76),s=Object.create,l=Object.defineProperties,f=Object.defineProperty,p=Object.prototype,h=s(null)
if("function"==typeof Symbol){n=Symbol
try{String(n()),a=!0}catch(t){}}var d=function(){var t=s(null)
return function(e){for(var r,n,o=0;t[e+(o||"")];)++o
return t[e+=o||""]=!0,f(p,r="@@"+e,u.gs(null,function(t){n||(n=!0,f(this,r,u(t)),n=!1)})),r}}()
i=function(t){if(this instanceof i)throw new TypeError("Symbol is not a constructor")
return o(t)},t.exports=o=function t(e){var r
if(this instanceof t)throw new TypeError("Symbol is not a constructor")
return a?n(e):(r=s(i.prototype),e=void 0===e?"":String(e),l(r,{__description__:u("",e),__name__:u("",d(e))}))},l(o,{for:u(function(t){return h[t]?h[t]:h[t]=o(String(t))}),keyFor:u(function(t){var e
for(e in c(t),h)if(h[e]===t)return e}),hasInstance:u("",n&&n.hasInstance||o("hasInstance")),isConcatSpreadable:u("",n&&n.isConcatSpreadable||o("isConcatSpreadable")),iterator:u("",n&&n.iterator||o("iterator")),match:u("",n&&n.match||o("match")),replace:u("",n&&n.replace||o("replace")),search:u("",n&&n.search||o("search")),species:u("",n&&n.species||o("species")),split:u("",n&&n.split||o("split")),toPrimitive:u("",n&&n.toPrimitive||o("toPrimitive")),toStringTag:u("",n&&n.toStringTag||o("toStringTag")),unscopables:u("",n&&n.unscopables||o("unscopables"))}),l(i.prototype,{constructor:u(o),toString:u("",function(){return this.__name__})}),l(o.prototype,{toString:u(function(){return"Symbol ("+c(this).__description__+")"}),valueOf:u(function(){return c(this)})}),f(o.prototype,o.toPrimitive,u("",function(){var t=c(this)
return"symbol"==typeof t?t:t.toString()})),f(o.prototype,o.toStringTag,u("c","Symbol")),f(i.prototype,o.toStringTag,u("c",o.prototype[o.toStringTag])),f(i.prototype,o.toPrimitive,u("c",o.prototype[o.toPrimitive]))},function(t,e,r){"use strict"
var n=r(77)
t.exports=function(t){if(!n(t))throw new TypeError(t+" is not a symbol")
return t}},function(t,e,r){"use strict"
t.exports=function(t){return!!t&&("symbol"==typeof t||!!t.constructor&&("Symbol"===t.constructor.name&&"Symbol"===t[t.constructor.toStringTag]))}},function(t,e,r){"use strict"
var n=r(13),o=r(12),i=r(14),a=r(3).iterator,u=Array.isArray
t.exports=function(t){return!!o(t)&&(!!u(t)||(!!i(t)||(!!n(t)||"function"==typeof t[a])))}},function(t,e,r){"use strict"
var n,o=r(11),i=r(21),a=r(5),u=r(3),c=r(15),s=Object.defineProperty
n=t.exports=function(t,e){if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
c.call(this,t),e=e?i.call(e,"key+value")?"key+value":i.call(e,"key")?"key":"value":"value",s(this,"__kind__",a("",e))},o&&o(n,c),delete n.prototype.constructor,n.prototype=Object.create(c.prototype,{_resolve:a(function(t){return"value"===this.__kind__?this.__list__[t]:"key+value"===this.__kind__?[t,this.__list__[t]]:t})}),s(n.prototype,u.toStringTag,a("c","Array Iterator"))},function(t,e,r){"use strict"
var n,o=r(81),i=r(40),a=r(4),u=r(86),c=r(4),s=r(2),l=Function.prototype.bind,f=Object.defineProperty,p=Object.prototype.hasOwnProperty
n=function(t,e,r){var n,i=s(e)&&c(e.value)
return delete(n=o(e)).writable,delete n.value,n.get=function(){return!r.overwriteDefinition&&p.call(this,t)?i:(e.value=l.call(i,r.resolveContext?r.resolveContext(this):this),f(this,t,e),this[t])},n},t.exports=function(t){var e=i(arguments[1])
return null!=e.resolveContext&&a(e.resolveContext),u(t,function(t,r){return n(r,t,e)})}},function(t,e,r){"use strict"
var n=r(82),o=r(20),i=r(2)
t.exports=function(t){var e=Object(i(t)),r=arguments[1],a=Object(arguments[2])
if(e!==t&&!r)return e
var u={}
return r?n(r,function(e){(a.ensure||e in t)&&(u[e]=t[e])}):o(u,t),u}},function(t,e,r){"use strict"
t.exports=r(83)()?Array.from:r(84)},function(t,e,r){"use strict"
t.exports=function(){var t,e,r=Array.from
return"function"==typeof r&&(e=r(t=["raz","dwa"]),Boolean(e&&e!==t&&"dwa"===e[1]))}},function(t,e,r){"use strict"
var n=r(3).iterator,o=r(13),i=r(85),a=r(36),u=r(4),c=r(2),s=r(12),l=r(14),f=Array.isArray,p=Function.prototype.call,h={configurable:!0,enumerable:!0,writable:!0,value:null},d=Object.defineProperty
t.exports=function(t){var e,r,v,y,b,m,_,g,w,O,E=arguments[1],k=arguments[2]
if(t=Object(c(t)),s(E)&&u(E),this&&this!==Array&&i(this))e=this
else{if(!E){if(o(t))return 1!==(b=t.length)?Array.apply(null,t):((y=new Array(1))[0]=t[0],y)
if(f(t)){for(y=new Array(b=t.length),r=0;r<b;++r)y[r]=t[r]
return y}}y=[]}if(!f(t))if(void 0!==(w=t[n])){for(_=u(w).call(t),e&&(y=new e),g=_.next(),r=0;!g.done;)O=E?p.call(E,k,g.value,r):g.value,e?(h.value=O,d(y,r,h)):y[r]=O,g=_.next(),++r
b=r}else if(l(t)){for(b=t.length,e&&(y=new e),r=0,v=0;r<b;++r)O=t[r],r+1<b&&(m=O.charCodeAt(0))>=55296&&m<=56319&&(O+=t[++r]),O=E?p.call(E,k,O,v):O,e?(h.value=O,d(y,v,h)):y[v]=O,++v
b=v}if(void 0===b)for(b=a(t.length),e&&(y=new e(b)),r=0;r<b;++r)O=E?p.call(E,k,t[r],r):t[r],e?(h.value=O,d(y,r,h)):y[r]=O
return e&&(h.value=null,y.length=b),y}},function(t,e,r){"use strict"
var n=Object.prototype.toString,o=n.call(r(34))
t.exports=function(t){return"function"==typeof t&&n.call(t)===o}},function(t,e,r){"use strict"
var n=r(4),o=r(87),i=Function.prototype.call
t.exports=function(t,e){var r={},a=arguments[2]
return n(e),o(t,function(t,n,o,u){r[n]=i.call(e,a,t,n,o,u)}),r}},function(t,e,r){"use strict"
t.exports=r(88)("forEach")},function(t,e,r){"use strict"
var n=r(4),o=r(2),i=Function.prototype.bind,a=Function.prototype.call,u=Object.keys,c=Object.prototype.propertyIsEnumerable
t.exports=function(t,e){return function(r,s){var l,f=arguments[2],p=arguments[3]
return r=Object(o(r)),n(s),l=u(r),p&&l.sort("function"==typeof p?i.call(p,r):void 0),"function"!=typeof t&&(t=l[t]),a.call(t,l,function(t,n){return c.call(r,t)?a.call(s,f,r[t],t,r,n):e})}}},function(t,e,r){"use strict"
var n,o=r(11),i=r(5),a=r(3),u=r(15),c=Object.defineProperty
n=t.exports=function(t){if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
t=String(t),u.call(this,t),c(this,"__length__",i("",t.length))},o&&o(n,u),delete n.prototype.constructor,n.prototype=Object.create(u.prototype,{_next:i(function(){if(this.__list__)return this.__nextIndex__<this.__length__?this.__nextIndex__++:void this._unBind()}),_resolve:i(function(t){var e,r=this.__list__[t]
return this.__nextIndex__===this.__length__?r:(e=r.charCodeAt(0))>=55296&&e<=56319?r+this.__list__[this.__nextIndex__++]:r})}),c(n.prototype,a.toStringTag,i("c","String Iterator"))},function(t,e,r){"use strict"
var n,o=r(11),i=r(5),a=r(15),u=r(3).toStringTag,c=r(91),s=Object.defineProperties,l=a.prototype._unBind
n=t.exports=function(t,e){if(!(this instanceof n))return new n(t,e)
a.call(this,t.__mapKeysData__,t),e&&c[e]||(e="key+value"),s(this,{__kind__:i("",e),__values__:i("w",t.__mapValuesData__)})},o&&o(n,a),n.prototype=Object.create(a.prototype,{constructor:i(n),_resolve:i(function(t){return"value"===this.__kind__?this.__values__[t]:"key"===this.__kind__?this.__list__[t]:[this.__list__[t],this.__values__[t]]}),_unBind:i(function(){this.__values__=null,l.call(this)}),toString:i(function(){return"[object Map Iterator]"})}),Object.defineProperty(n.prototype,u,i("c","Map Iterator"))},function(t,e,r){"use strict"
t.exports=r(92)("key","value","key+value")},function(t,e,r){"use strict"
var n=Array.prototype.forEach,o=Object.create
t.exports=function(t){var e=o(null)
return n.call(arguments,function(t){e[t]=!0}),e}},function(t,e,r){"use strict"
t.exports="undefined"!=typeof Map&&"[object Map]"===Object.prototype.toString.call(new Map)},function(t,e,r){"use strict"
r(95)()||Object.defineProperty(r(18),"WeakMap",{value:r(96),configurable:!0,enumerable:!1,writable:!0})},function(t,e,r){"use strict"
t.exports=function(){var t,e
if("function"!=typeof WeakMap)return!1
try{t=new WeakMap([[e={},"one"],[{},"two"],[{},"three"]])}catch(t){return!1}return"[object WeakMap]"===String(t)&&("function"==typeof t.set&&(t.set({},1)===t&&("function"==typeof t.delete&&("function"==typeof t.has&&"one"===t.get(e)))))}},function(t,e,r){"use strict"
var n,o=r(11),i=r(97),a=r(2),u=r(98),c=r(5),s=r(42),l=r(23),f=r(3).toStringTag,p=r(99),h=Array.isArray,d=Object.defineProperty,v=Object.prototype.hasOwnProperty,y=Object.getPrototypeOf
t.exports=n=function(){var t,e=arguments[0]
if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
return t=p&&o&&WeakMap!==n?o(new WeakMap,y(this)):this,null!=e&&(h(e)||(e=s(e))),d(t,"__weakMapData__",c("c","$weakMap$"+u())),e?(l(e,function(e){a(e),t.set(e[0],e[1])}),t):t},p&&(o&&o(n,WeakMap),n.prototype=Object.create(WeakMap.prototype,{constructor:c(n)})),Object.defineProperties(n.prototype,{delete:c(function(t){return!!v.call(i(t),this.__weakMapData__)&&(delete t[this.__weakMapData__],!0)}),get:c(function(t){if(v.call(i(t),this.__weakMapData__))return t[this.__weakMapData__]}),has:c(function(t){return v.call(i(t),this.__weakMapData__)}),set:c(function(t,e){return d(i(t),this.__weakMapData__,c("c",e)),this}),toString:c(function(){return"[object WeakMap]"})}),d(n.prototype,f,c("c","WeakMap"))},function(t,e,r){"use strict"
var n=r(39)
t.exports=function(t){if(!n(t))throw new TypeError(t+" is not an Object")
return t}},function(t,e,r){"use strict"
var n=Object.create(null),o=Math.random
t.exports=function(){var t
do{t=o().toString(36).slice(2)}while(n[t])
return t}},function(t,e,r){"use strict"
t.exports="function"==typeof WeakMap&&"[object WeakMap]"===Object.prototype.toString.call(new WeakMap)},function(t,e,r){"use strict"
r(101)()||Object.defineProperty(r(18),"Set",{value:r(102),configurable:!0,enumerable:!1,writable:!0})},function(t,e,r){"use strict"
t.exports=function(){var t,e
return"function"==typeof Set&&(t=new Set(["raz","dwa","trzy"]),"[object Set]"===String(t)&&(3===t.size&&("function"==typeof t.add&&("function"==typeof t.clear&&("function"==typeof t.delete&&("function"==typeof t.entries&&("function"==typeof t.forEach&&("function"==typeof t.has&&("function"==typeof t.keys&&("function"==typeof t.values&&(!1===(e=t.values().next()).done&&"raz"===e.value)))))))))))}},function(t,e,r){"use strict"
var n,o,i,a=r(19),u=r(35),c=r(11),s=r(4),l=r(5),f=r(41),p=r(3),h=r(22),d=r(23),v=r(103),y=r(104),b=Function.prototype.call,m=Object.defineProperty,_=Object.getPrototypeOf
y&&(i=Set),t.exports=n=function(){var t,e=arguments[0]
if(!(this instanceof n))throw new TypeError("Constructor requires 'new'")
return t=y&&c?c(new i,_(this)):this,null!=e&&h(e),m(t,"__setData__",l("c",[])),e?(d(e,function(t){-1===u.call(this,t)&&this.push(t)},t.__setData__),t):t},y&&(c&&c(n,i),n.prototype=Object.create(i.prototype,{constructor:l(n)})),f(Object.defineProperties(n.prototype,{add:l(function(t){return this.has(t)?this:(this.emit("_add",this.__setData__.push(t)-1,t),this)}),clear:l(function(){this.__setData__.length&&(a.call(this.__setData__),this.emit("_clear"))}),delete:l(function(t){var e=u.call(this.__setData__,t)
return-1!==e&&(this.__setData__.splice(e,1),this.emit("_delete",e,t),!0)}),entries:l(function(){return new v(this,"key+value")}),forEach:l(function(t){var e,r,n,o=arguments[1]
for(s(t),r=(e=this.values())._next();void 0!==r;)n=e._resolve(r),b.call(t,o,n,n,this),r=e._next()}),has:l(function(t){return-1!==u.call(this.__setData__,t)}),keys:l(o=function(){return this.values()}),size:l.gs(function(){return this.__setData__.length}),values:l(function(){return new v(this)}),toString:l(function(){return"[object Set]"})})),m(n.prototype,p.iterator,l(o)),m(n.prototype,p.toStringTag,l("c","Set"))},function(t,e,r){"use strict"
var n,o=r(11),i=r(21),a=r(5),u=r(15),c=r(3).toStringTag,s=Object.defineProperty
n=t.exports=function(t,e){if(!(this instanceof n))return new n(t,e)
u.call(this,t.__setData__,t),e=e&&i.call(e,"key+value")?"key+value":"value",s(this,"__kind__",a("",e))},o&&o(n,u),n.prototype=Object.create(u.prototype,{constructor:a(n),_resolve:a(function(t){return"value"===this.__kind__?this.__list__[t]:[this.__list__[t],this.__list__[t]]}),toString:a(function(){return"[object Set Iterator]"})}),s(n.prototype,c,a("c","Set Iterator"))},function(t,e,r){"use strict"
t.exports="undefined"!=typeof Set&&"[object Set]"===Object.prototype.toString.call(Set.prototype)},function(t,e,r){!function(t,e,n,o){"use strict"
function i(t,r,n){if(Array.isArray(t))t.forEach(function(t){return i(t,r,n)})
else if(t)if(function(t){return!!t.type}(t))if("function"==typeof t.type){var o=t.type,a=Object.assign({},o.defaultProps,function(t){return t.props||t.attributes}(t)),u=r,c=void 0
if(function(t){return t.prototype&&(t.prototype.render||t.prototype.isReactComponent)}(o)){var s=new o(a,r)
if(Object.defineProperty(s,"props",{value:s.props||a}),s.context=s.context||r,s.state=s.state||null,s.setState=function(t){"function"==typeof t&&(t=t(s.state,s.props,s.context)),s.state=Object.assign({},s.state,t)},o.getDerivedStateFromProps){var l=o.getDerivedStateFromProps(s.props,s.state)
null!==l&&(s.state=Object.assign({},s.state,l))}else s.UNSAFE_componentWillMount?s.UNSAFE_componentWillMount():s.componentWillMount&&s.componentWillMount()
if(function(t){return!!t.getChildContext}(s)&&(u=Object.assign({},r,s.getChildContext())),!1===n(t,s,r,u))return
c=s.render()}else{if(!1===n(t,null,r))return
c=o(a,r)}c&&(Array.isArray(c)?c.forEach(function(t){return i(t,u,n)}):i(c,u,n))}else if(t.type._context||t.type.Consumer){if(!1===n(t,null,r))return
var c=void 0
t.type._context?(t.type._context._currentValue=t.props.value,c=t.props.children):c=t.props.children(t.type._currentValue),c&&(Array.isArray(c)?c.forEach(function(t){return i(t,r,n)}):i(c,r,n))}else{if(!1===n(t,null,r))return
t.props&&t.props.children&&e.Children.forEach(t.props.children,function(t){t&&i(t,r,n)})}else"string"!=typeof t&&"number"!=typeof t||n(t,null,r)}function a(t,e,r){void 0===e&&(e={})
var n=function(t){var e=t.rootElement,r=t.rootContext,n=[]
return i(e,void 0===r?{}:r,function(t,e,r,o){if(e&&function(t){return"function"==typeof t.fetchData}(e)){var i=e.fetchData()
if(function(t){return"function"==typeof t.then}(i))return n.push({promise:i,context:o||r,instance:e}),!1}}),n}({rootElement:t,rootContext:e})
if(!n.length)return Promise.resolve()
var o=n.map(function(t){var e=t.promise,n=t.context,o=t.instance
return e.then(function(t){return a(o.render(),n,r)}).catch(function(t){return r(t)})})
return Promise.all(o)}var u=r(6),c=function(t,e){return u(!!e.client,'Could not find "client" in the context of ApolloConsumer. Wrap the root component in an <ApolloProvider>'),t.children(e.client)}
c.contextTypes={client:n.object.isRequired},c.propTypes={children:n.func.isRequired}
var s,l=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),f=r(6),p=function(t){function e(e,r){var n=t.call(this,e,r)||this
return n.operations=new Map,f(e.client,'ApolloProvider was not passed a client instance. Make sure you pass in your client via the "client" prop.'),e.client.__operations_cache__||(e.client.__operations_cache__=n.operations),n}return l(e,t),e.prototype.getChildContext=function(){return{client:this.props.client,operations:this.props.client.__operations_cache__}},e.prototype.render=function(){return this.props.children},e.propTypes={client:n.object.isRequired,children:n.node.isRequired},e.childContextTypes={client:n.object.isRequired,operations:n.object},e}(e.Component),h=r(6)
!function(t){t[t.Query=0]="Query",t[t.Mutation=1]="Mutation",t[t.Subscription=2]="Subscription"}(s||(s={}))
var d=new Map
function v(t){var e,r,n=d.get(t)
if(n)return n
h(!!t&&!!t.kind,"Argument of "+t+" passed to parser was not a valid GraphQL DocumentNode. You may need to use 'graphql-tag' or another method to convert your operation into a document")
var o=t.definitions.filter(function(t){return"FragmentDefinition"===t.kind}),i=t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&"query"===t.operation}),a=t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&"mutation"===t.operation}),u=t.definitions.filter(function(t){return"OperationDefinition"===t.kind&&"subscription"===t.operation})
h(!o.length||i.length||a.length||u.length,"Passing only a fragment to 'graphql' is not yet supported. You must include a query, subscription or mutation as well"),h(i.length+a.length+u.length<=1,"react-apollo only supports a query, subscription, or a mutation per HOC. "+t+" had "+i.length+" queries, "+u.length+" subscriptions and "+a.length+" mutations. You can use 'compose' to join multiple operation types to a component"),r=i.length?s.Query:s.Mutation,i.length||a.length||(r=s.Subscription)
var c=i.length?i:a.length?a:u
h(1===c.length,"react-apollo only supports one defintion per HOC. "+t+" had "+c.length+" definitions. You can use 'compose' to join multiple operation types to a component")
var l=c[0]
e=l.variableDefinitions||[]
var f={name:l.name&&"Name"===l.name.kind?l.name.value:"data",type:r,variables:e}
return d.set(t,f),f}var y=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),b=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},m=function(t,e){var r={}
for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.indexOf(n)<0&&(r[n]=t[n])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols)for(var o=0,n=Object.getOwnPropertySymbols(t);o<n.length;o++)e.indexOf(n[o])<0&&(r[n[o]]=t[n[o]])
return r},_=r(25),g=r(6),w=function(t){function e(e,r){var n=t.call(this,e,r)||this
return n.previousData={},n.hasMounted=!1,n.startQuerySubscription=function(){if(!n.querySubscription){var t=n.getQueryResult()
n.querySubscription=n.queryObservable.subscribe({next:function(e){var r=e.data
t&&7===t.networkStatus&&_(t.data,r)?t=void 0:(t=void 0,n.updateCurrentData())},error:function(t){if(n.resubscribeToQuery(),!t.hasOwnProperty("graphQLErrors"))throw t
n.updateCurrentData()}})}},n.removeQuerySubscription=function(){n.querySubscription&&(n.querySubscription.unsubscribe(),delete n.querySubscription)},n.updateCurrentData=function(){var t=n.props,e=t.onCompleted,r=t.onError
if(e||r){var o=n.queryObservable.currentResult(),i=o.loading,a=o.error,u=o.data
!e||i||a?r&&!i&&a&&r(a):e(u)}n.hasMounted&&n.forceUpdate()},n.getQueryResult=function(){var t={data:Object.create(null)}
Object.assign(t,function(t){return{variables:t.variables,refetch:t.refetch.bind(t),fetchMore:t.fetchMore.bind(t),updateQuery:t.updateQuery.bind(t),startPolling:t.startPolling.bind(t),stopPolling:t.stopPolling.bind(t),subscribeToMore:t.subscribeToMore.bind(t)}}(n.queryObservable))
var e=n.queryObservable.currentResult(),r=e.loading,i=e.networkStatus,a=e.errors,u=e.error
if(a&&a.length>0&&(u=new o.ApolloError({graphQLErrors:a})),Object.assign(t,{loading:r,networkStatus:i,error:u}),r?Object.assign(t.data,n.previousData,e.data):u?Object.assign(t,{data:(n.queryObservable.getLastResult()||{}).data}):(Object.assign(t.data,e.data),n.previousData=e.data),!n.querySubscription){var c=t.refetch
t.refetch=function(t){return n.querySubscription?c(t):new Promise(function(e,r){n.refetcherQueue={resolve:e,reject:r,args:t}})}}return t.client=n.client,t},n.client=e.client||r.client,g(!!n.client,'Could not find "client" in the context of Query or as passed props. Wrap the root component in an <ApolloProvider>'),n.initializeQueryObservable(e),n}return y(e,t),e.prototype.fetchData=function(){if(this.props.skip)return!1
var t=this.props,e=(t.children,t.ssr),r=(t.displayName,t.skip,t.client,t.onCompleted,t.onError,m(t,["children","ssr","displayName","skip","client","onCompleted","onError"])),n=r.fetchPolicy
if(!1===e)return!1
"network-only"!==n&&"cache-and-network"!==n||(n="cache-first")
var o=this.client.watchQuery(b({},r,{fetchPolicy:n})),i=this.queryObservable.currentResult()
return!!i.loading&&o.result()},e.prototype.componentDidMount=function(){if(this.hasMounted=!0,!this.props.skip&&(this.startQuerySubscription(),this.refetcherQueue)){var t=this.refetcherQueue,e=t.args,r=t.resolve,n=t.reject
this.queryObservable.refetch(e).then(r).catch(n)}},e.prototype.componentWillReceiveProps=function(t,e){if(!t.skip||this.props.skip){var r=t.client;(!_(this.props,t)||this.client!==r&&this.client!==e.client)&&(this.client!==r&&this.client!==e.client&&(this.client=r||e.client,this.removeQuerySubscription(),this.queryObservable=null,this.previousData={},this.updateQuery(t)),this.props.query!==t.query&&this.removeQuerySubscription(),this.updateQuery(t),t.skip||this.startQuerySubscription())}else this.removeQuerySubscription()},e.prototype.componentWillUnmount=function(){this.removeQuerySubscription(),this.hasMounted=!1},e.prototype.render=function(){var t=this.props.children,e=this.getQueryResult()
return t(e)},e.prototype.extractOptsFromProps=function(t){var e=t.variables,r=t.pollInterval,n=t.fetchPolicy,o=t.errorPolicy,i=t.notifyOnNetworkStatusChange,a=t.query,u=t.displayName,c=void 0===u?"Query":u,l=t.context,f=void 0===l?{}:l
return this.operation=v(a),g(this.operation.type===s.Query,"The <Query /> component requires a graphql query, but got a "+(this.operation.type===s.Mutation?"mutation":"subscription")+"."),function(t){return Object.keys(t).reduce(function(e,r){return void 0!==t[r]&&(e[r]=t[r]),e},{})}({variables:e,pollInterval:r,query:a,fetchPolicy:n,errorPolicy:o,notifyOnNetworkStatusChange:i,metadata:{reactComponent:{displayName:c}},context:f})},e.prototype.initializeQueryObservable=function(t){var e=this.extractOptsFromProps(t)
this.context.operations&&this.context.operations.set(this.operation.name,{query:e.query,variables:e.variables}),this.queryObservable=this.client.watchQuery(e)},e.prototype.updateQuery=function(t){this.queryObservable||this.initializeQueryObservable(t),this.queryObservable.setOptions(this.extractOptsFromProps(t)).catch(function(){return null})},e.prototype.resubscribeToQuery=function(){this.removeQuerySubscription()
var t=this.queryObservable.getLastError(),e=this.queryObservable.getLastResult()
this.queryObservable.resetLastResults(),this.startQuerySubscription(),Object.assign(this.queryObservable,{lastError:t,lastResult:e})},e.contextTypes={client:n.object.isRequired,operations:n.object},e.propTypes={children:n.func.isRequired,fetchPolicy:n.string,notifyOnNetworkStatusChange:n.bool,onCompleted:n.func,onError:n.func,pollInterval:n.number,query:n.object.isRequired,variables:n.object,ssr:n.bool},e}(e.Component),O=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),E=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},k=r(6),x=r(25),S={loading:!1,called:!1,error:void 0,data:void 0},j=function(t){function e(e,r){var n=t.call(this,e,r)||this
return n.hasMounted=!1,n.runMutation=function(t){void 0===t&&(t={}),n.onMutationStart()
var e=n.generateNewMutationId()
return n.mutate(t).then(function(t){return n.onMutationCompleted(t,e),t}).catch(function(t){if(n.onMutationError(t,e),!n.props.onError)throw t})},n.mutate=function(t){var e=n.props,r=e.mutation,o=e.variables,i=e.optimisticResponse,a=e.update,u=e.context,c=void 0===u?{}:u,s=e.awaitRefetchQueries,l=void 0!==s&&s,f=t.refetchQueries||n.props.refetchQueries
return f&&f.length&&Array.isArray(f)&&(f=f.map(function(t){return"string"==typeof t&&n.context.operations&&n.context.operations.get(t)||t}),delete t.refetchQueries),n.client.mutate(E({mutation:r,variables:o,optimisticResponse:i,refetchQueries:f,awaitRefetchQueries:l,update:a,context:c},t))},n.onMutationStart=function(){n.state.loading||n.props.ignoreResults||n.setState({loading:!0,error:void 0,data:void 0,called:!0})},n.onMutationCompleted=function(t,e){if(!1!==n.hasMounted){var r=n.props,o=r.onCompleted,i=r.ignoreResults,a=t.data,u=function(){return o?o(a):null}
n.isMostRecentMutation(e)&&!i?n.setState({loading:!1,data:a},u):u()}},n.onMutationError=function(t,e){if(!1!==n.hasMounted){var r=n.props.onError,o=function(){return r?r(t):null}
n.isMostRecentMutation(e)?n.setState({loading:!1,error:t},o):o()}},n.generateNewMutationId=function(){return n.mostRecentMutationId=n.mostRecentMutationId+1,n.mostRecentMutationId},n.isMostRecentMutation=function(t){return n.mostRecentMutationId===t},n.verifyDocumentIsMutation=function(t){var e=v(t)
k(e.type===s.Mutation,"The <Mutation /> component requires a graphql mutation, but got a "+(e.type===s.Query?"query":"subscription")+".")},n.client=e.client||r.client,k(!!n.client,'Could not find "client" in the context or props of Mutation. Wrap the root component in an <ApolloProvider>, or pass an ApolloClient instance in via props.'),n.verifyDocumentIsMutation(e.mutation),n.mostRecentMutationId=0,n.state=S,n}return O(e,t),e.prototype.componentDidMount=function(){this.hasMounted=!0},e.prototype.componentWillUnmount=function(){this.hasMounted=!1},e.prototype.componentWillReceiveProps=function(t,e){var r=t.client;(!x(this.props,t)||this.client!==r&&this.client!==e.client)&&(this.props.mutation!==t.mutation&&this.verifyDocumentIsMutation(t.mutation),this.client!==r&&this.client!==e.client&&(this.client=r||e.client,this.setState(S)))},e.prototype.render=function(){var t=this.props.children,e=this.state,r=e.loading,n=e.data,o=e.error,i=e.called,a={called:i,loading:r,data:n,error:o,client:this.client}
return t(this.runMutation,a)},e.contextTypes={client:n.object.isRequired,operations:n.object},e.propTypes={mutation:n.object.isRequired,variables:n.object,optimisticResponse:n.object,refetchQueries:n.oneOfType([n.arrayOf(n.oneOfType([n.string,n.object])),n.func]),awaitRefetchQueries:n.bool,update:n.func,children:n.func.isRequired,onCompleted:n.func,onError:n.func},e}(e.Component),P=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),I=r(25),T=r(6),q=function(t){function e(e,r){var n=t.call(this,e,r)||this
return n.initialize=function(t){n.queryObservable||(n.queryObservable=n.client.subscribe({query:t.subscription,variables:t.variables}))},n.startSubscription=function(){n.querySubscription||(n.querySubscription=n.queryObservable.subscribe({next:n.updateCurrentData,error:n.updateError}))},n.getInitialState=function(){return{loading:!0,error:void 0,data:void 0}},n.updateCurrentData=function(t){n.setState({data:t.data,loading:!1,error:void 0})},n.updateError=function(t){n.setState({error:t,loading:!1})},n.endSubscription=function(){n.querySubscription&&(n.querySubscription.unsubscribe(),delete n.querySubscription)},T(!!r.client,'Could not find "client" in the context of Subscription. Wrap the root component in an <ApolloProvider>'),n.client=r.client,n.initialize(e),n.state=n.getInitialState(),n}return P(e,t),e.prototype.componentDidMount=function(){this.startSubscription()},e.prototype.componentWillReceiveProps=function(t,e){if(!I(this.props.variables,t.variables)||this.client!==e.client||this.props.subscription!==t.subscription){var r=t.shouldResubscribe
"function"==typeof r&&(r=!!r(this.props,t))
var n=!1===r
if(this.client!==e.client&&(this.client=e.client),!n)return this.endSubscription(),delete this.queryObservable,this.initialize(t),this.startSubscription(),void this.setState(this.getInitialState())
this.initialize(t),this.startSubscription()}},e.prototype.componentWillUnmount=function(){this.endSubscription()},e.prototype.render=function(){var t=Object.assign({},this.state,{variables:this.props.variables})
return this.props.children(t)},e.contextTypes={client:n.object.isRequired},e.propTypes={subscription:n.object.isRequired,variables:n.object,children:n.func.isRequired,shouldResubscribe:n.oneOfType([n.func,n.bool])},e}(e.Component),N=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),R=r(6),A=function(){return{}},M=function(){return!1}
function Q(t){return t.displayName||t.name||"Component"}function D(t,e,r,n){for(var o={},i=0,a=t.variables;i<a.length;i++){var u=a[i],c=u.variable,l=u.type
if(c.name&&c.name.value){var f=c.name.value,p=e[f]
if(void 0===p)if("NonNullType"===l.kind){if(t.type===s.Mutation)return
R(void 0!==p,"The operation '"+t.name+"' wrapping '"+n+"' is expecting a variable: '"+c.name.value+"' but it was not found in the props passed to '"+r+"'")}else o[f]=null
else o[f]=p}}return o}var C=function(t){function e(e){var r=t.call(this,e)||this
return r.withRef=!1,r.setWrappedInstance=r.setWrappedInstance.bind(r),r}return N(e,t),e.prototype.getWrappedInstance=function(){return R(this.withRef,"To access the wrapped instance, you need to specify { withRef: true } in the options"),this.wrappedInstance},e.prototype.setWrappedInstance=function(t){this.wrappedInstance=t},e}(e.Component),F=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),L=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},V=function(t,e){var r={}
for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.indexOf(n)<0&&(r[n]=t[n])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols)for(var o=0,n=Object.getOwnPropertySymbols(t);o<n.length;o++)e.indexOf(n[o])<0&&(r[n[o]]=t[n[o]])
return r},B=r(16),U=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),W=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},G=r(16),Y=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),K=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},z=function(t,e){var r={}
for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.indexOf(n)<0&&(r[n]=t[n])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols)for(var o=0,n=Object.getOwnPropertySymbols(t);o<n.length;o++)e.indexOf(n[o])<0&&(r[n[o]]=t[n[o]])
return r},H=r(16),J=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),$=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},X=r(6),Z=r(16),tt=r(115)
t.compose=tt,t.getDataFromTree=function(t,e){void 0===e&&(e={})
var r=[]
return a(t,e,function(t){return r.push(t)}).then(function(t){return function(t){switch(t.length){case 0:break
case 1:throw t.pop()
default:var e=new Error(t.length+" errors were thrown when executing your fetchData functions.")
throw e.queryErrors=t,e}}(r)})},t.ApolloConsumer=c,t.ApolloProvider=p,t.Query=w,t.Mutation=j,t.Subscription=q,t.graphql=function(t,r){switch(void 0===r&&(r={}),v(t).type){case s.Mutation:return function(t,r){void 0===r&&(r={})
var n=v(t),o=r.options,i=void 0===o?A:o,a=r.alias,u=void 0===a?"Apollo":a,c=i
return"function"!=typeof c&&(c=function(){return i}),function(o){var i=u+"("+Q(o)+")",a=function(a){function u(){return null!==a&&a.apply(this,arguments)||this}return U(u,a),u.prototype.render=function(){var a=this.props,u=c(a)
return r.withRef&&(this.withRef=!0,a=Object.assign({},a,{ref:this.setWrappedInstance})),!u.variables&&n.variables.length>0&&(u.variables=D(n,a,i,Q(o))),e.createElement(j,W({},u,{mutation:t,ignoreResults:!0}),function(t,n){var i,u,c=r.name||"mutate",s=((i={})[c]=t,i)
if(r.props){var l=((u={})[c]=t,u.ownProps=a,u)
s=r.props(l)}return e.createElement(o,W({},a,s))})},u.displayName=i,u.WrappedComponent=o,u}(C)
return G(a,o,{})}}(t,r)
case s.Subscription:return function(t,r){void 0===r&&(r={})
var n=v(t),o=r.options,i=void 0===o?A:o,a=r.skip,u=void 0===a?M:a,c=r.alias,s=void 0===c?"Apollo":c,l=r.shouldResubscribe,f=i
"function"!=typeof f&&(f=function(){return i})
var p,h=u
return"function"!=typeof h&&(h=function(){return u}),function(o){var i=s+"("+Q(o)+")",a=function(a){function u(t){var e=a.call(this,t)||this
return e.state={resubscribe:!1},e}return Y(u,a),u.prototype.componentWillReceiveProps=function(t){l&&this.setState({resubscribe:l(this.props,t)})},u.prototype.render=function(){var a=this,u=this.props,c=h(u),s=c?Object.create(null):f(u)
return!c&&!s.variables&&n.variables.length>0&&(s.variables=D(n,u,i,Q(o))),e.createElement(q,K({},s,{displayName:i,skip:c,subscription:t,shouldResubscribe:this.state.resubscribe}),function(t){var n,i,s=t.data,l=z(t,["data"])
if(r.withRef&&(a.withRef=!0,u=Object.assign({},u,{ref:a.setWrappedInstance})),c)return e.createElement(o,K({},u))
var f=Object.assign(l,s||{}),h=r.name||"data",d=((n={})[h]=f,n)
if(r.props){var v=((i={})[h]=f,i.ownProps=u,i)
p=r.props(v,p),d=p}return e.createElement(o,K({},u,d))})},u.displayName=i,u.WrappedComponent=o,u}(C)
return H(a,o,{})}}(t,r)
case s.Query:default:return function(t,r){void 0===r&&(r={})
var n=v(t),o=r.options,i=void 0===o?A:o,a=r.skip,u=void 0===a?M:a,c=r.alias,s=void 0===c?"Apollo":c,l=i
"function"!=typeof l&&(l=function(){return i})
var f,p=u
return"function"!=typeof p&&(p=function(){return u}),function(o){var i=s+"("+Q(o)+")",a=function(a){function u(){return null!==a&&a.apply(this,arguments)||this}return F(u,a),u.prototype.render=function(){var a=this,u=this.props,c=p(u),s=c?Object.create(null):l(u)
return!c&&!s.variables&&n.variables.length>0&&(s.variables=D(n,u,i,Q(o))),e.createElement(w,L({},s,{displayName:i,skip:c,query:t,warnUnhandledError:!0}),function(t){t.client
var n,i,s=t.data,l=V(t,["client","data"])
if(r.withRef&&(a.withRef=!0,u=Object.assign({},u,{ref:a.setWrappedInstance})),c)return e.createElement(o,L({},u))
var p=Object.assign(l,s||{}),h=r.name||"data",d=((n={})[h]=p,n)
if(r.props){var v=((i={})[h]=p,i.ownProps=u,i)
f=r.props(v,f),d=f}return e.createElement(o,L({},u,d))})},u.displayName=i,u.WrappedComponent=o,u}(C)
return B(a,o,{})}}(t,r)}},t.withApollo=function(t,r){void 0===r&&(r={})
var n="withApollo("+function(t){return t.displayName||t.name||"Component"}(t)+")",o=function(o){function i(t){var e=o.call(this,t)||this
return e.setWrappedInstance=e.setWrappedInstance.bind(e),e}return J(i,o),i.prototype.getWrappedInstance=function(){return X(r.withRef,"To access the wrapped instance, you need to specify { withRef: true } in the options"),this.wrappedInstance},i.prototype.setWrappedInstance=function(t){this.wrappedInstance=t},i.prototype.render=function(){var n=this
return e.createElement(c,null,function(o){var i=Object.assign({},n.props,{client:o,ref:r.withRef?n.setWrappedInstance:void 0})
return e.createElement(t,$({},i))})},i.displayName=n,i.WrappedComponent=t,i}(e.Component)
return Z(o,t,{})},t.walkTree=i,Object.defineProperty(t,"__esModule",{value:!0})}(e,r(106),r(107),r(50))},function(t,e){t.exports=require("react")},function(t,e,r){t.exports=r(108)()},function(t,e,r){"use strict"
var n=r(109),o=r(110),i=r(111)
t.exports=function(){function t(t,e,r,n,a,u){u!==i&&o(!1,"Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")}function e(){return t}t.isRequired=t
var r={array:t,bool:t,func:t,number:t,object:t,string:t,symbol:t,any:t,arrayOf:e,element:t,instanceOf:e,node:t,objectOf:e,oneOf:e,oneOfType:e,shape:e,exact:e}
return r.checkPropTypes=n,r.PropTypes=r,r}},function(t,e,r){"use strict"
function n(t){return function(){return t}}var o=function(){}
o.thatReturns=n,o.thatReturnsFalse=n(!1),o.thatReturnsTrue=n(!0),o.thatReturnsNull=n(null),o.thatReturnsThis=function(){return this},o.thatReturnsArgument=function(t){return t},t.exports=o},function(t,e,r){"use strict"
var n=function(t){}
t.exports=function(t,e,r,o,i,a,u,c){if(n(e),!t){var s
if(void 0===e)s=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.")
else{var l=[r,o,i,a,u,c],f=0;(s=new Error(e.replace(/%s/g,function(){return l[f++]}))).name="Invariant Violation"}throw s.framesToPop=1,s}}},function(t,e,r){"use strict"
t.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"},function(t,e,r){"use strict"
Object.defineProperty(e,"__esModule",{value:!0})
var n=function(){function t(t,e){for(var r=0;r<e.length;r++){var n=e[r]
n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,r,n){return r&&t(e.prototype,r),n&&t(e,n),e}}()
function o(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}var i=function(){return"function"==typeof Symbol},a=function(t){return i()&&Boolean(Symbol[t])},u=function(t){return a(t)?Symbol[t]:"@@"+t}
function c(t,e){var r=t[e]
if(null!=r){if("function"!=typeof r)throw new TypeError(r+" is not a function")
return r}}function s(t){var e=t.constructor
return void 0!==e&&null===(e=e[u("species")])&&(e=void 0),void 0!==e?e:_}function l(t){return t instanceof _}function f(t){f.log?f.log(t):setTimeout(function(){throw t})}function p(t){Promise.resolve().then(function(){try{t()}catch(t){f(t)}})}function h(t){var e=t._cleanup
if(void 0!==e&&(t._cleanup=void 0,e))try{if("function"==typeof e)e()
else{var r=c(e,"unsubscribe")
r&&r.call(e)}}catch(t){f(t)}}function d(t){t._observer=void 0,t._queue=void 0,t._state="closed"}function v(t,e,r){t._state="running"
var n=t._observer
try{var o=c(n,e)
switch(e){case"next":o&&o.call(n,r)
break
case"error":if(d(t),!o)throw r
o.call(n,r)
break
case"complete":d(t),o&&o.call(n)}}catch(t){f(t)}"closed"===t._state?h(t):"running"===t._state&&(t._state="ready")}function y(t,e,r){if("closed"!==t._state){if("buffering"!==t._state)return"ready"!==t._state?(t._state="buffering",t._queue=[{type:e,value:r}],void p(function(){return function(t){var e=t._queue
if(e){t._queue=void 0,t._state="ready"
for(var r=0;r<e.length&&(v(t,e[r].type,e[r].value),"closed"!==t._state);++r);}}(t)})):void v(t,e,r)
t._queue.push({type:e,value:r})}}i()&&!a("observable")&&(Symbol.observable=Symbol("observable"))
var b=function(){function t(e,r){o(this,t),this._cleanup=void 0,this._observer=e,this._queue=void 0,this._state="initializing"
var n=new m(this)
try{this._cleanup=r.call(void 0,n)}catch(t){n.error(t)}"initializing"===this._state&&(this._state="ready")}return n(t,[{key:"unsubscribe",value:function(){"closed"!==this._state&&(d(this),h(this))}},{key:"closed",get:function(){return"closed"===this._state}}]),t}(),m=function(){function t(e){o(this,t),this._subscription=e}return n(t,[{key:"next",value:function(t){y(this._subscription,"next",t)}},{key:"error",value:function(t){y(this._subscription,"error",t)}},{key:"complete",value:function(){y(this._subscription,"complete")}},{key:"closed",get:function(){return"closed"===this._subscription._state}}]),t}(),_=e.Observable=function(){function t(e){if(o(this,t),!(this instanceof t))throw new TypeError("Observable cannot be called as a function")
if("function"!=typeof e)throw new TypeError("Observable initializer must be a function")
this._subscriber=e}return n(t,[{key:"subscribe",value:function(t){return"object"==typeof t&&null!==t||(t={next:t,error:arguments[1],complete:arguments[2]}),new b(t,this._subscriber)}},{key:"forEach",value:function(t){var e=this
return new Promise(function(r,n){if("function"==typeof t)var o=e.subscribe({next:function(e){try{t(e,i)}catch(t){n(t),o.unsubscribe()}},error:n,complete:r})
else n(new TypeError(t+" is not a function"))
function i(){o.unsubscribe(),r()}})}},{key:"map",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
return new(s(this))(function(r){return e.subscribe({next:function(e){try{e=t(e)}catch(t){return r.error(t)}r.next(e)},error:function(t){r.error(t)},complete:function(){r.complete()}})})}},{key:"filter",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
return new(s(this))(function(r){return e.subscribe({next:function(e){try{if(!t(e))return}catch(t){return r.error(t)}r.next(e)},error:function(t){r.error(t)},complete:function(){r.complete()}})})}},{key:"reduce",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=s(this),n=arguments.length>1,o=!1,i=arguments[1]
return new r(function(r){return e.subscribe({next:function(e){var a=!o
if(o=!0,!a||n)try{i=t(i,e)}catch(t){return r.error(t)}else i=e},error:function(t){r.error(t)},complete:function(){if(!o&&!n)return r.error(new TypeError("Cannot reduce an empty sequence"))
r.next(i),r.complete()}})})}},{key:"concat",value:function(){for(var t=this,e=arguments.length,r=Array(e),n=0;n<e;n++)r[n]=arguments[n]
var o=s(this)
return new o(function(e){var n=void 0
return function t(i){n=i.subscribe({next:function(t){e.next(t)},error:function(t){e.error(t)},complete:function(){0===r.length?(n=void 0,e.complete()):t(o.from(r.shift()))}})}(t),function(){n&&(n=void 0).unsubscribe()}})}},{key:"flatMap",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=s(this)
return new r(function(n){var o=[],i=e.subscribe({next:function(e){if(t)try{e=t(e)}catch(t){return n.error(t)}var i=r.from(e).subscribe({next:function(t){n.next(t)},error:function(t){n.error(t)},complete:function(){var t=o.indexOf(i)
t>=0&&o.splice(t,1),a()}})
o.push(i)},error:function(t){n.error(t)},complete:function(){a()}})
function a(){i.closed&&0===o.length&&n.complete()}return function(){o.forEach(function(t){return t.unsubscribe()}),i.unsubscribe()}})}},{key:u("observable"),value:function(){return this}}],[{key:"from",value:function(e){var r="function"==typeof this?this:t
if(null==e)throw new TypeError(e+" is not an object")
var n=c(e,u("observable"))
if(n){var o=n.call(e)
if(Object(o)!==o)throw new TypeError(o+" is not an object")
return l(o)&&o.constructor===r?o:new r(function(t){return o.subscribe(t)})}if(a("iterator")&&(n=c(e,u("iterator"))))return new r(function(t){p(function(){if(!t.closed){var r=!0,o=!1,i=void 0
try{for(var a,u=n.call(e)[Symbol.iterator]();!(r=(a=u.next()).done);r=!0){var c=a.value
if(t.next(c),t.closed)return}}catch(t){o=!0,i=t}finally{try{!r&&u.return&&u.return()}finally{if(o)throw i}}t.complete()}})})
if(Array.isArray(e))return new r(function(t){p(function(){if(!t.closed){for(var r=0;r<e.length;++r)if(t.next(e[r]),t.closed)return
t.complete()}})})
throw new TypeError(e+" is not observable")}},{key:"of",value:function(){for(var e=arguments.length,r=Array(e),n=0;n<e;n++)r[n]=arguments[n]
return new("function"==typeof this?this:t)(function(t){p(function(){if(!t.closed){for(var e=0;e<r.length;++e)if(t.next(r[e]),t.closed)return
t.complete()}})})}},{key:u("species"),get:function(){return this}}]),t}()
i()&&Object.defineProperty(_,Symbol("extensions"),{value:{symbol:u("observable"),hostReportError:f},configurabe:!0})},function(t,e,r){"use strict";(function(t,n){Object.defineProperty(e,"__esModule",{value:!0})
var o,i=function(t){return t&&t.__esModule?t:{default:t}}(r(114))
o="undefined"!=typeof self?self:"undefined"!=typeof window?window:void 0!==t?t:n
var a=(0,i.default)(o)
e.default=a}).call(this,r(43),r(44)(t))},function(t,e,r){"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(t){var e,r=t.Symbol
"function"==typeof r?r.observable?e=r.observable:(e=r("observable"),r.observable=e):e="@@observable"
return e}},function(t,e,r){var n=r(116)(!0)
t.exports=n},function(t,e,r){var n=r(26),o=r(117),i=r(48),a=r(49),u=r(32),c=r(145),s="Expected a function",l=8,f=32,p=128,h=256
t.exports=function(t){return o(function(e){var r=e.length,o=r,d=n.prototype.thru
for(t&&e.reverse();o--;){var v=e[o]
if("function"!=typeof v)throw new TypeError(s)
if(d&&!y&&"wrapper"==a(v))var y=new n([],!0)}for(o=y?o:r;++o<r;){v=e[o]
var b=a(v),m="wrapper"==b?i(v):void 0
y=m&&c(m[0])&&m[1]==(p|l|f|h)&&!m[4].length&&1==m[9]?y[a(m[0])].apply(y,m[3]):1==v.length&&c(v)?y[b]():y.thru(v)}return function(){var t=arguments,n=t[0]
if(y&&1==t.length&&u(n))return y.plant(n).value()
for(var o=0,i=r?e[o].apply(this,t):n;++o<r;)i=e[o].call(this,i)
return i}})}},function(t,e,r){var n=r(118),o=r(127),i=r(129)
t.exports=function(t){return i(o(t,void 0,n),t+"")}},function(t,e,r){var n=r(119)
t.exports=function(t){return null!=t&&t.length?n(t,1):[]}},function(t,e,r){var n=r(120),o=r(121)
t.exports=function t(e,r,i,a,u){var c=-1,s=e.length
for(i||(i=o),u||(u=[]);++c<s;){var l=e[c]
r>0&&i(l)?r>1?t(l,r-1,i,a,u):n(u,l):a||(u[u.length]=l)}return u}},function(t,e){t.exports=function(t,e){for(var r=-1,n=e.length,o=t.length;++r<n;)t[o+r]=e[r]
return t}},function(t,e,r){var n=r(29),o=r(123),i=r(32),a=n?n.isConcatSpreadable:void 0
t.exports=function(t){return i(t)||o(t)||!!(a&&t&&t[a])}},function(t,e,r){(function(e){var r="object"==typeof e&&e&&e.Object===Object&&e
t.exports=r}).call(this,r(43))},function(t,e,r){var n=r(124),o=r(31),i=Object.prototype,a=i.hasOwnProperty,u=i.propertyIsEnumerable,c=n(function(){return arguments}())?n:function(t){return o(t)&&a.call(t,"callee")&&!u.call(t,"callee")}
t.exports=c},function(t,e,r){var n=r(46),o=r(31),i="[object Arguments]"
t.exports=function(t){return o(t)&&n(t)==i}},function(t,e,r){var n=r(29),o=Object.prototype,i=o.hasOwnProperty,a=o.toString,u=n?n.toStringTag:void 0
t.exports=function(t){var e=i.call(t,u),r=t[u]
try{t[u]=void 0
var n=!0}catch(t){}var o=a.call(t)
return n&&(e?t[u]=r:delete t[u]),o}},function(t,e){var r=Object.prototype.toString
t.exports=function(t){return r.call(t)}},function(t,e,r){var n=r(128),o=Math.max
t.exports=function(t,e,r){return e=o(void 0===e?t.length-1:e,0),function(){for(var i=arguments,a=-1,u=o(i.length-e,0),c=Array(u);++a<u;)c[a]=i[e+a]
a=-1
for(var s=Array(e+1);++a<e;)s[a]=i[a]
return s[e]=r(c),n(t,this,s)}}},function(t,e){t.exports=function(t,e,r){switch(r.length){case 0:return t.call(e)
case 1:return t.call(e,r[0])
case 2:return t.call(e,r[0],r[1])
case 3:return t.call(e,r[0],r[1],r[2])}return t.apply(e,r)}},function(t,e,r){var n=r(130),o=r(140)(n)
t.exports=o},function(t,e,r){var n=r(131),o=r(132),i=r(139),a=o?function(t,e){return o(t,"toString",{configurable:!0,enumerable:!1,value:n(e),writable:!0})}:i
t.exports=a},function(t,e){t.exports=function(t){return function(){return t}}},function(t,e,r){var n=r(47),o=function(){try{var t=n(Object,"defineProperty")
return t({},"",{}),t}catch(t){}}()
t.exports=o},function(t,e,r){var n=r(134),o=r(135),i=r(27),a=r(137),u=/^\[object .+?Constructor\]$/,c=Function.prototype,s=Object.prototype,l=c.toString,f=s.hasOwnProperty,p=RegExp("^"+l.call(f).replace(/[\\^$.*+?()[\]{}|]/g,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$")
t.exports=function(t){return!(!i(t)||o(t))&&(n(t)?p:u).test(a(t))}},function(t,e,r){var n=r(46),o=r(27),i="[object AsyncFunction]",a="[object Function]",u="[object GeneratorFunction]",c="[object Proxy]"
t.exports=function(t){if(!o(t))return!1
var e=n(t)
return e==a||e==u||e==i||e==c}},function(t,e,r){var n=r(136),o=function(){var t=/[^.]+$/.exec(n&&n.keys&&n.keys.IE_PROTO||"")
return t?"Symbol(src)_1."+t:""}()
t.exports=function(t){return!!o&&o in t}},function(t,e,r){var n=r(30)["__core-js_shared__"]
t.exports=n},function(t,e){var r=Function.prototype.toString
t.exports=function(t){if(null!=t){try{return r.call(t)}catch(t){}try{return t+""}catch(t){}}return""}},function(t,e){t.exports=function(t,e){return null==t?void 0:t[e]}},function(t,e){t.exports=function(t){return t}},function(t,e){var r=800,n=16,o=Date.now
t.exports=function(t){var e=0,i=0
return function(){var a=o(),u=n-(a-i)
if(i=a,u>0){if(++e>=r)return arguments[0]}else e=0
return t.apply(void 0,arguments)}}},function(t,e,r){var n=r(142),o=n&&new n
t.exports=o},function(t,e,r){var n=r(47)(r(30),"WeakMap")
t.exports=n},function(t,e){t.exports=function(){}},function(t,e){t.exports={}},function(t,e,r){var n=r(33),o=r(48),i=r(49),a=r(146)
t.exports=function(t){var e=i(t),r=a[e]
if("function"!=typeof r||!(e in n.prototype))return!1
if(t===r)return!0
var u=o(r)
return!!u&&t===u[0]}},function(t,e,r){var n=r(33),o=r(26),i=r(28),a=r(32),u=r(31),c=r(147),s=Object.prototype.hasOwnProperty
function l(t){if(u(t)&&!a(t)&&!(t instanceof n)){if(t instanceof o)return t
if(s.call(t,"__wrapped__"))return c(t)}return new o(t)}l.prototype=i.prototype,l.prototype.constructor=l,t.exports=l},function(t,e,r){var n=r(33),o=r(26),i=r(148)
t.exports=function(t){if(t instanceof n)return t.clone()
var e=new o(t.__wrapped__,t.__chain__)
return e.__actions__=i(t.__actions__),e.__index__=t.__index__,e.__values__=t.__values__,e}},function(t,e){t.exports=function(t,e){var r=-1,n=t.length
for(e||(e=Array(n));++r<n;)e[r]=t[r]
return e}},function(t,e,r){var n=r(155).parse
function o(t){return t.replace(/[\s,]+/g," ").trim()}var i={},a={}
function u(t){return o(t.source.body.substring(t.start,t.end))}var c=!0
function s(t){var e=o(t)
if(i[e])return i[e]
var r=n(t)
if(!r||"Document"!==r.kind)throw new Error("Not a valid GraphQL document.")
return r=function t(e,r){var n=Object.prototype.toString.call(e)
if("[object Array]"===n)return e.map(function(e){return t(e,r)})
if("[object Object]"!==n)throw new Error("Unexpected input.")
r&&e.loc&&delete e.loc,e.loc&&(delete e.loc.startToken,delete e.loc.endToken)
var o,i,a,u=Object.keys(e)
for(o in u)u.hasOwnProperty(o)&&(i=e[u[o]],"[object Object]"!==(a=Object.prototype.toString.call(i))&&"[object Array]"!==a||(e[u[o]]=t(i,!0)))
return e}(r=function(t){for(var e={},r=[],n=0;n<t.definitions.length;n++){var o=t.definitions[n]
if("FragmentDefinition"===o.kind){var i=o.name.value,s=u(o.loc)
a.hasOwnProperty(i)&&!a[i][s]?(c&&console.warn("Warning: fragment with name "+i+" already exists.\ngraphql-tag enforces all fragment names across your application to be unique; read more about\nthis in the docs: http://dev.apollodata.com/core/fragments.html#unique-names"),a[i][s]=!0):a.hasOwnProperty(i)||(a[i]={},a[i][s]=!0),e[s]||(e[s]=!0,r.push(o))}else r.push(o)}return t.definitions=r,t}(r),!1),i[e]=r,r}function l(){for(var t=Array.prototype.slice.call(arguments),e=t[0],r="string"==typeof e?e:e[0],n=1;n<t.length;n++)t[n]&&t[n].kind&&"Document"===t[n].kind?r+=t[n].loc.source.body:r+=t[n],r+=e[n]
return s(r)}l.default=l,l.resetCaches=function(){i={},a={}},l.disableFragmentWarnings=function(){c=!1},t.exports=l},function(t,e,r){"use strict"
Object.defineProperty(e,"__esModule",{value:!0})
var n=function(){function t(t,e){for(var r=0;r<e.length;r++){var n=e[r]
n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,r,n){return r&&t(e.prototype,r),n&&t(e,n),e}}()
function o(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}var i=function(){return"function"==typeof Symbol},a=function(t){return i()&&Boolean(Symbol[t])},u=function(t){return a(t)?Symbol[t]:"@@"+t}
function c(t,e){var r=t[e]
if(null!=r){if("function"!=typeof r)throw new TypeError(r+" is not a function")
return r}}function s(t){var e=t.constructor
return void 0!==e&&null===(e=e[u("species")])&&(e=void 0),void 0!==e?e:_}function l(t){return t instanceof _}function f(t){f.log?f.log(t):setTimeout(function(){throw t})}function p(t){Promise.resolve().then(function(){try{t()}catch(t){f(t)}})}function h(t){var e=t._cleanup
if(void 0!==e&&(t._cleanup=void 0,e))try{if("function"==typeof e)e()
else{var r=c(e,"unsubscribe")
r&&r.call(e)}}catch(t){f(t)}}function d(t){t._observer=void 0,t._queue=void 0,t._state="closed"}function v(t,e,r){t._state="running"
var n=t._observer
try{var o=c(n,e)
switch(e){case"next":o&&o.call(n,r)
break
case"error":if(d(t),!o)throw r
o.call(n,r)
break
case"complete":d(t),o&&o.call(n)}}catch(t){f(t)}"closed"===t._state?h(t):"running"===t._state&&(t._state="ready")}function y(t,e,r){if("closed"!==t._state){if("buffering"!==t._state)return"ready"!==t._state?(t._state="buffering",t._queue=[{type:e,value:r}],void p(function(){return function(t){var e=t._queue
if(e){t._queue=void 0,t._state="ready"
for(var r=0;r<e.length&&(v(t,e[r].type,e[r].value),"closed"!==t._state);++r);}}(t)})):void v(t,e,r)
t._queue.push({type:e,value:r})}}i()&&!a("observable")&&(Symbol.observable=Symbol("observable"))
var b=function(){function t(e,r){o(this,t),this._cleanup=void 0,this._observer=e,this._queue=void 0,this._state="initializing"
var n=new m(this)
try{this._cleanup=r.call(void 0,n)}catch(t){n.error(t)}"initializing"===this._state&&(this._state="ready")}return n(t,[{key:"unsubscribe",value:function(){"closed"!==this._state&&(d(this),h(this))}},{key:"closed",get:function(){return"closed"===this._state}}]),t}(),m=function(){function t(e){o(this,t),this._subscription=e}return n(t,[{key:"next",value:function(t){y(this._subscription,"next",t)}},{key:"error",value:function(t){y(this._subscription,"error",t)}},{key:"complete",value:function(){y(this._subscription,"complete")}},{key:"closed",get:function(){return"closed"===this._subscription._state}}]),t}(),_=e.Observable=function(){function t(e){if(o(this,t),!(this instanceof t))throw new TypeError("Observable cannot be called as a function")
if("function"!=typeof e)throw new TypeError("Observable initializer must be a function")
this._subscriber=e}return n(t,[{key:"subscribe",value:function(t){return"object"==typeof t&&null!==t||(t={next:t,error:arguments[1],complete:arguments[2]}),new b(t,this._subscriber)}},{key:"forEach",value:function(t){var e=this
return new Promise(function(r,n){if("function"==typeof t)var o=e.subscribe({next:function(e){try{t(e,i)}catch(t){n(t),o.unsubscribe()}},error:n,complete:r})
else n(new TypeError(t+" is not a function"))
function i(){o.unsubscribe(),r()}})}},{key:"map",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
return new(s(this))(function(r){return e.subscribe({next:function(e){try{e=t(e)}catch(t){return r.error(t)}r.next(e)},error:function(t){r.error(t)},complete:function(){r.complete()}})})}},{key:"filter",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
return new(s(this))(function(r){return e.subscribe({next:function(e){try{if(!t(e))return}catch(t){return r.error(t)}r.next(e)},error:function(t){r.error(t)},complete:function(){r.complete()}})})}},{key:"reduce",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=s(this),n=arguments.length>1,o=!1,i=arguments[1]
return new r(function(r){return e.subscribe({next:function(e){var a=!o
if(o=!0,!a||n)try{i=t(i,e)}catch(t){return r.error(t)}else i=e},error:function(t){r.error(t)},complete:function(){if(!o&&!n)return r.error(new TypeError("Cannot reduce an empty sequence"))
r.next(i),r.complete()}})})}},{key:"concat",value:function(){for(var t=this,e=arguments.length,r=Array(e),n=0;n<e;n++)r[n]=arguments[n]
var o=s(this)
return new o(function(e){var n=void 0
return function t(i){n=i.subscribe({next:function(t){e.next(t)},error:function(t){e.error(t)},complete:function(){0===r.length?(n=void 0,e.complete()):t(o.from(r.shift()))}})}(t),function(){n&&(n.unsubscribe(),n=void 0)}})}},{key:"flatMap",value:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=s(this)
return new r(function(n){var o=[],i=e.subscribe({next:function(e){if(t)try{e=t(e)}catch(t){return n.error(t)}var i=r.from(e).subscribe({next:function(t){n.next(t)},error:function(t){n.error(t)},complete:function(){var t=o.indexOf(i)
t>=0&&o.splice(t,1),a()}})
o.push(i)},error:function(t){n.error(t)},complete:function(){a()}})
function a(){i.closed&&0===o.length&&n.complete()}return function(){o.forEach(function(t){return t.unsubscribe()}),i.unsubscribe()}})}},{key:u("observable"),value:function(){return this}}],[{key:"from",value:function(e){var r="function"==typeof this?this:t
if(null==e)throw new TypeError(e+" is not an object")
var n=c(e,u("observable"))
if(n){var o=n.call(e)
if(Object(o)!==o)throw new TypeError(o+" is not an object")
return l(o)&&o.constructor===r?o:new r(function(t){return o.subscribe(t)})}if(a("iterator")&&(n=c(e,u("iterator"))))return new r(function(t){p(function(){if(!t.closed){var r=!0,o=!1,i=void 0
try{for(var a,u=n.call(e)[Symbol.iterator]();!(r=(a=u.next()).done);r=!0){var c=a.value
if(t.next(c),t.closed)return}}catch(t){o=!0,i=t}finally{try{!r&&u.return&&u.return()}finally{if(o)throw i}}t.complete()}})})
if(Array.isArray(e))return new r(function(t){p(function(){if(!t.closed){for(var r=0;r<e.length;++r)if(t.next(e[r]),t.closed)return
t.complete()}})})
throw new TypeError(e+" is not observable")}},{key:"of",value:function(){for(var e=arguments.length,r=Array(e),n=0;n<e;n++)r[n]=arguments[n]
return new("function"==typeof this?this:t)(function(t){p(function(){if(!t.closed){for(var e=0;e<r.length;++e)if(t.next(r[e]),t.closed)return
t.complete()}})})}},{key:u("species"),get:function(){return this}}]),t}()
i()&&Object.defineProperty(_,Symbol("extensions"),{value:{symbol:u("observable"),hostReportError:f},configurabe:!0})},function(t,e,r){t.exports=r(152).Observable},function(t,e,r){"use strict";(function(t){!function(t,e){function r(t){return"function"==typeof Symbol&&Boolean(Symbol[t])}function n(t){return r(t)?Symbol[t]:"@@"+t}function o(t){setTimeout(function(){throw t})}function i(t,e){var r=t[e]
if(null!=r){if("function"!=typeof r)throw new TypeError(r+" is not a function")
return r}}function a(t){var e=t.constructor
return void 0!==e&&null===(e=e[n("species")])&&(e=void 0),void 0!==e?e:p}function u(t,e){Object.keys(e).forEach(function(r){var n=Object.getOwnPropertyDescriptor(e,r)
n.enumerable=!1,Object.defineProperty(t,r,n)})}function c(t){var e=t._cleanup
if(e){t._cleanup=void 0
try{e()}catch(t){o(t)}}}function s(t){return void 0===t._observer}function l(t,e){if(Object(t)!==t)throw new TypeError("Observer must be an object")
this._cleanup=void 0,this._observer=t
try{var r=i(t,"start")
r&&r.call(t,this)}catch(t){o(t)}if(!s(this)){t=new f(this)
try{var n=e.call(void 0,t)
if(null!=n){if("function"==typeof n.unsubscribe)n=function(t){return function(){t.unsubscribe()}}(n)
else if("function"!=typeof n)throw new TypeError(n+" is not a function")
this._cleanup=n}}catch(e){return void t.error(e)}s(this)&&c(this)}}function f(t){this._subscription=t}function p(t){if(!(this instanceof p))throw new TypeError("Observable cannot be called as a function")
if("function"!=typeof t)throw new TypeError("Observable initializer must be a function")
this._subscriber=t}"function"!=typeof Symbol||Symbol.observable||(Symbol.observable=Symbol("observable")),u(l.prototype={},{get closed(){return s(this)},unsubscribe:function(){!function(t){s(t)||(t._observer=void 0,c(t))}(this)}}),u(f.prototype={},{get closed(){return s(this._subscription)},next:function(t){var e=this._subscription
if(!s(e)){var r=e._observer
try{var n=i(r,"next")
n&&n.call(r,t)}catch(t){o(t)}}},error:function(t){var e=this._subscription
if(s(e))o(t)
else{var r=e._observer
e._observer=void 0
try{var n=i(r,"error")
if(!n)throw t
n.call(r,t)}catch(t){o(t)}c(e)}},complete:function(){var t=this._subscription
if(!s(t)){var e=t._observer
t._observer=void 0
try{var r=i(e,"complete")
r&&r.call(e)}catch(t){o(t)}c(t)}}}),u(p.prototype,{subscribe:function(t){for(var e=[],r=1;r<arguments.length;++r)e.push(arguments[r])
return"function"==typeof t?t={next:t,error:e[0],complete:e[1]}:"object"==typeof t&&null!==t||(t={}),new l(t,this._subscriber)},forEach:function(t){var e=this
return new Promise(function(r,n){if("function"!=typeof t)return Promise.reject(new TypeError(t+" is not a function"))
e.subscribe({_subscription:null,start:function(t){if(Object(t)!==t)throw new TypeError(t+" is not an object")
this._subscription=t},next:function(e){var r=this._subscription
if(!r.closed)try{t(e)}catch(t){n(t),r.unsubscribe()}},error:n,complete:r})})},map:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=a(this)
return new r(function(r){return e.subscribe({next:function(e){if(!r.closed){try{e=t(e)}catch(t){return r.error(t)}r.next(e)}},error:function(t){r.error(t)},complete:function(){r.complete()}})})},filter:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=a(this)
return new r(function(r){return e.subscribe({next:function(e){if(!r.closed){try{if(!t(e))return}catch(t){return r.error(t)}r.next(e)}},error:function(t){r.error(t)},complete:function(){r.complete()}})})},reduce:function(t){var e=this
if("function"!=typeof t)throw new TypeError(t+" is not a function")
var r=a(this),n=arguments.length>1,o=!1,i=arguments[1],u=i
return new r(function(r){return e.subscribe({next:function(e){if(!r.closed){var i=!o
if(o=!0,!i||n)try{u=t(u,e)}catch(t){return r.error(t)}else u=e}},error:function(t){r.error(t)},complete:function(){if(!o&&!n)return r.error(new TypeError("Cannot reduce an empty sequence"))
r.next(u),r.complete()}})})}}),Object.defineProperty(p.prototype,n("observable"),{value:function(){return this},writable:!0,configurable:!0}),u(p,{from:function(t){var e="function"==typeof this?this:p
if(null==t)throw new TypeError(t+" is not an object")
var o=i(t,n("observable"))
if(o){var a=o.call(t)
if(Object(a)!==a)throw new TypeError(a+" is not an object")
return a.constructor===e?a:new e(function(t){return a.subscribe(t)})}if(r("iterator")&&(o=i(t,n("iterator"))))return new e(function(e){for(var r,n=o.call(t)[Symbol.iterator]();!(r=n.next()).done;){var i=r.value
if(e.next(i),e.closed)return}e.complete()})
if(Array.isArray(t))return new e(function(e){for(var r=0;r<t.length;++r)if(e.next(t[r]),e.closed)return
e.complete()})
throw new TypeError(t+" is not observable")},of:function(){for(var t=[],e=0;e<arguments.length;++e)t.push(arguments[e])
var r="function"==typeof this?this:p
return new r(function(e){for(var r=0;r<t.length;++r)if(e.next(t[r]),e.closed)return
e.complete()})}}),Object.defineProperty(p,n("species"),{get:function(){return this},configurable:!0}),Object.defineProperty(p,"extensions",{value:{observableSymbol:n("observable"),setHostReportError:function(t){o=t}}}),t.Observable=p}(e)}).call(this,r(44)(t))},function(t,e,r){"use strict"
function n(t,e,r,o){if(function(t){return"IntValue"===t.kind}(r)||function(t){return"FloatValue"===t.kind}(r))t[e.value]=Number(r.value)
else if(function(t){return"BooleanValue"===t.kind}(r)||function(t){return"StringValue"===t.kind}(r))t[e.value]=r.value
else if(function(t){return"ObjectValue"===t.kind}(r)){var i={}
r.fields.map(function(t){return n(i,t.name,t.value,o)}),t[e.value]=i}else if(function(t){return"Variable"===t.kind}(r)){var a=(o||{})[r.name.value]
t[e.value]=a}else if(function(t){return"ListValue"===t.kind}(r))t[e.value]=r.values.map(function(t){var r={}
return n(r,e,t,o),r[e.value]})
else if(function(t){return"EnumValue"===t.kind}(r))t[e.value]=r.value
else{if(!function(t){return"NullValue"===t.kind}(r))throw new Error('The inline argument "'+e.value+'" of kind "'+r.kind+'" is not supported.\n                    Use variables instead of inline arguments to overcome this limitation.')
t[e.value]=null}}r.r(e)
var o=["connection","include","skip","client","rest","export"]
function i(t,e,r){if(r&&r.connection&&r.connection.key){if(r.connection.filter&&r.connection.filter.length>0){var n=r.connection.filter?r.connection.filter:[]
n.sort()
var i=e,a={}
return n.forEach(function(t){a[t]=i[t]}),r.connection.key+"("+JSON.stringify(a)+")"}return r.connection.key}var u=t
if(e){var c=JSON.stringify(e)
u+="("+c+")"}return r&&Object.keys(r).forEach(function(t){-1===o.indexOf(t)&&(r[t]&&Object.keys(r[t]).length?u+="@"+t+"("+JSON.stringify(r[t])+")":u+="@"+t)}),u}function a(t,e){if(t.arguments&&t.arguments.length){var r={}
return t.arguments.forEach(function(t){var o=t.name,i=t.value
return n(r,o,i,e)}),r}return null}function u(t){return t.alias?t.alias.value:t.name.value}function c(t){return"Field"===t.kind}function s(t){return"InlineFragment"===t.kind}function l(t){return t&&"id"===t.type}function f(t,e){if(void 0===e&&(e={}),!t.directives)return!0
var r=!0
return t.directives.forEach(function(t){if("skip"===t.name.value||"include"===t.name.value){var n=t.arguments||[],o=t.name.value
if(1!==n.length)throw new Error("Incorrect number of arguments for the @"+o+" directive.")
var i=n[0]
if(!i.name||"if"!==i.name.value)throw new Error("Invalid argument for the @"+o+" directive.")
var a=n[0].value,u=!1
if(a&&"BooleanValue"===a.kind)u=a.value
else{if("Variable"!==a.kind)throw new Error("Argument for the @"+o+" directive must be a variable or a boolean value.")
if(void 0===(u=e[a.name.value]))throw new Error("Invalid variable referenced in @"+o+" directive.")}"skip"===o&&(u=!u),u||(r=!1)}}),r}new Map
var p=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}
function h(t,e){var r=e,n=[]
if(t.definitions.forEach(function(t){if("OperationDefinition"===t.kind)throw new Error("Found a "+t.operation+" operation"+(t.name?" named '"+t.name.value+"'":"")+". No operations are allowed when using a fragment as a query. Only fragments are allowed.")
"FragmentDefinition"===t.kind&&n.push(t)}),void 0===r){if(1!==n.length)throw new Error("Found "+n.length+" fragments. `fragmentName` must be provided when there is not exactly 1 fragment.")
r=n[0].name.value}return p({},t,{definitions:[{kind:"OperationDefinition",operation:"query",selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:r}}]}}].concat(t.definitions)})}function d(t){for(var e=[],r=1;r<arguments.length;r++)e[r-1]=arguments[r]
return e.forEach(function(e){void 0!==e&&null!==e&&Object.keys(e).forEach(function(r){t[r]=e[r]})}),t}function v(t){if("Document"!==t.kind)throw new Error('Expecting a parsed GraphQL document. Perhaps you need to wrap the query string in a "gql" tag? http://docs.apollostack.com/apollo-client/core.html#gql')
var e=t.definitions.filter(function(t){return"FragmentDefinition"!==t.kind}).map(function(t){if("OperationDefinition"!==t.kind)throw new Error('Schema type definitions not allowed in queries. Found: "'+t.kind+'"')
return t})
if(e.length>1)throw new Error("Ambiguous GraphQL document: contains "+e.length+" operations")}function y(t){return v(t),t.definitions.filter(function(t){return"OperationDefinition"===t.kind})[0]}function b(t){return t.definitions.filter(function(t){return"FragmentDefinition"===t.kind})}function m(t){var e=y(t)
if(!e||"query"!==e.operation)throw new Error("Must contain a query definition.")
return e}function _(t){void 0===t&&(t=[])
var e={}
return t.forEach(function(t){e[t.name.value]=t}),e}function g(t){if(t&&t.variableDefinitions&&t.variableDefinitions.length){var e=t.variableDefinitions.filter(function(t){return t.defaultValue}).map(function(t){var e=t.variable,r=t.defaultValue,o={}
return n(o,e.name,r),o})
return d.apply(void 0,[{}].concat(e))}return{}}function w(t){if(Array.isArray(t))return t.map(function(t){return w(t)})
if(null!==t&&"object"==typeof t){var e={}
for(var r in t)t.hasOwnProperty(r)&&(e[r]=w(t[r]))
return e}return t}var O={kind:"Field",name:{kind:"Name",value:"__typename"}}
var E=new Map
function k(t){v(t)
var e=E.get(t)
if(e)return e
var r=w(t)
return r.definitions.forEach(function(t){var e="OperationDefinition"===t.kind
!function t(e,r){void 0===r&&(r=!1),e.selections&&(r||e.selections.some(function(t){return"Field"===t.kind&&"__typename"===t.name.value})||e.selections.push(O),e.selections.forEach(function(e){"Field"===e.kind?0!==e.name.value.lastIndexOf("__",0)&&e.selectionSet&&t(e.selectionSet):"InlineFragment"===e.kind&&e.selectionSet&&t(e.selectionSet)}))}(t.selectionSet,e)}),E.set(t,r),r}new Map
var x=r(9)
var S=Object.create({})
function j(t){if("number"==typeof t||"boolean"==typeof t||"string"==typeof t||void 0===t||null===t)return null
if(Array.isArray(t))return j(t[0])
var e=[]
return Object.keys(t).forEach(function(r){var n={kind:"Field",name:{kind:"Name",value:r}},o=j(t[r])
o&&(n.selectionSet=o),e.push(n)}),{kind:"SelectionSet",selections:e}}var P,I={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:null,variableDefinitions:null,directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",alias:null,name:{kind:"Name",value:"__typename"},arguments:[],directives:[],selectionSet:null}]}}]},T=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},q=function(){function t(){}return t.prototype.transformDocument=function(t){return t},t.prototype.transformForLink=function(t){return t},t.prototype.readQuery=function(t,e){return void 0===e&&(e=!1),this.read({query:t.query,variables:t.variables,optimistic:e})},t.prototype.readFragment=function(t,e){return void 0===e&&(e=!1),this.read({query:h(t.fragment,t.fragmentName),variables:t.variables,rootId:t.id,optimistic:e})},t.prototype.writeQuery=function(t){this.write({dataId:"ROOT_QUERY",result:t.data,query:t.query,variables:t.variables})},t.prototype.writeFragment=function(t){this.write({dataId:t.id,result:t.data,variables:t.variables,query:h(t.fragment,t.fragmentName)})},t.prototype.writeData=function(t){var e=t.id,r=t.data
if(void 0!==e){var n=null
try{n=this.read({rootId:e,optimistic:!1,query:I})}catch(t){}var o=n&&n.__typename||"__ClientData",i=T({__typename:o},r)
this.writeFragment({id:e,fragment:function(t,e){return{kind:"Document",definitions:[{kind:"FragmentDefinition",typeCondition:{kind:"NamedType",name:{kind:"Name",value:e||"__FakeType"}},name:{kind:"Name",value:"GeneratedClientQuery"},selectionSet:j(t)}]}}(i,o),data:i})}else this.writeQuery({query:function(t){return{kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GeneratedClientQuery"},selectionSet:j(t)}]}}(r),data:r})},t}()
P||(P={})
var N=!1,R=function(){function t(){}return t.prototype.ensureReady=function(){return Promise.resolve()},t.prototype.canBypassInit=function(){return!0},t.prototype.match=function(t,e,r){var n=r.store.get(t.id)
return!!n&&(n.__typename?n.__typename===e||(function(t,e){if(void 0===e&&(e="warn"),!Object(x.b)()&&!S[t])switch(Object(x.c)()||(S[t]=!0),e){case"error":console.error(t)
break
default:console.warn(t)}}("You are using the simple (heuristic) fragment matcher, but your queries contain union or interface types.\n     Apollo Client will not be able to able to accurately map fragments.To make this error go away, use the IntrospectionFragmentMatcher as described in the docs: https://www.apollographql.com/docs/react/recipes/fragment-matching.html","error"),r.returnPartialData=!0,!0):(N||(console.warn("You're using fragments in your queries, but either don't have the addTypename:\n  true option set in Apollo Client, or you are trying to write a fragment to the store without the __typename.\n   Please turn on the addTypename option and include __typename when writing fragments so that Apollo Client\n   can accurately match fragments."),console.warn("Could not find __typename on Fragment ",e,n),console.warn("DEPRECATION WARNING: using fragments without __typename is unsupported behavior and will be removed in future versions of Apollo client. You should fix this and set addTypename to true now."),Object(x.c)()||(N=!0)),r.returnPartialData=!0,!0))},t}(),A=function(){function t(t){t&&t.introspectionQueryResultData?(this.possibleTypesMap=this.parseIntrospectionResult(t.introspectionQueryResultData),this.isReady=!0):this.isReady=!1,this.match=this.match.bind(this)}return t.prototype.match=function(t,e,r){if(!this.isReady)throw new Error("FragmentMatcher.match() was called before FragmentMatcher.init()")
var n=r.store.get(t.id)
if(!n)return!1
if(!n.__typename)throw new Error("Cannot match fragment because __typename property is missing: "+JSON.stringify(n))
if(n.__typename===e)return!0
var o=this.possibleTypesMap[e]
return!!(o&&o.indexOf(n.__typename)>-1)},t.prototype.parseIntrospectionResult=function(t){var e={}
return t.__schema.types.forEach(function(t){"UNION"!==t.kind&&"INTERFACE"!==t.kind||(e[t.name]=t.possibleTypes.map(function(t){return t.name}))}),e},t}(),M=r(0),Q=function(){function t(t){void 0===t&&(t={}),this.data=t}return t.prototype.toObject=function(){return this.data},t.prototype.get=function(t){return this.data[t]},t.prototype.set=function(t,e){this.data[t]=e},t.prototype.delete=function(t){this.data[t]=void 0},t.prototype.clear=function(){this.data={}},t.prototype.replace=function(t){this.data=t||{}},t}()
function D(t){return new Q(t)}var C=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),F=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},L=function(t){function e(){var e=null!==t&&t.apply(this,arguments)||this
return e.type="WriteError",e}return C(e,t),e}(Error)
function V(t,e){var r=new L("Error writing result to store for query:\n "+Object(M.a)(e))
return r.message+="\n"+t.message,r.stack=t.stack,r}function B(t){var e=t.result,r=t.query,n=t.storeFactory,o=void 0===n?D:n,i=t.store,a=void 0===i?o():i,u=t.variables,c=t.dataIdFromObject,s=t.fragmentMap,l=void 0===s?{}:s,f=t.fragmentMatcherFunction,p=m(r)
u=d({},g(p),u)
try{return W({dataId:"ROOT_QUERY",result:e,selectionSet:p.selectionSet,context:{store:a,storeFactory:o,processedData:{},variables:u,dataIdFromObject:c,fragmentMap:l,fragmentMatcherFunction:f}})}catch(t){throw V(t,r)}}function U(t){var e=t.dataId,r=t.result,n=t.document,o=t.storeFactory,i=void 0===o?D:o,a=t.store,u=void 0===a?i():a,c=t.variables,s=t.dataIdFromObject,l=t.fragmentMatcherFunction,f=y(n),p=f.selectionSet,h=_(b(n))
c=d({},g(f),c)
try{return W({result:r,dataId:e,selectionSet:p,context:{store:u,storeFactory:i,processedData:{},variables:c,dataIdFromObject:s,fragmentMap:h,fragmentMatcherFunction:l}})}catch(t){throw V(t,n)}}function W(t){var e=t.result,r=t.dataId,o=t.selectionSet,a=t.context,p=a.variables,h=a.store,d=a.fragmentMap
return o.selections.forEach(function(t){var o=f(t,p)
if(c(t)){var h=u(t),v=e[h]
if(o)if(void 0!==v)!function(t){var e,r,o=t.field,a=t.value,u=t.dataId,c=t.context,s=c.variables,f=c.dataIdFromObject,p=c.store,h=function(t,e){var r=null
t.directives&&(r={},t.directives.forEach(function(t){r[t.name.value]={},t.arguments&&t.arguments.forEach(function(o){var i=o.name,a=o.value
return n(r[t.name.value],i,a,e)})}))
var o=null
return t.arguments&&t.arguments.length&&(o={},t.arguments.forEach(function(t){var r=t.name,i=t.value
return n(o,r,i,e)})),i(t.name.value,o,r)}(o,s),d=!1,v=""
if(o.selectionSet&&null!==a)if(Array.isArray(a)){var y=u+"."+h
e=function t(e,r,n,o){return e.map(function(e,i){if(null===e)return null
var a=r+"."+i
if(Array.isArray(e))return t(e,a,n,o)
var u=!0
if(o.dataIdFromObject){var c=o.dataIdFromObject(e)
c&&(a=c,u=!1)}Y(a,n,o.processedData)||W({dataId:a,result:e,selectionSet:n,context:o})
var s={type:"id",id:a,generated:u}
return s})}(a,y,o.selectionSet,c)}else{var b=u+"."+h,m=!0
if(G(b)||(b="$"+b),f){var _=f(a)
if(_&&G(_))throw new Error('IDs returned by dataIdFromObject cannot begin with the "$" character.')
_&&(b=_,m=!1)}if(Y(b,o,c.processedData)||W({dataId:b,result:a,selectionSet:o.selectionSet,context:c}),e={type:"id",id:b,generated:m},(r=p.get(u))&&r[h]!==e){var g=r[h]
if(l(e)&&e.generated&&l(g)&&!g.generated)throw new Error("Store error: the application attempted to write an object with no provided id but the store already contains an id of "+g.id+" for this object. The selectionSet that was trying to be written is:\n"+Object(M.a)(o))
l(g)&&g.generated&&(v=g.id,d=!0)}}else e=null!=a&&"object"==typeof a?{type:"json",json:a}:a
var w,O=F({},p.get(u),((w={})[h]=e,w))
d&&function t(e,r,n){var o=n.get(e)
var i=n.get(r)
Object.keys(o).forEach(function(a){var u=o[a],c=i[a]
l(u)&&G(u.id)&&l(c)&&t(u.id,c.id,n),n.delete(e),n.set(r,F({},o,i))})}(v,e.id,p);(r=p.get(u))&&e===r[h]||p.set(u,O)}({dataId:r,value:v,field:t,context:a})
else!(t.directives&&t.directives.length&&t.directives.some(function(t){return t.name&&"defer"===t.name.value}))&&a.fragmentMatcherFunction&&(Object(x.b)()||console.warn("Missing field "+h+" in "+JSON.stringify(e,null,2).substring(0,100)))}else{var y=void 0
if(s(t))y=t
else if(!(y=(d||{})[t.name.value]))throw new Error("No fragment named "+t.name.value+".")
var b=!0
if(a.fragmentMatcherFunction&&y.typeCondition){var m={store:new Q({self:e}),returnPartialData:!1,hasMissingField:!1,cacheRedirects:{}}
b=a.fragmentMatcherFunction({type:"id",id:"self",generated:!1},y.typeCondition.name.value,m),!Object(x.b)()&&m.returnPartialData&&console.error("WARNING: heuristic fragment matching going on!")}o&&b&&W({result:e,selectionSet:y.selectionSet,dataId:r,context:a})}}),h}function G(t){return"$"===t[0]}function Y(t,e,r){if(!r)return!1
if(r[t]){if(r[t].indexOf(e)>=0)return!0
r[t].push(e)}else r[t]=[e]
return!1}function K(t,e,r,n,o,i){void 0===i&&(i={})
var a=function(t){var e
v(t)
for(var r=0,n=t.definitions;r<n.length;r++){var o=n[r]
if("OperationDefinition"===o.kind){var i=o.operation
if("query"===i||"mutation"===i||"subscription"===i)return o}"FragmentDefinition"!==o.kind||e||(e=o)}if(e)return e
throw new Error("Expected a parsed GraphQL query with a query, mutation, subscription, or a fragment.")}(e),u={fragmentMap:_(b(e)),contextValue:n,variableValues:o,resultMapper:i.resultMapper,resolver:t,fragmentMatcher:i.fragmentMatcher||function(){return!0}}
return z(a.selectionSet,r,u)}function z(t,e,r){var n=r.fragmentMap,o=r.contextValue,i=r.variableValues,l={}
return t.selections.forEach(function(t){if(f(t,i))if(c(t)){var p=function(t,e,r){var n=r.variableValues,o=r.contextValue,i=r.resolver,c=t.name.value,s=a(t,n),l={isLeaf:!t.selectionSet,resultKey:u(t),directives:function(t,e){if(t.directives&&t.directives.length){var r={}
return t.directives.forEach(function(t){r[t.name.value]=a(t,e)}),r}return null}(t,n)},f=i(c,e,s,o,l)
if(!t.selectionSet)return f
if(null==f)return f
if(Array.isArray(f))return function t(e,r,n){return r.map(function(r){return null===r?null:Array.isArray(r)?t(e,r,n):z(e.selectionSet,r,n)})}(t,f,r)
return z(t.selectionSet,f,r)}(t,e,r),h=u(t)
void 0!==p&&(void 0===l[h]?l[h]=p:H(l[h],p))}else{var d=void 0
if(s(t))d=t
else if(!(d=n[t.name.value]))throw new Error("No fragment named "+t.name.value)
var v=d.typeCondition.name.value
if(r.fragmentMatcher(e,v,o)){var y=z(d.selectionSet,e,r)
H(l,y)}}}),r.resultMapper?r.resultMapper(l,e):l}function H(t,e){if(null===e||"object"!=typeof e)return e
Object.keys(t).forEach(function(r){e.hasOwnProperty(r)&&H(t[r],e[r])}),Object.keys(e).forEach(function(r){t.hasOwnProperty(r)||(t[r]=e[r])})}function J(t){this.message=t,this.stack=""}J.prototype=Error.prototype
var $=K,X=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},Z="undefined"!=typeof Symbol?Symbol("id"):"@@id"
function tt(t){return rt(X({},t,{returnPartialData:!1})).result}var et=function(t,e,r,n,o){var a=o.resultKey,u=o.directives
nt(e)
var c=e.id,s=n.store.get(c),f=i(t,r,u),p=(s||{})[f]
if(void 0===p&&n.cacheRedirects&&s&&(s.__typename||"ROOT_QUERY"===c)){var h=s.__typename||"Query",d=n.cacheRedirects[h]
if(d){var v=d[t]
v&&(p=v(s,r,{getCacheKey:function(t){return function(t,e){return void 0===e&&(e=!1),{type:"id",id:t,generated:e}}(n.dataIdFromObject(t))}}))}}if(void 0===p){if(!n.returnPartialData)throw new Error("Can't find field "+f+" on object ("+c+") "+JSON.stringify(s,null,2)+".")
return n.hasMissingField=!0,p}return function(t){return null!=t&&"object"==typeof t&&"json"===t.type}(p)?e.previousResult&&function t(e,r){if(e===r)return!0
if(e instanceof Date&&r instanceof Date)return e.getTime()===r.getTime()
if(null!=e&&"object"==typeof e&&null!=r&&"object"==typeof r){for(var n in e)if(Object.prototype.hasOwnProperty.call(e,n)){if(!Object.prototype.hasOwnProperty.call(r,n))return!1
if(!t(e[n],r[n]))return!1}for(var n in r)if(!Object.prototype.hasOwnProperty.call(e,n))return!1
return!0}return!1}(e.previousResult[a],p.json)?e.previousResult[a]:p.json:(e.previousResult&&(p=function t(e,r){if(l(e))return X({},e,{previousResult:r})
if(Array.isArray(e)){var n=new Map
return Array.isArray(r)&&r.forEach(function(t){t&&t[Z]&&n.set(t[Z],t)}),e.map(function(e,o){var i=r&&r[o]
return l(e)&&(i=n.get(e.id)||i),t(e,i)})}return e}(p,e.previousResult[a])),p)}
function rt(t){var e=t.store,r=t.query,n=t.variables,o=t.previousResult,i=t.returnPartialData,a=void 0===i||i,u=t.rootId,c=void 0===u?"ROOT_QUERY":u,s=t.fragmentMatcherFunction,l=t.config
n=d({},g(m(r)),n)
var f={store:e,returnPartialData:a,dataIdFromObject:l&&l.dataIdFromObject||null,cacheRedirects:l&&l.cacheRedirects||{},hasMissingField:!1}
return{result:$(et,r,{type:"id",id:c,previousResult:o},f,n,{fragmentMatcher:s,resultMapper:ot}),complete:!f.hasMissingField}}function nt(t){if(!l(t))throw new Error("Encountered a sub-selection on the query, but the store doesn't have an object reference. This should never happen during normal use unless you have custom code that is directly manipulating the store; please file an issue.")}function ot(t,e){if(e.previousResult){var r=Object.keys(t)
if(Object.keys(e.previousResult).reduce(function(t,e){return t&&r.indexOf(e)>-1},!0)&&r.every(function(r){return function t(e,r){if(e===r)return!0
if(!Array.isArray(e)||!Array.isArray(r)||e.length!==r.length)return!1
return e.every(function(e,n){return t(e,r[n])})}(t[r],e.previousResult[r])}))return e.previousResult}return Object.defineProperty(t,Z,{enumerable:!1,configurable:!1,writable:!1,value:e.id}),t}var it=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},at=function(){function t(t){void 0===t&&(t={}),this.data=t,this.recordedData={}}return t.prototype.record=function(t){t(this)
var e=this.recordedData
return this.recordedData={},e},t.prototype.toObject=function(){return it({},this.data,this.recordedData)},t.prototype.get=function(t){return this.recordedData.hasOwnProperty(t)?this.recordedData[t]:this.data[t]},t.prototype.set=function(t,e){this.get(t)!==e&&(this.recordedData[t]=e)},t.prototype.delete=function(t){this.recordedData[t]=void 0},t.prototype.clear=function(){var t=this
Object.keys(this.data).forEach(function(e){return t.delete(e)}),this.recordedData={}},t.prototype.replace=function(t){this.clear(),this.recordedData=it({},t)},t}()
function ut(t,e){return new at(t).record(e)}var ct=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),st=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t},lt={fragmentMatcher:new R,dataIdFromObject:ft,addTypename:!0,storeFactory:D}
function ft(t){if(t.__typename){if(void 0!==t.id)return t.__typename+":"+t.id
if(void 0!==t._id)return t.__typename+":"+t._id}return null}var pt=function(t){function e(e){void 0===e&&(e={})
var r=t.call(this)||this
return r.optimistic=[],r.watches=[],r.silenceBroadcast=!1,r.config=st({},lt,e),r.config.customResolvers&&(console.warn("customResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating customResolvers in the next major version."),r.config.cacheRedirects=r.config.customResolvers),r.config.cacheResolvers&&(console.warn("cacheResolvers have been renamed to cacheRedirects. Please update your config as we will be deprecating cacheResolvers in the next major version."),r.config.cacheRedirects=r.config.cacheResolvers),r.addTypename=r.config.addTypename,r.data=r.config.storeFactory(),r}return ct(e,t),e.prototype.restore=function(t){return t&&this.data.replace(t),this},e.prototype.extract=function(t){if(void 0===t&&(t=!1),t&&this.optimistic.length>0){var e=this.optimistic.map(function(t){return t.data})
return Object.assign.apply(Object,[{},this.data.toObject()].concat(e))}return this.data.toObject()},e.prototype.read=function(t){return t.rootId&&void 0===this.data.get(t.rootId)?null:tt({store:this.config.storeFactory(this.extract(t.optimistic)),query:this.transformDocument(t.query),variables:t.variables,rootId:t.rootId,fragmentMatcherFunction:this.config.fragmentMatcher.match,previousResult:t.previousResult,config:this.config})},e.prototype.write=function(t){U({dataId:t.dataId,result:t.result,variables:t.variables,document:this.transformDocument(t.query),store:this.data,dataIdFromObject:this.config.dataIdFromObject,fragmentMatcherFunction:this.config.fragmentMatcher.match}),this.broadcastWatches()},e.prototype.diff=function(t){return rt({store:this.config.storeFactory(this.extract(t.optimistic)),query:this.transformDocument(t.query),variables:t.variables,returnPartialData:t.returnPartialData,previousResult:t.previousResult,fragmentMatcherFunction:this.config.fragmentMatcher.match,config:this.config})},e.prototype.watch=function(t){var e=this
return this.watches.push(t),function(){e.watches=e.watches.filter(function(e){return e!==t})}},e.prototype.evict=function(t){throw new Error("eviction is not implemented on InMemory Cache")},e.prototype.reset=function(){return this.data.clear(),this.broadcastWatches(),Promise.resolve()},e.prototype.removeOptimistic=function(t){var e=this,r=this.optimistic.filter(function(e){return e.id!==t})
this.optimistic=[],r.forEach(function(t){e.recordOptimisticTransaction(t.transaction,t.id)}),this.broadcastWatches()},e.prototype.performTransaction=function(t){var e=this.silenceBroadcast
this.silenceBroadcast=!0,t(this),e||(this.silenceBroadcast=!1),this.broadcastWatches()},e.prototype.recordOptimisticTransaction=function(t,e){var r=this
this.silenceBroadcast=!0
var n=ut(this.extract(!0),function(e){var n=r.data
r.data=e,r.performTransaction(t),r.data=n})
this.optimistic.push({id:e,transaction:t,data:n}),this.silenceBroadcast=!1,this.broadcastWatches()},e.prototype.transformDocument=function(t){return this.addTypename?k(t):t},e.prototype.readQuery=function(t,e){return void 0===e&&(e=!1),this.read({query:t.query,variables:t.variables,optimistic:e})},e.prototype.readFragment=function(t,e){return void 0===e&&(e=!1),this.read({query:this.transformDocument(h(t.fragment,t.fragmentName)),variables:t.variables,rootId:t.id,optimistic:e})},e.prototype.writeQuery=function(t){this.write({dataId:"ROOT_QUERY",result:t.data,query:this.transformDocument(t.query),variables:t.variables})},e.prototype.writeFragment=function(t){this.write({dataId:t.id,result:t.data,query:this.transformDocument(h(t.fragment,t.fragmentName)),variables:t.variables})},e.prototype.broadcastWatches=function(){var t=this
this.silenceBroadcast||this.watches.forEach(function(e){var r=t.diff({query:e.query,variables:e.variables,previousResult:e.previousResult&&e.previousResult(),optimistic:e.optimistic})
e.callback(r)})},e}(q)
r.d(e,"InMemoryCache",function(){return pt}),r.d(e,"defaultDataIdFromObject",function(){return ft}),r.d(e,"ID_KEY",function(){return Z}),r.d(e,"readQueryFromStore",function(){return tt}),r.d(e,"diffQueryAgainstStore",function(){return rt}),r.d(e,"assertIdValue",function(){return nt}),r.d(e,"WriteError",function(){return L}),r.d(e,"enhanceErrorWithDocument",function(){return V}),r.d(e,"writeQueryToStore",function(){return B}),r.d(e,"writeResultToStore",function(){return U}),r.d(e,"writeSelectionSetToStore",function(){return W}),r.d(e,"HeuristicFragmentMatcher",function(){return R}),r.d(e,"IntrospectionFragmentMatcher",function(){return A}),r.d(e,"ObjectCache",function(){return Q}),r.d(e,"defaultNormalizedCacheFactory",function(){return D}),r.d(e,"RecordingCache",function(){return at}),r.d(e,"record",function(){return ut})},function(t,e,r){"use strict"
r.r(e)
var n=r(17),o=r.n(n),i=o.a,a=r(10),u=r(0),c=function(){var t=function(e,r){return(t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])})(e,r)}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),s=function(){return(s=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)}
var l=function(t){function e(e,r){var n=t.call(this,e)||this
return n.link=r,n}return c(e,t),e}(Error)
function f(t){return t.request.length<=1}function p(t){return new i(function(e){e.error(t)})}function h(t,e){var r=s({},t)
return Object.defineProperty(e,"setContext",{enumerable:!1,value:function(t){r=s({},r,"function"==typeof t?t(r):t)}}),Object.defineProperty(e,"getContext",{enumerable:!1,value:function(){return s({},r)}}),Object.defineProperty(e,"toKey",{enumerable:!1,value:function(){return function(t){return Object(u.a)(t.query)+"|"+JSON.stringify(t.variables)+"|"+t.operationName}(e)}}),e}var d=function(t,e){return e?e(t):i.of()},v=function(t){return"function"==typeof t?new g(t):t},y=function(){return new g(function(t,e){return i.of()})},b=function(t){return 0===t.length?y():t.map(v).reduce(function(t,e){return t.concat(e)})},m=function(t,e,r){void 0===r&&(r=new g(d))
var n=v(e),o=v(r)
return f(n)&&f(o)?new g(function(e){return t(e)?n.request(e)||i.of():o.request(e)||i.of()}):new g(function(e,r){return t(e)?n.request(e,r)||i.of():o.request(e,r)||i.of()})},_=function(t,e){var r=v(t)
if(f(r))return console.warn(new l("You are calling concat on a terminating link, which will have no effect",r)),r
var n=v(e)
return f(n)?new g(function(t){return r.request(t,function(t){return n.request(t)||i.of()})||i.of()}):new g(function(t,e){return r.request(t,function(t){return n.request(t,e)||i.of()})||i.of()})},g=function(){function t(t){t&&(this.request=t)}return t.prototype.split=function(e,r,n){return void 0===n&&(n=new t(d)),this.concat(m(e,r,n))},t.prototype.concat=function(t){return _(this,t)},t.prototype.request=function(t,e){throw new Error("request is not implemented")},t.empty=y,t.from=b,t.split=m,t.execute=w,t}()
function w(t,e){return t.request(h(e.context,function(t){var e={variables:t.variables||{},extensions:t.extensions||{},operationName:t.operationName,query:t.query}
return e.operationName||(e.operationName="string"!=typeof e.query?Object(a.a)(e.query):""),e}(function(t){for(var e=["query","operationName","variables","extensions","context"],r=0,n=Object.keys(t);r<n.length;r++){var o=n[r]
if(e.indexOf(o)<0)throw new Error("illegal argument: "+o)}return t}(e))))||i.of()}var O=function(){return(O=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)},E={http:{includeQuery:!0,includeExtensions:!1},headers:{accept:"*/*","content-type":"application/json"},options:{method:"POST"}},k=function(t,e,r){var n=new Error(r)
throw n.response=t,n.statusCode=t.status,n.result=e,n},x=function(t){return function(e){return e.text().then(function(t){try{return JSON.parse(t)}catch(n){var r=n
return r.response=e,r.statusCode=e.status,r.bodyText=t,Promise.reject(r)}}).then(function(r){return e.status>=300&&k(e,r,"Response not successful: Received status code "+e.status),Array.isArray(r)||r.hasOwnProperty("data")||r.hasOwnProperty("errors")||k(e,r,"Server response was missing for query '"+(Array.isArray(t)?t.map(function(t){return t.operationName}):t.operationName)+"'."),r})}},S=function(t){if(!t&&"undefined"==typeof fetch){var e="unfetch"
throw"undefined"==typeof window&&(e="node-fetch"),new Error("\nfetch is not found globally and no fetcher passed, to fix pass a fetch for\nyour environment like https://www.npmjs.com/package/"+e+".\n\nFor example:\nimport fetch from '"+e+"';\nimport { createHttpLink } from 'apollo-link-http';\n\nconst link = createHttpLink({ uri: '/graphql', fetch: fetch });")}},j=function(){if("undefined"==typeof AbortController)return{controller:!1,signal:!1}
var t=new AbortController
return{controller:t,signal:t.signal}},P=function(t,e){for(var r=[],n=2;n<arguments.length;n++)r[n-2]=arguments[n]
var o=O({},e.options,{headers:e.headers,credentials:e.credentials}),i=e.http
r.forEach(function(t){o=O({},o,t.options,{headers:O({},o.headers,t.headers)}),t.credentials&&(o.credentials=t.credentials),i=O({},i,t.http)})
var a=t.operationName,c=t.extensions,s=t.variables,l=t.query,f={operationName:a,variables:s}
return i.includeExtensions&&(f.extensions=c),i.includeQuery&&(f.query=Object(u.a)(l)),{options:o,body:f}},I=function(t,e){var r
try{r=JSON.stringify(t)}catch(t){var n=new Error("Network request failed. "+e+" is not serializable: "+t.message)
throw n.parseError=t,n}return r},T=function(t,e){var r=t.getContext().uri
return r||("function"==typeof e?e(t):e||"/graphql")},q=o.a,N=function(){var t=function(e,r){return(t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])})(e,r)}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),R=function(){return(R=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)}
var A=function(t){function e(e,r){var n=t.call(this,e)||this
return n.link=r,n}return N(e,t),e}(Error)
function M(t){return t.request.length<=1}function Q(t,e){var r=R({},t)
return Object.defineProperty(e,"setContext",{enumerable:!1,value:function(t){r=R({},r,"function"==typeof t?t(r):t)}}),Object.defineProperty(e,"getContext",{enumerable:!1,value:function(){return R({},r)}}),Object.defineProperty(e,"toKey",{enumerable:!1,value:function(){return function(t){return Object(u.a)(t.query)+"|"+JSON.stringify(t.variables)+"|"+t.operationName}(e)}}),e}var D=function(t,e){return e?e(t):q.of()},C=function(t){return"function"==typeof t?new B(t):t},F=function(){return new B(function(t,e){return q.of()})},L=function(t){return 0===t.length?F():t.map(C).reduce(function(t,e){return t.concat(e)})},V=function(t,e,r){void 0===r&&(r=new B(D))
var n=C(e),o=C(r)
return M(n)&&M(o)?new B(function(e){return t(e)?n.request(e)||q.of():o.request(e)||q.of()}):new B(function(e,r){return t(e)?n.request(e,r)||q.of():o.request(e,r)||q.of()})},B=function(){function t(t){t&&(this.request=t)}return t.prototype.split=function(e,r,n){return void 0===n&&(n=new t(D)),this.concat(V(e,r,n))},t.prototype.concat=function(t){return function(t,e){var r=C(t)
if(M(r))return console.warn(new A("You are calling concat on a terminating link, which will have no effect",r)),r
var n=C(e)
return M(n)?new B(function(t){return r.request(t,function(t){return n.request(t)||q.of()})||q.of()}):new B(function(t,e){return r.request(t,function(t){return n.request(t,e)||q.of()})||q.of()})}(this,t)},t.prototype.request=function(t,e){throw new Error("request is not implemented")},t.empty=F,t.from=L,t.split=V,t.execute=U,t}()
function U(t,e){return t.request(Q(e.context,function(t){var e={variables:t.variables||{},extensions:t.extensions||{},operationName:t.operationName,query:t.query}
return e.operationName||(e.operationName="string"!=typeof e.query?Object(a.a)(e.query):""),e}(function(t){for(var e=["query","operationName","variables","extensions","context"],r=0,n=Object.keys(t);r<n.length;r++){var o=n[r]
if(e.indexOf(o)<0)throw new Error("illegal argument: "+o)}return t}(e))))||q.of()}var W=function(){return(W=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)},G=function(){function t(t){var e=t.batchInterval,r=t.batchMax,n=void 0===r?0:r,o=t.batchHandler,i=t.batchKey,a=void 0===i?function(){return""}:i
this.queuedRequests=new Map,this.batchInterval=e,this.batchMax=n,this.batchHandler=o,this.batchKey=a}return t.prototype.enqueueRequest=function(t){var e=this,r=W({},t),n=!1,o=this.batchKey(t.operation)
return r.observable||(r.observable=new q(function(t){e.queuedRequests.has(o)||e.queuedRequests.set(o,[]),n||(e.queuedRequests.get(o).push(r),n=!0),r.next=r.next||[],t.next&&r.next.push(t.next.bind(t)),r.error=r.error||[],t.error&&r.error.push(t.error.bind(t)),r.complete=r.complete||[],t.complete&&r.complete.push(t.complete.bind(t)),1===e.queuedRequests.get(o).length&&e.scheduleQueueConsumption(o),e.queuedRequests.get(o).length===e.batchMax&&e.consumeQueue(o)})),r.observable},t.prototype.consumeQueue=function(t){void 0===t&&(t="")
var e=this.queuedRequests.get(t)
if(e){this.queuedRequests.delete(t)
var r=e.map(function(t){return t.operation}),n=e.map(function(t){return t.forward}),o=[],i=[],a=[],u=[]
e.forEach(function(t,e){o.push(t.observable),i.push(t.next),a.push(t.error),u.push(t.complete)})
var c=function(t){a.forEach(function(e){e&&e.forEach(function(e){return e(t)})})}
return(this.batchHandler(r,n)||q.of()).subscribe({next:function(t){if(Array.isArray(t)||(t=[t]),i.length!==t.length){var e=new Error("server returned results with length "+t.length+", expected length of "+i.length)
return e.result=t,c(e)}t.forEach(function(t,e){r[e].setContext({response:t}),i[e]&&i[e].forEach(function(e){return e(t)})})},error:c,complete:function(){u.forEach(function(t){t&&t.forEach(function(t){return t()})})}}),o}},t.prototype.scheduleQueueConsumption=function(t){var e=this
void 0===t&&(t=""),setTimeout(function(){e.queuedRequests.get(t)&&e.queuedRequests.get(t).length&&e.consumeQueue(t)},this.batchInterval)},t}(),Y=function(){var t=function(e,r){return(t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])})(e,r)}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),K=function(t){function e(e){void 0===e&&(e={})
var r=t.call(this)||this,n=e.batchInterval,o=void 0===n?10:n,i=e.batchMax,a=void 0===i?0:i,u=e.batchHandler,c=void 0===u?function(){return null}:u,s=e.batchKey,l=void 0===s?function(){return""}:s
return r.batcher=new G({batchInterval:o,batchMax:a,batchHandler:c,batchKey:l}),e.batchHandler.length<=1&&(r.request=function(t){return r.batcher.enqueueRequest({operation:t})}),r}return Y(e,t),e.prototype.request=function(t,e){return this.batcher.enqueueRequest({operation:t,forward:e})},e}(B),z=function(){var t=function(e,r){return(t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])})(e,r)}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),H=function(t,e){var r={}
for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.indexOf(n)<0&&(r[n]=t[n])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols){var o=0
for(n=Object.getOwnPropertySymbols(t);o<n.length;o++)e.indexOf(n[o])<0&&(r[n[o]]=t[n[o]])}return r},J=function(t){function e(e){void 0===e&&(e={})
var r=t.call(this)||this,n=e.uri,o=void 0===n?"/graphql":n,a=e.fetch,u=e.includeExtensions,c=e.batchInterval,s=e.batchMax,l=e.batchKey,f=H(e,["uri","fetch","includeExtensions","batchInterval","batchMax","batchKey"])
S(a),a||(a=fetch)
var h={http:{includeExtensions:u},options:f.fetchOptions,credentials:f.credentials,headers:f.headers}
r.batchInterval=c||10,r.batchMax=s||10
return l=l||function(t){var e=t.getContext(),r={http:e.http,options:e.fetchOptions,credentials:e.credentials,headers:e.headers}
return T(t,o)+JSON.stringify(r)},r.batcher=new K({batchInterval:r.batchInterval,batchMax:r.batchMax,batchKey:l,batchHandler:function(t){var e,r=T(t[0],o),n=t[0].getContext(),u={http:n.http,options:n.fetchOptions,credentials:n.credentials,headers:n.headers},c=t.map(function(t){return P(t,E,h,u)}),s=c.map(function(t){return t.body}),l=c[0].options
if("GET"===l.method)return p(new Error("apollo-link-batch-http does not support GET requests"))
try{l.body=I(s,"Payload")}catch(t){return p(t)}if(!l.signal){var f=j(),d=f.controller,v=f.signal;(e=d)&&(l.signal=v)}return new i(function(n){return a(r,l).then(x(t)).then(function(t){return n.next(t),n.complete(),t}).catch(function(t){"AbortError"!==t.name&&(t.result&&t.result.errors&&t.result.data&&n.next(t.result),n.error(t))}),function(){e&&e.abort()}})}}),r}return z(e,t),e.prototype.request=function(t){return this.batcher.request(t)},e}(g)
r.d(e,"BatchHttpLink",function(){return J})},function(t,e,r){"use strict"
function n(t,e){if(!t)throw new Error(e)}r.r(e)
var o=function t(e,r,o){!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t),this.body=e,this.name=r||"GraphQL request",this.locationOffset=o||{line:1,column:1},this.locationOffset.line>0||n(0,"line in locationOffset is 1-indexed and must be positive"),this.locationOffset.column>0||n(0,"column in locationOffset is 1-indexed and must be positive")}
function i(t,e){for(var r=/\r\n|[\n\r]/g,n=1,o=e+1,i=void 0;(i=r.exec(t.body))&&i.index<e;)n+=1,o=e+1-(i.index+i[0].length)
return{line:n,column:o}}function a(t,e){var r=e.line,n=t.locationOffset.line-1,o=function(t,e){return 1===e.line?t.locationOffset.column-1:0}(t,e),i=r+n,a=e.column+o,s=(i-1).toString(),l=i.toString(),f=(i+1).toString(),p=f.length,h=t.body.split(/\r\n|[\n\r]/g)
return h[0]=u(t.locationOffset.column-1)+h[0],[t.name+" ("+i+":"+a+")",r>=2&&c(p,s)+": "+h[r-2],c(p,l)+": "+h[r-1],u(2+p+a-1)+"^",r<h.length&&c(p,f)+": "+h[r]].filter(Boolean).join("\n")}function u(t){return Array(t+1).join(" ")}function c(t,e){return u(t-e.length)+e}function s(t,e,r,n,o,a,u){var c=Array.isArray(e)?0!==e.length?e:void 0:e?[e]:void 0,l=r
if(!l&&c){var f=c[0]
l=f&&f.loc&&f.loc.source}var p=n
!p&&c&&(p=c.reduce(function(t,e){return e.loc&&t.push(e.loc.start),t},[])),p&&0===p.length&&(p=void 0)
var h=void 0
n&&r?h=n.map(function(t){return i(r,t)}):c&&(h=c.reduce(function(t,e){return e.loc&&t.push(i(e.loc.source,e.loc.start)),t},[])),Object.defineProperties(this,{message:{value:t,enumerable:!0,writable:!0},locations:{value:h||void 0,enumerable:!0},path:{value:o||void 0,enumerable:!0},nodes:{value:c||void 0},source:{value:l||void 0},positions:{value:p||void 0},originalError:{value:a},extensions:{value:u||a&&a.extensions}}),a&&a.stack?Object.defineProperty(this,"stack",{value:a.stack,writable:!0,configurable:!0}):Error.captureStackTrace?Error.captureStackTrace(this,s):Object.defineProperty(this,"stack",{value:Error().stack,writable:!0,configurable:!0})}function l(t,e,r){return new s("Syntax Error: "+r,void 0,t,[e])}s.prototype=Object.create(Error.prototype,{constructor:{value:s},name:{value:"GraphQLError"},toString:{value:function(){return function(t){var e=[]
if(t.nodes)t.nodes.forEach(function(t){t.loc&&e.push(a(t.loc.source,i(t.loc.source,t.loc.start)))})
else if(t.source&&t.locations){var r=t.source
t.locations.forEach(function(t){e.push(a(r,t))})}return 0===e.length?t.message:[t.message].concat(e).join("\n\n")+"\n"}(this)}}})
Object.assign
function f(t){for(var e=t.split(/\r\n|[\n\r]/g),r=null,n=1;n<e.length;n++){var o=e[n],i=p(o)
if(i<o.length&&(null===r||i<r)&&0===(r=i))break}if(r)for(var a=1;a<e.length;a++)e[a]=e[a].slice(r)
for(;e.length>0&&h(e[0]);)e.shift()
for(;e.length>0&&h(e[e.length-1]);)e.pop()
return e.join("\n")}function p(t){for(var e=0;e<t.length&&(" "===t[e]||"\t"===t[e]);)e++
return e}function h(t){return p(t)===t.length}function d(t,e){var r=new w(b.SOF,0,0,0,0,null)
return{source:t,options:e,lastToken:r,token:r,line:1,lineStart:0,advance:v,lookahead:y}}function v(){return this.lastToken=this.token,this.token=this.lookahead()}function y(){var t=this.token
if(t.kind!==b.EOF)do{t=t.next||(t.next=E(this,t))}while(t.kind===b.COMMENT)
return t}var b=Object.freeze({SOF:"<SOF>",EOF:"<EOF>",BANG:"!",DOLLAR:"$",AMP:"&",PAREN_L:"(",PAREN_R:")",SPREAD:"...",COLON:":",EQUALS:"=",AT:"@",BRACKET_L:"[",BRACKET_R:"]",BRACE_L:"{",PIPE:"|",BRACE_R:"}",NAME:"Name",INT:"Int",FLOAT:"Float",STRING:"String",BLOCK_STRING:"BlockString",COMMENT:"Comment"})
function m(t){var e=t.value
return e?t.kind+' "'+e+'"':t.kind}var _=String.prototype.charCodeAt,g=String.prototype.slice
function w(t,e,r,n,o,i,a){this.kind=t,this.start=e,this.end=r,this.line=n,this.column=o,this.value=a,this.prev=i,this.next=null}function O(t){return isNaN(t)?b.EOF:t<127?JSON.stringify(String.fromCharCode(t)):'"\\u'+("00"+t.toString(16).toUpperCase()).slice(-4)+'"'}function E(t,e){var r=t.source,n=r.body,o=n.length,i=function(t,e,r){var n=t.length,o=e
for(;o<n;){var i=_.call(t,o)
if(9===i||32===i||44===i||65279===i)++o
else if(10===i)++o,++r.line,r.lineStart=o
else{if(13!==i)break
10===_.call(t,o+1)?o+=2:++o,++r.line,r.lineStart=o}}return o}(n,e.end,t),a=t.line,u=1+i-t.lineStart
if(i>=o)return new w(b.EOF,o,o,a,u,e)
var c=_.call(n,i)
if(c<32&&9!==c&&10!==c&&13!==c)throw l(r,i,"Cannot contain the invalid character "+O(c)+".")
switch(c){case 33:return new w(b.BANG,i,i+1,a,u,e)
case 35:return function(t,e,r,n,o){var i=t.body,a=void 0,u=e
do{a=_.call(i,++u)}while(null!==a&&(a>31||9===a))
return new w(b.COMMENT,e,u,r,n,o,g.call(i,e+1,u))}(r,i,a,u,e)
case 36:return new w(b.DOLLAR,i,i+1,a,u,e)
case 38:return new w(b.AMP,i,i+1,a,u,e)
case 40:return new w(b.PAREN_L,i,i+1,a,u,e)
case 41:return new w(b.PAREN_R,i,i+1,a,u,e)
case 46:if(46===_.call(n,i+1)&&46===_.call(n,i+2))return new w(b.SPREAD,i,i+3,a,u,e)
break
case 58:return new w(b.COLON,i,i+1,a,u,e)
case 61:return new w(b.EQUALS,i,i+1,a,u,e)
case 64:return new w(b.AT,i,i+1,a,u,e)
case 91:return new w(b.BRACKET_L,i,i+1,a,u,e)
case 93:return new w(b.BRACKET_R,i,i+1,a,u,e)
case 123:return new w(b.BRACE_L,i,i+1,a,u,e)
case 124:return new w(b.PIPE,i,i+1,a,u,e)
case 125:return new w(b.BRACE_R,i,i+1,a,u,e)
case 65:case 66:case 67:case 68:case 69:case 70:case 71:case 72:case 73:case 74:case 75:case 76:case 77:case 78:case 79:case 80:case 81:case 82:case 83:case 84:case 85:case 86:case 87:case 88:case 89:case 90:case 95:case 97:case 98:case 99:case 100:case 101:case 102:case 103:case 104:case 105:case 106:case 107:case 108:case 109:case 110:case 111:case 112:case 113:case 114:case 115:case 116:case 117:case 118:case 119:case 120:case 121:case 122:return function(t,e,r,n,o){var i=t.body,a=i.length,u=e+1,c=0
for(;u!==a&&null!==(c=_.call(i,u))&&(95===c||c>=48&&c<=57||c>=65&&c<=90||c>=97&&c<=122);)++u
return new w(b.NAME,e,u,r,n,o,g.call(i,e,u))}(r,i,a,u,e)
case 45:case 48:case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:return function(t,e,r,n,o,i){var a=t.body,u=r,c=e,s=!1
45===u&&(u=_.call(a,++c))
if(48===u){if((u=_.call(a,++c))>=48&&u<=57)throw l(t,c,"Invalid number, unexpected digit after 0: "+O(u)+".")}else c=k(t,c,u),u=_.call(a,c)
46===u&&(s=!0,u=_.call(a,++c),c=k(t,c,u),u=_.call(a,c))
69!==u&&101!==u||(s=!0,43!==(u=_.call(a,++c))&&45!==u||(u=_.call(a,++c)),c=k(t,c,u))
return new w(s?b.FLOAT:b.INT,e,c,n,o,i,g.call(a,e,c))}(r,i,c,a,u,e)
case 34:return 34===_.call(n,i+1)&&34===_.call(n,i+2)?function(t,e,r,n,o){var i=t.body,a=e+3,u=a,c=0,s=""
for(;a<i.length&&null!==(c=_.call(i,a));){if(34===c&&34===_.call(i,a+1)&&34===_.call(i,a+2))return s+=g.call(i,u,a),new w(b.BLOCK_STRING,e,a+3,r,n,o,f(s))
if(c<32&&9!==c&&10!==c&&13!==c)throw l(t,a,"Invalid character within String: "+O(c)+".")
92===c&&34===_.call(i,a+1)&&34===_.call(i,a+2)&&34===_.call(i,a+3)?(s+=g.call(i,u,a)+'"""',u=a+=4):++a}throw l(t,a,"Unterminated string.")}(r,i,a,u,e):function(t,e,r,n,o){var i=t.body,a=e+1,u=a,c=0,s=""
for(;a<i.length&&null!==(c=_.call(i,a))&&10!==c&&13!==c;){if(34===c)return s+=g.call(i,u,a),new w(b.STRING,e,a+1,r,n,o,s)
if(c<32&&9!==c)throw l(t,a,"Invalid character within String: "+O(c)+".")
if(++a,92===c){switch(s+=g.call(i,u,a-1),c=_.call(i,a)){case 34:s+='"'
break
case 47:s+="/"
break
case 92:s+="\\"
break
case 98:s+="\b"
break
case 102:s+="\f"
break
case 110:s+="\n"
break
case 114:s+="\r"
break
case 116:s+="\t"
break
case 117:var f=x(_.call(i,a+1),_.call(i,a+2),_.call(i,a+3),_.call(i,a+4))
if(f<0)throw l(t,a,"Invalid character escape sequence: \\u"+i.slice(a+1,a+5)+".")
s+=String.fromCharCode(f),a+=4
break
default:throw l(t,a,"Invalid character escape sequence: \\"+String.fromCharCode(c)+".")}u=++a}}throw l(t,a,"Unterminated string.")}(r,i,a,u,e)}throw l(r,i,function(t){if(39===t)return"Unexpected single quote character ('), did you mean to use a double quote (\")?"
return"Cannot parse the unexpected character "+O(t)+"."}(c))}function k(t,e,r){var n=t.body,o=e,i=r
if(i>=48&&i<=57){do{i=_.call(n,++o)}while(i>=48&&i<=57)
return o}throw l(t,o,"Invalid number, expected digit but got: "+O(i)+".")}function x(t,e,r,n){return S(t)<<12|S(e)<<8|S(r)<<4|S(n)}function S(t){return t>=48&&t<=57?t-48:t>=65&&t<=70?t-55:t>=97&&t<=102?t-87:-1}w.prototype.toJSON=w.prototype.inspect=function(){return{kind:this.kind,value:this.value,line:this.line,column:this.column}}
var j=Object.freeze({NAME:"Name",DOCUMENT:"Document",OPERATION_DEFINITION:"OperationDefinition",VARIABLE_DEFINITION:"VariableDefinition",VARIABLE:"Variable",SELECTION_SET:"SelectionSet",FIELD:"Field",ARGUMENT:"Argument",FRAGMENT_SPREAD:"FragmentSpread",INLINE_FRAGMENT:"InlineFragment",FRAGMENT_DEFINITION:"FragmentDefinition",INT:"IntValue",FLOAT:"FloatValue",STRING:"StringValue",BOOLEAN:"BooleanValue",NULL:"NullValue",ENUM:"EnumValue",LIST:"ListValue",OBJECT:"ObjectValue",OBJECT_FIELD:"ObjectField",DIRECTIVE:"Directive",NAMED_TYPE:"NamedType",LIST_TYPE:"ListType",NON_NULL_TYPE:"NonNullType",SCHEMA_DEFINITION:"SchemaDefinition",OPERATION_TYPE_DEFINITION:"OperationTypeDefinition",SCALAR_TYPE_DEFINITION:"ScalarTypeDefinition",OBJECT_TYPE_DEFINITION:"ObjectTypeDefinition",FIELD_DEFINITION:"FieldDefinition",INPUT_VALUE_DEFINITION:"InputValueDefinition",INTERFACE_TYPE_DEFINITION:"InterfaceTypeDefinition",UNION_TYPE_DEFINITION:"UnionTypeDefinition",ENUM_TYPE_DEFINITION:"EnumTypeDefinition",ENUM_VALUE_DEFINITION:"EnumValueDefinition",INPUT_OBJECT_TYPE_DEFINITION:"InputObjectTypeDefinition",SCALAR_TYPE_EXTENSION:"ScalarTypeExtension",OBJECT_TYPE_EXTENSION:"ObjectTypeExtension",INTERFACE_TYPE_EXTENSION:"InterfaceTypeExtension",UNION_TYPE_EXTENSION:"UnionTypeExtension",ENUM_TYPE_EXTENSION:"EnumTypeExtension",INPUT_OBJECT_TYPE_EXTENSION:"InputObjectTypeExtension",DIRECTIVE_DEFINITION:"DirectiveDefinition"}),P=Object.freeze({QUERY:"QUERY",MUTATION:"MUTATION",SUBSCRIPTION:"SUBSCRIPTION",FIELD:"FIELD",FRAGMENT_DEFINITION:"FRAGMENT_DEFINITION",FRAGMENT_SPREAD:"FRAGMENT_SPREAD",INLINE_FRAGMENT:"INLINE_FRAGMENT",SCHEMA:"SCHEMA",SCALAR:"SCALAR",OBJECT:"OBJECT",FIELD_DEFINITION:"FIELD_DEFINITION",ARGUMENT_DEFINITION:"ARGUMENT_DEFINITION",INTERFACE:"INTERFACE",UNION:"UNION",ENUM:"ENUM",ENUM_VALUE:"ENUM_VALUE",INPUT_OBJECT:"INPUT_OBJECT",INPUT_FIELD_DEFINITION:"INPUT_FIELD_DEFINITION"})
function I(t,e){var r="string"==typeof t?new o(t):t
if(!(r instanceof o))throw new TypeError("Must provide Source. Received: "+String(r))
return function(t){var e=t.token
_t(t,b.SOF)
var r=[]
do{r.push(R(t))}while(!mt(t,b.EOF))
return{kind:j.DOCUMENT,definitions:r,loc:vt(t,e)}}(d(r,e||{}))}function T(t,e){var r=d("string"==typeof t?new o(t):t,e||{})
_t(r,b.SOF)
var n=Y(r,!1)
return _t(r,b.EOF),n}function q(t,e){var r=d("string"==typeof t?new o(t):t,e||{})
_t(r,b.SOF)
var n=Z(r)
return _t(r,b.EOF),n}function N(t){var e=_t(t,b.NAME)
return{kind:j.NAME,value:e.value,loc:vt(t,e)}}function R(t){if(bt(t,b.NAME))switch(t.token.value){case"query":case"mutation":case"subscription":case"fragment":return A(t)
case"schema":case"scalar":case"type":case"interface":case"union":case"enum":case"input":case"extend":case"directive":return et(t)}else{if(bt(t,b.BRACE_L))return A(t)
if(rt(t))return et(t)}throw wt(t)}function A(t){if(bt(t,b.NAME))switch(t.token.value){case"query":case"mutation":case"subscription":return M(t)
case"fragment":return function(t){var e=t.token
if(gt(t,"fragment"),t.options.experimentalFragmentVariables)return{kind:j.FRAGMENT_DEFINITION,name:G(t),variableDefinitions:D(t),typeCondition:(gt(t,"on"),tt(t)),directives:$(t,!1),selectionSet:L(t),loc:vt(t,e)}
return{kind:j.FRAGMENT_DEFINITION,name:G(t),typeCondition:(gt(t,"on"),tt(t)),directives:$(t,!1),selectionSet:L(t),loc:vt(t,e)}}(t)}else if(bt(t,b.BRACE_L))return M(t)
throw wt(t)}function M(t){var e=t.token
if(bt(t,b.BRACE_L))return{kind:j.OPERATION_DEFINITION,operation:"query",name:void 0,variableDefinitions:[],directives:[],selectionSet:L(t),loc:vt(t,e)}
var r=Q(t),n=void 0
return bt(t,b.NAME)&&(n=N(t)),{kind:j.OPERATION_DEFINITION,operation:r,name:n,variableDefinitions:D(t),directives:$(t,!1),selectionSet:L(t),loc:vt(t,e)}}function Q(t){var e=_t(t,b.NAME)
switch(e.value){case"query":return"query"
case"mutation":return"mutation"
case"subscription":return"subscription"}throw wt(t,e)}function D(t){return bt(t,b.PAREN_L)?Ot(t,b.PAREN_L,C,b.PAREN_R):[]}function C(t){var e=t.token
return{kind:j.VARIABLE_DEFINITION,variable:F(t),type:(_t(t,b.COLON),Z(t)),defaultValue:mt(t,b.EQUALS)?Y(t,!0):void 0,loc:vt(t,e)}}function F(t){var e=t.token
return _t(t,b.DOLLAR),{kind:j.VARIABLE,name:N(t),loc:vt(t,e)}}function L(t){var e=t.token
return{kind:j.SELECTION_SET,selections:Ot(t,b.BRACE_L,V,b.BRACE_R),loc:vt(t,e)}}function V(t){return bt(t,b.SPREAD)?function(t){var e=t.token
if(_t(t,b.SPREAD),bt(t,b.NAME)&&"on"!==t.token.value)return{kind:j.FRAGMENT_SPREAD,name:G(t),directives:$(t,!1),loc:vt(t,e)}
var r=void 0
"on"===t.token.value&&(t.advance(),r=tt(t))
return{kind:j.INLINE_FRAGMENT,typeCondition:r,directives:$(t,!1),selectionSet:L(t),loc:vt(t,e)}}(t):function(t){var e=t.token,r=N(t),n=void 0,o=void 0
mt(t,b.COLON)?(n=r,o=N(t)):o=r
return{kind:j.FIELD,alias:n,name:o,arguments:B(t,!1),directives:$(t,!1),selectionSet:bt(t,b.BRACE_L)?L(t):void 0,loc:vt(t,e)}}(t)}function B(t,e){var r=e?W:U
return bt(t,b.PAREN_L)?Ot(t,b.PAREN_L,r,b.PAREN_R):[]}function U(t){var e=t.token
return{kind:j.ARGUMENT,name:N(t),value:(_t(t,b.COLON),Y(t,!1)),loc:vt(t,e)}}function W(t){var e=t.token
return{kind:j.ARGUMENT,name:N(t),value:(_t(t,b.COLON),z(t)),loc:vt(t,e)}}function G(t){if("on"===t.token.value)throw wt(t)
return N(t)}function Y(t,e){var r=t.token
switch(r.kind){case b.BRACKET_L:return function(t,e){var r=t.token,n=e?z:H
return{kind:j.LIST,values:function(t,e,r,n){_t(t,e)
var o=[]
for(;!mt(t,n);)o.push(r(t))
return o}(t,b.BRACKET_L,n,b.BRACKET_R),loc:vt(t,r)}}(t,e)
case b.BRACE_L:return function(t,e){var r=t.token
_t(t,b.BRACE_L)
var n=[]
for(;!mt(t,b.BRACE_R);)n.push(J(t,e))
return{kind:j.OBJECT,fields:n,loc:vt(t,r)}}(t,e)
case b.INT:return t.advance(),{kind:j.INT,value:r.value,loc:vt(t,r)}
case b.FLOAT:return t.advance(),{kind:j.FLOAT,value:r.value,loc:vt(t,r)}
case b.STRING:case b.BLOCK_STRING:return K(t)
case b.NAME:return"true"===r.value||"false"===r.value?(t.advance(),{kind:j.BOOLEAN,value:"true"===r.value,loc:vt(t,r)}):"null"===r.value?(t.advance(),{kind:j.NULL,loc:vt(t,r)}):(t.advance(),{kind:j.ENUM,value:r.value,loc:vt(t,r)})
case b.DOLLAR:if(!e)return F(t)}throw wt(t)}function K(t){var e=t.token
return t.advance(),{kind:j.STRING,value:e.value,block:e.kind===b.BLOCK_STRING,loc:vt(t,e)}}function z(t){return Y(t,!0)}function H(t){return Y(t,!1)}function J(t,e){var r=t.token
return{kind:j.OBJECT_FIELD,name:N(t),value:(_t(t,b.COLON),Y(t,e)),loc:vt(t,r)}}function $(t,e){for(var r=[];bt(t,b.AT);)r.push(X(t,e))
return r}function X(t,e){var r=t.token
return _t(t,b.AT),{kind:j.DIRECTIVE,name:N(t),arguments:B(t,e),loc:vt(t,r)}}function Z(t){var e=t.token,r=void 0
return mt(t,b.BRACKET_L)?(r=Z(t),_t(t,b.BRACKET_R),r={kind:j.LIST_TYPE,type:r,loc:vt(t,e)}):r=tt(t),mt(t,b.BANG)?{kind:j.NON_NULL_TYPE,type:r,loc:vt(t,e)}:r}function tt(t){var e=t.token
return{kind:j.NAMED_TYPE,name:N(t),loc:vt(t,e)}}function et(t){var e=rt(t)?t.lookahead():t.token
if(e.kind===b.NAME)switch(e.value){case"schema":return function(t){var e=t.token
gt(t,"schema")
var r=$(t,!0),n=Ot(t,b.BRACE_L,ot,b.BRACE_R)
return{kind:j.SCHEMA_DEFINITION,directives:r,operationTypes:n,loc:vt(t,e)}}(t)
case"scalar":return function(t){var e=t.token,r=nt(t)
gt(t,"scalar")
var n=N(t),o=$(t,!0)
return{kind:j.SCALAR_TYPE_DEFINITION,description:r,name:n,directives:o,loc:vt(t,e)}}(t)
case"type":return function(t){var e=t.token,r=nt(t)
gt(t,"type")
var n=N(t),o=it(t),i=$(t,!0),a=at(t)
return{kind:j.OBJECT_TYPE_DEFINITION,description:r,name:n,interfaces:o,directives:i,fields:a,loc:vt(t,e)}}(t)
case"interface":return function(t){var e=t.token,r=nt(t)
gt(t,"interface")
var n=N(t),o=$(t,!0),i=at(t)
return{kind:j.INTERFACE_TYPE_DEFINITION,description:r,name:n,directives:o,fields:i,loc:vt(t,e)}}(t)
case"union":return function(t){var e=t.token,r=nt(t)
gt(t,"union")
var n=N(t),o=$(t,!0),i=lt(t)
return{kind:j.UNION_TYPE_DEFINITION,description:r,name:n,directives:o,types:i,loc:vt(t,e)}}(t)
case"enum":return function(t){var e=t.token,r=nt(t)
gt(t,"enum")
var n=N(t),o=$(t,!0),i=ft(t)
return{kind:j.ENUM_TYPE_DEFINITION,description:r,name:n,directives:o,values:i,loc:vt(t,e)}}(t)
case"input":return function(t){var e=t.token,r=nt(t)
gt(t,"input")
var n=N(t),o=$(t,!0),i=ht(t)
return{kind:j.INPUT_OBJECT_TYPE_DEFINITION,description:r,name:n,directives:o,fields:i,loc:vt(t,e)}}(t)
case"extend":return function(t){var e=t.lookahead()
if(e.kind===b.NAME)switch(e.value){case"scalar":return function(t){var e=t.token
gt(t,"extend"),gt(t,"scalar")
var r=N(t),n=$(t,!0)
if(0===n.length)throw wt(t)
return{kind:j.SCALAR_TYPE_EXTENSION,name:r,directives:n,loc:vt(t,e)}}(t)
case"type":return function(t){var e=t.token
gt(t,"extend"),gt(t,"type")
var r=N(t),n=it(t),o=$(t,!0),i=at(t)
if(0===n.length&&0===o.length&&0===i.length)throw wt(t)
return{kind:j.OBJECT_TYPE_EXTENSION,name:r,interfaces:n,directives:o,fields:i,loc:vt(t,e)}}(t)
case"interface":return function(t){var e=t.token
gt(t,"extend"),gt(t,"interface")
var r=N(t),n=$(t,!0),o=at(t)
if(0===n.length&&0===o.length)throw wt(t)
return{kind:j.INTERFACE_TYPE_EXTENSION,name:r,directives:n,fields:o,loc:vt(t,e)}}(t)
case"union":return function(t){var e=t.token
gt(t,"extend"),gt(t,"union")
var r=N(t),n=$(t,!0),o=lt(t)
if(0===n.length&&0===o.length)throw wt(t)
return{kind:j.UNION_TYPE_EXTENSION,name:r,directives:n,types:o,loc:vt(t,e)}}(t)
case"enum":return function(t){var e=t.token
gt(t,"extend"),gt(t,"enum")
var r=N(t),n=$(t,!0),o=ft(t)
if(0===n.length&&0===o.length)throw wt(t)
return{kind:j.ENUM_TYPE_EXTENSION,name:r,directives:n,values:o,loc:vt(t,e)}}(t)
case"input":return function(t){var e=t.token
gt(t,"extend"),gt(t,"input")
var r=N(t),n=$(t,!0),o=ht(t)
if(0===n.length&&0===o.length)throw wt(t)
return{kind:j.INPUT_OBJECT_TYPE_EXTENSION,name:r,directives:n,fields:o,loc:vt(t,e)}}(t)}throw wt(t,e)}(t)
case"directive":return function(t){var e=t.token,r=nt(t)
gt(t,"directive"),_t(t,b.AT)
var n=N(t),o=ct(t)
gt(t,"on")
var i=function(t){mt(t,b.PIPE)
var e=[]
do{e.push(dt(t))}while(mt(t,b.PIPE))
return e}(t)
return{kind:j.DIRECTIVE_DEFINITION,description:r,name:n,arguments:o,locations:i,loc:vt(t,e)}}(t)}throw wt(t,e)}function rt(t){return bt(t,b.STRING)||bt(t,b.BLOCK_STRING)}function nt(t){if(rt(t))return K(t)}function ot(t){var e=t.token,r=Q(t)
_t(t,b.COLON)
var n=tt(t)
return{kind:j.OPERATION_TYPE_DEFINITION,operation:r,type:n,loc:vt(t,e)}}function it(t){var e=[]
if("implements"===t.token.value){t.advance(),mt(t,b.AMP)
do{e.push(tt(t))}while(mt(t,b.AMP)||t.options.allowLegacySDLImplementsInterfaces&&bt(t,b.NAME))}return e}function at(t){return t.options.allowLegacySDLEmptyFields&&bt(t,b.BRACE_L)&&t.lookahead().kind===b.BRACE_R?(t.advance(),t.advance(),[]):bt(t,b.BRACE_L)?Ot(t,b.BRACE_L,ut,b.BRACE_R):[]}function ut(t){var e=t.token,r=nt(t),n=N(t),o=ct(t)
_t(t,b.COLON)
var i=Z(t),a=$(t,!0)
return{kind:j.FIELD_DEFINITION,description:r,name:n,arguments:o,type:i,directives:a,loc:vt(t,e)}}function ct(t){return bt(t,b.PAREN_L)?Ot(t,b.PAREN_L,st,b.PAREN_R):[]}function st(t){var e=t.token,r=nt(t),n=N(t)
_t(t,b.COLON)
var o=Z(t),i=void 0
mt(t,b.EQUALS)&&(i=z(t))
var a=$(t,!0)
return{kind:j.INPUT_VALUE_DEFINITION,description:r,name:n,type:o,defaultValue:i,directives:a,loc:vt(t,e)}}function lt(t){var e=[]
if(mt(t,b.EQUALS)){mt(t,b.PIPE)
do{e.push(tt(t))}while(mt(t,b.PIPE))}return e}function ft(t){return bt(t,b.BRACE_L)?Ot(t,b.BRACE_L,pt,b.BRACE_R):[]}function pt(t){var e=t.token,r=nt(t),n=N(t),o=$(t,!0)
return{kind:j.ENUM_VALUE_DEFINITION,description:r,name:n,directives:o,loc:vt(t,e)}}function ht(t){return bt(t,b.BRACE_L)?Ot(t,b.BRACE_L,st,b.BRACE_R):[]}function dt(t){var e=t.token,r=N(t)
if(P.hasOwnProperty(r.value))return r
throw wt(t,e)}function vt(t,e){if(!t.options.noLocation)return new yt(e,t.lastToken,t.source)}function yt(t,e,r){this.start=t.start,this.end=e.end,this.startToken=t,this.endToken=e,this.source=r}function bt(t,e){return t.token.kind===e}function mt(t,e){var r=t.token.kind===e
return r&&t.advance(),r}function _t(t,e){var r=t.token
if(r.kind===e)return t.advance(),r
throw l(t.source,r.start,"Expected "+e+", found "+m(r))}function gt(t,e){var r=t.token
if(r.kind===b.NAME&&r.value===e)return t.advance(),r
throw l(t.source,r.start,'Expected "'+e+'", found '+m(r))}function wt(t,e){var r=e||t.token
return l(t.source,r.start,"Unexpected "+m(r))}function Ot(t,e,r,n){_t(t,e)
for(var o=[r(t)];!mt(t,n);)o.push(r(t))
return o}r.d(e,"parse",function(){return I}),r.d(e,"parseValue",function(){return T}),r.d(e,"parseType",function(){return q}),r.d(e,"parseConstValue",function(){return z}),r.d(e,"parseTypeReference",function(){return Z}),r.d(e,"parseNamedType",function(){return tt}),yt.prototype.toJSON=yt.prototype.inspect=function(){return{start:this.start,end:this.end}}},function(t,e,r){"use strict"
r.r(e)
var n=r(151),o=r(10),i=r(0),a=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),u=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}
var c=function(t){function e(e,r){var n=t.call(this,e)||this
return n.link=r,n}return a(e,t),e}(Error)
function s(t){return t.request.length<=1}function l(t,e){var r=u({},t)
return Object.defineProperty(e,"setContext",{enumerable:!1,value:function(t){r=u({},r,"function"==typeof t?t(r):t)}}),Object.defineProperty(e,"getContext",{enumerable:!1,value:function(){return u({},r)}}),Object.defineProperty(e,"toKey",{enumerable:!1,value:function(){return function(t){return Object(i.a)(t.query)+"|"+JSON.stringify(t.variables)+"|"+t.operationName}(e)}}),e}var f=function(t,e){return e?e(t):n.of()},p=function(t){return"function"==typeof t?new b(t):t},h=function(){return new b(function(t,e){return n.of()})},d=function(t){return 0===t.length?h():t.map(p).reduce(function(t,e){return t.concat(e)})},v=function(t,e,r){void 0===r&&(r=new b(f))
var o=p(e),i=p(r)
return s(o)&&s(i)?new b(function(e){return t(e)?o.request(e)||n.of():i.request(e)||n.of()}):new b(function(e,r){return t(e)?o.request(e,r)||n.of():i.request(e,r)||n.of()})},y=function(t,e){var r=p(t)
if(s(r))return console.warn(new c("You are calling concat on a terminating link, which will have no effect",r)),r
var o=p(e)
return s(o)?new b(function(t){return r.request(t,function(t){return o.request(t)||n.of()})||n.of()}):new b(function(t,e){return r.request(t,function(t){return o.request(t,e)||n.of()})||n.of()})},b=function(){function t(t){t&&(this.request=t)}return t.prototype.split=function(e,r,n){return void 0===n&&(n=new t(f)),this.concat(v(e,r,n))},t.prototype.concat=function(t){return y(this,t)},t.prototype.request=function(t,e){throw new Error("request is not implemented")},t.empty=h,t.from=d,t.split=v,t.execute=m,t}()
function m(t,e){return t.request(l(e.context,function(t){var e={variables:t.variables||{},extensions:t.extensions||{},operationName:t.operationName,query:t.query}
return e.operationName||(e.operationName="string"!=typeof e.query?Object(o.a)(e.query):""),e}(function(t){for(var e=["query","operationName","variables","extensions","context"],r=0,n=Object.keys(t);r<n.length;r++){var o=n[r]
if(e.indexOf(o)<0)throw new Error("illegal argument: "+o)}return t}(e))))||n.of()}r.d(e,"onError",function(){return g}),r.d(e,"ErrorLink",function(){return w})
var _=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),g=function(t){return new b(function(e,r){return new n(function(n){var o
try{o=r(e).subscribe({next:function(r){r.errors&&t({graphQLErrors:r.errors,response:r,operation:e}),n.next(r)},error:function(r){t({operation:e,networkError:r,graphQLErrors:r.result&&r.result.errors}),n.error(r)},complete:n.complete.bind(n)})}catch(r){t({networkError:r,operation:e}),n.error(r)}return function(){o&&o.unsubscribe()}})})},w=function(t){function e(e){var r=t.call(this)||this
return r.link=g(e),r}return _(e,t),e.prototype.request=function(t,e){return this.link.request(t,e)},e}(b)},function(t,e,r){"use strict"
r.r(e)
var n=r(1),o=r(0),i=function(){return(i=Object.assign||function(t){for(var e,r=1,n=arguments.length;r<n;r++)for(var o in e=arguments[r])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)},a={http:{includeQuery:!0,includeExtensions:!1},headers:{accept:"*/*","content-type":"application/json"},options:{method:"POST"}},u=function(t,e,r){var n=new Error(r)
throw n.response=t,n.statusCode=t.status,n.result=e,n},c=function(t,e){var r
try{r=JSON.stringify(t)}catch(t){var n=new Error("Network request failed. "+e+" is not serializable: "+t.message)
throw n.parseError=t,n}return r},s=function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])}
return function(e,r){function n(){this.constructor=e}t(e,r),e.prototype=null===r?Object.create(r):(n.prototype=r.prototype,new n)}}(),l=function(t,e){var r={}
for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.indexOf(n)<0&&(r[n]=t[n])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols){var o=0
for(n=Object.getOwnPropertySymbols(t);o<n.length;o++)e.indexOf(n[o])<0&&(r[n[o]]=t[n[o]])}return r},f=function(t){void 0===t&&(t={})
var e=t.uri,r=void 0===e?"/graphql":e,s=t.fetch,f=t.includeExtensions,p=t.useGETForQueries,h=l(t,["uri","fetch","includeExtensions","useGETForQueries"])
!function(t){if(!t&&"undefined"==typeof fetch){var e="unfetch"
throw"undefined"==typeof window&&(e="node-fetch"),new Error("\nfetch is not found globally and no fetcher passed, to fix pass a fetch for\nyour environment like https://www.npmjs.com/package/"+e+".\n\nFor example:\nimport fetch from '"+e+"';\nimport { createHttpLink } from 'apollo-link-http';\n\nconst link = createHttpLink({ uri: '/graphql', fetch: fetch });")}}(s),s||(s=fetch)
var d={http:{includeExtensions:f},options:h.fetchOptions,credentials:h.credentials,headers:h.headers}
return new n.ApolloLink(function(t){var e=function(t,e){var r=t.getContext().uri
return r||("function"==typeof e?e(t):e||"/graphql")}(t,r),l=t.getContext(),f={http:l.http,options:l.fetchOptions,credentials:l.credentials,headers:l.headers},h=function(t,e){for(var r=[],n=2;n<arguments.length;n++)r[n-2]=arguments[n]
var a=i({},e.options,{headers:e.headers,credentials:e.credentials}),u=e.http
r.forEach(function(t){a=i({},a,t.options,{headers:i({},a.headers,t.headers)}),t.credentials&&(a.credentials=t.credentials),u=i({},u,t.http)})
var c=t.operationName,s=t.extensions,l=t.variables,f=t.query,p={operationName:c,variables:l}
return u.includeExtensions&&(p.extensions=s),u.includeQuery&&(p.query=Object(o.a)(f)),{options:a,body:p}}(t,a,d,f),v=h.options,y=h.body,b=function(){if("undefined"==typeof AbortController)return{controller:!1,signal:!1}
var t=new AbortController
return{controller:t,signal:t.signal}}(),m=b.controller,_=b.signal
m&&(v.signal=_)
if(p&&!t.query.definitions.some(function(t){return"OperationDefinition"===t.kind&&"mutation"===t.operation})&&(v.method="GET"),"GET"===v.method){var g=function(t,e){var r=[],n=function(t,e){r.push(t+"="+encodeURIComponent(e))}
"query"in e&&n("query",e.query)
e.operationName&&n("operationName",e.operationName)
if(e.variables){var o=void 0
try{o=c(e.variables,"Variables map")}catch(t){return{parseError:t}}n("variables",o)}if(e.extensions){var i=void 0
try{i=c(e.extensions,"Extensions map")}catch(t){return{parseError:t}}n("extensions",i)}var a="",u=t,s=t.indexOf("#");-1!==s&&(a=t.substr(s),u=t.substr(0,s))
var l=-1===u.indexOf("?")?"?":"&"
return{newURI:u+l+r.join("&")+a}}(e,y),w=g.newURI,O=g.parseError
if(O)return Object(n.fromError)(O)
e=w}else try{v.body=c(y,"Payload")}catch(O){return Object(n.fromError)(O)}return new n.Observable(function(r){return s(e,v).then(function(e){return t.setContext({response:e}),e}).then(function(t){return function(e){return e.text().then(function(t){try{return JSON.parse(t)}catch(n){var r=n
return r.response=e,r.statusCode=e.status,r.bodyText=t,Promise.reject(r)}}).then(function(r){return e.status>=300&&u(e,r,"Response not successful: Received status code "+e.status),Array.isArray(r)||r.hasOwnProperty("data")||r.hasOwnProperty("errors")||u(e,r,"Server response was missing for query '"+(Array.isArray(t)?t.map(function(t){return t.operationName}):t.operationName)+"'."),r})}}(t)).then(function(t){return r.next(t),r.complete(),t}).catch(function(t){"AbortError"!==t.name&&(t.result&&t.result.errors&&t.result.data&&r.next(t.result),r.error(t))}),function(){m&&m.abort()}})})}
var p=function(t){function e(e){return t.call(this,f(e).request)||this}return s(e,t),e}(n.ApolloLink)
r.d(e,"createHttpLink",function(){return f}),r.d(e,"HttpLink",function(){return p})}])

});
KAdefine("javascript/apollo-package/apollo-fetch.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.default=apolloFetch
exports.apolloMutate=apolloMutate
var _createClient=require("./create-client.js")
var _createClient2=babelHelpers.interopRequireDefault(_createClient)
function apolloFetch(e,t){var a=arguments.length>2&&arguments[2]!==undefined?arguments[2]:"network-only"
var r=arguments[3]
var l=(0,_createClient2.default)(undefined,r)
return l.query({query:e,variables:t,fetchPolicy:a})}function apolloMutate(e,t,a){var r=(0,_createClient2.default)(undefined,a)
return r.mutate({mutation:e,variables:t})}
});
KAdefine("javascript/apollo-package/apollo-wrapper.jsx", function(require, module, exports) {
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactApollo=require("react-apollo")
var _createClient=require("./create-client.js")
var _createClient2=babelHelpers.interopRequireDefault(_createClient)
var ApolloProviderWrapper=function e(r){var a=r.initialState,t=r.module,l=r.children
return React.createElement(_reactApollo.ApolloProvider,{client:(0,_createClient2.default)(a,t)},l)}
module.exports=ApolloProviderWrapper

});
KAdefine("javascript/apollo-package/ka-query.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactApollo=require("react-apollo")
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v1")
var _kaProvider=require("../components/ssr-package/ka-provider.jsx")
var _kaProvider2=babelHelpers.interopRequireDefault(_kaProvider)
var _queryBatchingContext=require("./query-batching-context.js")
var _queryBatchingContext2=babelHelpers.interopRequireDefault(_queryBatchingContext)
var KAQuery=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.renderWithBatchingContext=function e(r){var t=this.props.children
var a=babelHelpers.extends({},this.props,{context:{useBatchingClient:r}})
if(this.props.refetchOnClientSideNav){a=babelHelpers.extends({fetchPolicy:"cache-and-network"},a)}if(this.props.onlyFetchesUserData){a=babelHelpers.extends({ssr:false},a)}if(!a.ssr){var n=function e(){return t({loading:true})}
if(this.props.onlyFetchesUserData){return React.createElement(_kaProvider2.default,{placeholder:n},function(e){return e.getKaid()?React.createElement(_reactApollo.Query,a,t):t({data:{},loading:false})})}else{return React.createElement(_wonderBlocksCoreV.NoSSR,{placeholder:n},function(){return React.createElement(_reactApollo.Query,a,t)})}}else{return React.createElement(_reactApollo.Query,a,t)}}
r.prototype.render=function e(){var r=this
return React.createElement(_queryBatchingContext2.default.Consumer,null,function(e){return r.renderWithBatchingContext(e)})}
return r}(React.Component)
KAQuery.defaultProps={onlyFetchesUserData:false}
exports.default=KAQuery

});
KAdefine("javascript/apollo-package/create-client.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.createInMemoryCache=undefined
exports.default=createClient
exports.installOverrideClient=installOverrideClient
var _khanFetch=require("../shared-package/khan-fetch.js")
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _apolloClient=require("apollo-client")
var _apolloCacheInmemory=require("apollo-cache-inmemory")
var _apolloLink=require("apollo-link")
var _apolloLinkHttp=require("apollo-link-http")
var _apolloLinkBatchHttp=require("apollo-link-batch-http")
var _apolloLinkError=require("apollo-link-error")
var _fragmentTypes=require("../../genfiles/khan-apollo/{{lang}}/fragment-types.js")
var _fragmentTypes2=babelHelpers.interopRequireDefault(_fragmentTypes)
var moduleEndpoints={default:"/api/internal/graphql",vm:"/api/internal/_vm/graphql",multithreaded:"/api/internal/_mt/graphql","content-editing":"/api/internal/_ce/graphql"}
var singletons={default:null,vm:null,multithreaded:null,"content-editing":null}
var _overrideApolloClientSingleton=null
var errorLink=(0,_apolloLinkError.onError)(function(e){var r=e.networkError,n=e.graphQLErrors
if(r){console.log("GraphQL Network Error: ",r)}if(n){console.log("GraphQL Data Error: ",n)}})
var createInMemoryCache=exports.createInMemoryCache=function e(){return new _apolloCacheInmemory.InMemoryCache({fragmentMatcher:new _apolloCacheInmemory.IntrospectionFragmentMatcher({introspectionQueryResultData:_fragmentTypes2.default})})}
function createClient(e,r){if(!r){r="default"}var n=_overrideApolloClientSingleton||singletons[r]
if(!n){var l=moduleEndpoints[r]
if(!l){throw new Error("Unsupported module for GraphQL: "+r)}var t=createInMemoryCache().restore(e||{})
var a=_apolloLink.ApolloLink.split(function(e){var r=e.getContext()
var n=r&&r.useBatchingClient
return _ka2.default.featureFlag("GRAPHQL_BATCH_QUERIES")||n},new _apolloLinkBatchHttp.BatchHttpLink({uri:l,fetch:_khanFetch.khanFetch}),(0,_apolloLinkHttp.createHttpLink)({uri:l,fetch:_khanFetch.khanFetch}))
n=new _apolloClient.ApolloClient({connectToDevTools:true,cache:t,link:errorLink.concat(a)})
singletons[r]=n}return n}function installOverrideClient(e){if(_overrideApolloClientSingleton){console.warn("Installing an override Apollo client when one is already in place.")}_overrideApolloClientSingleton=e
return function(){_overrideApolloClientSingleton=null}}
});
KAdefine("javascript/apollo-package/query-batching-context.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
exports.default=React.createContext(false)

});
KAdefine("genfiles/khan-apollo/en/fragment-types.js", function(require, module, exports) {
module.exports={__schema:{types:[{kind:"INTERFACE",name:"PointContainerInterface",possibleTypes:[{name:"PointsForAccuracyImprovement"},{name:"PointsForChallengeTasks"},{name:"PointsForPassedTasks"},{name:"PointsForStageAcceleration"},{name:"PointsForOnboarding"}]},{kind:"INTERFACE",name:"TaskDescriptor",possibleTypes:[{name:"ExpressDiagnosticTaskDescriptor"},{name:"SkillTaskDescriptor"},{name:"TestTaskDescriptor"},{name:"TmsTaskDescriptor"}]},{kind:"INTERFACE",name:"Task",possibleTypes:[{name:"TmsTask"},{name:"ExpressDiagnosticTask"},{name:"SkillTask"},{name:"TestSectionTask"}]},{kind:"INTERFACE",name:"ContentContainerInterface",possibleTypes:[{name:"Concept"},{name:"Skill"}]},{kind:"UNION",name:"ArticleOrVideoUnion",possibleTypes:[{name:"Video"},{name:"Article"}]},{kind:"INTERFACE",name:"LearnableContent",possibleTypes:[{name:"Video"},{name:"Article"},{name:"TopicQuiz"},{name:"Exercise"},{name:"TopicUnitTest"},{name:"Scratchpad"},{name:"Challenge"},{name:"Interactive"},{name:"Project"},{name:"Talkthrough"}]},{kind:"UNION",name:"TopicChildren",possibleTypes:[{name:"Topic"},{name:"Article"},{name:"Exercise"},{name:"Video"},{name:"Scratchpad"},{name:"Challenge"},{name:"Interactive"},{name:"Project"},{name:"Talkthrough"},{name:"TopicQuiz"},{name:"TopicUnitTest"}]},{kind:"INTERFACE",name:"CurationItemProgress",possibleTypes:[{name:"SubjectProgress"},{name:"UnitProgress"},{name:"DomainProgress"}]},{kind:"INTERFACE",name:"ContentItemProgress",possibleTypes:[{name:"VideoItemProgress"},{name:"ArticleItemProgress"},{name:"ChallengeItemProgress"},{name:"SimpleContentItemProgress"},{name:"ExerciseItemProgress"},{name:"InteractiveItemProgress"},{name:"ProjectItemProgress"},{name:"ScratchpadItemProgress"},{name:"TalkthroughItemProgress"}]},{kind:"INTERFACE",name:"TeacherCampaignStep",possibleTypes:[{name:"TeacherCampaignAwardStep"},{name:"TeacherCampaignInfoStep"},{name:"TeacherCampaignResponseStep"},{name:"TeacherCampaignVideoStep"}]},{kind:"INTERFACE",name:"BaseCampaign",possibleTypes:[{name:"LearnStormCampaign"},{name:"LearnStormEditableCampaign"}]},{kind:"UNION",name:"Campaign",possibleTypes:[{name:"LearnStormCampaign"},{name:"LearnStormEditableCampaign"}]}]}}

});
; KAdefine.updateFilenameRewriteMap({"genfiles/khan-apollo/{{lang}}/fragment-types.js": "../en/fragment-types.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/apollo-package.js.map 