KAdefine("javascript/page-template-package/route-fix-entry.js", function(require, module, exports) {
if(window.location.hash==="#_=_"){if(history.replaceState){history.replaceState(null,"",window.location.href.split("#")[0])}else{window.location.hash=""}}
});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/route-fix-entry-package.js.map 