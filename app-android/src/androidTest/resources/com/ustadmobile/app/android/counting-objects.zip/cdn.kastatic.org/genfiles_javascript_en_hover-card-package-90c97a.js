KAdefine("javascript/hover-card-package/hover-card.js", function(require, module, exports) {
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query getUserHoverCardProfileDeprecated($kaid: String!) {\n        user(kaid: $kaid) {\n            id\n            nickname\n            username\n            bio\n            avatar {\n                imageSrc\n            }\n            points\n            profileRoot\n            publicBadges {\n                description\n                icons {\n                    smallUrl\n                }\n            }\n            isActivityAccessible\n            isPhantom\n            isPublic\n        }\n    }\n"],["\n    query getUserHoverCardProfileDeprecated($kaid: String!) {\n        user(kaid: $kaid) {\n            id\n            nickname\n            username\n            bio\n            avatar {\n                imageSrc\n            }\n            points\n            profileRoot\n            publicBadges {\n                description\n                icons {\n                    smallUrl\n                }\n            }\n            isActivityAccessible\n            isPhantom\n            isPublic\n        }\n    }\n"])
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _apolloFetch2=babelHelpers.interopRequireDefault(_apolloFetch)
var $=require("jquery")
var HoverCardView=require("./hover-card-view.js")
var ProfileModel=require("../shared-package/profile-model.js")
var i18n=require("../shared-package/i18n.js")
var HOVER_CARD_PROFILE_QUERY=(0,_graphqlTag2.default)(_templateObject)
var HoverCard={_link:function e(r,a){if(a!=null&&r.is("a")&&!r.attr("href")){var t="discussion"
if(r.hasClass("profile-programs")){t="projects"}r.attr("href",a+t)}},canFitToRight:function e(r){var a=500
var t=$(window).width()-r.offset().left-r.width()
return t>a},cleanupUserData:function e(r){return babelHelpers.extends({},r,{publicBadges:r.publicBadges||[],points:r.points||i18n._("?")})},createHoverCardQtip:function e(r,a){var t=this
var i=$(r)
var n=i.data("user-kaid")
var o=i.data("has-qtip")
if(!n||o){return Promise.resolve()}var l=false
var s=!HoverCard.canFitToRight(i)
var d=new HoverCardView
var c=d.render().el.innerHTML
if(s){i.data("right-triangle",true)
l={my:"top right",at:"bottom right"}}var p=(0,_apolloFetch2.default)(HOVER_CARD_PROFILE_QUERY,{kaid:n},"cache-first").then(function(e){var r=e.data.user
if(!r){return}r=t.cleanupUserData(r)
var a=r.publicBadges.map(function(e){var r=e.description,a=e.icons.smallUrl
return{description:r,icons:{small:a}}})
var n=babelHelpers.extends({},r,{avatarSrc:r.avatar.imageSrc,publicBadges:a,includesUserDataInfo:true})
HoverCard._onHoverCardDataLoaded(i,n)})
i.data("has-qtip",true)
i.qtip({content:{text:c},style:{classes:"custom-override"},hide:{delay:100,fixed:true},position:a||l||{my:"top left",at:"bottom left"}})
i.qtip("show")
if(s){$(".hover-card-triangle").addClass("right")}return p},_onHoverCardDataLoaded:function e(r,a){var t=new ProfileModel(a)
if(r.attr("href")){t.set({href:r.attr("href")})}if(r.hasClass("profile-programs")){t.set({href:t.get("profileRoot")+"projects"})}var i=new HoverCardView({model:t})
var n=i.render().el.innerHTML
r.qtip("option","content.text",n)
var o=t.get("profileRoot")
HoverCard._link(r,o)
if(r.data("right-triangle")){$(".hover-card-triangle").addClass("right")}}}
module.exports=HoverCard

});
KAdefine("javascript/hover-card-package/hover-card-view.js", function(require, module, exports) {
var Backbone=require("backbone")
var i18n=require("../shared-package/i18n.js")
var HoverCardView=Backbone.View.extend({initialize:function e(i){var t={hideStreak:true}
this._options=babelHelpers.extends({},t,i)
this.template=require("./hover-card.handlebars.js")
if(this.model){this.model.bind("change",this.render.bind(this))}this.render=this.render.bind(this)},render:function e(){var i=this._options
if(this.model){Object.assign(i,this.model.toJSON())
if(this.model.isPhantom()){i["nickname"]=i18n._("Unclaimed points")}if(this.model.isPrivate()){i["isPrivate"]=this.model.isPrivate()}}else{i["messageOnly"]=true}this.$el.html(this.template(i))
if(this.model){this.model.fetchFull()}return this}})
module.exports=HoverCardView

});
KAdefine("javascript/hover-card-package/hover-card.handlebars.js", function(require, module, exports) {
var _handlebars=require("handlebars")
var _handlebars2=babelHelpers.interopRequireDefault(_handlebars)
var i18n=require("../shared-package/i18n.js")
module.exports=_handlebars2.default.compile('<div class="hover-card-container">\n    {{#unless hideTriangle}}\n    <div class="hover-card-triangle"></div>\n    {{/unless}}\n    <div class="hover-card-content-container{{#unless hideShadow}} vertical-shadow{{/unless}}">\n        <div class="hover-card-content clearfix">\n            {{#if messageOnly}}\n                <div class="hover-card-message">\n                    '+i18n._("Finding profile information...")+'\n                </div>\n            {{else}}\n                <div class="user-stats {{#if isPrivate}}private{{/if}}">\n                    <div class="badge-container">\n                        {{#each publicBadges}}\n                            {{#if this}}\n                                {{#with this}}\n                                    <img class="badge-icon" src="{{staticUrl icons.small}}" alt="{{description}}" title="{{description}}">\n                                {{/with}}\n                            {{/if}}\n                        {{/each}}\n                    </div>\n                    <div class="energy-points-badge">\n                        {{#if isSal}}\n                            <span class="infinity-energy-points">\n                                &infin;\n                            </span>\n                        {{else}}\n                            {{commafy points}}\n                        {{/if}}\n                    </div>\n                    {{#unless hideStreak}}\n                    <div class="energy-points-badge"\n                         style="background-color: #e57909; margin-right: 5px;">\n                         {{commafy streakLength}}\n                    </div>\n                    {{/unless}}\n                </div>\n                {{! The "Support/Follow" buttons are rendered inside of the\n                    `.user-actions` container (see follow-list-item.jsx)\n                }}\n                <div class="user-actions"></div>\n                <div class="user-info">\n                    <a class="profile-link" href="{{#if href}}{{href}}{{else}}{{profileRoot}}{{/if}}">\n                        <img src="{{staticUrl avatarSrc}}" class="avatar">\n                        <div class="nickname-container">\n                            <span class="nickname">\n                                {{nickname}}\n                            </span>\n                            <span class="username">\n                                {{usernameFormatted}}\n                            </span>\n                        </div>\n                    </a>\n                    <div class="bio">\n                        {{bio}}\n                    </div>\n                </div>\n            {{/if}}\n        </div>\n    </div>\n</div>')

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/hover-card-package.js.map 