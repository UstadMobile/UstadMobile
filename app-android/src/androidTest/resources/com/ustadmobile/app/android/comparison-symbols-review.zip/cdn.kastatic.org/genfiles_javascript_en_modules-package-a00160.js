KAdefine("javascript/modules-package/module-list.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var React=require("react")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var BigBingo=require("../shared-package/bigbingo.js")
var _require2=require("./content-filters.js"),applyFilterToItem=_require2.applyFilterToItem
var globalStyles=require("../shared-styles-package/global-styles.js")
var _require3=require("./separators.jsx"),Spacer=_require3.Spacer,CompressedSeparator=_require3.CompressedSeparator,Separator=_require3.Separator,NarrowSeparator=_require3.NarrowSeparator
var getSeparator=function e(r,t,n,o){var l=r.kind
var a=t.kind
if(a==="ClassesDashboard"){return React.createElement(Spacer,{key:n})}if(o){return React.createElement(CompressedSeparator,{key:n})}if(l==="PartnershipDescription"||a==="PartnershipDescription"){return null}if(l==="SubjectUpsellShelf"||a==="SubjectUpsellShelf"||l==="KhanKidsUpsell"||a==="KhanKidsUpsell"){return null}if(l==="BrowseProjects"&&a==="BrowseProjects"){return null}if(l==="FloatingSidebar"){return React.createElement("div",{className:"contents_beginSticky",key:n})}if((l==="ContentList"||l==="InterspersedQuiz")&&a!=="ContentList"&&a!=="InterspersedQuiz"){return React.createElement(Separator,{key:n,extraClasses:"contents_endSticky"})}if(l==="PracticeModule"&&a!=="PracticeModule"){return React.createElement(Separator,{key:n,extraClasses:"contents_endSticky"})}if(a==="TabFooter"||a==="PartnershipDescription"||l==="BrowseProjects"||a==="BrowseProjects"){return React.createElement(Separator,{key:n})}if(l==="ConceptTags"||a==="ConceptTags"||l==="BrowseProjects"||a==="BrowseProjects"||l==="ContentCarousel"&&a==="ContentCarousel"||l==="ContentCarousel"&&a==="SubjectIntro"||l==="ContentCarousel"&&a==="SubjectExperienceUpsell"||l==="QuickLinks"&&a==="ContentCarousel"||l==="QuickLinks"&&a==="SubjectIntro"||l==="QuickLinks"&&a==="SubjectExperienceUpsell"||l==="ResearchFeaturedContent"||l==="ResearchPeople"||l==="SubjectIntro"&&a==="ContentCarousel"||l==="SubjectIntro"&&a==="QuickLinks"||l==="SubjectIntro"&&a==="SubjectIntro"||l==="SubjectIntro"&&a==="SubjectExperienceUpsell"||l==="SubjectExperienceUpsell"&&a==="ContentCarousel"||l==="SubjectExperienceUpsell"&&a==="QuickLinks"||l==="SubjectExperienceUpsell"&&a==="SubjectIntro"||l==="SubjectExperienceUpsell"&&a==="SubjectExperienceUpsell"||l==="TableOfContentsRow"&&a==="ContentCarousel"){return React.createElement(NarrowSeparator,{alignment:"center",key:n})}if(a==="ContentList"||a==="InterspersedQuiz"){return React.createElement(NarrowSeparator,{alignment:"right",key:n})}return null}
var getModuleProps=function e(r,t){if(!t){return r}else{return babelHelpers.extends({userInfo:t[r.kind]},r)}}
var ModuleList=function(e){babelHelpers.inherits(r,e)
function r(){var t,n,o
babelHelpers.classCallCheck(this,r)
for(var l=arguments.length,a=Array(l),s=0;s<l;s++){a[s]=arguments[s]}return o=(t=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(a))),n),n.state={contentFilterKey:null},n.handleFilterChange=function(e){if(e!==n.state.contentFilterKey){if(e==="Video"){BigBingo.markConversion("topic_page_filter_video")}else if(e==="Practice"){BigBingo.markConversion("topic_page_filter_practice")}else if(e==="Article"){BigBingo.markConversion("topic_page_filter_article")}else{BigBingo.markConversion("topic_page_filter_all")}n.setState({contentFilterKey:e})}},n.applyFilterToModuleAndProps=function(e,r){var t=n.state.contentFilterKey
if(e.kind==="ContentList"&&t){var o=r.contentItems.filter(function(e){return applyFilterToItem(t,e)})
if(!o.length){return null}else{return babelHelpers.extends({},r,{contentItems:o})}}return r},n.applyInterModuleFilters=function(e,r){var t={}
var o=[]
e.forEach(function(e,l){var a=n.applyFilterToModuleAndProps(e,r[l])
if(a){o.push({module:e,moduleProps:a})}else if(e.kind==="ContentList"){t[r[l].slug]=1}})
var l=n.state.contentFilterKey
if(l){o=o.map(function(e){var r=e.module,n=e.moduleProps
if(r.kind==="FloatingSidebar"){return{module:r,moduleProps:babelHelpers.extends({},n,{links:n.links.filter(function(e){var r=e.slug
return!t[r]})})}}else{return{module:r,moduleProps:n}}})}return o},t),babelHelpers.possibleConstructorReturn(n,o)}r.prototype.render=function e(){var r=this
var t=this.props,n=t.backgroundColor,o=t.moduleComponents,l=t.compact,a=t.domain,s=t.modules,i=t.titleTag,u=t.userInfo,c=t.useOldColors
var p=this.applyInterModuleFilters(s,s.map(function(e){return getModuleProps(e,u)}))
var d={_prevModule:null,moduleList:[]}
var f=function e(t,n,s){var u=n.module,p=n.moduleProps
var d=!!s&&t._prevModule&&getSeparator(t._prevModule,u,"separator"+s,l)
var f=o[u.kind]
var m=React.createElement(f,babelHelpers.extends({},p,{domain:a,key:s,titleTag:i,useOldColors:c,onComponentInteractive:r.props.onComponentInteractive}))
return{_prevModule:u,moduleList:t.moduleList.concat(d||null,m)}}
var m=p.reduce(f,d),S=m.moduleList
return React.createElement("div",{className:css(styles.moduleList),style:{backgroundColor:n||globalStyles.colors.white}},S)}
return r}(React.Component)
ModuleList.defaultProps={compact:false,useOldColors:false}
exports.default=ModuleList
var styles=StyleSheet.create({moduleList:{position:"relative"}})

});
KAdefine("javascript/modules-package/separators.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.Spacer=exports.CompressedSeparator=exports.NarrowSeparator=exports.Separator=undefined
var _mobileOnlySeparator,_narrow
var _react=require("react")
var _react2=babelHelpers.interopRequireDefault(_react)
var _aphrodite=require("aphrodite")
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var Separator=exports.Separator=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=(0,_aphrodite.css)(styles.separator)
if(this.props.extraClasses){r+=" "+this.props.extraClasses}return _react2.default.createElement("div",{className:r,"aria-hidden":true})}
return r}(_react2.default.Component)
var NarrowSeparator=exports.NarrowSeparator=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){return _react2.default.createElement("div",{className:this.props.alignment==="center"?(0,_aphrodite.css)(styles.centered):(0,_aphrodite.css)(styles.right,styles.compress)},_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.separator,styles.narrow),"aria-hidden":true}))}
return r}(_react2.default.Component)
var CompressedSeparator=exports.CompressedSeparator=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){return _react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.compress)})}
return r}(_react2.default.Component)
var Spacer=exports.Spacer=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){return _react2.default.createElement("div",null,_react2.default.createElement("div",{className:(0,_aphrodite.css)(styles.mobileOnlySeparator)}))}
return r}(_react2.default.Component)
var _globalStyles$constan=_globalStyles2.default.constants,moduleHorizontalPadding=_globalStyles$constan.moduleHorizontalPadding,moduleHorizontalPaddingSmall=_globalStyles$constan.moduleHorizontalPaddingSmall,moduleVerticalPaddingCompactModifer=_globalStyles$constan.moduleVerticalPaddingCompactModifer
var styles=_aphrodite.StyleSheet.create({compress:{marginTop:2*moduleVerticalPaddingCompactModifer,position:"relative",top:-moduleVerticalPaddingCompactModifer},separator:{backgroundColor:_globalStyles2.default.colors.gray85,height:1},mobileOnlySeparator:(_mobileOnlySeparator={},_mobileOnlySeparator[_globalStyles2.default.queries.small]={backgroundColor:_globalStyles2.default.colors.gray85,height:1},_mobileOnlySeparator),calloutBottomSpacer:{height:_globalStyles2.default.missionCalloutVerticalPadding},centered:babelHelpers.extends({},_globalStyles2.default.moduleLayout.defaultAlignment),right:babelHelpers.extends({},_globalStyles2.default.moduleLayout.rightAlignment),narrow:(_narrow={marginLeft:moduleHorizontalPadding,marginRight:moduleHorizontalPadding},_narrow[_globalStyles2.default.queries.small]={marginLeft:moduleHorizontalPaddingSmall,marginRight:moduleHorizontalPaddingSmall},_narrow)})

});
KAdefine("javascript/modules-package/content-filters.js", function(require, module, exports) {
var i18n=require("../shared-package/i18n.js")
var FILTER_LABELS={All:i18n._("All types"),Video:i18n._("Videos"),Practice:i18n._("Practice"),Article:i18n._("Articles")}
var FILTERABLE_KINDS=["Video","Exercise","Article","Scratchpad"]
var filterKeyForKind=function e(r){if(r==="Scratchpad"||r==="Exercise"){return"Practice"}return r}
var applyFilterToItem=function e(r,i){if(!r||r==="All"){return true}else if(r==="Practice"){return i.kind==="Exercise"||i.kind==="Scratchpad"}else{return i.kind===r}}
module.exports={FILTER_LABELS:FILTER_LABELS,FILTERABLE_KINDS:FILTERABLE_KINDS,filterKeyForKind:filterKeyForKind,applyFilterToItem:applyFilterToItem}

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/modules-package.js.map 