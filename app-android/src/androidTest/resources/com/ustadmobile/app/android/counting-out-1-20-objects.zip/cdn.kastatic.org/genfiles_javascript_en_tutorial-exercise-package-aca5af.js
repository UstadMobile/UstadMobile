KAdefine("javascript/tutorial-exercise-package/exercise-page.jsx", function(require, module, exports) {
"use strict"
var _sharingFooterWrapper
var _pageloadMarker=require("../analytics-package/pageload-marker.jsx")
var _pageloadMarker2=babelHelpers.interopRequireDefault(_pageloadMarker)
var _staticUrl=require("../shared-package/static-url.js")
var React=require("react")
var PropTypes=require("prop-types")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var Analytics=require("../analytics-package/analytics.js")
var globalStyles=require("../shared-styles-package/global-styles.js")
var mediaQueries=require("../shared-styles-package/media-queries.js")
var ContentPageHeader=require("../tutorial-shared-package/components/content-page-header.jsx")
var KA=require("../shared-package/ka.js")
var StatefulExerciseManagerWrapper=require("../exercises-package/stateful-exercise-manager.jsx")
var SharingFooter=require("../tutorial-shared-package/components/sharing-footer.jsx")
var LibraryExercise=require("../exercises-package/components/library-exercise.jsx")
var ANALYTICS_PAGE_NAME="exercise_page"
var ExercisePage=function(e){babelHelpers.inherits(r,e)
function r(){var t,a,s
babelHelpers.classCallCheck(this,r)
for(var i=arguments.length,o=Array(i),n=0;n<i;n++){o[n]=arguments[n]}return s=(t=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),a),a.state={showConceptHeader:true},a.reportPageUsable=function(){Analytics.reportPageUsableTiming(ANALYTICS_PAGE_NAME)},a.handleComponentRendered=function(e,r){if(r.taskComplete){a.handleTaskComplete()}},a.handleTaskComplete=function(){if(a.props.exercise.isSkillCheck){a.setState({showConceptHeader:false})}},a.resetHeader=function(){a.setState({showConceptHeader:true})},t),babelHelpers.possibleConstructorReturn(a,s)}r.prototype.UNSAFE_componentWillMount=function e(){if(this.props.showTutorialNav!=null){KA.showTutorialNav=this.props.showTutorialNav}if(this.props.inFixture){KA.isBibliotronPage=true}}
r.prototype.componentDidMount=function e(){if(this.props.inFixture){require.dynimport("../../stylesheets/react-datepicker-package/react-datepicker.less")
require.dynimport("../../stylesheets/exercises-package/exercises.less")
require.dynimport("../../stylesheets/katex-package/katex.less")
require.dynimport("../../stylesheets/perseus-renderer-package/perseus-renderer.less")}if(!this.props.inFixture&&KA.isTablet){var r=document.querySelector("#footer")
r.classList.add("web-tablet-exercise-footer")}}
r.prototype.componentWillUnmount=function e(){if(!this.props.inFixture&&KA.isTablet){var r=document.querySelector("#footer")
r.classList.remove("web-tablet-exercise-footer")}}
r.prototype.render=function e(){var r=this
var t=this.props,a=t.breadcrumbs,s=t.domain,i=t.exercise,o=t.initialItem,n=t.initialCards,p=t.mobileTutorialNav,l=t.showEditorShortcuts,c=t.showTutorialNav,u=t.tutorial,d=t.nextTaskKind,g=t.onCheckAnswer,h=t.onNextTask,m=t.onNavigateToParentTopic
var y=(0,_staticUrl.absoluteUrlFromPath)(window.location.pathname)
return React.createElement("div",{className:css(styles.exercisePage)},this.state.showConceptHeader&&React.createElement(ContentPageHeader,{breadcrumbs:a,domain:s,title:i.translatedTitle,hideDescriptionOnMobile:true,showEditorShortcuts:l,editContentUrl:"/devadmin/content/exercises/"+i.slug+"/"+i.id+"/items",editMetadataUrl:"/devadmin/content#"+u.id+"-Exercise:"+i.id,standards:i.standards}),React.createElement("div",{className:css(styles.sharingFooterWrapper)},React.createElement(SharingFooter,{domain:s,title:i.translatedTitle,url:y,contentDescriptor:i.kind+":"+i.id})),React.createElement("div",{className:"bibliotron-exercise task-container",style:{position:"relative"}},React.createElement(StatefulExerciseManagerWrapper,{ExerciseComponent:LibraryExercise,domain:s,topic:u.slug,exerciseName:i.name,initialItem:o,initialCards:n,inPractice:false,exercise:i,nextTaskKind:d(),onCheckAnswer:g,onCloseTask:m,onNextTask:h,onComponentUsable:function e(){return r.reportPageUsable()},onPracticeAgain:function e(){return r.resetHeader()},onRendered:function e(t,a){r.handleComponentRendered(t,a)},onTaskComplete:function e(){return r.handleTaskComplete()}})),c&&p,React.createElement(_pageloadMarker2.default,{key:i.id,pageName:ANALYTICS_PAGE_NAME,markFullyInteractiveOnMount:true,markSufficientlyUsable:"never"}))}
return r}(React.Component)
ExercisePage.propTypes={breadcrumbs:PropTypes.arrayOf(PropTypes.shape({title:PropTypes.string.isRequired,href:PropTypes.string.isRequired})),domain:PropTypes.string.isRequired,exercise:PropTypes.shape({authorList:ContentPageHeader.propTypes.authorList,name:PropTypes.string.isRequired,translatedTitle:PropTypes.string.isRequired,translatedDescription:PropTypes.string,isSkillCheck:PropTypes.bool.isRequired}).isRequired,nextTaskKind:PropTypes.func.isRequired,onCheckAnswer:PropTypes.func,onNavigateToParentTopic:PropTypes.func,onNextTask:PropTypes.func,inFixture:PropTypes.bool,initialCards:PropTypes.any,initialItem:PropTypes.any,mobileTutorialNav:PropTypes.node,showEditorShortcuts:PropTypes.bool,showTutorialNav:PropTypes.bool,tutorial:PropTypes.shape({id:PropTypes.string.isRequired,slug:PropTypes.string.isRequired}).isRequired}
ExercisePage.defaultProps={inFixture:false,showTutorialNav:true}
var styles=StyleSheet.create({exercisePage:{position:"relative"},sharingFooterWrapper:(_sharingFooterWrapper={marginLeft:"auto",marginRight:"auto",paddingTop:16,paddingBottom:16,maxWidth:globalStyles.constants.contentWidth},_sharingFooterWrapper[mediaQueries.smOrSmaller]={paddingLeft:globalStyles.constants.moduleHorizontalPadding,paddingRight:globalStyles.constants.moduleHorizontalPadding},_sharingFooterWrapper)})
module.exports=ExercisePage

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/tutorial-exercise-package.js.map 