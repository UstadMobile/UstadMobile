//tealium universal tag - utag.5 ut4.0.201810151748, Copyright 2018 Tealium.com Inc. All Rights Reserved.
try{(function(id,loader,u){try{u=utag.o[loader].sender[id]={}}catch(e){u=utag.sender[id]};u.ev={'view':1};u.forcessl='no';u.base_url='//dnn506yrbagrg.cloudfront.net/pages/scripts/0026/0255.js';if(u.forcessl=='yes'||location.protocol=='https:'){u.base_url='https://s3.amazonaws.com/new.cetrk.com/pages/scripts/0026/0255.js';}
u.map={};u.extend=[];u.send=function(a,b,c,d,e,f){if(u.ev[a]||typeof u.ev.all!='undefined'){u.head=document.getElementsByTagName('head')[0];u.scr=document.createElement('script');u.scr.src=u.base_url;u.head.appendChild(u.scr);}}
try{utag.o[loader].loader.LOAD(id)}catch(e){utag.loader.LOAD(id)}})('5','bbg.voa-pangea');}catch(e){}
