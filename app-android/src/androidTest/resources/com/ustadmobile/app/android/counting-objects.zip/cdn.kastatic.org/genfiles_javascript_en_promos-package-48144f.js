KAdefine("javascript/promos-package/promos.js", function(require, module, exports) {
var _templateObject=babelHelpers.taggedTemplateLiteralLoose(["\n    query getPromoForUser($promoName: String!) {\n        user {\n            id\n            promotion(promoName: $promoName)\n        }\n    }\n"],["\n    query getPromoForUser($promoName: String!) {\n        user {\n            id\n            promotion(promoName: $promoName)\n        }\n    }\n"])
var _graphqlTag=require("graphql-tag")
var _graphqlTag2=babelHelpers.interopRequireDefault(_graphqlTag)
var _apolloFetch=require("../apollo-package/apollo-fetch.js")
var _apolloFetch2=babelHelpers.interopRequireDefault(_apolloFetch)
var _require=require("../shared-package/khan-fetch.js"),khanFetch=_require.khanFetch
var Promos={}
Promos.cache_={}
var HAS_USER_SEEN_PROMO_QUERY=(0,_graphqlTag2.default)(_templateObject)
Promos.hasUserSeen=function(e,r,o,a){if(e in Promos.cache_){r.call(o,Promos.cache_[e])
return}var t={promoName:e};(0,_apolloFetch2.default)(HAS_USER_SEEN_PROMO_QUERY,t).then(function(a){var t=a.data.user.promotion
t=t||!!Promos.cache_[e]
Promos.cache_[e]=t
r.call(o,t)}).catch(function(t){var n=a==null?true:a
if(e in Promos.cache_){n=Promos.cache_[e]}r.call(o,n)})}
Promos.markAsSeen=function(e){Promos.cache_[e]=true
return khanFetch("/api/internal/user/promo/"+encodeURIComponent(e),{method:"POST"})}
module.exports=Promos

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/promos-package.js.map 