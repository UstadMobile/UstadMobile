KAdefine("javascript/components/tooltip-package/tooltip.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.TooltipInner=undefined
var _fullWidthWrapperOnPh
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _reactDom=require("react-dom")
var _reactDom2=babelHelpers.interopRequireDefault(_reactDom)
var _aphrodite=require("aphrodite")
var _icon=require("../../shared-styles-package/icon.jsx")
var _icon2=babelHelpers.interopRequireDefault(_icon)
var _khanFetch=require("../../shared-package/khan-fetch.js")
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v1")
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _constants=require("../../shared-styles-package/constants.js")
var _constants2=babelHelpers.interopRequireDefault(_constants)
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var closeIcon="\nM6.26353762,4.99851587 L9.73097464,1.53107884 C10.0836373,1.17841618\n10.0842213,0.612127047 9.73530496,0.263210718 C9.38395604,-0.0881381913\n8.81874474,-0.0837668714 8.46743686,0.267541014 L4.99999981,3.73497806\nL1.5325628,0.267541051 C1.1812549,-0.0837668481 0.616043606,\n-0.0881381955 0.264694717,0.263210694 C-0.0842215912,0.612127004\n-0.0836375768,1.17841613 0.269025093,1.5310788 L3.73646206,4.9985158\nL0.269025109,8.46595276 C-0.083637537,8.81861541 -0.0842215923,\n9.38490462 0.264694642,9.73382106 C0.616043456,10.0851701 1.18125469,\n10.0807988 1.53256259,9.72949093 L4.99999988,6.26205363 L8.46743739,\n9.72949117 C8.8187453,10.0807991 9.38395655,10.0851704 9.73530537,\n9.73382138 C10.0842216,9.38490498 10.0836375,8.81861579 9.73097488,\n8.46595313 L6.26353762,4.99851587 Z\n"
var arrowWidth=18
var arrowHeight=9
var defaultHorizontalPadding=23
var dropShadowXOffset=0
var dropShadowYOffset=1
var dropShadowOpacity=.1
var dropShadowRadius=4
var Triangle=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype._renderTriangle=function e(t){var o=this.props,i=o.width,n=o.height,r=o.side,s=o.backgroundColor,a=o.horizontalShift,l=o.horizontalAlignment
var p=""
var h={}
if(r==="top"){p="0,0 "+i/2+","+n+" "+i+",0"}else if(r==="right"){p=n+",0 0,"+i/2+" "+n+","+i}else if(r==="bottom"){p="0,"+n+" "+i/2+",0 "+i+","+n}else if(r==="left"){p="0,0 "+n+","+i/2+" 0,"+i}if(r==="top"||r==="bottom"){if(l==="left"){h.left="calc("+(i-a)+"px)"}else if(l==="center"){h.left="calc(50% - "+a+"px)"}else{h.left="calc(100% - "+(i+a)+"px)"}}return React.createElement("svg",{width:["left","right"].indexOf(r)===-1?i:n,height:["left","right"].indexOf(r)===-1?n:i,className:(0,_aphrodite.css)(triangleStyles.common,triangleStyles[r]),style:h},React.createElement("filter",{id:t.get("dropshadow"),height:"150%"},React.createElement("feOffset",{dx:dropShadowXOffset,dy:dropShadowYOffset,result:"offsetblur"}),React.createElement("feGaussianBlur",{in:"SourceAlpha",stdDeviation:dropShadowRadius/2}),React.createElement("feComponentTransfer",null,React.createElement("feFuncA",{type:"linear",slope:dropShadowOpacity})),React.createElement("feMerge",null,React.createElement("feMergeNode",null),React.createElement("feMergeNode",{in:"SourceGraphic"}))),React.createElement("polyline",{fill:s,stroke:s,points:p}),React.createElement("polyline",{fill:s,points:p,stroke:"rgba(0, 0, 0, 0.1)",filter:"url(#"+t.get("dropshadow")}))}
t.prototype.render=function e(){var t=this
return React.createElement(_wonderBlocksCoreV.UniqueIDProvider,{scope:"triangle"},function(e){return t._renderTriangle(e)})}
return t}(React.Component)
var triangleStyles=_aphrodite.StyleSheet.create({common:{position:"absolute"},top:{bottom:-arrowHeight,transform:"translateX(-50%)"},right:{top:"50%",transform:"translateY(-50%)",left:-arrowHeight},bottom:{top:-arrowHeight,transform:"translateX(-50%)"},left:{top:"50%",transform:"translateY(-50%)",right:-arrowHeight}})
var TooltipInner=exports.TooltipInner=function(e){babelHelpers.inherits(t,e)
function t(){var o,i,n
babelHelpers.classCallCheck(this,t)
for(var r=arguments.length,s=Array(r),a=0;a<r;a++){s[a]=arguments[a]}return n=(o=(i=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),i),i.state={fadeOut:false},o),babelHelpers.possibleConstructorReturn(i,n)}t.prototype.componentDidMount=function e(){var t=this
this._mounted=true
if(this.props.autoDismissTimeout){setTimeout(function(){t.setState({fadeOut:true},function(){var e=t.props.onClose
if(e){setTimeout(function(){if(t._mounted){e()}},200)}})},this.props.autoDismissTimeout)}}
t.prototype.componentWillUnmount=function e(){this._mounted=false}
t.prototype._getTransformForHorizontalAlignment=function e(){var t=this.props.horizontalAlignment
if(t==="left"){return"translateX(0%)"}else if(t==="center"){return"translateX(-50%)"}else{return"translateX(-100%)"}}
t.prototype.render=function e(){var t=this.props,o=t.inverted,i=t.color,n=t.offset,r=t.side,s=t.hasCloseIcon,a=t.onClose,l=t.horizontalShift,p=t.horizontalAlignment,h=t.width,d=t.onMouseEnter,c=t.onMouseLeave
var u=this.state.fadeOut
var f=_globalStyles.colors.white
var m={}
m.backgroundColor=o?i:f
m.color=o?f:i
m.width=h?h+"px":"100%"
var g=this.props.horizontalPadding!=null?this.props.horizontalPadding:defaultHorizontalPadding
m.paddingLeft=g
m.paddingRight=g
var v=this.props.verticalPadding!=null?this.props.verticalPadding:10
m.paddingTop=v
m.paddingBottom=v
if(r==="top"){m.bottom=n
m.transform=this._getTransformForHorizontalAlignment()}else if(r==="right"){m.left=n
m.transform="translateY(-50%)"}else if(r==="bottom"){m.top=n
m.transform=this._getTransformForHorizontalAlignment()}else if(r==="left"){m.right=n
m.transform="translateY(-50%)"}return React.createElement("span",{className:(0,_aphrodite.css)(styles.container,s&&styles.closeContainer,u&&styles.fadeOut),style:m,onMouseEnter:d,onMouseLeave:c},this.props.children,React.createElement(Triangle,{width:arrowWidth,height:arrowHeight,side:r,backgroundColor:o?i:f,horizontalShift:l,horizontalAlignment:p}),s&&React.createElement("span",{className:(0,_aphrodite.css)(styles.closeIcon),onClick:a},React.createElement(_icon2.default,{icon:closeIcon,size:10,color:o?"rgba(255, 255, 255, 0.7)":"rgba(0, 0, 0, 0.15)"})))}
return t}(_react.Component)
var styles=_aphrodite.StyleSheet.create({container:babelHelpers.extends({},_globalStyles.typography.labelMedium,{display:"flex",alignItems:"center",justifyContent:"center",position:"relative",borderRadius:_constants2.default.borderRadiusLarge,border:"1px solid rgba(0, 0, 0, 0.1)",boxShadow:dropShadowXOffset+"px "+dropShadowYOffset+"px "+(dropShadowRadius+"px 0px ")+("rgba(0, 0, 0, "+dropShadowOpacity+")"),opacity:1,transition:"opacity "+_globalStyles.standardTransition,boxSizing:"border-box"}),closeContainer:{paddingRight:34},closeIcon:{position:"absolute",top:10,right:10,cursor:"pointer"},fullWidthWrapperOnPhone:(_fullWidthWrapperOnPh={},_fullWidthWrapperOnPh[_mediaQueries2.default.mdOrSmaller]={width:"100%"},_fullWidthWrapperOnPh),fadeOut:{opacity:0}})
function hasSeenTooltip(e){return(0,_khanFetch.khanFetch)("/api/internal/dismiss/"+e).then(function(e){return e.json()}).then(function(t){if(!t.dismissed){markAsSeenTooltip(e)}return t.dismissed}).catch(function(){return true})}function markAsSeenTooltip(e){var t=new Date((new Date).getTime()*2).toISOString();(0,_khanFetch.khanFetch)("/api/internal/dismiss/"+e+"?expires="+t,{method:"POST"})}var Tooltip=function(e){babelHelpers.inherits(t,e)
function t(){var o,i,n
babelHelpers.classCallCheck(this,t)
for(var r=arguments.length,s=Array(r),a=0;a<r;a++){s[a]=arguments[a]}return n=(o=(i=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),i),i.timeouts=[],i.handleInteract=function(){i.hideTooltip()
i.unbindHandlers()},i.handleResize=function(){i.showTooltip()},i.handleMouseEnter=function(){if(i.container){return}if(i.props.toggleOnHover){if(i.hideTooltipTimeout){clearTimeout(i.hideTooltipTimeout)
i.hideTooltipTimeout=null}i.showTooltip()}},i.handleMouseLeave=function(){if(i.props.toggleOnHover){if(i.hideTooltipTimeout){clearTimeout(i.hideTooltipTimeout)
i.hideTooltipTimeout=null}i.hideTooltipTimeout=setTimeout(function(){i.hideTooltip()
i.unbindHandlers()},_globalStyles.standardTransitionMs)}},i.handleMouseEnterTooltip=function(){if(i.props.toggleOnHover&&i.hideTooltipTimeout){clearTimeout(i.hideTooltipTimeout)
i.hideTooltipTimeout=null}},i.handleMouseLeaveTooltip=function(){if(i.props.toggleOnHover){i.hideTooltip()
i.unbindHandlers()}},i.handleFocus=function(){if(i.container){return}if(i.props.toggleOnHover){if(i.hideTooltipTimeout){clearTimeout(i.hideTooltipTimeout)
i.hideTooltipTimeout=null}i.showTooltip()}},i.handleBlur=function(){if(i.props.toggleOnHover){if(i.hideTooltipTimeout){clearTimeout(i.hideTooltipTimeout)
i.hideTooltipTimeout=null}i.hideTooltip()
i.unbindHandlers()}},o),babelHelpers.possibleConstructorReturn(i,n)}t.prototype.componentDidMount=function e(){var t=this
if(this.props.dismissKey){hasSeenTooltip(this.props.dismissKey).then(function(e){if(e){t.hideTooltip()}else{t.displayTooltipOnMount()}})}else if(this.props.showOnMount){this.displayTooltipOnMount()}}
t.prototype.UNSAFE_componentWillUpdate=function e(){this._hideIfParentGoneOrReshow()}
t.prototype.componentDidUpdate=function e(t){if(this.container&&(t.width!==this.props.width||t.left!==this.props.left)){this.hideTooltip()
this.showTooltip()}}
t.prototype.componentWillUnmount=function e(){this.timeouts.forEach(clearTimeout)
if(this.hideTooltipTimeout){clearTimeout(this.hideTooltipTimeout)}this.hideTooltip()}
t.prototype.displayTooltipOnMount=function e(){var t=this
if(this.container){return}if(this.props.toggleOnHover===false){this.timeouts.push(setTimeout(function(){return t.showTooltip()},0))}this.timeouts.push(setTimeout(function(){return t.showTooltip()},1e3))}
t.prototype._getClampedHorizontalShift=function e(t,o){var i=this.props,n=i.autoshift,r=i.horizontalAlignment,s=i.horizontalShift,a=i.left
var l=a===undefined?s:a-t+defaultHorizontalPadding
if(r==="left"){if(n){l=-(o.width/2+defaultHorizontalPadding-arrowWidth)}else{l=Math.min(0,l)}}else if(r==="right"){if(n){l=o.width/2+defaultHorizontalPadding-arrowWidth}else{l=Math.max(0,l)}}return l}
t.prototype._getInnerHorizontalAlignment=function e(){if(this.props.left!==undefined){return"left"}else{return this.props.horizontalAlignment}}
t.prototype.showTooltip=function e(){var t=this
var o=this.props,i=o.onTopOfModal,n=o.inverted,r=o.color,s=o.offset,a=o.dismissOnClickClose,l=o.dismissOnScroll,p=o.dismissOnInteraction,h=o.enablePointerEvents,d=o.fixedPosition,c=o.modalBody,u=o.horizontalTooltipShift,f=o.width,m=o.autoDismissTimeout,g=o.zIndex,v=o.ariaLive
if(!this.node){this.unbindHandlers()
return}var y=!!this.node.offsetParent
if(!y){return}var T=this.node.getBoundingClientRect()
var b=!this.container&&!this.wrapper
if(b){this.container=document.createElement("span")
this.wrapper=document.createElement("span")}this.wrapper.style.position="absolute"
this.wrapper.style.left="0px"
this.wrapper.style.top="0px"
this.wrapper.style.width=document.body.scrollWidth+"px"
this.wrapper.style.height=document.body.scrollHeight+"px"
this.wrapper.style.overflow="hidden"
this.wrapper.style.pointerEvents="none"
this.wrapper.setAttribute("aria-live",v||"off")
this.container.style.position=i?"fixed":"absolute"
this.container.style.pointerEvents=a||h?"all":"none"
var w=i?_constants2.default.zindexAboveModal:_constants2.default.zindexTooltip
this.container.style.zIndex=(g||w).toString()
var H=T.top+T.height/2
var O=T.left+T.width/2
if(!d){H+=window.pageYOffset
O+=window.pageXOffset}var S=window.innerWidth
var C=i?document.body.clientHeight:document.body.scrollHeight
var z=this._getClampedHorizontalShift(O,T)
var E=z
var R=this._getSide(T)
var x=R==="top"||R==="bottom"
if(u&&x){E+=u}if(this._getInnerHorizontalAlignment()==="left"){E-=defaultHorizontalPadding}else if(this._getInnerHorizontalAlignment()==="right"){E+=defaultHorizontalPadding}if(R==="top"){this.container.style.left=O+E+"px"
this.container.style.bottom=s+C-H+T.height/2+"px"}else if(R==="right"){this.container.style.left=s+O+T.width/2+"px"
this.container.style.top=H+"px"}else if(R==="bottom"){this.container.style.left=O+E+"px"
this.container.style.top=s+H+T.height/2+"px"}else if(R==="left"){this.container.style.right=s+S-O+T.width/2+"px"
this.container.style.top=H+"px"}if(b){this.wrapper.appendChild(this.container)
document.body.appendChild(this.wrapper)
_reactDom2.default.render(React.createElement(TooltipInner,{onTopOfModal:i,side:R,inverted:n,color:r,hasCloseIcon:a,horizontalShift:z,onClose:function e(){t.hideTooltip()
t.unbindHandlers()},onMouseEnter:this.handleMouseEnterTooltip,onMouseLeave:this.handleMouseLeaveTooltip,horizontalAlignment:this._getInnerHorizontalAlignment(),width:f,autoDismissTimeout:m},this.props.content),this.container,function(){t.unbindHandlers()
if(l||p){document.addEventListener("scroll",t.handleInteract)
if(c){c.addEventListener("scroll",t.handleInteract)}}if(p){document.addEventListener("mousedown",t.handleInteract)
document.addEventListener("touchstart",t.handleInteract)}window.addEventListener("resize",t.handleResize)})}}
t.prototype.hideTooltip=function e(){if(this.container&&this.wrapper){_reactDom2.default.unmountComponentAtNode(this.container)
document.body.removeChild(this.wrapper)
delete this.container
delete this.wrapper}if(this.props.onDismiss){this.props.onDismiss()}}
t.prototype._hideIfParentGoneOrReshow=function e(){if(!this.node||!this.container||!this.wrapper){return}var t=!!this.node.offsetParent
if(!t){this.container.style.display="none"
this.wrapper.style.display="none"}else{this.wrapper.style.display="initial"
this.container.style.display="initial"}}
t.prototype._getSide=function e(t){if(this.props.side==="top-or-bottom"){if(t.top+200>window.innerHeight){return"top"}return"bottom"}else{return this.props.side}}
t.prototype.unbindHandlers=function e(){document.removeEventListener("mousedown",this.handleInteract)
document.removeEventListener("touchstart",this.handleInteract)
document.removeEventListener("scroll",this.handleInteract)
window.removeEventListener("resize",this.handleResize)
var t=this.props.modalBody
if(t){t.removeEventListener("scroll",this.handleInteract)}}
t.prototype.render=function e(){var t=this
var o=(0,_aphrodite.css)(this.props.fullWidthWrapperOnPhone&&styles.fullWidthWrapperOnPhone)
return React.createElement("span",{className:o,ref:function e(o){return t.node=o},onMouseEnter:this.handleMouseEnter,onMouseLeave:this.handleMouseLeave,onFocus:this.handleFocus,onBlur:this.handleBlur},this.props.children)}
return t}(_react.Component)
Tooltip.defaultProps={inverted:false,color:_globalStyles.colors.gray17,side:"top",toggleOnHover:true,dismissOnClickClose:false,dismissOnScroll:false,dismissOnInteraction:false,enablePointerEvents:false,horizontalShift:0,autoshift:false,horizontalAlignment:"center",showOnMount:false}
exports.default=Tooltip

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/tooltip-package.js.map 