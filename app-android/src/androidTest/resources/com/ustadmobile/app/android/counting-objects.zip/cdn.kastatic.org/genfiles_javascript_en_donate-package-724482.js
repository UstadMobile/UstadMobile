KAdefine("javascript/donate-package/amounts.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.commafy=commafy
exports.parse=parse
exports.format=format
exports.clean=clean
var MAX_LOGGED_DONATION_VALUE=exports.MAX_LOGGED_DONATION_VALUE=1e3
function _reverse(e){return e.split("").reverse().join("")}function commafy(e){if(typeof e!=="number"||e!==e||!isFinite(e)){throw new Error("Expected "+e+" to be a finite number")}var r=_reverse(String(e)).match(/.{1,3}/g)
if(!r){throw new Error("Could not parse number of dollars: "+e)}return _reverse(r.join(","))}function parse(e){var r=String(e).replace("$","").replace(/(?:,| |, )(\d\d\d)(?=\.|,|$)/g,"$1")
var t=Number(r)||0
return Math.round(t*100)}function format(e){var r=arguments.length>1&&arguments[1]!==undefined?arguments[1]:"forInput"
if(r==="forInput"){if(e===0){return""}else{return"$"+(e/100).toFixed(2)}}else if(r==="forHumans"){var t=commafy(Math.floor(e/100))
var n=e%100
if(n>0){return"$"+t+"."+n}else{return"$"+t}}throw new Error('Expected style to be "forInput" or "forHumans". It was '+r+".")}function clean(e){var r=arguments.length>1&&arguments[1]!==undefined?arguments[1]:undefined
return this.format(this.parse(e),r)}
});
KAdefine("javascript/donate-package/donate-form-controller.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.formContextIsBanner=undefined
var _parseQueryString=require("../shared-package/parse-query-string.js")
var _parseQueryString2=babelHelpers.interopRequireDefault(_parseQueryString)
var _ka=require("../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _importFromExternalScript=require("../shared-package/import-from-external-script.js")
var _importFromExternalScript2=babelHelpers.interopRequireDefault(_importFromExternalScript)
var _amounts=require("./amounts.js")
var Amounts=babelHelpers.interopRequireWildcard(_amounts)
var _donateForm=require("./donate-form.jsx")
var _donateForm2=babelHelpers.interopRequireDefault(_donateForm)
var _errorMessage=require("./error-message.jsx")
var _errorMessage2=babelHelpers.interopRequireDefault(_errorMessage)
var _paypal=require("./methods/paypal.js")
var _paypal2=babelHelpers.interopRequireDefault(_paypal)
var _stripe=require("./methods/stripe.js")
var _stripe2=babelHelpers.interopRequireDefault(_stripe)
var React=require("react")
var i18n=require("../shared-package/i18n.js")
var MIN_DONATION_CENTS=100
var DEFAULT_AMOUNT_TEXT="10"
var defaultMissionParagraphs=[{text:i18n._("Help us do more"),style:"headingFont"},{text:i18n._("We'll get right to the point: we're "+"asking you to help support Khan Academy. We're a "+"nonprofit that relies on support from people like "+"you. <b> If everyone reading this gives "+"$10 monthly, Khan Academy can continue "+"to thrive for years. </b> "+"Please help keep Khan Academy free, for anyone, "+"anywhere forever."),style:"smallFont"}]
function amountTextIsValid(e){return Amounts.parse(e)>=MIN_DONATION_CENTS}var formContextIsBanner=exports.formContextIsBanner=function e(t){return t.startsWith("banner")}
var DonateFormController=function(e){babelHelpers.inherits(t,e)
function t(){var r,n,a
babelHelpers.classCallCheck(this,t)
for(var o=arguments.length,i=Array(o),s=0;s<o;s++){i[s]=arguments[s]}return a=(r=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(i))),n),n.state={chosenAmountText:null,customAmountText:null,donorName:null,explicitlyChoseCustomAmount:false,honoree:{name:"",email:"",selected:false},interval:null,touched:false,DonateEvenMoreReminderModal:null,showDoubleChargeReminder:false,onDoubleChargeReminderAccepted:null},n.parseError=function(e){if(e["error[type]"]){return{type:e["error[type]"],message:e["error[message]"]}}else{return null}},n.triggerResizeEvent=function(){setTimeout(function(){return window.dispatchEvent(new Event("resize"),0)})},n.getCustomAmountText=function(e){if(n.state.customAmountText===null){var t=e.defaults.chosenAmountText
var r=n.getInterval(e)
var a=n.getAskStringForInterval(r)
for(var o=a,i=Array.isArray(o),s=0,o=i?o:o[Symbol.iterator]();;){var l
if(i){if(s>=o.length)break
l=o[s++]}else{s=o.next()
if(s.done)break
l=s.value}var u=l
if(u.amountText===t){return""}}return t}else{return n.state.customAmountText}},n.getField=function(e,t){if(n.state[e]===null){return t.defaults[e]}else{return n.state[e]}},n.getInterval=function(e){if(n.state.interval){return n.state.interval}if(e.defaults.interval){return e.defaults.interval}return"once"},n.handleCustomAmount=function(e){n.setState({customAmountText:e,chosenAmountText:e,explicitlyChoseCustomAmount:true,touched:true})},n.handleDonorName=function(e){n.setState({donorName:e,touched:true})},n.handleHonoree=function(e){n.setState({honoree:e,touched:true})},n.getAskStringForInterval=function(e){var t=n.getCombinedFormState()
return e==="month"?t.askStringMonthly:t.askStringOnetime},n.getAskStringIndex=function(){var e=n.getCombinedFormState()
var t=n.getField("chosenAmountText",e)
var r=n.getAskStringForInterval(n.getInterval(e))
return r.findIndex(function(e){return e.amountText===t})},n.handleInterval=function(e){var t=n.getAskStringIndex()
if(!n.state.explicitlyChoseCustomAmount&&t!==-1){var r=n.getAskStringForInterval(e)
var a=r[t].amountText
n.handlePredefinedAmount(a)}n.setState({interval:e,touched:true})},n.handlePredefinedAmount=function(e){n.setState({chosenAmountText:e,explicitlyChoseCustomAmount:false,touched:true})},n.renderModal=function(){var e=n.state,t=e.DonateEvenMoreReminderModal,r=e.showDoubleChargeReminder,a=e.onDoubleChargeReminderAccepted
if(t&&r){var o=function e(){n.setState({DonateEvenMoreReminderModal:null,showDoubleChargeReminder:false,onDoubleChargeReminderAccepted:null})}
var i=function e(){a&&a()
o()}
return React.createElement(t,{onClose:o,onAccept:i})}},r),babelHelpers.possibleConstructorReturn(n,a)}t.prototype.componentDidMount=function e(){this.triggerResizeEvent();(0,_importFromExternalScript2.default)("https://checkout.stripe.com/checkout.js","StripeCheckout")}
t.prototype.componentDidUpdate=function e(t,r){if(this.state.honoree.selected!==r.honoree.selected){this.triggerResizeEvent()}}
t.prototype.getUseCreditCardString=function e(){if(_ka2.default.language==="en"){return i18n._("Give by credit card")}return i18n._("Use credit card")}
t.prototype.getUsePayPalString=function e(){if(_ka2.default.language==="en"){return i18n._("Give with PayPal")}return i18n._("Use PayPal")}
t.prototype.getCombinedFormState=function e(){var t=this.props,r=t.donateParameters,n=t.query
var a=(0,_parseQueryString2.default)(n)
var o=a.recurring!=="0"
var i={defaults:{chosenAmountText:a.amount||DEFAULT_AMOUNT_TEXT,donorName:"",interval:o?"month":"once"},formContext:this.props.formContext,askStringOnetime:[{amountText:"10",label:i18n._("$10")},{amountText:"35",label:i18n._("$35")},{amountText:"50",label:i18n._("$50")},{amountText:"100",label:i18n._("$100")},{amountText:"250",label:i18n._("$250")}],askStringMonthly:[{amountText:"10",label:i18n._("$10")},{amountText:"35",label:i18n._("$35")},{amountText:"50",label:i18n._("$50")},{amountText:"100",label:i18n._("$100")},{amountText:"250",label:i18n._("$250")}],methodChoices:[{id:"stripe",label:this.getUseCreditCardString(),onSubmit:_stripe2.default},{id:"paypal",label:this.getUsePayPalString(),onSubmit:_paypal2.default}],missionParagraphs:defaultMissionParagraphs,error:this.parseError(a),imageRelativeUrl:"/images/donate/donation-illustration-earth.svg"}
if(r){var s=[["amount","chosenAmountText",i.defaults],["askStringOnetime","askStringOnetime",i],["askStringMonthly","askStringMonthly",i],["askHtml","missionParagraphs",i],["imageRelativeUrl","imageRelativeUrl",i]]
s.forEach(function(e){var t=e[0],n=e[1],a=e[2]
if(r.hasOwnProperty(t)){a[n]=r[t]}})
if(a.amount){i.defaults.chosenAmountText=a.amount}if(o){i.defaults.interval="month"}i.thermometer=r.thermometer}function l(e){if(!e){return null}var t=atob(e).split(",").map(function(e){return parseInt(e,10)})
if(!t.every(function(e){return!isNaN(e)})||t.length!==5){return null}return t.map(function(e){return{amountText:String(e),label:Amounts.format(e*100,"forHumans")}})}if(a.a){var u=l(a.a)
if(u){i.askStringMonthly=u
var m=l(a.ao)
i.askStringOnetime=m||i.askStringMonthly
if(!a.amount){i.defaults.chosenAmountText=i.askStringMonthly[1].amountText}}else{console.warn(a.a+" is not a valid ask string")}}return i}
t.prototype.render=function e(){var t=this
var r=this.getCombinedFormState()
var n=this.getInterval(r)
var a={chosenAmountText:this.getField("chosenAmountText",r),customAmountText:this.getCustomAmountText(r),customAmountIsValid:amountTextIsValid(this.getCustomAmountText(r)),explicitlyChoseCustomAmount:this.state.explicitlyChoseCustomAmount,onChooseCustomAmount:this.handleCustomAmount,onChoosePredefinedAmount:this.handlePredefinedAmount,predefinedAmounts:this.getAskStringForInterval(n),formContext:this.props.formContext,interval:"month"}
var o=amountTextIsValid(this.getField("chosenAmountText",r))
var i=r.methodChoices.map(function(e){var n=t.state.honoree
if(!n.selected){n={name:"",email:"",selected:false}}var a=function a(){e.onSubmit({amountText:t.getField("chosenAmountText",r),donorName:t.getField("donorName",r),honoree:n,interval:t.getInterval(r),returnPath:"/donate/thanks"})}
return babelHelpers.extends({},e,{buttonEnabled:o,onSubmit:a})})
return React.createElement("div",null,r.error&&React.createElement(_errorMessage2.default,{error:r.error}),React.createElement(_donateForm2.default,{amount:a,donorName:this.getField("donorName",r),formContext:r.formContext,honoree:this.state.honoree,imageRelativeUrl:r.imageRelativeUrl,interval:this.getInterval(r),methodChoices:i,missionParagraphs:r.missionParagraphs,onDonorNameChange:this.handleDonorName,onHonoreeChange:this.handleHonoree,onIntervalChange:this.handleInterval,touched:this.state.touched,thermometer:r.thermometer}),this.renderModal())}
return t}(React.Component)
exports.default=DonateFormController

});
KAdefine("javascript/donate-package/donate-form.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _wrapper,_wrapperInBanner,_firstSection,_lastSection,_divider
var _aphrodite=require("aphrodite")
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _link=require("../components/link-package/link.jsx")
var _link2=babelHelpers.interopRequireDefault(_link)
var _mission=require("./mission.jsx")
var _mission2=babelHelpers.interopRequireDefault(_mission)
var _styles=require("./styles.js")
var _fields=require("./fields/fields.jsx")
var _fields2=babelHelpers.interopRequireDefault(_fields)
var _intervalFields=require("./fields/interval-fields.jsx")
var _intervalFields2=babelHelpers.interopRequireDefault(_intervalFields)
var _metadataFields=require("./fields/metadata-fields.jsx")
var _metadataFields2=babelHelpers.interopRequireDefault(_metadataFields)
var _amountFields=require("./fields/amount-fields.jsx")
var _amountFields2=babelHelpers.interopRequireDefault(_amountFields)
var _methodFields=require("./fields/method-fields.jsx")
var _methodFields2=babelHelpers.interopRequireDefault(_methodFields)
var React=require("react")
var i18n=require("../shared-package/i18n.js")
var $_=i18n.$_
var formContextIsBanner=function e(r){return r.startsWith("banner")}
var Divider=function e(){return React.createElement("div",{className:(0,_aphrodite.css)(styles.divider)})}
var Disclaimer=function e(){var r=React.createElement(_link2.default,{style:[styles.disclaimerLink],href:"/about/tos",target:"_blank"},$_(null,"terms of service"))
var t=React.createElement(_link2.default,{style:[styles.disclaimerLink],href:"/about/privacy-policy",target:"_blank"},$_(null,"privacy policy"))
return React.createElement("div",{className:(0,_aphrodite.css)(styles.disclaimerMessage)},$_({tos:r,privacy:t},"By donating, you agree to our %(tos)s and %(privacy)s."))}
var DonateForm=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props.formContext
var t=[React.createElement(_intervalFields2.default,{key:"interval",interval:this.props.interval,onChange:this.props.onIntervalChange,touched:this.props.touched,formContext:r}),React.createElement(_amountFields2.default,babelHelpers.extends({key:"amount"},this.props.amount,{interval:this.props.interval,formContext:r}))]
var a=(0,_aphrodite.css)(styles.wrapper,formContextIsBanner(this.props.formContext)&&styles.wrapperInBanner)
var s=function(){if(r==="donate-page"){return styles.outerWrapperWonderblocks}else if(r==="banner"||r==="banner-white-btns"){return styles.outerWrapper}else if(r==="banner-legacy"){return styles.outerWrapperLegacy}throw new Error("Not reached: invalid formContext")}()
return React.createElement("div",{className:(0,_aphrodite.css)(s)},React.createElement("div",{className:a},React.createElement(_mission2.default,{className:(0,_aphrodite.css)(styles.firstSection)+" mission",imageRelativeUrl:this.props.imageRelativeUrl,paragraphs:this.props.missionParagraphs,thermometer:this.props.thermometer,formContext:r}),React.createElement(Divider,null),React.createElement(_fields2.default,{className:(0,_aphrodite.css)(styles.lastSection)},t,React.createElement(_metadataFields2.default,{donorName:this.props.donorName,honoree:this.props.honoree,onDonorNameChange:this.props.onDonorNameChange,onHonoreeChange:this.props.onHonoreeChange}),React.createElement(_methodFields2.default,{choices:this.props.methodChoices,formContext:r}),React.createElement(Disclaimer,null)),React.createElement("div",{className:(0,_aphrodite.css)(styles.wrapperClear)})))}
return r}(React.Component)
exports.default=DonateForm
var styles=_aphrodite.StyleSheet.create({wrapper:(_wrapper={alignItems:"center",color:_globalStyles2.default.colors.white,display:"flex",flexDirection:"row",justifyContent:"center",padding:"30px 0",position:"relative",textAlign:"left"},_wrapper[_styles.isMobile]={display:"block",padding:"30px 20px"},_wrapper.margin="0 auto",_wrapper.maxWidth=1200,_wrapper),outerWrapperLegacy:{background:_styles.legacyColors.blue},outerWrapper:{background:_styles.bannerColors.blue},outerWrapperWonderblocks:{background:_wonderBlocksColorV2.default.darkBlue},wrapperInBanner:(_wrapperInBanner={padding:"35px 0",maxWidth:1200,margin:"0 auto"},_wrapperInBanner[_styles.isMobile]={padding:"45px 20px 20px"},_wrapperInBanner),wrapperClear:{clear:"both"},firstSection:(_firstSection={},_firstSection[_styles.isDesktop]={paddingLeft:20,paddingRight:26},_firstSection[_styles.isMobile]={borderBottom:"2px solid "+_styles.legacyColors.lightBlue,marginBottom:15,paddingBottom:15},_firstSection),lastSection:(_lastSection={},_lastSection[_styles.isDesktop]={marginBottom:"auto",paddingLeft:16,paddingRight:20},_lastSection[_styles.isMobile]={paddingTop:15},_lastSection),divider:(_divider={},_divider[_styles.isDesktop]={display:"none"},_divider),disclaimerMessage:{marginTop:_styles.formPaddingPx},disclaimerLink:{borderBottom:"1px solid "+_globalStyles2.default.colors.white,textDecoration:"none",":hover":{textDecoration:"none"}}})

});
KAdefine("javascript/donate-package/donate-page.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v1")
var _donateFormController=require("./donate-form-controller.jsx")
var _donateFormController2=babelHelpers.interopRequireDefault(_donateFormController)
var _faqModule=require("./modules/faq-module.jsx")
var _faqModule2=babelHelpers.interopRequireDefault(_faqModule)
var _calloutModule=require("./modules/callout-module.jsx")
var _calloutModule2=babelHelpers.interopRequireDefault(_calloutModule)
var _thankYouModule=require("./modules/thank-you-module.jsx")
var _thankYouModule2=babelHelpers.interopRequireDefault(_thankYouModule)
var _footer=require("./modules/footer.jsx")
var _footer2=babelHelpers.interopRequireDefault(_footer)
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var DonatePage=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.renderWith=function e(r){return React.createElement("div",{className:css(styles.donatePage)},React.createElement(_donateFormController2.default,{donateParameters:r.donateParameters,formContext:"donate-page"}),React.createElement(_thankYouModule2.default,{thankYouVideo:r.thankYouVideo}),React.createElement(_calloutModule2.default,{newDonationsStrings:r.newDonationsStrings}),React.createElement(_faqModule2.default,{newDonationsStrings:r.newDonationsStrings}),React.createElement(_footer2.default,null))}
r.prototype.render=function e(){var r=this
return React.createElement(_wonderBlocksCoreV.NoSSR,null,function(){return r.renderWith(r.props)})}
return r}(React.Component)
exports.default=DonatePage
var styles=StyleSheet.create({donatePage:{borderTop:"62px solid "+_wonderBlocksColorV2.default.darkBlue}})

});
KAdefine("javascript/donate-package/error-message.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _aphrodite=require("aphrodite")
var React=require("react")
var globalStyles=require("../shared-styles-package/global-styles.js")
var styleConstants=require("../shared-styles-package/constants.js")
var i18n=require("../shared-package/i18n.js")
var $_=i18n.$_
var ErrorMessage=function(e){babelHelpers.inherits(r,e)
function r(){var s,a,t
babelHelpers.classCallCheck(this,r)
for(var o=arguments.length,n=Array(o),l=0;l<o;l++){n[l]=arguments[l]}return t=(s=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(n))),a),a.renderErrorMessage=function(){return $_({message:a.props.error.message||""},"%(message)s We weren't able to process your donation.")},a.renderApology=function(){if(a.props.error.type==="card_error"){return $_(null,"Sorry for the inconvenience, please try again once the issue is fixed. Thank you!")}else{return $_(null,"The problem should have been temporary, so please try again. Thank you!")}},s),babelHelpers.possibleConstructorReturn(a,t)}r.prototype.render=function e(){return React.createElement("div",{className:(0,_aphrodite.css)(styles.errorMessage)},React.createElement("p",{className:(0,_aphrodite.css)(styles.errorMessageParagraph)},this.renderErrorMessage()),React.createElement("p",{className:(0,_aphrodite.css)(styles.errorMessageParagraph)},this.renderApology()))}
return r}(React.Component)
exports.default=ErrorMessage
var styles=_aphrodite.StyleSheet.create({errorMessage:{background:styleConstants.orange,color:globalStyles.colors.white,overflow:"hidden",padding:"22px 0",textAlign:"center"},errorMessageParagraph:{fontSize:18,margin:"10px 0"}})

});
KAdefine("javascript/donate-package/form-context.js", function(require, module, exports) {

});
KAdefine("javascript/donate-package/fields/amount-fields.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _field=require("./field.jsx")
var _field2=babelHelpers.interopRequireDefault(_field)
var _horizontalChooser=require("./horizontal-chooser.jsx")
var _horizontalChooser2=babelHelpers.interopRequireDefault(_horizontalChooser)
var React=require("react")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var globalStyles=require("../../shared-styles-package/global-styles.js")
var i18n=require("../../shared-package/i18n.js")
var styleConstants=require("../../shared-styles-package/constants.js")
var AmountFields=function(e){babelHelpers.inherits(t,e)
function t(){var o,s,r
babelHelpers.classCallCheck(this,t)
for(var n=arguments.length,a=Array(n),u=0;u<n;u++){a[u]=arguments[u]}return r=(o=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(a))),s),s.state={customAmountFocused:false},s.choseCustom=function(){return s.props.explicitlyChoseCustomAmount||!s.props.predefinedAmounts.some(function(e){var t=e.amountText
return t===s.props.chosenAmountText})},s.handleChoice=function(e){if(e===""){s.props.onChooseCustomAmount(s.props.customAmountText)}else{s.props.onChoosePredefinedAmount(e)}},s.handleCustomAmountBlur=function(){s.setState({customAmountFocused:false})},s.handleCustomAmountChange=function(e){s.props.onChooseCustomAmount(e.target.value)},s.handleCustomAmountFocus=function(){s.setState({customAmountFocused:true})},s.renderCustomOptionLabel=function(){if(s.choseCustom()){return React.createElement("input",{autoFocus:s.props.explicitlyChoseCustomAmount,className:css(styles.customChoice),onBlur:s.handleCustomAmountBlur,onChange:s.handleCustomAmountChange,onFocus:s.handleCustomAmountFocus,type:"text",value:s.props.customAmountText})}else{return i18n._("Other")}},s.shouldShowCustomAmountError=function(){return!s.props.customAmountIsValid&&s.choseCustom()&&!s.state.customAmountFocused},o),babelHelpers.possibleConstructorReturn(s,r)}t.prototype.render=function e(){var t=this.props.predefinedAmounts.map(function(e){return{label:e.label,value:e.amountText}})
var o={className:css(styles.customChoiceLabel,this.shouldShowCustomAmountError()&&styles.invalidCustomChoiceLabel),label:this.renderCustomOptionLabel(),value:""}
t.push(o)
var s=this.choseCustom()?"":this.props.chosenAmountText
var r=this.props.interval
return React.createElement(_field2.default,{className:css(styles.extraSpacingUnderStandaloneButtonChooser),label:i18n._("Select your amount"),key:r},React.createElement(_horizontalChooser2.default,{name:"amount",onChange:this.handleChoice,options:t,value:s}))}
return t}(React.Component)
exports.default=AmountFields
var styles=StyleSheet.create({extraSpacingUnderStandaloneButtonChooser:{marginBottom:27},customChoice:babelHelpers.extends({},globalStyles.typography.bodyXsmallBold,{boxSizing:"border-box",lineHeight:1,margin:-3,padding:0,textAlign:"inherit",width:"75%"}),customChoiceLabel:{transition:"background 0.25s"},invalidCustomChoiceLabel:{background:styleConstants.red}})

});
KAdefine("javascript/donate-package/fields/donate-button.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.donateButtonHoverColor=exports.donateButtonColor=undefined
var _aphrodite=require("aphrodite")
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _styles=require("../styles.js")
var React=require("react")
var donateButtonColor=exports.donateButtonColor=_globalStyles2.default.colors.kaGreen
var donateButtonHoverColor=exports.donateButtonHoverColor=_globalStyles2.default.colors.kaGreenHover
var DonateButton=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement("button",{"aria-disabled":this.props.disabled?"true":"false",className:(0,_aphrodite.css)(styles.donateButton)+" "+(this.props.className||""),disabled:this.props.disabled,onClick:this.props.onClick},React.createElement("div",{className:(0,_aphrodite.css)(styles.buttonInner,this.props.innerStyle)},this.props.label))}
return t}(React.Component)
exports.default=DonateButton
var styles=_aphrodite.StyleSheet.create({donateButton:babelHelpers.extends({},_globalStyles2.default.typography.bodyXsmallBold,{fontSize:16,lineHeight:1.25,alignItems:"center",backgroundColor:donateButtonColor,border:"none",borderRadius:_styles.formComponentRadiusPx,color:_globalStyles2.default.colors.white,display:"inline-flex",flexBasis:_styles.buttonBaseWidth,flexGrow:0,flexShrink:1,height:40,justifyContent:"center",":hover":{backgroundColor:donateButtonHoverColor,cursor:"pointer"}}),buttonInner:{alignItems:"center",display:"flex",flexBasis:_styles.buttonBaseWidth,flexGrow:0,flexShrink:1,justifyContent:"center"}})

});
KAdefine("javascript/donate-package/fields/field.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _labelRow,_labelRight
var _aphrodite=require("aphrodite")
var _wonderBlocksTypographyV=require("@khanacademy/wonder-blocks-typography-v1")
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v1")
var _wonderBlocksLayoutV=require("@khanacademy/wonder-blocks-layout-v1")
var _styles=require("./../styles.js")
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var React=require("react")
var Field=function(e){babelHelpers.inherits(l,e)
function l(){babelHelpers.classCallCheck(this,l)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}l.prototype.render=function e(){var l=this.props,a=l.className,r=l.label,t=l.rightLabel,s=l.note,o=l.children
return React.createElement("div",{className:(0,_aphrodite.css)(styles.field)+" "+(a||"")},React.createElement("header",{className:(0,_aphrodite.css)(styles.fieldHeader)},React.createElement(_wonderBlocksCoreV.View,{style:styles.labelRow},React.createElement(_wonderBlocksTypographyV.LabelMedium,null,r),React.createElement(_wonderBlocksLayoutV.Spring,null),t&&React.createElement(_wonderBlocksTypographyV.LabelSmall,{style:[styles.labelRight]},t)),React.createElement("div",{className:(0,_aphrodite.css)(styles.fieldNote)},s)),o)}
return l}(React.Component)
exports.default=Field
var styles=_aphrodite.StyleSheet.create({field:{display:"block",position:"relative",marginBottom:_styles.formPaddingPx},fieldHeader:{display:"block",marginBottom:_styles.formPaddingPx},fieldNote:{float:"right"},labelRow:(_labelRow={flexDirection:"row"},_labelRow[_mediaQueries2.default.smOrSmaller]={flexDirection:"column"},_labelRow),labelRight:(_labelRight={fontSize:13,alignSelf:"flex-end"},_labelRight[_mediaQueries2.default.smOrSmaller]={display:"block",marginTop:8,alignSelf:"flex-start"},_labelRight)})

});
KAdefine("javascript/donate-package/fields/fields.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _form
var _aphrodite=require("aphrodite")
var _styles=require("../styles.js")
var React=require("react")
var Fields=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement("form",{className:this.props.className+" "+(0,_aphrodite.css)(styles.form),onSubmit:function e(t){return t.preventDefault()}},this.props.children)}
return t}(React.Component)
Fields.defaultProps={className:""}
exports.default=Fields
var styles=_aphrodite.StyleSheet.create({form:(_form={display:"block",fontSize:14},_form[_styles.isDesktop]={boxSizing:"border-box",float:"right",width:"50%"},_form[_styles.isMobile]={marginLeft:"auto",marginRight:"auto",maxWidth:800,paddingBottom:15},_form)})

});
KAdefine("javascript/donate-package/fields/horizontal-chooser.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _wonderBlocksTypographyV=require("@khanacademy/wonder-blocks-typography-v1")
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _styles=require("../styles.js")
var _windowWidth=require("./window-width.jsx")
var _windowWidth2=babelHelpers.interopRequireDefault(_windowWidth)
var React=require("react")
var _require=require("aphrodite"),StyleSheet=_require.StyleSheet,css=_require.css
var MOBILE_CUTOFF=768
var MOBILE_ITEMS_PER_ROW=3
var CheckedIcon=function e(){return React.createElement("svg",{width:"24px",height:"24px",viewBox:"0 0 24 24",role:"img",focusable:"false",className:css(styles.checkmarkIcon)},React.createElement("g",{id:"Thermometer-banner",stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd"},React.createElement("g",{id:"Group",transform:"translate(0, -39)",fill:"#FFFFFF",fillRule:"nonzero"},React.createElement("path",{d:"M12,63 C5.372583,63 0,57.627417 0,51 C0,44.372583 5.372583,39 12,39 C18.627417,39 24,44.372583 24,51 C24,57.627417 18.627417,63 12,63 Z M12,61 C17.5228475,61 22,56.5228475 22,51 C22,45.4771525 17.5228475,41 12,41 C6.4771525,41 2,45.4771525 2,51 C2,56.5228475 6.4771525,61 12,61 Z M10.0718189,53.3994059 L16.2474786,46.3415091 C16.6111606,45.9258725 17.2429232,45.8837549 17.6585599,46.247437 C18.0741965,46.6111191 18.116314,47.2428817 17.752632,47.6585183 L10.7685053,55.6403774 C10.3512514,56.1172389 9.60134243,56.0907533 9.21877029,55.5856431 L6.20289696,51.6037841 C5.8694438,51.1635257 5.95602653,50.5363086 6.39628491,50.2028554 C6.83654328,49.8694022 7.46376041,49.955985 7.79721356,50.3962433 L10.0718189,53.3994059 Z"}))))}
var UncheckedIcon=function e(){return React.createElement("svg",{width:"24px",height:"24px",viewBox:"0 0 24 24",role:"img",focusable:"false",className:css(styles.checkmarkIcon)},React.createElement("g",{id:"Thermometer-banner",stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd"},React.createElement("g",{id:"Group",transform:"translate(-40, -39)",fill:"#FFFFFF",fillRule:"nonzero"},React.createElement("path",{d:"M52,63 C45.372583,63 40,57.627417 40,51 C40,44.372583 45.372583,39 52,39 C58.627417,39 64,44.372583 64,51 C64,57.627417 58.627417,63 52,63 Z M52,61 C57.5228475,61 62,56.5228475 62,51 C62,45.4771525 57.5228475,41 52,41 C46.4771525,41 42,45.4771525 42,51 C42,56.5228475 46.4771525,61 52,61 Z"}))))}
var HorizontalChooser=function(e){babelHelpers.inherits(t,e)
function t(){var o,r,l
babelHelpers.classCallCheck(this,t)
for(var i=arguments.length,a=Array(i),n=0;n<i;n++){a[n]=arguments[n]}return l=(o=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(a))),r),r.handleChange=function(e){if(e.target instanceof HTMLInputElement){r.props.onChange(e.target.value)}},o),babelHelpers.possibleConstructorReturn(r,l)}t.prototype.renderAtWidth=function e(t){var o=this
var r=this.props.showAsRadio
var l=null
var i=1
if(!r){if(t<=MOBILE_CUTOFF&&this.props.options.length>=MOBILE_ITEMS_PER_ROW){i=Math.floor(this.props.options.length/MOBILE_ITEMS_PER_ROW)}l={width:100/this.props.options.length*i+"%",minWidth:100/this.props.options.length*i+"%"}}var a=i>1?MOBILE_ITEMS_PER_ROW:this.props.options.length
return React.createElement("ul",{className:css(styles.horizontalChooser,!r&&styles.horizontalChooserButtons)},this.props.options.map(function(e,t){var n=e.value===o.props.value
var s=i>1?Math.floor(t/MOBILE_ITEMS_PER_ROW):0
var c=i>1?t%MOBILE_ITEMS_PER_ROW:t
var h=s===0
var d=s+1===i
var u=c===0
var p=c+1===a
var g=(e.className||"")+" "+(r?css(styles.choice,styles.choiceRadio):css(styles.choice,styles.choiceButton,n&&styles.chosenButton,h&&styles.choiceButtonTop,u&&styles.choiceButtonLeft,h&&u&&styles.choiceButtonTopLeft,h&&p&&styles.choiceButtonTopRight,d&&u&&styles.choiceButtonBottomLeft,d&&p&&styles.choiceButtonBottomRight))
var f=null
if(r){if(n){f=React.createElement(CheckedIcon,null)}else{f=React.createElement(UncheckedIcon,null)}}return React.createElement("li",{className:g,key:e.value,style:l},React.createElement(_wonderBlocksTypographyV.LabelLarge,{style:[styles.choiceLabel,r&&styles.choiceLabelRadioPadding],tag:"label"},f,React.createElement("input",{checked:n,className:"sr-only",name:o.props.name,onChange:o.handleChange,type:"radio",value:e.value}),e.label))}))}
t.prototype.render=function e(){var t=this
return React.createElement(_windowWidth2.default,null,function(e){return t.renderAtWidth(e)})}
return t}(React.Component)
exports.default=HorizontalChooser
var styles=StyleSheet.create({horizontalChooser:{lineHeight:0},horizontalChooserButtons:{display:"flex",flexWrap:"wrap"},choice:{boxSizing:"border-box",display:"inline-block",height:40,overflow:"hidden",textAlign:"center",flex:1},choiceButton:{border:"0 solid "+_globalStyles2.default.colors.white,borderRightWidth:1,borderBottomWidth:1,display:"inline-flex",justifyContent:"center"},choiceButtonLeft:{borderLeftWidth:1},choiceButtonTop:{borderTopWidth:1},choiceButtonTopLeft:{borderTopLeftRadius:_styles.formComponentRadiusPx},choiceButtonTopRight:{borderTopRightRadius:_styles.formComponentRadiusPx},choiceButtonBottomLeft:{borderBottomLeftRadius:_styles.formComponentRadiusPx},choiceButtonBottomRight:{borderBottomRightRadius:_styles.formComponentRadiusPx},chosenButton:{background:_globalStyles2.default.colors.white,color:_styles.bannerColors.lightBlue,fontFamily:"inherit"},choiceRadio:{marginRight:32,overflow:"visible",marginBottom:-5},choiceRadioIcon:{display:"inline-block",width:12,height:12,marginRight:10,borderRadius:12,border:"1px solid "+_globalStyles2.default.colors.white,boxShadow:"0 0 1px 0 "+_globalStyles2.default.colors.white,position:"relative",verticalAlign:-1,marginTop:-1},chosenRadioIconInner:{backgroundColor:_globalStyles2.default.colors.white,borderRadius:8,display:"inline-block",width:8,height:8,top:2,left:2,position:"absolute"},choiceLabel:{cursor:"pointer",display:"flex",flexDirection:"column",lineHeight:1,margin:0,padding:0,alignSelf:"center",width:"100%",height:"100%",justifyContent:"center",alignItems:"center"},choiceLabelRadioPadding:{display:"block",padding:"6px 0",height:16},checkmarkIcon:{display:"inline-block",verticalAlign:-6,marginTop:-6,marginRight:8}})

});
KAdefine("javascript/donate-package/fields/window-width.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _wonderBlocksCoreV=require("@khanacademy/wonder-blocks-core-v1")
var React=require("react")
var WindowWidth=function(e){babelHelpers.inherits(t,e)
function t(){var n,r,o
babelHelpers.classCallCheck(this,t)
for(var i=arguments.length,s=Array(i),a=0;a<i;a++){s[a]=arguments[a]}return o=(n=(r=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),r),r.state={width:window.innerWidth},r._handleResize=function(){r.setState({width:window&&window.innerWidth||1024})},n),babelHelpers.possibleConstructorReturn(r,o)}t.prototype.componentDidMount=function e(){window.addEventListener("resize",this._handleResize)}
t.prototype.componentWillUnmount=function e(){window.removeEventListener("resize",this._handleResize)}
t.prototype.render=function e(){var t=this
return React.createElement(_wonderBlocksCoreV.NoSSR,null,function(){return t.props.children(t.state.width)})}
return t}(React.Component)
exports.default=WindowWidth

});
KAdefine("javascript/donate-package/fields/interval-fields.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _field=require("./field.jsx")
var _field2=babelHelpers.interopRequireDefault(_field)
var _horizontalChooser=require("./horizontal-chooser.jsx")
var _horizontalChooser2=babelHelpers.interopRequireDefault(_horizontalChooser)
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var IntervalFields=function(e){babelHelpers.inherits(r,e)
function r(){babelHelpers.classCallCheck(this,r)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}r.prototype.render=function e(){var r=this.props,t=r.interval,a=r.formContext
var l=[{label:i18n._("Monthly"),value:"month"},{label:i18n._("One time"),value:"once"}]
return React.createElement(_field2.default,{label:i18n._("Select your support"),className:this.props.className},React.createElement("div",null,React.createElement(_horizontalChooser2.default,{name:"interval",onChange:this.props.onChange,options:l,value:t,showAsRadio:true,formContext:a})))}
return r}(React.Component)
exports.default=IntervalFields

});
KAdefine("javascript/donate-package/fields/metadata-fields.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _aphrodite=require("aphrodite")
var _field=require("./field.jsx")
var _field2=babelHelpers.interopRequireDefault(_field)
var _styles=require("../styles.js")
var React=require("react")
var globalStyles=require("../../shared-styles-package/global-styles.js")
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var MetadataFields=function(e){babelHelpers.inherits(t,e)
function t(){var a,n,o
babelHelpers.classCallCheck(this,t)
for(var r=arguments.length,l=Array(r),s=0;s<r;s++){l[s]=arguments[s]}return o=(a=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),n),n.handleDonorNameChange=function(e){n.props.onDonorNameChange(e.target.value)},n.handleHonoreeEmailChange=function(e){n.props.onHonoreeChange(babelHelpers.extends({},n.props.honoree,{email:e.target.value}))},n.handleHonoreeNameChange=function(e){n.props.onHonoreeChange(babelHelpers.extends({},n.props.honoree,{name:e.target.value}))},n.selectHonoree=function(){n.props.onHonoreeChange(babelHelpers.extends({},n.props.honoree,{selected:true}))},n.deselectHonoree=function(){n.props.onHonoreeChange(babelHelpers.extends({},n.props.honoree,{selected:false}))},n.renderHonoreeFields=function(){if(n.props.honoree.selected){var e=React.createElement("a",{className:(0,_aphrodite.css)(styles.deselectHonoreeLink),href:"javascript:void(0)",onClick:n.deselectHonoree},React.createElement("span",{className:(0,_aphrodite.css)(styles.deselectHonoreeLongText)},$_(null,"Never mind — this gift isn't in honor of another person")),React.createElement("span",{className:(0,_aphrodite.css)(styles.deselectHonoreeShortText)},$_(null,"Never mind")))
var t=React.createElement("span",{className:(0,_aphrodite.css)(styles.honoreeEmailNote)},$_(null,"We will notify your honoree of your gift"))
return React.createElement("div",null,React.createElement("label",null,React.createElement(_field2.default,{label:i18n._("Honoree's name"),note:e},React.createElement("input",{className:(0,_aphrodite.css)(styles.textField),onChange:n.handleHonoreeNameChange,type:"text",value:n.props.honoree.name}))),React.createElement("label",null,React.createElement(_field2.default,{label:i18n._("Honoree's email (optional)"),note:t},React.createElement("input",{className:(0,_aphrodite.css)(styles.textField),onChange:n.handleHonoreeEmailChange,type:"text",value:n.props.honoree.email}))))}else{return React.createElement("a",{className:(0,_aphrodite.css)(styles.selectHonoreeLink),href:"javascript:void(0)",onClick:n.selectHonoree},$_(null,"▸ Click here to give in honor of another person"))}},a),babelHelpers.possibleConstructorReturn(n,o)}t.prototype.render=function e(){return React.createElement("div",null,React.createElement("label",null,React.createElement(_field2.default,{label:i18n._("Your name")},React.createElement("input",{className:(0,_aphrodite.css)(styles.textField),onChange:this.handleDonorNameChange,type:"text",value:this.props.donorName}))),this.renderHonoreeFields())}
return t}(React.Component)
exports.default=MetadataFields
var styles=_aphrodite.StyleSheet.create({deselectHonoreeLink:{color:"inherit"},deselectHonoreeLongText:{"@media screen and (max-width: 599px)":{display:"none"}},deselectHonoreeShortText:{"@media screen and (min-width: 600px)":{display:"none"}},selectHonoreeLink:{color:"inherit",display:"block",fontSize:13,lineHeight:"27px",marginBottom:_styles.formPaddingPx,marginTop:-10,textDecoration:"none"},honoreeEmailNote:{"@media screen and (max-width: 511px)":{display:"none"}},textField:babelHelpers.extends({},globalStyles.typography.bodyXsmallBold,{backgroundColor:_styles.semiTransparent,border:0,borderRadius:_styles.formComponentRadiusPx,boxSizing:"border-box",color:globalStyles.colors.white,lineHeight:1,margin:0,padding:"12px",width:"100%"})})

});
KAdefine("javascript/donate-package/fields/method-fields.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _methodChoiceList,_methodChoiceListItem
var _aphrodite=require("aphrodite")
var _wonderBlocksButtonV=require("@khanacademy/wonder-blocks-button-v2")
var _wonderBlocksButtonV2=babelHelpers.interopRequireDefault(_wonderBlocksButtonV)
var _mediaQueries=require("../media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var _styles=require("../styles.js")
var _donateButton=require("./donate-button.jsx")
var _donateButton2=babelHelpers.interopRequireDefault(_donateButton)
var React=require("react")
var _media$screen$breakAt=_mediaQueries2.default.screen.breakAtWidth(400),donationButtonH=_media$screen$breakAt[0],donationButtonV=_media$screen$breakAt[1]
var MethodFields=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this.props,o=t.choices,n=t.formContext
return React.createElement("ul",{className:(0,_aphrodite.css)(styles.methodChoiceList)},o.map(function(e){return React.createElement("li",{className:(0,_aphrodite.css)(styles.methodChoiceListItem),key:e.id},(n==="donate-page"||n==="banner")&&React.createElement("div",{className:(0,_aphrodite.css)(styles.methodButton)},React.createElement(_wonderBlocksButtonV2.default,{onClick:e.onSubmit,disabled:!e.buttonEnabled},e.label)),n==="banner-white-btns"&&React.createElement("div",{className:(0,_aphrodite.css)(styles.methodButton)},React.createElement(_wonderBlocksButtonV2.default,{kind:"secondary",style:styles.bannerButton,onClick:e.onSubmit,disabled:!e.buttonEnabled},e.label)),n==="banner-legacy"&&React.createElement(_donateButton2.default,{disabled:!e.buttonEnabled,label:e.label,onClick:e.onSubmit}))}))}
return t}(React.Component)
exports.default=MethodFields
var styles=_aphrodite.StyleSheet.create({methodChoiceList:(_methodChoiceList={alignItems:"center",display:"flex",justifyContent:"center",marginTop:28,textAlign:"center"},_methodChoiceList[donationButtonH]={flexDirection:"column"},_methodChoiceList),methodChoiceListItem:(_methodChoiceListItem={display:"flex",flexBasis:_styles.buttonBaseWidth,flexGrow:0,flexShrink:1,listStyle:"none"},_methodChoiceListItem[donationButtonV]={":not(:last-of-type)":{marginRight:20}},_methodChoiceListItem[donationButtonH]={flexBasis:40,width:_styles.buttonBaseWidth,":not(:last-of-type)":{marginBottom:20}},_methodChoiceListItem),methodBannerLabel:{color:_styles.bannerColors.lightBlue},bannerButton:{background:"white"},methodButton:{width:"100%",display:"flex",flexDirection:"column"}})

});
KAdefine("javascript/donate-package/media-queries.js", function(require, module, exports) {
var MediaQuery=function(){function e(t,r){babelHelpers.classCallCheck(this,e)
this.type=t
this.features=r}e.prototype.and=function t(r){return new e(this.type,this.features.concat([r]))}
e.prototype.breakAtWidth=function e(t){return[this.and("(max-width: "+(t-1)+"px)"),this.and("(min-width: "+t+"px)")]}
e.prototype.intersect=function t(r){if(this.type!==r.type){throw Error("cannot AND media queries of different media type")}return new e(this.type,this.features.concat(r.features))}
e.prototype.toString=function e(){return"@media "+this.type+" and "+this.features.join(" and ")}
return e}()
function query(e,t){return new MediaQuery(e,t)}var screen=query("screen",[])
module.exports={query:query,screen:screen}

});
KAdefine("javascript/donate-package/methods/paypal.js", function(require, module, exports) {
var _bigbingo=require("../../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var _khanFetch=require("../../shared-package/khan-fetch.js")
var _ka=require("../../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var i18n=require("../../shared-package/i18n.js")
var Amounts=require("../amounts.js")
var _require=require("./util.jsx"),redirect=_require.redirect,startRequest=_require.startRequest
var INTERVAL_CODES={month:"M",year:"Y"}
function resolvePath(e){var t=document.location,n=t.protocol,r=t.host
return n+"//"+r+e}var PaypalRequest=function(){function e(t){var n=t.amountText,r=t.donorName,a=t.honoree,o=t.interval,i=t.returnPath
babelHelpers.classCallCheck(this,e)
this._amountText=n
this._donorName=r
this._honoree=a
this._interval=o
this._returnPath=i||"/donate"}e.prototype.start=function e(){var t=this
this._ensurePhantomUser().then(function(e){var n=e[0],r=e[1]
var a=Amounts.parse(t._amountText)
var o=a/100
var i=t._interval==="once"?"one-time":"monthly"
setTimeout(function(e,n){t.redirectToPayPal(e,n)},1e3)
var s=[]
if(o&&!isNaN(o)&&o<=Amounts.MAX_LOGGED_DONATION_VALUE){var u=t.markConversion(o,i)
s.push(u)
if(window.ga){var c=t.gaPromise(o,i)
s.push(c)}if(window.fbq){window.fbq("track","Purchase",{content_name:"Donation",content_category:"PayPal",content_type:i,value:o.toFixed(2),currency:"USD"})}}Promise.all(s).then(function(){t.redirectToPayPal(n,r)})})}
e.prototype.markConversion=function e(t,n){return _bigbingo2.default.markConversionsWithExtras([{id:"donation_banner_option_clicked",extra:{page:window.location.href,amount:t,frequency:n,source:"PayPal",kaid:_ka2.default.getKaid()}}])}
e.prototype.gaPromise=function e(t,n){return new Promise(function(e,r){window.ga("send","event","Donation","PayPal",n,t,{hitCallback:e})})}
e.prototype.redirectToPayPal=function e(t,n){redirect("https://www.paypal.com/cgi-bin/webscr","GET",babelHelpers.extends({business:"JBBC7SGTYUGK2",lc:"US",no_note:"1",no_shipping:"2",currency_code:"USD",bn:"PP-SubscriptionsBF:btn_subscribeCC_LG.gif:NonHosted",return:resolvePath(this._returnPath),custom:this._getCustomParam(t,n)},this._getIntervalParams()))}
e.prototype._getCustomParam=function e(t,n){return JSON.stringify({donor:{name:this._donorName,userId:t,kaid:n},honoree:{name:this._honoree.name,email:this._honoree.email},source:"/donate"})}
e.prototype._getIntervalParams=function e(){var t=Amounts.clean(this._amountText).replace("$","")
if(this._interval==="once"){return{cmd:"_donations",item_name:i18n._("One-time donation to Khan Academy"),src:"0",amount:t}}else{return{cmd:"_xclick-subscriptions",item_name:i18n._("Recurring donation to Khan Academy"),src:"1",t3:INTERVAL_CODES[this._interval],p3:"1",a3:t}}}
e.prototype._ensurePhantomUser=function e(){return(0,_khanFetch.khanFetch)("/api/internal/user/force_phantom",{method:"POST"}).then(function(e){return e.json()}).then(function(e){return[e.user_id,e.kaid]})}
return e}()
module.exports=function(e){return startRequest(PaypalRequest,e)}

});
KAdefine("javascript/donate-package/methods/stripe.js", function(require, module, exports) {
var _staticUrl=require("../../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _importFromExternalScript=require("../../shared-package/import-from-external-script.js")
var _importFromExternalScript2=babelHelpers.interopRequireDefault(_importFromExternalScript)
var _ka=require("../../shared-package/ka.js")
var _ka2=babelHelpers.interopRequireDefault(_ka)
var _bigbingo=require("../../shared-package/bigbingo.js")
var _bigbingo2=babelHelpers.interopRequireDefault(_bigbingo)
var i18n=require("../../shared-package/i18n.js")
var Amounts=require("../amounts.js")
var _require=require("./util.jsx"),redirect=_require.redirect,startRequest=_require.startRequest
function getPanelLabel(e){if(e==="month"){return i18n._("Give %(amount)s monthly",{amount:"{{amount}}"})}else{return i18n._("Give %(amount)s",{amount:"{{amount}}"})}}var StripeRequest=function(){function e(t){var r=this
var n=t.amountText,a=t.donorName,i=t.honoree,o=t.interval,s=t.returnPath
babelHelpers.classCallCheck(this,e)
this._amountText=n
this._donorName=a
this._honoree=i
this._interval=o
this._returnPath=s||"/donate"
this._handler=(0,_importFromExternalScript2.default)("https://checkout.stripe.com/checkout.js","StripeCheckout").then(function(e){return e.configure({key:_ka2.default.stripePublicKey,description:i18n._("Donation"),image:(0,_staticUrl2.default)("/images/donate/handtree.new.png"),name:i18n._("Khan Academy"),token:r._handleSuccess.bind(r),zipCode:true,billingAddress:true})})}e.prototype.start=function e(){var t=this
var r=Amounts.parse(this._amountText)
var n=r/100
if(n&&!isNaN(n)&&n<=Amounts.MAX_LOGGED_DONATION_VALUE){_bigbingo2.default.markConversionsWithExtras([{id:"donation_banner_option_clicked",extra:{page:window.location.href,amount:n,frequency:this._interval==="once"?"one-time":"monthly",source:"Credit Card",kaid:_ka2.default.getKaid()}}])}this._handler.then(function(e){return e.open({amount:r,panelLabel:getPanelLabel(t._interval)})})}
e.prototype.stop=function e(){this._handler.then(function(e){return e.close()})}
e.prototype._handleSuccess=function e(t){var r=Amounts.parse(this._amountText)
var n=r/100
var a=this._interval==="once"?"one-time":"monthly"
if(window.fbq){window.fbq("track","Purchase",{content_name:"Donation",content_category:"Stripe",content_type:a,value:n,currency:"USD"})}if(window.ga){window.ga("send","event","Donation","Stripe",a,n)}redirect("/donate/stripe","POST",{amount:this._amountText,name:this._donorName,recurring:this._interval==="once"?null:"on",interval:this._interval==="once"?null:this._interval,stripe_token:t.id,tribute:this._honoree.selected?"on":null,tribute_email:this._honoree.email,tribute_name:this._honoree.name,email:t.email,return_path:this._returnPath})}
return e}()
module.exports=function(e){return startRequest(StripeRequest,e)}

});
KAdefine("javascript/donate-package/methods/util.jsx", function(require, module, exports) {
var React=require("react")
var PropTypes=require("prop-types")
var ReactDOM=require("react-dom")
var RedirectForm=function(e){babelHelpers.inherits(r,e)
function r(){var t,a,o
babelHelpers.classCallCheck(this,r)
for(var n=arguments.length,s=Array(n),p=0;p<n;p++){s[p]=arguments[p]}return o=(t=(a=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(s))),a),a.submit=function(){a.refs.form.submit()},t),babelHelpers.possibleConstructorReturn(a,o)}r.prototype.render=function e(){var r=this
return React.createElement("form",{action:this.props.action,method:this.props.method,ref:"form"},Object.keys(this.props.params).map(function(e){return React.createElement("input",{key:e,name:e,type:"hidden",value:r.props.params[e]})}))}
return r}(React.Component)
RedirectForm.propTypes={action:PropTypes.string,method:PropTypes.oneOf(["GET","POST"]),params:PropTypes.any}
function redirect(e,r,t){var a=document.createElement("div")
document.body.appendChild(a)
var o=ReactDOM.render(React.createElement(RedirectForm,{action:e,method:r,params:t}),a)
o.submit()}function startRequest(e,r){var t=new e(r)
t.start()
return t}module.exports={redirect:redirect,startRequest:startRequest}

});
KAdefine("javascript/donate-package/modules/callout-module.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _calloutContainer,_babelHelpers$extends
var _aphrodite=require("aphrodite")
var _wonderBlocksColorV=require("@khanacademy/wonder-blocks-color-v1")
var _wonderBlocksColorV2=babelHelpers.interopRequireDefault(_wonderBlocksColorV)
var _link=require("../../components/link-package/link.jsx")
var _link2=babelHelpers.interopRequireDefault(_link)
var _staticUrl=require("../../shared-package/static-url.js")
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
function getAnnualReportCopy(e){return $_({year:e},"%(year)s annual report")}var CalloutModule=function(e){babelHelpers.inherits(a,e)
function a(){babelHelpers.classCallCheck(this,a)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}a.prototype.render=function e(){var a=$_(null,"Supporters page")
return React.createElement("div",{className:(0,_aphrodite.css)(styles.calloutContainer)},React.createElement("p",{className:(0,_aphrodite.css)(styles.calloutHeader)},this.props.newDonationsStrings?$_(null,"Khan Academy is a registered 501(c)(3) non-profit in the United States, and all gifts to us are tax deductible in the United States to the fullest extent allowed by law. Our Tax ID number is 26-1544963."):$_(null,"Khan Academy is a US tax-exempt 501(c)(3) non-profit organization (Tax ID Number: 26‑1544963). Your gift is tax-deductible as allowed by law."),React.createElement("br",null),React.createElement("br",null),$_({supporters:React.createElement(_link2.default,{href:"/about/our-supporters",style:[styles.mainLink]},a),annualReport:React.createElement(_link2.default,{href:"/annualreport",style:[styles.mainLink]},getAnnualReportCopy(2017)),olderAnnualReport:React.createElement(_link2.default,{href:"http://2016.khanacademyannualreport.org",style:[styles.mainLink]},getAnnualReportCopy(2016))},"To learn more about our generous donors, please visit our %(supporters)s. Click here for our %(annualReport)s and here for our %(olderAnnualReport)s.")))}
return a}(React.Component)
exports.default=CalloutModule
var styles=_aphrodite.StyleSheet.create({calloutContainer:(_calloutContainer={position:"relative",backgroundColor:_wonderBlocksColorV2.default.offWhite,backgroundImage:(0,_staticUrl.cssUrl)("/images/donate/crowd.svg"),backgroundSize:"cover",backgroundPosition:"50% bottom",paddingBottom:"calc(8vw + 20px)"},_calloutContainer[_mediaQueries2.default.xsOrSmaller]={paddingBottom:"calc(20vw + 20px)"},_calloutContainer),calloutHeader:babelHelpers.extends({},_globalStyles2.default.typography.bodyLarge,_globalStyles2.default.moduleLayout.defaultSpacing,(_babelHelpers$extends={maxWidth:560,margin:"auto",fontWeight:"normal",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale",lineHeight:1.35,color:_wonderBlocksColorV2.default.offBlack},_babelHelpers$extends[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({},_globalStyles2.default.typography.bodySmall,{fontWeight:"normal"}),_babelHelpers$extends)),mainLink:{borderBottom:"1px solid "+_wonderBlocksColorV2.default.offBlack,":hover":{textDecoration:"none"}}})

});
KAdefine("javascript/donate-package/modules/faq-module.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _babelHelpers$extends,_babelHelpers$extends2,_babelHelpers$extends3,_babelHelpers$extends4,_babelHelpers$extends5,_faqBodyMore
var _aphrodite=require("aphrodite")
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _link=require("../../components/link-package/link.jsx")
var _link2=babelHelpers.interopRequireDefault(_link)
var _staticUrl=require("../../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _absoluteLinks=require("../../shared-package/absolute-links.js")
var _absoluteLinks2=babelHelpers.interopRequireDefault(_absoluteLinks)
var _icon=require("../../shared-styles-package/icon.jsx")
var _icon2=babelHelpers.interopRequireDefault(_icon)
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_,$i18nDoNotTranslate=i18n.$i18nDoNotTranslate
var iconAngleDown={path:"M100.439 8.36q0 1.32-1.056 2.288l-46.816 46.904q-.968.968-2.376.968t-2.288-.968l-46.904-46.904q-.968-.968-.968-2.288t.968-2.376l5.104-5.016q.968-.968 2.288-.968t2.288.968l39.512 39.512 39.512-39.512q.968-.968 2.376-.968t2.288.968l5.016 5.016q1.056 1.056 1.056 2.376z",width:100,height:58.282}
var FrequentlyAskedQuestion=function(e){babelHelpers.inherits(t,e)
function t(){var a,n,l
babelHelpers.classCallCheck(this,t)
for(var r=arguments.length,o=Array(r),s=0;s<r;s++){o[s]=arguments[s]}return l=(a=(n=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),n),n.state={isOpen:false},n.toggleOpen=function(){n.setState({isOpen:!n.state.isOpen})},a),babelHelpers.possibleConstructorReturn(n,l)}t.prototype.render=function e(){var t=this.state.isOpen
return React.createElement("div",{className:(0,_aphrodite.css)(styles.faqWrapper)},React.createElement("div",{className:(0,_aphrodite.css)(styles.faqContainer)},React.createElement(_link2.default,{style:[styles.faqHeader],onClick:this.toggleOpen},React.createElement("h3",{className:(0,_aphrodite.css)(styles.faqQuestion)},this.props.question),React.createElement(_icon2.default,{className:(0,_aphrodite.css)(styles.faqArrow,t&&styles.faqArrowUp),icon:iconAngleDown,size:8})),t&&React.createElement("p",{className:(0,_aphrodite.css)(styles.faqBody)},this.props.children)),React.createElement("div",{className:(0,_aphrodite.css)(styles.dividerContainer)},React.createElement("hr",{className:(0,_aphrodite.css)(styles.dividerHorizontal)})))}
return t}(React.Component)
var OtherWaysToDonateOnline=function e(){return React.createElement("span",null,$_({square:React.createElement(_link2.default,{href:"https://cash.me/$khanacademy",style:[styles.link]},$i18nDoNotTranslate(null,"Square Cash")),facebook:React.createElement(_link2.default,{href:"https://www.facebook.com/khanacademy/",style:[styles.link]},$i18nDoNotTranslate(null,"Facebook"))},"Yes, we accept donations by cryptocurrency and %(square)s, and we also have a link to donate on our %(facebook)s page."),React.createElement("br",null),React.createElement("br",null),$_(null,"We also gladly accept Bitcoin (BTC), Bitcoin Cash (BCH), Litecoin (LTC), and Ethereum (ETH)."),React.createElement("br",null),React.createElement("br",null),$_(null,"Please use the following addresses to donate cryptocurrency."),React.createElement("br",null),React.createElement("br",null),$i18nDoNotTranslate(null,"Bitcoin (BTC): 1NpkkXRQaXg46btFK4Ugvu7rpGJTBybCqF"),React.createElement("br",null),$i18nDoNotTranslate(null,"Bitcoin Cash (BCH): 1GL5cFzFFAjBzjqdRz5Av3tQLuu2K6N9BL"),React.createElement("br",null),$i18nDoNotTranslate(null,"Litecoin (LTC): LSkMkREkg82yHygBucs3Y914UfBKZKLz9f"),React.createElement("br",null),$i18nDoNotTranslate(null,"Ethereum (ETH): 0x95a647B3d8a3F11176BAdB799b9499C671fa243a"),React.createElement("br",null),React.createElement("br",null),$_({amazon:React.createElement(_link2.default,{href:"http://smile.amazon.com/ch/26-1544963",style:[styles.link]},$i18nDoNotTranslate(null,"Amazon Smile"))},"Another way to have impact is to consider naming Khan Academy on your %(amazon)s account so that Amazon will donate a small amount of the purchases you make at no cost to you."),React.createElement("br",null),React.createElement("br",null),$_({email:React.createElement(_link2.default,{href:"mailto:donate@khanacademy.org",style:[styles.link]},$i18nDoNotTranslate(null,"donate@khanacademy.org"))},"Email %(email)s if you have any questions."))}
var FrequentlyAskedQuestions=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=React.createElement(_link2.default,{href:"mailto:donate@khanacademy.org",style:[styles.link]},$i18nDoNotTranslate(null,"donate@khanacademy.org"))
return React.createElement("span",null,React.createElement("h2",{className:(0,_aphrodite.css)(styles.faqTitle)},$_(null,"Frequently asked questions")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Can I send a check?")},$_(null,"Yes, please send checks to the following address:"),React.createElement("br",null),React.createElement("b",null,$i18nDoNotTranslate(null,"Khan Academy"),React.createElement("br",null),$i18nDoNotTranslate(null,"P.O. Box 1630"),React.createElement("br",null),$i18nDoNotTranslate(null,"Mountain View CA 94042")),React.createElement("br",null),React.createElement("br",null),$_(null,"Checks should be made payable to Khan Academy, and you should enclose a letter with your name, address, phone number, email address, and donation amount—we want to know who you are so we can show our gratitude for your support!")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Can I donate stock or make my donation by wire transfer? ")},$_({email:t},"Yes, we accept donations of stock and donations by domestic and international wire transfer. Please email %(email)s for our wire and stock transfer information.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Are there other ways to donate online, such "+"as cryptocurrency or Square Cash?")},React.createElement(OtherWaysToDonateOnline,null)),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Do you accept employer matches?")},$_({match:React.createElement(_link2.default,{href:"https://www.khanacademy.org/donate/match",style:[styles.link]},$_(null,"here"))},"Yes, we do. You’ll find more information on employer matched gifts %(match)s.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Can I donate in a currency other than US dollars?")},$_(null,"We only accept donations in US dollars. We cannot accept foreign cash or foreign checks. Since donations made using PayPal are automatically converted to US dollars, supporters outside the United States may want to donate using this method.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("What is the Learners Fund?")},this.props.newDonationsStrings?$_({email:t},"The Learners Fund is a select community of supporters who make unrestricted gifts of $1,000 to $99,999 each year. Interested in joining the Learners Fund and changing lives for millions of learners each month in more than 190 countries? Email us at %(email)s to learn more."):$_({email:t},"The Learners Fund is a new donor community that recognizes supporters who make unrestricted gifts of $1,000 to $99,999 in a calendar year. Interested in joining the Learners Fund? Email us at %(email)s.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("How do I update the credit card information on file for my recurring donation?")},React.createElement("u",null,$_(null,"If you make your recurring gift through PayPal:")),React.createElement("br",null),$_(null,"You can make changes within your PayPal account. Since donations are initiated from your PayPal account, Khan Academy is unfortunately unable to change or edit settings on your behalf."),React.createElement("br",null),React.createElement("br",null),React.createElement("u",null,$_(null,"If you make your recurring gift by credit card through our website:")),React.createElement("br",null),$_({noReply:React.createElement("u",null,$i18nDoNotTranslate(null,"no-reply@khanacademy.org"))},"Please cancel your current gift by following the link at the bottom of your monthly receipts from %(noReply)s, and then visit our donations page to start a new recurring donation with your updated credit card information.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("How do I change the amount of my recurring donation?")},React.createElement("u",null,$_(null,"If you make your recurring gift through PayPal:")),React.createElement("br",null),$_(null,"You can make changes within your PayPal account. Since donations are initiated from your PayPal account, Khan Academy is unfortunately unable to change or edit settings on your behalf."),React.createElement("br",null),React.createElement("br",null),React.createElement("u",null,$_(null,"If you make your recurring gift by credit card through our website:")),React.createElement("br",null),$_({noReply:React.createElement("u",null,$i18nDoNotTranslate(null,"no-reply@khanacademy.org"))},"Please cancel your current gift by following the link at the bottom of your monthly receipts from %(noReply)s, and then visit our donations page to start a new recurring donation with the new donation amount.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("How do I cancel my recurring donation?")},$_({noReply:React.createElement("u",null,$i18nDoNotTranslate(null,"no-reply@khanacademy.org"))},"To cancel your recurring donation, follow the cancellation link at the bottom of your monthly receipts from %(noReply)s. You may cancel your recurring donation at any time.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Is my donation tax deductible?")},this.props.newDonationsStrings?$_(null,"We are a registered 501(c)(3) non-profit in the United States, and all gifts to us are tax deductible in the United States to the fullest extent allowed by law. Our Tax ID number is 26-1544963."):$_(null,"We are a registered 501(c)(3) non-profit in the United States, and all gifts to us are tax deductible to the fullest extent allowed by law. Our Tax ID number is 26-1544963.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("Where is my donation receipt?")},$_({noReply:React.createElement("u",null,$i18nDoNotTranslate(null,"no-reply@khanacademy.org"))},"If you made your gift on our site either by credit card or PayPal, please check your email. We send donation receipts—from %(noReply)s—to the email address you provided when making the donation. If you signed up to make a recurring donation, you will be sent an individual receipt each month when your donation is processed.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("I want to make sure my gift is making a difference. Where can I find information about how Khan Academy uses its funds?")},$_({report:React.createElement(_link2.default,{href:"https://www.khanacademy.org/annualreport",style:[styles.link]},$_(null,"annual report"))},"We like our supporters to be 100 percent in the loop about how Khan Academy uses donations. Take a look at our most recent %(report)s for the details about Khan Academy’s finances.")),React.createElement(FrequentlyAskedQuestion,{question:i18n._("How do I verify Khan Academy’s charitable registration compliance for each state?")},React.createElement("a",{href:_absoluteLinks2.default.safeLinkTo("http://www.fundraisingregistration.com/index.php?key=13f320e7b5ead1024ac95c3b208610db&s=l"),target:"_blank"},React.createElement("img",{alt:"state charitable fundraising registration",title:"Khan Academy, Inc. is committed to full compliance with state charitable registration statutes. Click here for a list of registration states and required state disclaimers.",src:(0,_staticUrl2.default)("/images/donate/seal-of-compliance.png"),width:"198",height:"198"}))),React.createElement("div",{className:(0,_aphrodite.css)(styles.faqMore)},React.createElement("p",{className:(0,_aphrodite.css)(styles.faqBody,styles.faqBodyMore)},$_({email:t},"If you have any other donation related questions not answered here, please email %(email)s. If you have a question related to a recent donation, please include your first and last name and the email address used when making the donation.")),React.createElement("p",{className:(0,_aphrodite.css)(styles.faqBody,styles.faqBodyMore)},$_({help:React.createElement(_link2.default,{href:"https://khanacademy.zendesk.com/",style:[styles.link]},$_(null,"Help center"))},"For all other inquiries not related to donations, such as help re-setting passwords, please visit the %(help)s."))))}
return t}(React.Component)
exports.default=FrequentlyAskedQuestions
var styles=_aphrodite.StyleSheet.create({faqTitle:babelHelpers.extends({},_globalStyles2.default.typography.conceptHeadingDesktop,_globalStyles2.default.moduleLayout.defaultAlignment,_globalStyles2.default.moduleLayout.defaultSpacing,(_babelHelpers$extends={marginBottom:0,color:_globalStyles2.default.colors.gray17,maxWidth:1160},_babelHelpers$extends[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({},_globalStyles2.default.typography.conceptHeadingMobile),_babelHelpers$extends)),faqWrapper:{marginBottom:24,maxWidth:1160,paddingLeft:20,paddingRight:20,marginLeft:"auto",marginRight:"auto"},faqContainer:babelHelpers.extends({},_globalStyles2.default.moduleLayout.defaultAlignment,_globalStyles2.default.moduleLayout.defaultSpacing,(_babelHelpers$extends2={padding:0},_babelHelpers$extends2[_mediaQueries2.default.mdOrSmaller]={padding:0},_babelHelpers$extends2)),faqHeader:{display:"flex",justifyContent:"space-between",cursor:"pointer",userSelect:"none"},faqQuestion:babelHelpers.extends({},_globalStyles2.default.typography.bodyLarge,(_babelHelpers$extends3={flex:1,maxWidth:660,color:_globalStyles2.default.colors.gray17},_babelHelpers$extends3[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({},_globalStyles2.default.typography.bodySmall),_babelHelpers$extends3)),faqArrow:{marginTop:10,marginLeft:10,color:_globalStyles2.default.colors.gray85},faqArrowUp:{transform:"scale(1, -1)",color:_globalStyles2.default.colors.kaBlueHover},faqBody:babelHelpers.extends({},_globalStyles2.default.typography.bodySmall,(_babelHelpers$extends4={maxWidth:660,marginTop:0,color:"#191b21"},_babelHelpers$extends4[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({},_globalStyles2.default.typography.bodyXsmall),_babelHelpers$extends4)),faqMore:babelHelpers.extends({},_globalStyles2.default.moduleLayout.defaultAlignment,_globalStyles2.default.moduleLayout.defaultSpacing,(_babelHelpers$extends5={display:"flex",paddingTop:30,paddingBottom:30},_babelHelpers$extends5[_mediaQueries2.default.mdOrSmaller]={flexDirection:"column",paddingTop:20,paddingBottom:20},_babelHelpers$extends5)),faqBodyMore:(_faqBodyMore={flex:1},_faqBodyMore[_mediaQueries2.default.lgOrLarger]={":first-child":{paddingRight:30},":not(:first-child)":{paddingLeft:30}},_faqBodyMore),dividerContainer:babelHelpers.extends({},_globalStyles2.default.moduleLayout.defaultAlignment),dividerHorizontal:{borderColor:_globalStyles2.default.colors.gray85,borderStyle:"solid",borderWidth:"0 0 1px",boxShadow:"none",height:0,margin:0},link:{color:_globalStyles2.default.colors.kaBlueHover}})

});
KAdefine("javascript/donate-package/modules/footer.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _footerContainer,_footerCaption,_babelHelpers$extends
var _aphrodite=require("aphrodite")
var _link=require("../../components/link-package/link.jsx")
var _link2=babelHelpers.interopRequireDefault(_link)
var _globalStyles=require("../../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var React=require("react")
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_,$i18nDoNotTranslate=i18n.$i18nDoNotTranslate
var Footer=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){return React.createElement("div",{className:(0,_aphrodite.css)(styles.footerContainer)},React.createElement("div",{className:(0,_aphrodite.css)(styles.footerCaption)},$_(null,"Get in touch.")),React.createElement("div",{className:(0,_aphrodite.css)(styles.footerContent)},React.createElement(_link2.default,{href:"donate@khanacademy.org"},$i18nDoNotTranslate(null,"donate@khanacademy.org")),React.createElement("br",null),React.createElement("br",null),$i18nDoNotTranslate(null,"P.O. Box 1630"),React.createElement("br",null),$i18nDoNotTranslate(null,"Mountain View, CA 94042")))}
return t}(React.Component)
exports.default=Footer
var styles=_aphrodite.StyleSheet.create({footerContainer:(_footerContainer={display:"flex",alignItems:"center",padding:"28px 0",backgroundColor:"#5f9abc",color:_globalStyles2.default.colors.white},_footerContainer[_mediaQueries2.default.mdOrSmaller]={flexDirection:"column"},_footerContainer),footerCaption:(_footerCaption={flex:1,paddingRight:32,fontSize:42,lineHeight:"145px",textAlign:"right",borderRight:"1px solid "+_globalStyles2.default.colors.white},_footerCaption[_mediaQueries2.default.mdOrSmaller]={width:"50%",paddingRight:0,paddingBottom:16,fontSize:21,lineHeight:"26px",textAlign:"center",borderRight:"none",borderBottom:"1px solid "+_globalStyles2.default.colors.white},_footerCaption),footerContent:babelHelpers.extends({},_globalStyles2.default.typography.bodySmall,(_babelHelpers$extends={flex:1,paddingLeft:32,lineHeight:1},_babelHelpers$extends[_mediaQueries2.default.mdOrSmaller]=babelHelpers.extends({},_globalStyles2.default.typography.bodyXsmall,{paddingLeft:0,paddingTop:16,lineHeight:1,textAlign:"center"}),_babelHelpers$extends))})

});
KAdefine("javascript/donate-package/modules/thank-you-module.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _videoModule,_videoHeader,_smVideoHeader,_videoText,_videoPreview
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _aphrodite=require("aphrodite")
var _staticUrl=require("../../shared-package/static-url.js")
var _icon=require("../../shared-styles-package/icon.jsx")
var _icon2=babelHelpers.interopRequireDefault(_icon)
var _lazyLoadComponent=require("../../components/lazy-load-package/lazy-load-component.jsx")
var _lazyLoadComponent2=babelHelpers.interopRequireDefault(_lazyLoadComponent)
var _mediaQueries=require("../../shared-styles-package/media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var i18n=require("../../shared-package/i18n.js")
var $_=i18n.$_
var playIcon="M1.6,9.9C1.5,10,1.3,10,1.2,10C1.1,10,1,10,0.9,9.9C0.7,9.8,0.6,9.6,\n    0.6,9.4V0.6c0-0.2,0.2-0.4,0.4-0.5C1.1,0,1.4,0,1.6,0.1l7.6,4.5c0.2,0.1,\n    0.3,0.3,0.3,0.5c0,0.2-0.1,0.4-0.3,0.5L1.6,9.9z"
var ThankYouModule=function(e){babelHelpers.inherits(a,e)
function a(){var t,i,o
babelHelpers.classCallCheck(this,a)
for(var r=arguments.length,l=Array(r),n=0;n<r;n++){l[n]=arguments[n]}return o=(t=(i=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(l))),i),i.state={videoVisible:false},i.handlePlayButtonClick=function(){i.setState({videoVisible:true})},i.handleVideoClosed=function(){i.setState({videoVisible:false})},t),babelHelpers.possibleConstructorReturn(i,o)}a.prototype.render=function e(){var a=this
var t=this.state.videoVisible
var i=this.props.thankYouVideo
if(!i){return null}var o={id:i.contentId,kind:i.kind,kaUrl:i.kaUrl,readableId:i.readableId,translatedTitle:i.title,translatedYoutubeId:i.translatedYoutubeId,youtubeId:i.youtubeId}
return React.createElement("div",{id:"thank-you",className:(0,_aphrodite.css)(styles.videoModule)},React.createElement("div",{className:(0,_aphrodite.css)(styles.videoText)},React.createElement("h2",{className:(0,_aphrodite.css)(styles.videoHeader)},$_(null,"Give the gift of life-changing education!")),React.createElement("p",{className:(0,_aphrodite.css)(styles.videoCopy)},$_(null,"Anjali lives with her family in a one-room tenement in India, but dreams of changing the world. Learn how she’s using Khan Academy to get there."))),React.createElement("div",{className:(0,_aphrodite.css)(styles.videoPreview),onClick:this.handlePlayButtonClick},React.createElement("div",{className:(0,_aphrodite.css)(styles.playButtonContainer)},React.createElement("button",{"aria-label":i18n._("Play video"),className:(0,_aphrodite.css)(styles.playButton),onClick:this.handlePlayButtonClick,style:styles.playButton},React.createElement(_icon2.default,{icon:playIcon,size:44,color:"#fff"})))),React.createElement("h2",{className:(0,_aphrodite.css)(styles.smVideoHeader)},$_(null,"Give the gift of life-changing education!")),t&&React.createElement(_lazyLoadComponent2.default,{load:function e(){return[require.dynimport("../../components/modal-package/video-modal.jsx"),require.dynimport("../../apollo-package/apollo-wrapper.jsx")]},loadingIndicator:function e(){return React.createElement("span",null)}},function(e,t){return React.createElement(t,null,React.createElement(e,{title:o.translatedTitle,video:o,shouldAutoplay:true,footer:null,linkToContent:false,onClose:a.handleVideoClosed,shouldAnimate:true}))}))}
return a}(React.Component)
exports.default=ThankYouModule
var styles=_aphrodite.StyleSheet.create({videoModule:(_videoModule={maxWidth:1200,display:"flex",margin:"auto",padding:"64px 0"},_videoModule[_mediaQueries2.default.smOrSmaller]={flexDirection:"column-reverse",padding:"32px 0"},_videoModule),videoCopy:{lineHeight:1.35,fontSize:17},videoHeader:(_videoHeader={fontSize:23,color:"black"},_videoHeader[_mediaQueries2.default.smOrSmaller]={display:"none"},_videoHeader),smVideoHeader:(_smVideoHeader={fontSize:23,color:"black",textAlign:"center"},_smVideoHeader[_mediaQueries2.default.mdOrLarger]={display:"none"},_smVideoHeader),videoText:(_videoText={flex:1,marginLeft:20,marginRight:152},_videoText[_mediaQueries2.default.mdOrSmaller]={marginRight:20},_videoText.marginTop="auto",_videoText.marginBottom="auto",_videoText),videoPreview:(_videoPreview={height:252,width:448,marginRight:20,display:"inline-block",background:"black",color:"white",backgroundImage:(0,_staticUrl.cssUrl)("/images/donate/mid-year-video-thumbnail.png"),backgroundSize:"cover",position:"relative"},_videoPreview[_mediaQueries2.default.smOrSmaller]={margin:"auto"},_videoPreview[_mediaQueries2.default.mdOrSmaller]={height:194,width:344},_videoPreview),playButtonContainer:{position:"absolute",left:0,right:0,top:0,bottom:0,transition:"background-color 200ms ease-in-out",":hover":{backgroundColor:"rgba(0, 0, 0, 0.2)"},backgroundColor:"rgba(0, 0, 0, 0)",alignItems:"center",cursor:"pointer",display:"flex",justifyContent:"center"},playButton:{border:"1px solid white",borderRadius:"50%",boxShadow:"0 0 1px 1px white",cursor:"pointer",height:82,padding:"0 0 0 10px",width:82,backgroundColor:"#10adcd"},missionSummary:{marginBottom:12}})

});
KAdefine("javascript/donate-package/mission.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _largeFont,_largeFontBold,_smallFont,_babelHelpers$extends,_mission,_missionImage,_missionThermometer,_desktopThermometer,_mobileThermometer,_paragraphWithThermom,_missionText,_missionTextBlock,_missionTextBlockWith
var _aphrodite=require("aphrodite")
var _staticUrl=require("../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var _globalStyles=require("../shared-styles-package/global-styles.js")
var _globalStyles2=babelHelpers.interopRequireDefault(_globalStyles)
var _thermometer=require("./thermometer.jsx")
var _thermometer2=babelHelpers.interopRequireDefault(_thermometer)
var _styles=require("./styles.js")
var React=require("react")
var i18n=require("../shared-package/i18n.js")
var formContextIsBanner=function e(t){return t.startsWith("banner")}
var KADonateLogo=function e(){return React.createElement("svg",{className:(0,_aphrodite.css)(styles.logo),"aria-hidden":true,width:"176px",height:"28px",viewBox:"0 0 176 28"},React.createElement("path",{d:"M33.66,6.5A.54.54,0,0,1,34.21,6h2a.55.55,0,0,1,.55.55v6.2l5.79-6.52A.53.53,0,0,1,43,6h2.3a.48.48,0,0,1,.36.82l-6,6.75,6.43,7.69a.51.51,0,0,1-.41.81h-2.5a.55.55,0,0,1-.42-.16l-6-7.4v7a.56.56,0,0,1-.55.56h-2a.55.55,0,0,1-.55-.56Z"}),React.createElement("path",{d:"M47.78,6.45a.54.54,0,0,1,.5-.5h1.86a.52.52,0,0,1,.51.5v5.63a4.07,4.07,0,0,1,2.7-.9c3.38,0,4.3,2.34,4.3,5v5.32a.53.53,0,0,1-.51.51H55.28a.51.51,0,0,1-.5-.51V16.16c0-1.47-.67-2.36-1.93-2.36a2.18,2.18,0,0,0-2.2,1.86v5.85c0,.3-.14.51-.56.51H48.28a.52.52,0,0,1-.5-.51Z"}),React.createElement("path",{d:"M63.48,15.31a7.7,7.7,0,0,1,2,.3c0-1.35-.34-2-1.47-2a13.49,13.49,0,0,0-3,.39c-.35.12-.55-.13-.6-.45l-.23-1.2a.48.48,0,0,1,.34-.64,13.49,13.49,0,0,1,3.63-.53c3.31,0,4,1.72,4,4.62v5.71a.51.51,0,0,1-.51.51h-.78c-.18,0-.32-.07-.46-.37l-.3-.71a4.66,4.66,0,0,1-3.33,1.33,3.38,3.38,0,0,1-3.58-3.63C59.25,16.76,60.79,15.31,63.48,15.31Zm.07,4.82A2.27,2.27,0,0,0,65.45,19V17.45a4.23,4.23,0,0,0-1.56-.32c-1.22,0-1.88.57-1.88,1.51A1.4,1.4,0,0,0,63.55,20.13Z"}),React.createElement("path",{d:"M70.59,11.92a.51.51,0,0,1,.51-.51H72a.42.42,0,0,1,.44.32l.39,1a4.26,4.26,0,0,1,3.42-1.54c3.37,0,4.24,2.27,4.24,4.84v5.49A.52.52,0,0,1,80,22H78.1a.51.51,0,0,1-.51-.51V16c0-1.37-.55-2.22-1.83-2.22a2.34,2.34,0,0,0-2.3,1.65v6.06c0,.39-.16.51-.66.51H71.1a.53.53,0,0,1-.51-.51Z"}),React.createElement("path",{d:"M85.89,21.42,93,6a.4.4,0,0,1,.39-.25h.23A.39.39,0,0,1,94,6l7.07,15.45a.41.41,0,0,1-.39.6h-2a.66.66,0,0,1-.67-.46l-1.12-2.48H90.07l-1.13,2.48a.69.69,0,0,1-.66.46h-2A.4.4,0,0,1,85.89,21.42Zm9.91-4.89-2.29-5.05h-.07l-2.25,5.05Z"}),React.createElement("path",{d:"M107,11.18A5.24,5.24,0,0,1,111,13c.23.23.12.53-.11.76l-1,1.06c-.23.25-.48.13-.69-.07a2.84,2.84,0,0,0-2.11-.92,2.78,2.78,0,0,0-2.8,2.91,2.77,2.77,0,0,0,2.78,2.94,2.81,2.81,0,0,0,2.25-1.17.5.5,0,0,1,.66-.07l1,.87c.25.23.37.49.18.76a4.75,4.75,0,0,1-4.2,2.23,5.55,5.55,0,1,1,0-11.09Z"}),React.createElement("path",{d:"M116.83,15.31a7.82,7.82,0,0,1,2,.3c0-1.35-.35-2-1.47-2a13.5,13.5,0,0,0-3,.39c-.34.12-.55-.13-.59-.45l-.23-1.2a.48.48,0,0,1,.34-.64,13.49,13.49,0,0,1,3.63-.53c3.3,0,4,1.72,4,4.62v5.71a.51.51,0,0,1-.5.51h-.78c-.19,0-.32-.07-.46-.37l-.3-.71a4.68,4.68,0,0,1-3.33,1.33,3.38,3.38,0,0,1-3.58-3.63C112.61,16.76,114.15,15.31,116.83,15.31Zm.07,4.82A2.29,2.29,0,0,0,118.81,19V17.45a4.23,4.23,0,0,0-1.56-.32c-1.22,0-1.88.57-1.88,1.51A1.39,1.39,0,0,0,116.9,20.13Z"}),React.createElement("path",{d:"M128.62,11.18a7.67,7.67,0,0,1,2.55.44V6.45a.54.54,0,0,1,.5-.5h1.86a.52.52,0,0,1,.51.5V21.51a.51.51,0,0,1-.51.51h-.85c-.25,0-.41-.21-.5-.51l-.28-.83a4.55,4.55,0,0,1-3.46,1.59c-2.9,0-5.08-2.34-5.08-5.56A5.21,5.21,0,0,1,128.62,11.18Zm2.55,3.22a4.18,4.18,0,0,0-2.21-.6,2.68,2.68,0,0,0-2.64,2.91c0,1.5.85,2.94,2.51,2.94a2.43,2.43,0,0,0,2.34-1.47Z"}),React.createElement("path",{d:"M141.22,11.18a4.75,4.75,0,0,1,4.87,4.91c0,.16,0,.53-.05.69a.53.53,0,0,1-.5.48h-6.8a2.55,2.55,0,0,0,2.64,2.46,3.49,3.49,0,0,0,2.27-.78c.26-.21.53-.23.69,0l.9,1.19a.45.45,0,0,1-.05.69,6,6,0,0,1-3.95,1.45,5.37,5.37,0,0,1-5.37-5.56A5.37,5.37,0,0,1,141.22,11.18Zm2,4.2a1.94,1.94,0,0,0-2-1.83,2.11,2.11,0,0,0-2.25,1.83Z"}),React.createElement("path",{d:"M147.79,11.92a.51.51,0,0,1,.5-.51h.83a.4.4,0,0,1,.43.3l.39,1a4,4,0,0,1,3.24-1.54,3.61,3.61,0,0,1,3.17,1.61,4.53,4.53,0,0,1,3.42-1.61c3.39,0,4.2,2.16,4.2,4.91v5.42a.52.52,0,0,1-.53.51H161.6a.51.51,0,0,1-.5-.51V16c0-1.37-.51-2.22-1.84-2.22a2,2,0,0,0-2,1.1s0,.53,0,1v5.6a.52.52,0,0,1-.5.51H155a.5.5,0,0,1-.51-.51V16c0-1.37-.39-2.22-1.74-2.22a2.1,2.1,0,0,0-2,1.65v6.06a.52.52,0,0,1-.5.51h-1.86a.52.52,0,0,1-.5-.51Z"}),React.createElement("path",{d:"M165.07,12.1a.47.47,0,0,1,.46-.69h2.2a.42.42,0,0,1,.44.3l1.9,6.33h.05l2.41-6.33c.16-.28.34-.3.67-.3h2a.47.47,0,0,1,.46.69l-6.25,15.06a.53.53,0,0,1-.46.32h-2.2a.48.48,0,0,1-.46-.71l2.13-5.37Z"}),React.createElement("path",{fill:"#14bf96",d:"M2.31,5.8A3.56,3.56,0,0,0,.66,8.6V19.4a3.56,3.56,0,0,0,1.65,2.8L12,27.62a3.75,3.75,0,0,0,3.3,0L25,22.2a3.56,3.56,0,0,0,1.65-2.8V8.6A3.56,3.56,0,0,0,25,5.8L15.31.38a3.75,3.75,0,0,0-3.3,0Z"}),React.createElement("path",{fill:"#ffffff",d:"M23.61,11.32c-5.38,0-9.4,4.46-9.4,9.93v.23H13.13v-.23c0-5.47-4-9.91-9.42-9.93,0,.34,0,.69,0,1a9.91,9.91,0,0,0,6.4,9.32,10.47,10.47,0,0,0,3.59.64,10.64,10.64,0,0,0,3.62-.64,9.92,9.92,0,0,0,6.39-9.32C23.66,12,23.64,11.66,23.61,11.32Z"}),React.createElement("circle",{fill:"#ffffff",cx:"13.66",cy:"8.74",r:"3"}))}
var Mission=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=this
var a=formContextIsBanner(this.props.formContext)
return React.createElement("div",{className:(0,_aphrodite.css)(styles.mission)+" "+this.props.className},this.props.imageRelativeUrl&&!this.props.thermometer&&React.createElement("img",{alt:i18n._("Piggy bank"),className:(0,_aphrodite.css)(styles.missionImage),src:(0,_staticUrl2.default)(this.props.imageRelativeUrl)}),this.props.thermometer&&React.createElement("div",{className:(0,_aphrodite.css)(styles.missionThermometer,styles.desktopThermometer)},React.createElement(_thermometer2.default,babelHelpers.extends({},this.props.thermometer,{key:this.props.thermometer.current.amountText}))),React.createElement("div",{className:(0,_aphrodite.css)(styles.missionTextBlock,a&&styles.missionTextBlockWithLogo)},React.createElement("div",null,a&&React.createElement(KADonateLogo,null),this.props.paragraphs.map(function(e,a){var s=e.text,r=e.style
var i=React.createElement("p",{className:(0,_aphrodite.css)(styles.missionText)+" "+(0,_aphrodite.css)(missionStyles[r]),key:a,dangerouslySetInnerHTML:{__html:s}})
if(t.props.thermometer&&a===1){return React.createElement("div",{key:a,className:(0,_aphrodite.css)(styles.paragraphWithThermometer)},i,React.createElement("div",{className:(0,_aphrodite.css)(styles.missionThermometer,styles.mobileThermometer)},React.createElement(_thermometer2.default,babelHelpers.extends({},t.props.thermometer,{key:t.props.thermometer.current.amountText}))))}return i}))))}
return t}(React.Component)
Mission.defaultProps={className:""}
exports.default=Mission
var missionStyles=_aphrodite.StyleSheet.create({largeFont:(_largeFont={fontSize:"20px"},_largeFont[_styles.isNarrowMobile]={fontSize:"15px",fontWeight:"bold"},_largeFont),largeFontBold:(_largeFontBold={fontSize:"20px",fontWeight:"bold"},_largeFontBold[_styles.isNarrowMobile]={fontSize:"15px"},_largeFontBold),smallFont:(_smallFont={fontSize:19,lineHeight:1.45},_smallFont[_styles.is768OrLess]={fontSize:16},_smallFont),headingFont:babelHelpers.extends({},_globalStyles2.default.typography.conceptHeadingDesktop,(_babelHelpers$extends={fontSize:36,fontWeight:900},_babelHelpers$extends[_styles.isSmallDesktop]={fontSize:31},_babelHelpers$extends[_styles.isNarrowMobile]=babelHelpers.extends({},_globalStyles2.default.typography.conceptHeadingMobile),_babelHelpers$extends))})
var styles=_aphrodite.StyleSheet.create({mission:(_mission={alignItems:"flex-start",display:"flex",flexDirection:"row",height:"100%",justifyContent:"space-around",marginBottom:"auto"},_mission[_styles.isDesktop]={boxSizing:"border-box",height:"100%",width:"50%"},_mission[_styles.isMobile]={marginLeft:"auto",marginRight:"auto",maxWidth:800,paddingBottom:15,width:"100%",flexDirection:"row-reverse !important"},_mission),missionImage:(_missionImage={flexShrink:0,borderRadius:4,marginTop:4,marginRight:30,width:150},_missionImage[_styles.isDesktop]={maxWidth:200,marginLeft:20,flex:1},_missionImage[_styles.isMobile]={marginRight:0,marginLeft:16},_missionImage[_styles.isNarrowMobile]={display:"none"},_missionImage),missionThermometer:(_missionThermometer={flexShrink:0,marginRight:30,marginTop:14,width:64,height:128,position:"relative"},_missionThermometer[_styles.isDesktop]={width:158,marginLeft:-14,height:256,marginRight:15},_missionThermometer[_styles.isMobile]={marginRight:28,marginLeft:-52},_missionThermometer),desktopThermometer:(_desktopThermometer={},_desktopThermometer[_styles.isNarrowMobile]={display:"none"},_desktopThermometer),mobileThermometer:(_mobileThermometer={marginTop:0,marginBottom:-20,display:"none"},_mobileThermometer[_styles.isNarrowMobile]={display:"block"},_mobileThermometer),paragraphWithThermometer:(_paragraphWithThermom={margin:"22px 0"},_paragraphWithThermom[_styles.isMobile]={display:"flex"},_paragraphWithThermom),missionText:(_missionText={textAlign:"left",":last-of-type":{marginBottom:0}},_missionText[_styles.isDesktop]={fontSize:"1.5rem",marginLeft:"auto",marginRight:0,marginTop:0},_missionText[_styles.isMobile]={fontSize:"1rem",marginTop:0},_missionText),missionTextBlock:(_missionTextBlock={flexShrink:1,height:"100%",maxWidth:"100%",marginTop:16},_missionTextBlock[_styles.isDesktop]={maxWidth:304},_missionTextBlock),missionTextBlockWithLogo:(_missionTextBlockWith={marginTop:0},_missionTextBlockWith[_styles.isMobile]={marginTop:16},_missionTextBlockWith),logo:{marginBottom:16,fill:"white",":hover":{color:"white"}}})

});
KAdefine("javascript/donate-package/styles.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
exports.isSmallDesktop=exports.isNarrowMobile=exports.is768OrLess=exports.formComponentRadiusPx=exports.buttonBaseWidth=exports.semiTransparent=exports.bannerColors=exports.legacyColors=exports.isDesktop=exports.isMobile=exports.formPaddingPx=undefined
var _mediaQueries=require("./media-queries.js")
var _mediaQueries2=babelHelpers.interopRequireDefault(_mediaQueries)
var formPaddingPx=exports.formPaddingPx=12
var isMobile=exports.isMobile="@media screen and (max-width: 1023px)"
var isDesktop=exports.isDesktop="@media screen and (min-width: 1023.5px)"
var legacyColors=exports.legacyColors={blue:"#2d5a74",lightBlue:"rgba(255, 255, 255, 0.15)"}
var bannerColors=exports.bannerColors={blue:"#011a47",lightBlue:"#1865f2"}
var semiTransparent=exports.semiTransparent="rgba(255, 255, 255, 0.15)"
var buttonBaseWidth=exports.buttonBaseWidth="100%"
var formComponentRadiusPx=exports.formComponentRadiusPx=4
var is768OrLess=exports.is768OrLess=_mediaQueries2.default.screen.and("(max-width: 768px)")
var isNarrowMobile=exports.isNarrowMobile=_mediaQueries2.default.screen.and("(max-width: 550px)")
var isSmallDesktop=exports.isSmallDesktop=_mediaQueries2.default.screen.and("(max-width: 1067px)")

});
KAdefine("javascript/donate-package/thermometer.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _label,_thermometer
var _aphrodite=require("aphrodite")
var _amounts=require("./amounts.js")
var _thermometerAssets=require("./thermometer-assets.js")
var _styles=require("./styles.js")
var React=require("react")
var i18n=require("../shared-package/i18n.js")
var ANIMATION_DELAY=1200
var ANIMATION_TIME=1e3
var ThermometerFlask=function e(){return React.createElement("svg",{className:(0,_aphrodite.css)(styles.layer),viewBox:_thermometerAssets.SVG_LAYER_VIEWBOX},React.createElement("path",{className:(0,_aphrodite.css)(styles.flask),d:_thermometerAssets.FLASK_SVG_PATH}))}
var ThermometerNotches=function e(){return React.createElement("svg",{className:(0,_aphrodite.css)(styles.layer),viewBox:_thermometerAssets.SVG_LAYER_VIEWBOX},React.createElement("path",{className:(0,_aphrodite.css)(styles.notches),d:_thermometerAssets.NOTCHES_SVG_PATH}))}
var ThermometerFill=function e(t){var r=t.pct
return React.createElement("div",{className:(0,_aphrodite.css)(styles.layerFill),style:{height:r*100+"%"}})}
var Thermometer=function(e){babelHelpers.inherits(t,e)
function t(){var r,s,a
babelHelpers.classCallCheck(this,t)
for(var l=arguments.length,o=Array(l),i=0;i<l;i++){o[i]=arguments[i]}return a=(r=(s=babelHelpers.possibleConstructorReturn(this,e.call.apply(e,[this].concat(o))),s),s.state={visualPct:0,amountVisible:false},r),babelHelpers.possibleConstructorReturn(s,a)}t.prototype.componentDidMount=function e(){var t=this
setTimeout(function(){setTimeout(function(){t.setState(t.getDerivedState(t.props))
setTimeout(function(){t.setState({amountVisible:true})},ANIMATION_TIME*1.2)},ANIMATION_DELAY)},0)}
t.prototype.UNSAFE_componentWillReceiveProps=function e(t){if(this.props.current.amountText!==t.current.amountText||this.props.current.label!==t.current.label||this.props.target.amountText!==t.target.amountText||this.props.target.label!==t.target.label){this.setState(this.getDerivedState(t))}}
t.prototype.getDerivedState=function e(t){var r=this.props,s=r.current,a=r.target
var l=(0,_amounts.parse)(s.amountText)
var o=(0,_amounts.parse)(a.amountText)
return{visualPct:Math.min(l/o,1)*(_thermometerAssets.FILL_MAX_FILL-_thermometerAssets.FILL_MIN_FILL)+_thermometerAssets.FILL_MIN_FILL}}
t.prototype.render=function e(){var t=this.props,r=t.current,s=t.target,a=t.className
var l=this.state,o=l.visualPct,i=l.amountVisible
var n=i18n._("So far, we've raised $%(amount)s of our $%(target)s target!",{amount:r.label,target:s.label})
return React.createElement("div",{className:a||"",title:n,"aria-label":n},React.createElement("span",{className:(0,_aphrodite.css)(styles.thermometer)},i&&React.createElement("span",{className:(0,_aphrodite.css)(styles.label,o<.323&&styles.labelLow),style:{bottom:o*100+"%"}},r.label),o<_thermometerAssets.FILL_MAX_FILL-.071&&React.createElement("span",{className:(0,_aphrodite.css)(styles.label,styles.target),style:{bottom:_thermometerAssets.FILL_MAX_FILL*100+"%"}},s.label),React.createElement(ThermometerFlask,null),React.createElement(ThermometerFill,{pct:o}),React.createElement(ThermometerNotches,null)))}
return t}(React.Component)
exports.default=Thermometer
var styles=_aphrodite.StyleSheet.create({label:(_label={color:"white",position:"absolute",left:-80,width:85,textAlign:"right",lineHeight:0},_label[_styles.isMobile]={display:"none"},_label),labelLow:{width:80},target:{opacity:.64},thermometer:(_thermometer={position:"absolute",left:60,width:64,height:256},_thermometer[_styles.isMobile]={width:32,height:128},_thermometer),layer:{position:"absolute",left:0,bottom:0,width:"100%",height:"100%"},flask:{fill:"white"},notches:{fill:"#0A2A66",zIndex:1},layerFill:{position:"absolute",left:0,bottom:0,width:"100%",background:"url("+_thermometerAssets.FILL_BASE64+") no-repeat left bottom",backgroundSize:"cover",transition:ANIMATION_TIME+"ms height ease-in-out"}})

});
KAdefine("javascript/donate-package/thermometer-assets.js", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var SVG_LAYER_VIEWBOX=exports.SVG_LAYER_VIEWBOX="0 0 64 256"
var FLASK_SVG_PATH=exports.FLASK_SVG_PATH="M48,196.3c9.6,5.5,16,15.9,16,27.7c0,17.7-14.3,32-32,32S0,241.7,0,224c0-11.8,6.4-22.2,16-27.7L16,16c0-8.8,7.2-16,16-16s16,7.2,16,16L48,196.3L48,196.3z"
var NOTCHES_SVG_PATH=exports.NOTCHES_SVG_PATH="M16,181h10.5c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5H16V181z M16,163h10.5 c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5H16V163z M16,127h10.5c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5H16V127z M16,145h10.5 c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5H16V145z M16,109h10.5c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5H16V109z M16,92h10.5 c0.8,0,1.5,0.7,1.5,1.5S27.3,95,26.5,95H16V92z M16,74h10.5c0.8,0,1.5,0.7,1.5,1.5S27.3,77,26.5,77H16V74z M16,56h10.5 c0.8,0,1.5,0.7,1.5,1.5S27.3,59,26.5,59H16V56z M16,38h10.5c0.8,0,1.5,0.7,1.5,1.5S27.3,41,26.5,41H16V38z M16,20h10.5 c0.8,0,1.5,0.7,1.5,1.5S27.3,23,26.5,23H16V20z"
var FILL_BASE64=exports.FILL_BASE64="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAIACAYAAABKEWQ6AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAANNBJREFUeNrtfXuQHeV1p/7Jw3HiEMcJbLIP1Zad3a2tOPIjcZVdW8uCkAAhzQgQwggZgTF4k7gMGxJXdtnasZNdJ/FuyetdZ5Mg3mBJGJhBY+TBQh4jsIWN7LEsMDbICAgvW4/RjCQkzUO9/fvm/lqnz/36dW/fe/veOV/VV7en++u+9/bvd875nfN9fWfBAmvWrFmzZs2aNWvWrFmzZs2atR5qU/0Pnh32gbCPhn1f2IOEvq82BmPPtjvX/aDfHvbxFMCz+njtGkaGLgN+tAnQk/qoEaHawC8M+2ALgNcd77HQ7ni1wO9v0tU3Ehr67c5XA/z1bQRe9/WGQGfBv72D4LPfbkjMX/CNBPPQ7Vs4qIDgCyraTRi2IdUbrzABxi1FbC0BBisMflQnMKRaV+ELuqRbxbAFBBjtIgKMGmLz1/rNC/R4zm+1gQ4QYLwLCTBuyM1f929hoEQCDHQxAQYMwfml/i0baAEB9nUxAfYZgs0TIOjmbggaAazNZwLY5JB5AGtGAGtGAGtGAGtGAGtGAGtGAGu9QYDpm3cEp/bsd31207NRn7l1tzs2fd2IEaDZduyiTZUEf+YLu4I8zRDsMQ8wfeP2YPbJ14K8zRDsEQI4d//C4TqAT/30mHP5MgTMbn8pGmsINtkOnLshOLzkzuDIBfcGR5dtrJS7B8hTa4aTSWMaoBwPcGLF/cGRC78U7D/nlmBi6V3tBT+0bt0QAmY+u9OygHY0WD7BR4dHaBcJ4Mpj7eiU0wCWBrY5BAB4hoGDi28NJs+/OxhfcofzDO0CP8vdGwFa1AA+PABApxdw+0IygBzYX7rgC2N3GeAbAUposHhYP14BPIQggGdvhReY3bL3NPhhkccqgR1sBBwu/9B5t7ttkIGv8AT6psNj+Pbn6qGlI9azIQMwAnSwQfDR7YMEABav+Bvun4Lw+PL7opuO442mjNL6QQSbC+hwe3P5ZhcCADjDgO7UA/AQsH6UjxsRiTr2IwU0AnS4vXDJVx2QzAaSOt0+vILbDvvJvgeKWX9YxZMVPpsNrEA762OTwX9Y90qwYvWe4MMrnwx2L747EoAEH5YPi2eX4aBRAmDbCFARArh+7eHgzDX/GLxr9XPB5gsfijSALBBRHGoCsIzsKyDJ2UYjQJUJoPqfrv5u8MLiucxAkgB/w/WjA3BWEUEOn2eQHsMI0EUEQH/v1a8HG/oedUQgCQA0rBrCEWSAiISn8BWMQBKMp1g0AnQZAdjf9dGDwfWX7w5eu+jLzpqZBrJ2gG2EAZBBA4TxRoAuJwD7OVe/Gnz/0m0RsHD/0tp9oOOVXiOWBTRZATQCdIAA7CvXvRT8n8t2Bnsu2BwVhBASsE1tQEIwXMA76DoAFoEYAbqQADI0PLL8K3MVxNAbwNrRfWIQRMB+OQuIeX8jQBcTgP0/r9kT7D7vnlg6CA/AFBD7IBJBDsz3y2YE6AECuH7NwaD/8meCn/U96IShKxuHhAARuOwMngKgoQpYVhgwBKtCgLCQdNZHXgs+3v9NBzyrh6wjgAQUjTIMNLMWwAhQJQIIT7B16X1R1VBPKGH/0c89XrcgBALRCNALBEABae3Lwb7z7ooRABqA6w0RDma276tfDBp6hqIhwRCsIAEoDAE2QgDXGNIrUCweu/O73uXgRRaJGIIVJQD6+6/5WfDnV/wg2HnRULTaiPUCisLp//EtVxTyeYM82sAQrDABZN9w4XBsfQFXH2U9GYRagXwolNskjSHYJQQ484qXgieWbIytPOK6AxSI4BVOXD7kJYE9G9gDBDjr6v3Bx/sej60zkHMJ8Aauirg6nD+4e3esVmAE6AUChP2ii5+KUkI5TcxSMfbDG3AewT0pLB4Klb8TgEfH7NnALiMACkUvLbnLxX94AS4sIQk4sQRiYAxIkbXu0BDsJgKE/ey1LwbfWjYYhQKuNGYI4NQywEca6VtjYAToYgKwf+PS7VGdwD2XKFYZJ60vNAL0EAHed9WrUXGIS8s4WcTl53meSzQEu5QAyApuWzESezKZdQEWibRQNAL0EgEwZ7DqGVcH4POG3I6yApEmGgF6kABnrftZsGHZw879c55AWnySAJQVREOwmwkQ9r61e70WD/B9D6FwNbIRoEcIgA6rZzrINBBWDi3gW2aO43iFSDQEe4AAO1aNRiJQPnYOQiSlg/AQ6IZgDxAA/S8v3Rn9QgksnNVCnQXIbMFCQA8R4Kyr3gg+vOKJaD1htI6wNj8Aa+dTSVxgAqIYgr1CgI+OR5NF8mFUPoHERSTIFvgLJjhmCPYKAVAX+PDzsYdQ+Stl0AH4G14A3gF/M2U0BHuIAPACEnz9szVuHWFtkojVQkOwlwgQ9s0XPRwBTsvnD1fJ5w24wtgQ7DECXL/6+7F1gwAcrp6aQGoE0wA9SAD0B/q3RWDT8uHy+XQRVxShG4I9SIDfufZQ8L2LR6IniSj8pBcgCQzBHiQA+ifW/jj6BVP5a2VcSQxBiH2GYI8SAP25vi11dQGkhXT/+NsQ7GECXL/8sUj1S1HI1BBhwBDsYQKcuXpv8PT5G2M/RScfKIEwNAR7mABnrX3VPUzCuQFOGXM+wEJArxMAv1562XPR7xTyx6bk08aGYC8ToNY/3feN6DkCLh7h7xYbgvOAAP9+1Z5oFpAFIYpBQ3AeEAA/Yi1/akYKQUNwHhAAi0V+sHRjrB7AV0Owxwjwzz91NPi9B6aCf/3FEzECjJx/fyQE5S+YG4IVJcA7//rN4HfWHw9+64+OFHtk7JGZ4APfnHUd53P/1hoB+O9qjAAVJgCAI4jvGZ7ORQKM+bd3nozOQ/83t5z2AutXPhYrC7MoZAhWkAC/u3EqBiRc+j+98UgM7IX/9VjU4e5/f3Qmdo4mDh4r9/0vI0OwggRAHNeAosO9A1i939dBDH1d/B6xEaBLNEASCfJ23zX/cM0zdauCDMEKZwEQgkkAwxMgNLAj3stjSdfcu/IrMRIYghVPA6Wqh8iDa/eJQikcoSHS/muJZQFdRAAIPAIby+1ThKNM/5LmBlgRNAR7hABZAjBWGg5nCL+5dLMRoIz2m9dMBr9+1WSA11YTIM21JxWAkuYG1i/bagQoo7111UTwS5dOtMwDwJoJLLKCPMUjkCHrfxLgQVIjQAnt7R+ZCH71ijkCwBOgl00C6d6RHiZVAuW4f/kXGWHg8heMAGW0X7l8InjLxYcDvP7cisPBr105UWo4kB6AYQBpn7R2pIAYJ4UgxmQ9R4j5AUOwBA8A0BEKzlgz4YiAXgb4sGoZ24v2LDF406rvGAHKyAJ+vu+w8wJlC0EZ1xvpWVoA/7fQECyBAO+4eo4E8ADwBPAA+LvMIpCs8qFCiMkheAhsw/UnzRHgeNp7GIJNNgpAdBAAOuDMayddL9P6kQFkgYkO8SfnENJqB0aAkkQgXD9SQWwzC8A+eIay1gTI6eCsjrHwCigdZ60lMASbbIj9sPwovQotH0SAZ/iFlYeDX149RwyIxaICEAACyKKrgop0Q7DJBvAlAWD10AHQAAAdIQEkYYrIcdgGOTq9htAQLEEDAGgAz7iPV+4HEbANAsAjkAQIGWkEaFVp2QjQolIw3Dxe4Q1ABgAI8HEcfxNwEAHb8ApJQhEkKSOLMAK0iQAAFoCj09IBMkCEKATY2GY4wDa6DAn0GLgGdUU7vIAh2GQDqOgAkCVhgM99eCXgJAG6dP/wBDiXxGFWUVQ4GgE60ACaBBd/E3QACGABNl4pBnGMYYMun+kkt5tJIY0AbU4DCSpeOSkEgBEepAeQY2nx9Bgkks4WpCBsBSkMwRJCgHTtTAFJAnoE2aWXoIcAyHjFPgKO0EBNgOv6hCPCTDPEMARLJIAkgrR8fcw3DuDK1JDhg2IS+31ZA4jRjFYwBEsSgbLgI4Wetn66fv5NwUgi0PoBKsbhFWGC276U0TxABUSgBlpmAb5QwBlDSQwJJDMBXAOWD0tHSol9WiOAGI2uRDIES/QAEmRs6wyBZNAZA61fpoaoA+A43T5LziAExsnyM8bJWUkjQJsJQNcvvQH2saLHaqFPG0gPwTUFLB5xuRnJAOC55IzEwFiuS2wkFBiCJRAAwGgXTzBpsRr0JMGI63CpOQCSuoKziiCUFIQghS4uGQE6EAJ8go9FH18mAEABJsOFLBKRANQKIBNFIAtFnGdgBVGGBSNAh+oASZqAoUDvo4WzaMRwAGDpOSgGufBUppZaSBoBOkQAX8FHVv5k0Ud6BbruJBKxMsgsgUTxkQ1juEqZk0tcsWwEaCEBCD5nBjU4cjKIQDNF1LUBTQSGB4xnBuHLIigUfeemFYoMwZILQRJAnRb6iKGB12ViX8FIhgtfeOF6A3qPtEfXDMESCkE+l5xUHpbAJ52rdYKvysgwosMJr80VyjiWlh4agi3IArIqg1T2WvlTD+gFJL7ryullGXZkLQKun08rGQFaTACf69dWq925tlyfh9DTzUleI0l3MIOQk0csH2OcIViiB2A5N6kmkAc4xnhdVZTrDPJcA6CTBFyiLjtDhCHYwkKQ9gpJ7txHgCTyJKWcUjhyTQLHkjySHKwyGoIlFoJ85d004KTS5zENWBpRkkILp48ZAkgoppNcfGIeoMUeIK84lPv5gKmcTSzyHjqVREmZy9LlhBHFpiFYIgGSijl5CMHVP1TtMiPAdeVSM319n77Atbh2gM8s8qFVEIFewhBssQdIKgwl5f1JQi8t9vvOlRVDhgCKQZIGBDME2xgCfGAnVQh9zxKkiUTfdaj0ZXVQTk+bBiihvXXtZOp0cB5C6GpeWsUwqXagQxA64r0sFOGVs43UBIZgk+2s/3KsYbEm43reMnJShqEJJ5ejyaeVJKGw3xBssr3z704UBl5PHvGxMp3DN3JNeT6Xl/nWIfD9DcEm2/u/Hv4QU+gFmknVkgBnFpD3enostQGIQA2gRakh2GTjz7j8qztONmSxelIo7eGSIsUg6gpdCNLjDcGSCOB+kStHONDx3We5nFNoNAzoKeO0jMMQLJEA6P/k5mOZ+bo87hOCvvp92Z2exRAsmQDQBGmpYZEaQasJYBqgBQRw/9kj/GWvdgHZLAkMwRYQIK8e8BWEmo37eT2KVQJbTACS4BdXTRRyyVnFn7Sni3yTQVnvawi2kADUBL/9mTcrGwYMwRYTIPo/fqJYVKabz+P+k94PHsIQbBMBpCbg079VyBQMwTYR4D1bp+vW8xddNJL0m0ONzkMYAdpIAJLgX3zuePC2dY17ANMAXUwA9veOzARvWV1smXfeNYZF9YUh2AECcPIoKe3zeQffU8FFwE5asWwIdogAMjPQi0NbVfXzPTlsCHaQADo9lL802uxS87wZhSHYYQIwHBSdQCqjloCwYghWgABJ3qAdRSNDsEIEaGQSqRmy2GxgBQng/j/w3xwvDXhOMmlxyX2GYAUJgP72Pz5SaGWxhYAeI4BcbZx3CriROQNDsKIEkKuLfuNPjpoInK8EkB4BAjGJDI2GAUOwSwjgI8Pbrp2M5hPk7w5mPUksjxmCXUgA2d89OF237CzPT9caAXqEAEkksBAwjwjAtQYQjAgNWIP4i+qXxmxVcI8ToMgcg1yCbgj2MAH0qmSpASAg/9l/f9MI0OsE0JkDyADNwP2G4DwhQFI3BI0A1owA1owA1owA1owA1owA1owA1owA1owA1owA1rqWAKj9//7ojBFgvhJg0cPTwXsfCUnw2IwRoFcJ8L5HZxzISQtE4AXePTTl9Q5/sMMI0PUEgJW/b9tMHfC/t2XO+nFMhgGADtL87gNTwaLhuXMNwS4gwB88Mdd9Vq4BJrCw8veMTMevER4n+DgXBDIEu4AAsGifoIOVA0x5jAQA+ACbGgCEwHgA/+7BKRca8LchWGECADwABkABbF0IGJ6L87R+egBauCNAjRwMCziGcThuBOgCD+CsduQ00CQG3Ldz5+Er3DsBxj4ADOBh6TzPnVPzDtjmWEOwC0KAs2gRzwEe3TgI4DKCbXPKnlauPQCzBhzDeSAMxhiCFSeAi+c1scd47lx9zQMASJABx1zIGJn7m0DjPOclwnPwtyNB7VzzAF2gAUAAijeX2j06l9oBTOoDhgJsY7/rg1ORxYMkGOO8xmCNFMPTRoAqEQBgyzivCz6M8bBwguc8Q00P0BPwFfvwSuD5iuPSCxiCFSEAlT4AluVbZgIEnLGf1uzKvaMzUeyna49IMnJ6Hz2B3G8IVigEODf+aNwTYJugSXBp5QAVHdtyrAsH9AhDU3XXcB5hyAhQKQ8A8GGZrNMzf6f7ptumR2D811avx/s6tYEh2AECAGhd0qVbZolW5upRzj9cDyjzfbp0jqF3qLN6ETqsFNwBAuDGAxhNCKnuAZSbyVMiztX3t8ZdOrUD95EA/Jvkkm4/0gFWB2g/AajadW3fqfah04C5Qs1IXPxJl+7EYi2d4zGSK+Y1RDbgCxWGYAdCAKdsJQkAPiyc07XM42MxfXguPJAsOJ8eAWPp3jXgvvhvBOggAQA0S7hM81jAkQJNirno2MNznoGEocr3WXqebgi2kAAEWs/lU9xxwQbr+NraHbA1a3UWXrN0V8zZNhPLCiK9MOQXi0aANhMAoLu0rlbClRqAVq2neAkoLdqn4GX93+X/w/6KX14SGIItIgCAppCTaZ9T/NtmYrN1HMOiDjqLOgRbp3EUjJwt1CEgrQZgBGijBqA4k8UdqnUu6qQ16zw+D4DOowydPp8rf+T5adcyBFtMAKZ9CAks9UYzeDXLBWDRap0nZr1KXhZ1KBg5+6fzfC730ufLa/J6hmALCeBAH54DmKqdoEfufOi0HiBBCGqaqpdxnoBLMshpYd8cgHmANhGAr3oxhq+8G03sDJ/WAEkTOTLuazL4gLYQ0ME6AOJ/lNcPxadjZamWil5aLlf4+ur60urpBaL1ABlZgC0IaXMhiDGZgEfr+moCMLL42kQN5wKiFTwP+2v6MvWT23oOoI4AtiCkfQSQYLLAo2N0pP6HTy8DJ2FIFhn/WQ30zfT5agcWAjpIALp7LtKAFuAafrnUy6cJkgRhkrjTRDENUAECEETW/bnCV7tzWf/3Aaq7TO3Spn1lxmEEaDMB+NAGweSCDwImBaJ81aIxzfrlXIBc/JklBDHOEGwxATj3z4og1+3H1u55XHfeSqDP+jndHFsEunW6rhhkHqBNBCDoAJpP+spiUFJNIM3y03L8uoxhMB4CrBDUYgK4p3RCqwfQTOlIArf4c9tMHdi+tM1HAp/okzOCkgBeoWgeoA0EqK3T5480cFKIv9oh1f1lo9PB6M9OBdtfnQ0+uGWqoRm9JA/B2oNcbGIEKLkt/nbyLKBb4iWexuXCTwnE3c/PBmx/vXsmtqhDewCt5BPX+6ulYb7YbwQoqd3y8qlEArDix3UB7rGuh+Nr+J7afyoiwE17ZhPTtbx5fTTB5CPQUP21DcEm25HpIPB5gaguX1u8yWf2tTX+6PBpAlyzI7ncKyuGeSZ50nSDEaDEBuCkF4Dw4/p9/hqHb04AfelXpwPZoAGKxvpUHWCVwPYQAF6gf1f8WT7W6uWCUDmrB3CGXjwd/187ETQk9rIsPGuMIVgCAdCGXzsVLfGiq2YmECl/ARysXbabvzuTCGyRVb65dIIRoHwCTIZ4/ruviTX6Q+kVvb/94Wnrf/XYKX89P+eDHmmrfnzH7BdCSmwAL7LiXbVf7hiJz+LpQg2sf1I4AJxX1IqzXL5eE6gfKDUClNTueeG0JX8jTOn4mDctVxd+0AG49Bxa/BUVcsz1054O0s8PcNsQbLJdPxZ35Yz7dOe+EICqH9s9P5ltOKVrRABaFlByA8CycZk3Fb9c5Yt+/iPx8UgFmwJ9ML3Sl+VJDMEmG26i1AGf/vGpaI2/fmQLXaZ+KAK1w+r1bwewf+LzLxsByiCArOeDDIjpOu6DFKj0xVK/XTOFQK1bFjaUbfFJeuKDG48FU/0PGgHKIIBW9ZzUiVYC1Z7ikZ4CcwBpP96UZtEIGyAPvAn0BMOIPC/rcXFYvxGghMZcX+b1AIWAUAxi2xf7i6R8lz46HZs8YgMRvE8OPTydSKo7/nzMCFAWAdBXfX06ltpRnDE90+KvSJwH8JJguuFY0spg+cQQPyvc/8HLho0AZYUATr3KMHDDd2ai2T8Q4G+eno25/zTAEVLg4uFJJqf8oENAQnt8cudMag1B/uYAj9H6jQAlNP7Wj57c2fKPp6IUUBZ+GCJ8rh9hQdYIfA064prHG0sdP3TfmzHwjQAleQDO8H3yyXiF70Oh9cFCteXKpV/OJYd/QzgmWTu9BsVl3pXC8neDIfro9o0AJTbEZxl/9dyAFG0En24e1i7H+1y8vH4R0RhbMBpuP3TzrjrwjQAlNFgtgP7QV6brZvm0RVP5A3y5Ekg2nKPjerMdnuCltSNGgFY0CRwsVuqAurg/NBfnfeBj30Mvz+ZeFVSkVHzNP7zhBd8IUCIBshoI4AMepGl06XceHfB//9vTieAbAUpocPlp4i2tsYCTd7VvEaKg9PzAnzyVCr4RoMRSMHQAyJAU23Uq18wikDwC8ME/ywbfCFBGJbBWYkWKlqTok8QeCFN2zEf/4meezgW+EaCEhhm+IsC3mghL75zIDb4RoI0ikErfN5kjNQHyfv2DEXk7avxPX/2oEaBTBPh/P56NVf7gGaQmYNyHtaeJR5wnJ3jy9Es2HCgMvhGgJALAqlnkgRaQqZ8sDOlJIIrHpBDi6v47pr3pHSt96/72daf2fWVeI0Abml7TJwtBAB8uPWnqVmYAmEdIKiKRDF9//ZS7Hlz9Z//yx8GLV440BLoRoOQ0UHYZ42m9GtjY/IF6GpjhIU00HvrUjqaBNwKUnAb6HvaUtX/p5qMC0FDys/9Jq39cOzoVTN+8wwhQNQ8gAePjXuxSHHLFUNqvedc9SvbU8ToenNqzv2kiGIIlEUDP+/tW6ugVQ3mrf8jtofBnvrDL6xCaIYEhWBIBpPX7VvzAvUstwEkg+c8e0KnqkwCbvnF7MPvkazECgBhGgA4SQCv9pKd9pJeQD4V8cHNxVT993Ugwu+nZYObW3RYCOk0AadlJCz7hES742nRdNoB1es9ct700VW8EaHP74IPHU2O/7jIbgBd4+o8f6xj4RoAS2l89cThR+X/qr54LPvcftwfrP7XLLcpEfP/ifW/ECDO7/SUjQDe3yRP1v/OHDiE3sfSu4NhFm4ITK+6P3XTEbdmMAF0+F8DizNSaYZeuoZ/seyA4uPjW4MiFX/LeeCNAjxFApmJvLt8cHDrv9mDy/LtjBDhywb3BgXM3BIeX3BknwJphI0A3E2DmB284dz++5A4HMPr+c25xRJA3G4Q4umyjG4sqXhl5vBGgAgR4887vOfABOiwfHe4fNxiAwwvA+gE8XkGMEw/+MFbSNQJ0MQFO3L3bgQ4CoMMDQPzR6kEAegSS49CazfEw8PnvON0AwmjPga6FpBGgQgQ4fONXIvAduDWQCSReYf0MASSDDAPuOtcNunNBBJyHbYzDedg2AlSwnTpy0lm89AByG9YPACn+cAzhAiCf/OS2AOdHoSDcnvrYV2OiEefjHJxrBKhgm370hUj4EWRuwwvA8gGgHCNd/MT1QzESTPynh91xEISZBP6G56BnkGFB7zMCtLkduWnEWTqAB9jcJgGgBejC0Y8vvy8GACz8+CdGXDiY3bLXAYrz0eEppDeQf/M9fHrBCNDGBlAANF6ZCbDzGIGHxbIzQ8A4EIcWjXPoNbgf51JcgiAgDY4leQCMx7WNAG1ouNkAGeDASn06gDEcx2WKiH0O0FqBiF4C3cX/sFNEuqpi+DfOIRmw7VLKGqE4Hh5HagbpJUAM6YUMwSabA75mkSwAMRtApycgWLR6vNJrMHTwfABIrwJwmUaykwS8FgAF+NQLDD18P0e+8Br0MJIQhmCTTQIudQAtnZkAYzq9hAwXBJSegtuaVLIDbFdjEF5BZg2sOUhxCm+jK5SGYJONKR7AplVLYEkCWirHMETQWnkNGTrkub7OMEHy4Rq4vqs+1kQjtnFNWD/enx7HCFBSk0DixtJ1yzgtQZNWKYHE3/QeIJUPcN/1NNmoRQA2rZ4d+/AeUjgagiVkAQSTqp+Wq7dJFgpCWKesGNJaeU15viSB9g5ymyVoWLx09RR+eG+ZIRiCTTYZswmYVOq0Sm2x2A+QmMtTSErrl+FAnyuvyW0SC9fltVhrYAiiIDUClCwC2enGCRL+plrXNQLsZzjgOIAlPYpPCyQJw4gEtfIzK4kkE/UKvAS9jyHYZPvMpTvrCADgCEBaLOcrBRo9CK+RN/77NEbS+zlvU/MS+NsQbLKd9bHJYGT5cOTuqb59oPsAoydIcuu+OJ82jn/L/cw6pNehlzAESyDAuz56MNi67KFU15yU0tFL4FxYZZ4UUAtBXoNZCPUIrZ5xX2ch2DYESyAA+4q1P3FE0GD5rFKCSCDlTGKSF8EYxnVegwRgFqIri7LYJF8xzhAskQDsN122K5fr18QgAbLifFJmwUpg2nuzUshXQ7AFBEA/+yMvB7uXfCnR7UurzxMukogh90vVn1QnYKjgeYZgiwhAbbB5+dY6N8zyrQZVxmcNGucSfJ4kycMk1RNIAGQehmALCcC+/Mq9Xm2Q5eqzus97UD9IQajHcO7B0sA2EYD9+st3By8svsMLipwgaqZnEYuik2mhIdhGAjAs3H7xaMx6s2b98nZNIjkppd+Haw4MwTYTgP3PVn+vjgBFiCBXHyWJyKxaghGggwSgN0BYoD4oogvyVACT0kZ6CUsDO0wAn1jc0Pdornq/b1/eOoLshmCFCMD+3qtfr8safJW/pDmBPCRgKmgIVpAA7Fdc8azLGvKKxaLWbwSoOAGkTkBVEV5h/crHXKk5qcpI686bUhqCFSdAVl0B6xFkR+Xx8Qu+nAk8CWUIdjEB8mgJXzUSRIFnwX5DsIcJkBRS5N+G4DwjgO6GoBHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHAmhHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwARgAjgBHACGAEMAIYAYwATfRfv8oIUGkCnHntZPBrV0607PpvufiwEaCqBPiFlYcd+G9d5ScA9v/K5c2R45dXTxgBqkqAM9bMAfxLl044T6BdNwiAMb5zf/OayeAdVydfG8dh/UaAChMgzfoBPIiRZtlJ56KDHLj+z62wEFA5AgBcgAeAf/WKCa9wg/VKgOEhOB7gpoUHWv/P9x124w3BCnqAt39kjgAAi+4fVg2LRdfWT9BJDFi3PB+kAti4BrYBPsZZCKgoAejCASTIIEMCxSHABZh4xXi5D+do4tDqcZzbFgIqQgAABgABGkAGMIzz2I9O0EAAnAMXjzH4myGDoOJ6FIIgAPYjdOA62JbexBCsiAegWwZoBBKgAniCBVDhymVWAALQE2AsOtNEnINrkTj4W4KP/YZghwkA4CRIABAg4xV/04LxN8YydvNcHpfhAQQhwNiHDo+B8VT/5gEqQgC4awkg4zVe8bf0BvAOcOXYz/OwX57HTIGhQYLNMEByGAE6TADGaQABq4U1A1CCTyIAOLwCUADPV3gKeg+ci2shHDArkOKP2oEZAa9tCHaQADJ1A0AABgRgqsYwAAJgP8aBNBSA+Bvn4G/tSWjhtHZel8TA6wcuecUI0E4C0DKltevaP104QEUnWPQIOJfFIOyTSp+hgmkk9+EV1yIx8Lpw7cHgwMotRoB2ewAAx7RPVvsINv+mAATYGC+tmdfBNZgK4nwZDmSuz5Ai9cCu/q8FU/0PGgHaTQAARZBhzdimKwdwcPFMCxmvCSz1AS0c1g+gMQ7XkoBzHK2eHoBEAPhGgA4QAIBSpRMM6aoZpxkO6MrlBA7Pk7k96we8FoHn3zIkvHPFG0aAVhGAFuxb3EEVLq1Uqn2WdPE3RZuv0kdASRq8Jzo1gPQAzARwXXqT9X1PGQHKJgDjOufZ9Uoepm8ETgMq0zxOBslMgGMZ26n4OUZWDOkZ4Pal5b9jxYHgtr6dEfhGgBIa3DlVPW48VThuupzIwT5aoC7JyuKPLAGTTARRhwy9TfDxfniFV+Bn0pZvBGiyhTf7jPDGDsDKCDDBkGkcbr4sw3I8UzuCI6t5JANecS2Z4rEeQK/AsSAXCcBjrBKyVvB8/9Y6AoR9IOxnGKL5Xf4ZYR8486OT41K8yfhLL0BQWKhhPJfqHq+6BCytm/UCAqktnuPoLVhM4vvQM0nh5+njRoQc7TeumbwhBH+cQo+5uwRCWiU6lTundwmOVOeyGijzdRIKCp8k0CSRnWP4GUiY9/e/Enzvkm1pBJBEuMGQrrf6RW/78MQYq3As0mgC6MkXCTzzfe4nOMwOZHzHteWMHt25z/p9nUTBeFj+/v4tecCXfSzsiwz5OfAH5Ho9Vtl8ipvpm5yKlWmZJIw8Tm3A82XRR4YKvm8SEWRIolc5t//FouDH9MG8BT684QtD0J3VAyhaPyddpIXrmJ2k0HXxhuVbOUPHmb+k87K6LgYtuaQpAtAbLJxX4L/1sol1ocsfZwGHs3MUcgwBdLXY1mmdDgkSGILDYg/TNRJDWroGPi0M+NLDi/ueb5YA1Abr5gX4IRjrKaAAuFycATFGNS4JoLVAnhgtl3vx4Q/puvOA6+syDMlJn5L6+l5P7wYZ7ync6OLpqlnu5eRKHpfsA4kTObR4ru1nhc9HmqQUMOl9B/rGygSffbDn0kWAH960MVnHl3k0H7SQKRzFmSy8FPECsmbA+J9l+Vm6QP6dkfeXoQt6gwSo6IUAjLGCJyd1mJvLpVpJK3Zl4ScNQDmTJ+cFigg/OQ+QRI7t/aOtJEBvkACWHwI3RgBAAFo2LZNW7rvZGjg5hqIwj2eQEz1ZYSWPRyhJ+PU2CWoxf4xuncKPhZ6k2KuXVWsAfNmAjP26fJwXZFYRs8iEGb8GCj/ziwQEn49O0Z3z4Qou1/KlYnkALCIOfWMl0Gnj9OcA+A/0Pd5O8LuTBG+7fGJQrphhl0UduX5e3mS5Dr+d3ScQpQa5uu/Zdlt+XXbQFeCHIK/nsmpW4uSN1IBnxf1mepHqXlLFD5/98yuf6iTw3VMnCG/cOqpv/v6OnGyREzJ6Va0GQRIlizRFe9qMn36f6y/7UVXAZ19XVfAXhn1cPyzJm8rZuqS0rRkLzgNk0rxBGrHet+KVqoHPsvHCKhJgTN9c36pcX+z15fdpsbmodadV89KqfyWXeUsVhVUDf8B3Q2XKphdj8KEMDXCjrr7IeVmW30G1331TyeENW6SnYdMsk9U/LuTIE5fL7mngn9P3YtLavir2RZVz/Tq31k/RavebZbmN6IA88V8fA/BtKO/2VigIb9wNWSVb35O0zAr0A5ZF5+aTFnsWJQhy/C4DXvYbOgU+ZvjGfY9SaQuXBSA5S5e2Dq/s1C+pY0FnOwE7tHo4GPj7fcEHvjkb/M8vPFdWVnBGx4Sfb6GkBjsJSP6smi4UZZ3XaCFIXg8pnn6Kp9V9+5/uDM79+gkHPjv2dZ0glNafZLFyWbZe2ycfzuB6gKRqoO9pnWbJ0W7g0R+6eVcMeHYQ4tuf2NFdXkBbf5oFJq2+kcu1iij1rMmbKoL/zHXb60DXnuCmO15x4aHyXoDWn1Tc0eXbtHl+vcI2j5hrxPJ5ThUsH8CDEHD92ht8fNNPq+8F8lp/Uhzmk736uF4BlLdokyddRLzvRIpHsafB5/GXrxpxoMsx9/7F7mp7gfCG7kuyft8aOh8wcp9+9Dop1Stq7cjrO1nN0+D3bT0SA192uH9Jkr//3A8bfd99rQa/X7tt6cq5lLsoYGWle7B05PSdLuggvZPgXzl4KDW+4xgIkpcwGb2/lQQYzJqgKbIUy/d4V5E4DyvHM/lVq+Bpt59H3AFsLQwb1ASDrRR/DS3Rlq686EMeSaHD92MMVenamhEOss6B29eisIlC0RmtIMC6olbfSKrmHuoIZ+P07BwewoCld0O9HuIObr8ICaT1Y7tJMbiuZe7ft+Cj7NIs195hVq4LJ2iiuC7FXRoJALYEHwSq3PrBNOFWhAzaWwBwxHL0Ciy8bHk2IBU+gC/qKfL2ssE/u5E8HGADVKRjn+4fc278hr49DuxO1OI71bUnQHHIF/PRS7B+9rNLI0AI7kBagSZJA1x7yY/mBcB5woG2dN1BkhLmBFpTFArBHPURAOKMahyxGtuwcvT5Yt1FhKFO85jvl2j1so+2JP4DdLhwgNxFS6cqmx2UNB3cOh3ANX94HNqsupxwwPp/WYKvpWsGv92/rb9bUzHrJZSFaz9waDezO/tAGQQYtBvZtX2wDAKM2o3s2j5aBgH22Y3s2r6vDALYjezibgQwAhgBjABGACOAEcAIYAQwAhgBjABGACOAEcAIUEkCzHx2ZzC76dlg+sbtDV9j+rqRYPrmHQZ+iQRoWyk4ODoVuBa+AsjCBLp1d8A2u2WvEaCkUvBo2wkQtlN79uc/d81wMPvka4Fs+NsIUM5k0GA7Q0AMxO0vOXCzzgNZZDv102NNhRGbDu7gghCAXgRM6fYjy18zbOCXuCCkv60fOgRPW7TTBB4SQOzVeQwDvfQlYYs68eGRDWhPIC0bIi/t+Hzth5fcGRxdtrHcH5Ls1JeB1fvc+6kXDufyEPOtn+x7IBhfckfw5vLNbru05wI6uSxMx3iZKTjLD8nQSMrYq/3g4luD/efcUu6DIZ1eGayFoeX6/g7LB/gTS+8q99EwPGjY6S9XZ/kJMf/48vuc+5tv4AN0xH6EgCMXfgmv5T0c2k4dcOSCe12XcW1m4zNeDwD3L0lw7KJNzgKECJo3sf/AuRvc94YIhBGU/vsA7SoI4cvgS0QVvp2vxt3+60fqNUBNAPLL+zzAiRX3OyvB8V4kAcA/dN7tzgCOLds42AoCrGtFzJo8/26vO5u4fqjO7c/+ZDw4sCIkx7176oThyU9uc1YgvQeBp3fADUoKD9jPsd0QQvB9cP/4meH6AT6+Y3gP1rWCAGeU/SXw4d0HDmOWBmP6Wy/HMD75xIvB5CWb3FicN/OFXXFPcORkcHTVl91N4XVALpCCqRGsH9tJoYchxEfKKqp9GAq9Jd0/vm/4HVrzi6FlhwEASZeMV3wJfCmkdbJN/++53yAAWQAkrbyOBEoT4FoAFYDiHLxKgmjxiDG4ibSqqos+dOnx8B0OnXdb6/6/YJllYdxkegB+IQCEfbIKCLUP0AAk2I1xsGJ4CXiD4//rW3Vh4thl90fWgU5gfW4fpGN4oEaQ4SDyEOF7YVw7hV0aEXEM9wPfC58dHduh9bfuhyLRwjfal1dlO0UPkDzCCy4MgOMYtnmTTw7GS8DTG77vvhgLHPiidH9078fvGoudM7P3oNMKIA6Oc5zWH+i8gVIg0ltIgYVxSaGhFcTgZ8O1SQStbxj3cT/wHcPe2p+KRQs/2ABuGG4Kbgg+hHTlksGMp3glABiLY/iCTrSFoNcKF/Vz+m8cdUASRIzDtWR37h264JHnY+dObfvJnPWHxzCOrh/vz88tr4PPRPGH98FNxdiaVUVk5ffEWHoLagwtPOmWm1H2IAC/P70lj9XifeTlwu3W/1h0TQyOk/l0x7hBUmnTUp2rDj8cbiotkrVqGf/RY5a/94ADn7EO1yIYZD1fccMdEUeeO02A778WO09WyiiWmDbh89EjUDxiP8bQujAW+/md+F2ddqgJU6pykgXjOL4ZAvDzMAxhvySvM8YL7hlvmfhLKw0TRN5sdpYkcfNwY/Ahsd+nwp2YCb/c9O7Xo2ldnksCEHwCQoAITqQN7vmBA3/8Yw9GABIMAk4S8Jp0t1JrYCyvj+uSNPR8FIs1y4uuwWtSgPL7MgvxeQmKW1+cZ6jEe7OWgW2SgmExPNa+fxsDL3BixZfHtYomKHS79AK8ebgZ6DqW8obTymRcJtg8l3/zvWjBFET0OLwerY+fj5aEY7gew4okrnwPjOG1cA1+NoYFAk0tw88p35MZhvzeUh9hvNYROMaMh5+FJGe2RIIeXnrn+FS7/3FU+CEGyFInxMQNJtjyRpIQBBhfmPEfnRYnLb1W1Ih9WWn9dIUEDjeMYFFrEBh9XflePCcicI1Q8jvIV34PEgTXpKsmuFI/MPTRY0hP6fbVDEZ6CIYWeh+cJ7WA0kLt/adR9ALhB3JeQFuNr9Ny8KUIGFMZCinGVX5B6e5Z+ZKqnjeRN4XWSndM10kQsM33kJ9Lk5WxnkTg55Xfk/tAQqazJBrzc5KcNQ7GcH5+hj5+HmZXeMU5NC75PbT7D3v7Yr9u4RvfQKuUN0l2fnACI10tvygtnRbFV2nxFGo8Jm+KHE+ljPG0ft40EoAg6M9KAhEgfm5JEBkC+F1wPe4nONQU9I7SsqUu0JkSu/SsuD5TX889vmFBJ1v4Acb0h+JNY9ySN5ezfRxHgcdqnYx5UvHDUjhG1gWkNfJ9MIaWyfAhXTyB4TX5WaW38ZGYn1kfI1j0SnTbMkQwE8FYmXYypebn4f2SGU8U62v7hDfo/H8RP7Zs0yL5IZNCQNIxgiPjsb4WxQ/20WPIMfzbVyPQHoWqmq5aulMSSd78rO/GEKIJS6LwfSgWSXIKQ53NyIyGZOb1letHX7SgCi38kANp8V/fHC2opGDCcYo7yXzGWILJzEKmSbo+IMWT/AywNF5TTkEnEdQHvtxHEScFsAxVJKn8XvIz6ffQRS9pHB0VfmkN7igL/CRXKmaxYt5Aj2MspICSx2gx8r1IDIYMrphlesUClkdVJ3opGS5kncCXnmptpImo9YUcl6apKuH6PVpgYU2R1sXlrHBAfaC/OFMySQBaBuO4fK+0EMSaAN0wRZoknyactkwSSe5nBdR3jgacWkffC32vkvSNUP0LF1SxhR9sXZ4wwBtEC5TxWoMh1beM47RoOUZ6EX3j6eZl+GDBSJ6XdPN1oUhmLlKc+TIT6fZlmuv7rDlS6nULqtzCm7Tel674vpT88rrWLyttPh0hFX+aEGSMljUDZgJpny0p/5evnPCSYGuPIi1eW3+S7kjRT+sXdEPDogQp9vKQQVbgJDmo2KVLlVPBacDLOCuFmfQkSZao9UTStbVOkASlvuD51C2y/JxVPKPADD/P4IJuaahMHVx825icTUtyd3lUd1KhSbtsHzgUb3oKmNlDHssjiL4MRopY7SWY/vH9ODuos6E0ItSOjXWs2tcMCXxFIp9aTrIqHwH08TwC0JdmZYWNrM+bpu4lQeRnl/ol631FDaT7wNckyBMKksICrcjnFXRlLEmw6QITAePETB4PULTAlXZdWZXMuG73gp/kCdJUtrZKn2Xp1C9Pl+mlFJVFrpHmdbIKRfJzcN4ghxcYa/sUb7vDgb5Zcn5eu0xWCPO6Tl059AEj6wpl9rTPmEd3hJ+9+y3fR4ID5946mNfdylgpa+a+2O4LAVnWq/PxogDrDCAvAbLGIoPqOfAVEdYXnSwq2xKzrL6IMMwz51HgGusXzIdWqxiON+Nms9Yf5B1TpKdZfRGgpfepvY63fD1/RecOxpqNqUkTTXIWsewYn6emkTdzQL2ksrX9NhFhoGhJNC9pfFlEVXrNOw0ssOZIsCivN2gkRFSQCGOVWcxRMSLc0Ig2aGQlkm8evhGdUbCPd3wNX5fUDAaaEYlJ8bcocFmTTAWBH+jp9K5VRAhBKEyEPNbdyhTQgG+NR9iXBogsz2aVZrVrLzptnQP4fQZ8a8jQH/bBomsOm6n7F+yD8y6f76BXWEcyFCkFN1q5S/EAg7XPYtbeQUKcXXO5o3kBbELJj9be62y789WuK/TXgBo8tPi2Ufx6RgGQ99WAHqxdo9/ydmvWrFmzZs2aNWvWrFmzZs1at7f/D9GUHGYEXl1VAAAAAElFTkSuQmCC"
var FILL_MIN_FILL=exports.FILL_MIN_FILL=.218
var FILL_MAX_FILL=exports.FILL_MAX_FILL=.918

});
; KAdefine.updatePathToPackageMap({"javascript/apollo-package/apollo-wrapper.jsx": "apollo.js", "javascript/components/modal-package/video-modal.jsx": "modal.js"});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/donate-package.js.map 