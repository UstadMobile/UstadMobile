;
! function() {
  var options = {};
  function init(_options) {
    options = _options || {};
    load();
  }

  function load() {
    requirejs([
        'common/views/login.popup.view',
      ],
      function(signin) {
        $.cookie = Cookies.get;
        var hostname = window.location.hostname;
        if(-1 != hostname.indexOf("simtest")){
          hostname = "gamma.ck12.org";
        } else if(-1 !== hostname.indexOf("interactives")){
          hostname = "www.ck12.org";
        }
        requirejs([
            'vendor/foundation/js/foundation.min',
            'common/utils/globals'
          ],
          function() {
            signin.showLoginDialogue({
              'returnTo': encodeURIComponent(window.location.href),
              hostname: hostname
            });
            handleAction();
            if(!options.dontOnboard){
              Wait.hide();
            }
          }
        );
      }
    );
  }

  function handleAction() {
    // TODO investigate why isn't foundation reveal close isn't working
    $('.close-reveal-modal').off('click.close').on('click.close', close);
  }

  function close() {
    $('.user-login').removeClass('disabled');
    $('.main-container').removeClass('no-overflow');
    $('#sign-in-modal').foundation('reveal', 'close');
    /*displaying the onboarding modal*/
    if(!options.dontOnboard){
      $("#onboarding").removeClass("hide");
    }
    // onboarding.init();
  }

  window.signIn = {
    'init': init
  };

}
();