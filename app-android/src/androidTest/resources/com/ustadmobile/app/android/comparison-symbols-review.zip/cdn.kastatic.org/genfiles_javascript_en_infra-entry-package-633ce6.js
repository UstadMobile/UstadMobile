KAdefine("javascript/page-template-package/infra-entry.js", function(require, module, exports) {
var tplParams=window["./javascript/page-template-package/infra-entry.js"]
require("../shared-package/site-infra.js").init(tplParams.miniProfilerRequestId)

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/infra-entry-package.js.map 