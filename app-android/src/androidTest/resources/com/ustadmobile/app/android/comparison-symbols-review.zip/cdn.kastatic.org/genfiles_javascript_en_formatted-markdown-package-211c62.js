KAdefine("javascript/components/formatted-markdown-package/format-content.js", function(require, module, exports) {
var _staticUrl=require("../../shared-package/static-url.js")
var _staticUrl2=babelHelpers.interopRequireDefault(_staticUrl)
var i18n=require("../../shared-package/i18n.js")
var escape={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;","=":"&#x3D;"}
var escapeCharacter=function e(r){return escape[r]}
var possible=/[&<>"'`=]/
var badChars=/[&<>"'`=]/g
var escapeExpression=function e(r){if(typeof r!=="string"){if(r&&r.toHTML){return r.toHTML()}else if(r==null){return""}else if(!r){return r+""}r=""+r}if(!possible.test(r)){return r}return r.replace(badChars,escapeCharacter)}
var autolink=function e(r,a){var t=/\b(?:(?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>&]+|&amp;|\((?:[^\s()<>]|(?:\([^\s()<>]+\)))*\))+(?:\((?:[^\s()<>]|(?:\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’&]))/gi
return r.replace(t,function(e){if(!/^https?:\/\//.test(e)){e="http://"+e}var r=a?'rel="nofollow"':""
return'<a  href="'+e+'" '+r+">"+e+"</a>"})}
var formatTimestamp_=function e(r,a,t){var s="<img src="+(0,_staticUrl2.default)("/images/play.png")+' class=\'youTubePlayIcon\' aria-hidden="true" alt="" />'
var n=60*parseInt(a,10)+parseInt(t,10)
var i=i18n._("Click to jump to %(timestamp)s in video",{timestamp:r})
var o=r+" "+i
return"<div class='youTubeLink' data-seconds='"+n+"' tabindex='0' role='link' aria-label='"+o+"'>"+s+" "+r+"</div>"}
var formatContent=function e(r,a){var t=escapeExpression(r)
var s=/[\n]/g
t=t.replace(s,"<br>")
t=t.replace(/(\W|^)_(\S.*?\S)_(\W|$)/g,function(e,r,a,t){return r+"<em>"+a+"</em>"+t})
t=t.replace(/(\W|^)\*(\b.*?\b)\*(\W|$)/g,function(e,r,a,t){return r+"<strong>"+a+"</strong>"+t})
t=t.replace(/&#x60;&#x60;&#x60;(.*?)&#x60;&#x60;&#x60;/gm,function(e,r){r=r.replace(/^\s*(<br>)+/,"")
r=r.replace(/(<br>)+\s*$/,"")
return"<pre><code class='discussion-code-format discussion-code-block'>"+r+"</code></pre>"})
t=t.replace(/&#x60;(.*?)&#x60;/g,function(e,r){return"<code class='discussion-code-format discussion-code-inline'>"+r+"</code>"})
t=autolink(t,a)
var n=/(\d{1,3}):([0-5]\d)/g
t=t.replace(n,formatTimestamp_)
return t}
module.exports={formatContent:formatContent}

});
KAdefine("javascript/components/formatted-markdown-package/formatted-markdown.jsx", function(require, module, exports) {
Object.defineProperty(exports,"__esModule",{value:true})
var _react=require("react")
var React=babelHelpers.interopRequireWildcard(_react)
var _formatContent=require("./format-content.js")
var FormattedMarkdown=function(e){babelHelpers.inherits(t,e)
function t(){babelHelpers.classCallCheck(this,t)
return babelHelpers.possibleConstructorReturn(this,e.apply(this,arguments))}t.prototype.render=function e(){var t=(0,_formatContent.formatContent)(this.props.string,true)
return React.createElement("span",{dangerouslySetInnerHTML:{__html:t}})}
return t}(React.Component)
exports.default=FormattedMarkdown

});

//# sourceMappingURL=/genfiles/compressed_js_packages_prod/en/formatted-markdown-package.js.map 